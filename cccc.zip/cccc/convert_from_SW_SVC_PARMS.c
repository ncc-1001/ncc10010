#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void convert_from_SW_SVC_PARMS(uint *param_1,uintptr_t *param_2,uint param_3)



{

  byte bVar1;

  uint32_t uVar2;

  uint uVar3;

  uint32_t uVar4;

  ushort uVar5;

  

  *param_2 = *(uintptr_t *)param_1;

  uVar3 = *param_1;

  param_2[1] = (byte)(uVar3 >> 0x10) & 0xc0 | (byte)(uVar3 >> 10) & 0x20 |

               (byte)(uVar3 >> 10) & 0x10 | (byte)(uVar3 >> 4) & 8 | (byte)(uVar3 >> 4) & 6 |

               (byte)(uVar3 >> 4) & 1;

  param_2[2] = param_2[2] & 0x3f | ((int)param_1[1] < 0) << 7 | (byte)(param_1[1] >> 9) & 0x40;

  insert_bits(param_2,0x12,0,param_1[1] >> 1 & 0x3fff,0xe);

  uVar3 = param_3 & 3;

  param_2[0x10] = param_2[0x10] & 0xf7 | ((int)param_1[8] < 0) << 3;

  if (uVar3 == 0) {

    if ((*param_1 & 0x8000) == 0) {

      uVar3 = param_3 & 3 | 2;

    }

    else {

      uVar3 = param_3 & 3 | 1;

    }

  }

  if (uVar3 == 1) {

    param_2[4] = param_2[4] & 0x3f | ((int)param_1[2] < 0) << 7 | (byte)(param_1[2] >> 0x18) & 0x40;

    param_2[0xc] = param_2[0xc] & 0xcf | (byte)(param_1[6] >> 10) & 0x20 |

                   (byte)(param_1[6] >> 10) & 0x10;

    insert_bits(param_2,0x66,0,param_1[7] >> 0xc,0x14);

    param_2[4] = param_2[4] & 0xf0 | (byte)(param_1[2] >> 0xc) & 0xc | (byte)(param_1[3] >> 0x1e);

    insert_bits(param_2,0x28,0,param_1[3] >> 1 & 0x7fff,0xf);

    param_2[6] = param_2[6] & 0xfe | (byte)(param_1[4] >> 0x1f);

    param_2[7] = param_2[7] & 0x3f | (byte)(param_1[4] >> 0x17) & 0x80 |

                 (byte)(param_1[4] >> 0x17) & 0x40;

    insert_bits(param_2,0x3a,0,*(uint16_t *)((int)param_1 + 0x12),0x10);

    param_2[9] = param_2[9] & 0xcf | (byte)((param_1[5] >> 0x1e) << 4);

    insert_bits(param_2,0x4c,0,param_1[5] >> 0x19 & 0x1f,5);

    uVar3 = param_3 & 0xc;

    param_2[10] = param_2[10] & 0xbf | (byte)(param_1[5] >> 9) & 0x40;

    if (uVar3 == 0) {

      if ((param_1[5] & 0x8000) == 0) {

        uVar3 = param_3 & 0xc | 8;

      }

      else {

        uVar3 = param_3 & 0xc | 4;

      }

    }

    if (uVar3 == 4) {

      uVar5 = *(ushort *)(param_1 + 6);

      uVar2 = 0x52;

      uVar4 = 0x10;

    }

    else {

      if (uVar3 != 8) {

        uVar2 = 0x9c7b014;

        uVar4 = 0xbacf;

        goto LAB_02c88d68;

      }

      param_2[10] = param_2[10] & 0xdf | ((int)param_1[6] < 0) << 5;

      uVar2 = 0x53;

      uVar5 = *(ushort *)(param_1 + 6) & 0x7fff;

      uVar4 = 0xf;

    }

    insert_bits(param_2,uVar2,0,uVar5,uVar4);

    uVar3 = param_3 & 0xc0;

    goto LAB_02c88d74;

  }

  uVar4 = 0xbb09;

  if (uVar3 == 2) {

    convert_from_LAG_DEST_PORT_AND_IDX(param_1 + 2,param_2 + 4,0);

    uVar3 = param_3 & 0xc;

    if (uVar3 == 0) {

      if ((*param_1 & 0x4000) == 0) {

        uVar3 = param_3 & 0xc | 8;

      }

      else {

        uVar3 = param_3 & 0xc | 4;

      }

    }

    if (uVar3 != 4) {

      if (uVar3 == 8) {

        param_2[6] = param_2[6] & 0x7f | (byte)(param_1[2] >> 8) & 0x80;

        insert_bits(param_2,0x31,0,param_1[2] & 0x7fff,0xf);

        convert_from_IP_ADDRESS((uintptr_t *)((int)param_1 + 0x12),param_2 + 0xc,0);

        uVar3 = param_3 & 0x30;

        bVar1 = (byte)(param_1[5] >> 8);

        param_2[0x10] = param_2[0x10] & 0x1f | bVar1 & 0x80 | bVar1 & 0x40 | bVar1 & 0x20;

        if (uVar3 == 0) {

          if ((param_1[5] & 0x2000) == 0) {

            if ((param_1[5] & 0x8000) == 0) {

              param_3 = param_3 | 0x30;

            }

            else {

              param_3 = param_3 | 0x20;

            }

          }

          else {

            param_3 = param_3 | 0x10;

          }

          uVar3 = param_3 & 0x30;

        }

        if (uVar3 == 0x20) {

          convert_from_IP_ADDRESS(param_1 + 3,param_2 + 8,0);

          uVar3 = param_3 & 0xc0;

          goto LAB_02c88d74;

        }

        if (uVar3 < 0x21) {

          if (uVar3 == 0x10) {

            param_2[8] = (char)((ushort)*(uint16_t *)(param_1 + 3) >> 8);

            param_2[9] = (char)*(uint16_t *)(param_1 + 3);

            goto LAB_02c88d70;

          }

        }

        else if (uVar3 == 0x30) {

          param_2[8] = param_2[8] & 0x7f | ((int)param_1[3] < 0) << 7;

          insert_bits(param_2,0x41,0,param_1[3] >> 1 & 0x7fff,0xf);

          insert_bits(param_2,0x50,0,param_1[4] >> 0x11,0xf);

          uVar3 = param_3 & 0xc0;

          goto LAB_02c88d74;

        }

        uVar2 = 0x9c7b088;

        uVar4 = 0xbb01;

      }

      else {

        uVar2 = 0x9c7b058;

        uVar4 = 0xbb05;

      }

      goto LAB_02c88d68;

    }

    param_2[6] = (char)((ushort)*(uint16_t *)((int)param_1 + 10) >> 8);

    param_2[7] = (char)*(uint16_t *)((int)param_1 + 10);

    convert_from_L2TP_TUNNEL_AND_SESSION(param_1 + 3,param_2 + 8,0);

    param_2[0xc] = param_2[0xc] & 0x3f | *(byte *)(param_1 + 4) & 0xc0;

    insert_bits(param_2,0x62,0,param_1[4] >> 0x12 & 0xfff,0xc);

    insert_bits(param_2,0x6e,0,param_1[4] >> 0xd & 7,3);

    param_2[0xe] = param_2[0xe] & 0x9f | (byte)(param_1[4] >> 6) & 0x40 |

                   (byte)(param_1[4] >> 2) & 0x20;

  }

  else {

    uVar2 = 0x9c7a570;

LAB_02c88d68:

    timosAssert(0x9c74c64,0x9c748e4,uVar4,0x9c7b0c0,uVar2);

  }

LAB_02c88d70:

  uVar3 = param_3 & 0xc0;

LAB_02c88d74:

  if (uVar3 == 0) {

    uVar3 = param_3 & 0xc0 | 0x40;

  }

  if (uVar3 == 0x40) {

    uVar3 = param_3 & 0x300;

    param_2[0x10] = param_2[0x10] & 0xfb | (byte)(param_1[8] >> 0x15) & 4;

    if (uVar3 == 0) {

      if ((param_1[8] & 0x800000) == 0) {

        uVar3 = param_3 & 0x300 | 0x100;

      }

      else {

        uVar3 = param_3 & 0x300 | 0x200;

      }

    }

    if (uVar3 == 0x100) {

      param_2[0x10] = param_2[0x10] & 0xfc | (byte)(param_1[8] >> 0xe) & 3;

      convert_from_SW_SVC_VLL_CW_BITS((uintptr_t *)((int)param_1 + 0x23),param_2 + 0x11,0);

      return;

    }

    uVar2 = 0xbb25;

    if (uVar3 == 0x200) {

      param_2[0x10] = param_2[0x10] & 0xfc | (byte)(param_1[8] >> 0xe) & 3;

      param_2[0x11] = *(uintptr_t *)((int)param_1 + 0x23);

      return;

    }

    uVar4 = 0x9c7afe8;

  }

  else {

    uVar2 = 0xbb2c;

    if (uVar3 == 0x80) {

      param_2[0x10] = param_2[0x10] & 0xf8 | (byte)(param_1[8] >> 0x15) & 7;

      return;

    }

    uVar4 = 0x9c7a570;

  }

  timosAssert(0x9c74c64,0x9c748e4,uVar2,0x9c7b0c0,uVar4);

  return;

}



