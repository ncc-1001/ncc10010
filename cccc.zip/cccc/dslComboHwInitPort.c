#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t dslComboHwInitPort(int param_1,int param_2)



{

  uint32_t uVar1;

  int iVar2;

  

  sarmXdslHwInitPort();

  *(uint32_t *)(param_2 + 0x1c0) = 3;

  if (*(char *)(param_1 + 0x63b30) == '\0') {

    uVar1 = pfHwMdaToSwMdaType(*(uint32_t *)(param_1 + 0x108),0);

    iVar2 = getPortTypeFromMdaPortInfo(uVar1,0,*(int *)(param_2 + 0x10) + 1,1);

    if (iVar2 == 0x1d) {

      socratesInitComplete(*(uint32_t *)(param_1 + 8));

      shdslInitPort(param_1,param_2);

    }

    hwWakiClearAllInterruptEventReg();

    hwWakiEnableDisableInterrupts(1);

    if (*(int *)(param_2 + 0x10) == *(int *)(param_1 + 0xec) + -1) {

      *(uintptr_t *)(param_1 + 0x63b69) = 1;

    }

  }

  return 0;

}



