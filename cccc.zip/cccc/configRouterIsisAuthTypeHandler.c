#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int configRouterIsisAuthTypeHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t *puStack_18;

  int *piStack_14;

  

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_18);

  uVar2 = 0;

  if (iVar1 == 0) {

    uVar2 = *puStack_18;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,&piStack_14);

  if (iVar1 == 0) {

    iVar1 = *piStack_14;

    if (iVar1 != 0) {

      iVar1 = RCC_DB_FullEnum(piStack_14[5],iVar1);

    }

    iVar1 = configRouterIsisAuthType(param_1,uVar2,iVar1);

  }

  return iVar1;

}



