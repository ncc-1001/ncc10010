#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char *isisTitleStr;
extern int _traceEnabled;
extern int _tracepointsActive;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void isisCircUpdateIpAddrInfo(uint32_t *param_1,int param_2)
{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  int iVar4;
  uint16_t uVar6;
  byte bVar7;
  uint32_t uVar5;
  uint32_t uVar10;
  uint32_t uVar11;
  char *pcVar12;
  char *pcVar13;
  uintptr_t uVar14;
  int iVar15;
  char cStack_58;
  char cStack_57;
  uintptr_t uStack_56;
  uintptr_t uStack_55;
  char cStack_54;
  char cStack_53;
  char cStack_52;
  char cStack_51;
  char acStack_50 [4];
  uint32_t uStack_4c;
  uint32_t uStack_48;
  uint32_t uStack_44;
  uint32_t uStack_40;
  char acStack_38 [4];
  uint32_t uStack_34;
  uint32_t uStack_30;
  uint32_t uStack_2c;
  uint32_t uStack_28;
  uintptr_t auStack_20 [4];
  uintptr_t auStack_1c [4];
  uint uVar9; // Modified: Added declaration for uVar9
  int *piVar8; // Modified: Added declaration for piVar8
  
  pcVar2 = (char *)isisCalloc(0x260,1);
  pcVar3 = (char *)isisCalloc(0x260,1);
  if (pcVar2 != (char *)0x0 && pcVar3 != (char *)0x0) {
    iVar4 = pipGetIfInfo(*param_1,*(uint32_t *)(param_2 + 8),&cStack_58,&cStack_57,&uStack_56,
                         &cStack_52,&uStack_55,&cStack_54,auStack_20,auStack_1c,pcVar2,pcVar3,
                         &cStack_53,&cStack_51,acStack_50,param_2 + 0x1c8,acStack_38);
    if (iVar4 == 0) {
      *(uintptr_t *)(param_2 + 0x20) = 1;
      *(uintptr_t *)(param_2 + 0xc) = 1;
      *(uint32_t *)(param_2 + 0x10) = 0;
      *(uint32_t *)(param_2 + 0x24) = 0;
      *(uintptr_t *)(param_2 + 0x34) = 0;
      memset(param_2 + 0x38,0,0x10);
      *(uintptr_t *)(param_2 + 0x48) = 0;
      memset(param_2 + 0x4c,0,0x10);
      *(char *)(param_2 + 0x1b4) = acStack_50[0];
      if (acStack_50[0] == '\0') {
        *(uint32_t *)(param_2 + 0x1bc) = uStack_48;
        *(uint32_t *)(param_2 + 0x1c0) = uStack_44;
        *(uint32_t *)(param_2 + 0x1b8) = uStack_4c;
        *(uint32_t *)(param_2 + 0x1c4) = uStack_40;
      }
      else {
        *(uint32_t *)(param_2 + 0x1b8) = uStack_4c;
      }
      if (cStack_52 == '\x01') {
        bVar7 = *(byte *)(param_2 + 0x1b2) | 1;
      }
      else {
        bVar7 = *(byte *)(param_2 + 0x1b2) & 0xfe;
      }
      *(byte *)(param_2 + 0x1b2) = bVar7;
      if (cStack_53 == '\x01') {
        bVar7 = *(byte *)(param_2 + 0x1b2) | 2;
      }
      else {
        bVar7 = *(byte *)(param_2 + 0x1b2) & 0xfd;
      }
      *(byte *)(param_2 + 0x1b2) = bVar7;
      if (cStack_54 == '\0') {
        bVar7 = *(byte *)(param_2 + 0x1b2) & 0xfb;
      }
      else {
        bVar7 = *(byte *)(param_2 + 0x1b2) | 4;
      }
      *(byte *)(param_2 + 0x1b2) = bVar7;
      if (cStack_51 == '\0') {
        bVar7 = *(byte *)(param_2 + 0x1b2) & 0xf7;
      }
      else {
        bVar7 = *(byte *)(param_2 + 0x1b2) | 8;
      }
      *(byte *)(param_2 + 0x1b2) = bVar7;
      *(char *)(param_2 + 0x5c) = acStack_38[0];
      if (acStack_38[0] == '\0') {
        *(uint32_t *)(param_2 + 100) = uStack_30;
        *(uint32_t *)(param_2 + 0x68) = uStack_2c;
        *(uint32_t *)(param_2 + 0x60) = uStack_34;
        *(uint32_t *)(param_2 + 0x6c) = uStack_28;
      }
      else {
        *(uint32_t *)(param_2 + 0x60) = uStack_34;
      }
      *(uint16_t *)(param_2 + 0x1b0) = 0;
      iVar4 = 7;
      pcVar12 = pcVar2;
      pcVar13 = pcVar3;
      do {
        if (((cStack_58 != '\0') && (param_1[0xb] != 0)) && (*pcVar12 == '\x01')) {
          if (pcVar12[0x45] == '\0') {
            if (pcVar12[0x46] == '\0') {
              *(char *)((uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2 + 0x70) = pcVar12[4];
              iVar15 = (uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2;
              if (*(char *)(iVar15 + 0x70) == '\0') {
                uVar10 = *(uint32_t *)(pcVar12 + 0xc);
                uVar11 = *(uint32_t *)(pcVar12 + 0x10);
                uVar5 = *(uint32_t *)(pcVar12 + 0x14);
                *(uint32_t *)(iVar15 + 0x74) = *(uint32_t *)(pcVar12 + 8);
                *(uint32_t *)(iVar15 + 0x78) = uVar10;
                *(uint32_t *)(iVar15 + 0x80) = uVar5;
                *(uint32_t *)(iVar15 + 0x7c) = uVar11;
              }
              else {
                *(uint32_t *)(iVar15 + 0x74) = *(uint32_t *)(pcVar12 + 8);
              }
              *(char *)((uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2 + 0x84) = pcVar12[0x18];
              iVar15 = (uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2;
              if (*(char *)(iVar15 + 0x84) == '\0') {
                uVar5 = *(uint32_t *)(pcVar12 + 0x28);
                uVar10 = *(uint32_t *)(pcVar12 + 0x20);
                uVar11 = *(uint32_t *)(pcVar12 + 0x24);
                *(uint32_t *)(iVar15 + 0x88) = *(uint32_t *)(pcVar12 + 0x1c);
                *(uint32_t *)(iVar15 + 0x8c) = uVar10;
                *(uint32_t *)(iVar15 + 0x94) = uVar5;
                *(uint32_t *)(iVar15 + 0x90) = uVar11;
                *(short *)(param_2 + 0x1b0) = *(short *)(param_2 + 0x1b0) + 1;
              }
              else {
                *(uint32_t *)(iVar15 + 0x88) = *(uint32_t *)(pcVar12 + 0x1c);
                *(short *)(param_2 + 0x1b0) = *(short *)(param_2 + 0x1b0) + 1;
              }
            }
          }
          else {
            cVar1 = pcVar12[4];
            *(char *)(param_2 + 0xc) = cVar1;
            if (cVar1 == '\0') {
              uVar5 = *(uint32_t *)(pcVar12 + 0xc);
              uVar10 = *(uint32_t *)(pcVar12 + 0x10);
              uVar11 = *(uint32_t *)(pcVar12 + 0x14);
              *(uint32_t *)(param_2 + 0x10) = *(uint32_t *)(pcVar12 + 8);
              *(uint32_t *)(param_2 + 0x14) = uVar5;
              *(uint32_t *)(param_2 + 0x18) = uVar10;
              *(uint32_t *)(param_2 + 0x1c) = uVar11;
            }
            else {
              *(uint32_t *)(param_2 + 0x10) = *(uint32_t *)(pcVar12 + 8);
            }
            cVar1 = pcVar12[0x18];
            *(char *)(param_2 + 0x20) = cVar1;
            if (cVar1 == '\0') {
              uVar5 = *(uint32_t *)(pcVar12 + 0x20);
              uVar10 = *(uint32_t *)(pcVar12 + 0x24);
              uVar11 = *(uint32_t *)(pcVar12 + 0x28);
              *(uint32_t *)(param_2 + 0x24) = *(uint32_t *)(pcVar12 + 0x1c);
              *(uint32_t *)(param_2 + 0x28) = uVar5;
              *(uint32_t *)(param_2 + 0x2c) = uVar10;
              *(uint32_t *)(param_2 + 0x30) = uVar11;
            }
            else {
              *(uint32_t *)(param_2 + 0x24) = *(uint32_t *)(pcVar12 + 0x1c);
            }
          }
        }
        if (((cStack_57 != '\0') && (param_1[0xc] != 0)) && (*pcVar13 == '\x01')) {
          if (pcVar13[0x45] == '\0') {
            if (pcVar13[0x46] == '\0') {
              *(char *)((uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2 + 0x70) = pcVar13[4];
              iVar15 = (uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2;
              if (*(char *)(iVar15 + 0x70) == '\0') {
                uVar10 = *(uint32_t *)(pcVar13 + 0xc);
                uVar11 = *(uint32_t *)(pcVar13 + 0x10);
                uVar5 = *(uint32_t *)(pcVar13 + 0x14);
                *(uint32_t *)(iVar15 + 0x74) = *(uint32_t *)(pcVar13 + 8);
                *(uint32_t *)(iVar15 + 0x78) = uVar10;
                *(uint32_t *)(iVar15 + 0x80) = uVar5;
                *(uint32_t *)(iVar15 + 0x7c) = uVar11;
              }
              else {
                *(uint32_t *)(iVar15 + 0x74) = *(uint32_t *)(pcVar13 + 8);
              }
              *(char *)((uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2 + 0x84) = pcVar13[0x18];
              iVar15 = (uint)*(ushort *)(param_2 + 0x1b0) * 0x28 + param_2;
              if (*(char *)(iVar15 + 0x84) == '\0') {
                uVar5 = *(uint32_t *)(pcVar13 + 0x28);
                uVar10 = *(uint32_t *)(pcVar13 + 0x20);
                uVar11 = *(uint32_t *)(pcVar13 + 0x24);
                *(uint32_t *)(iVar15 + 0x88) = *(uint32_t *)(pcVar13 + 0x1c);
                *(uint32_t *)(iVar15 + 0x8c) = uVar10;
                *(uint32_t *)(iVar15 + 0x94) = uVar5;
                *(uint32_t *)(iVar15 + 0x90) = uVar11;
                *(short *)(param_2 + 0x1b0) = *(short *)(param_2 + 0x1b0) + 1;
              }
              else {
                *(uint32_t *)(iVar15 + 0x88) = *(uint32_t *)(pcVar13 + 0x1c);
                *(short *)(param_2 + 0x1b0) = *(short *)(param_2 + 0x1b0) + 1;
              }
            }
          }
          else {
            cVar1 = pcVar13[4];
            *(char *)(param_2 + 0x34) = cVar1;
            if (cVar1 == '\0') {
              uVar5 = *(uint32_t *)(pcVar13 + 0xc);
              uVar10 = *(uint32_t *)(pcVar13 + 0x10);
              uVar11 = *(uint32_t *)(pcVar13 + 0x14);
              *(uint32_t *)(param_2 + 0x38) = *(uint32_t *)(pcVar13 + 8);
              *(uint32_t *)(param_2 + 0x3c) = uVar5;
              *(uint32_t *)(param_2 + 0x40) = uVar10;
              *(uint32_t *)(param_2 + 0x44) = uVar11;
            }
            else {
              *(uint32_t *)(param_2 + 0x38) = *(uint32_t *)(pcVar13 + 8);
            }
            cVar1 = pcVar13[0x18];
            *(char *)(param_2 + 0x48) = cVar1;
            if (cVar1 == '\0') {
              uVar5 = *(uint32_t *)(pcVar13 + 0x20);
              uVar10 = *(uint32_t *)(pcVar13 + 0x24);
              uVar11 = *(uint32_t *)(pcVar13 + 0x28);
              *(uint32_t *)(param_2 + 0x4c) = *(uint32_t *)(pcVar13 + 0x1c);
              *(uint32_t *)(param_2 + 0x50) = uVar5;
              *(uint32_t *)(param_2 + 0x54) = uVar10;
              *(uint32_t *)(param_2 + 0x58) = uVar11;
            }
            else {
              *(uint32_t *)(param_2 + 0x4c) = *(uint32_t *)(pcVar13 + 0x1c);
            }
          }
        }
        iVar4 = iVar4 + -1;
        pcVar12 = pcVar12 + 0x4c;
        pcVar13 = pcVar13 + 0x4c;
      } while (-1 < iVar4);
      uVar9 = 0;
      piVar8 = param_1 + 0xd;
      do {
        iVar4 = uVar9 + param_2;
        uVar9 = uVar9 + 1;
        uVar14 = 0;
        if ((*(char *)(iVar4 + 0x3e4) != '\0') && (*piVar8 != 0)) {
          uVar14 = 1;
        }
        *(uintptr_t *)(iVar4 + 0x3e6) = uVar14;
        piVar8 = piVar8 + 1;
      } while (uVar9 < 2);
      uVar6 = pipDbGetLdpSyncTime(*param_1,*(uint32_t *)(param_2 + 8));
      *(uint16_t *)(param_2 + 0x3c6) = uVar6;
    }
    else if (((param_1[0x1b] & 0x40) != 0) && (iVar4 = isisDebugCheck(param_1,0x40,0,0), iVar4 != 0)
            ) {
      if (_IsisLogger == 0) {
        tracePrint(_MOD_ISIS,0xa1a85dc,0,0,0xa1a8630,*(uint32_t *)(param_2 + 8));
      }
      else {
        logEvent_debug_fmt(*param_1,0xa1a7e00,&isisTitleStr,0xa1a8630,*(uint32_t *)(param_2 + 8));
      }
    }
    isisFree(pcVar2);
    isisFree(pcVar3);
    return;
  }
  if ((_traceEnabled == 0) &&
     ((_tracepointsActive == 0 || (iVar4 = traceTest(_MOD_ISIS,0xa1a85dc,4,0x1a), iVar4 == 0)))) {
    return;
  }
  tracePrintVRtr(_MOD_ISIS,0xa1a85dc,4,0x1a,1,0xa1a85f8);
  return;
}