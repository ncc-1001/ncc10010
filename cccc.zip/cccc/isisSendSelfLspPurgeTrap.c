#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendSelfLspPurgeTrap(uint32_t *param_1,int param_2,uint32_t param_3,uint32_t param_4)



{

  uint32_t uVar1;

  uint32_t uVar2;

  uintptr_t auStack_40 [40];

  

  auStack_40[0] = 0;

  FmtIsisLSPId(*param_1,param_3,8,auStack_40,0x21,1);

  uVar1 = strlen(auStack_40);

  uVar2 = *param_1;

  logEvent_ISIS_vRtrIsisOwnLSPPurge

            (uVar2,0xa1bba70,uVar2,*(uint32_t *)(param_2 + 8),uVar2,param_3,8,auStack_40,uVar1,

             param_4);

  return;

}



