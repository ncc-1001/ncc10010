#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisRedTunlUpdate(uint32_t *param_1,uint *param_2,int param_3,uint32_t param_4)



{

  int iVar1;

  uint uVar2;

  uint32_t uStack_40;

  int iStack_3c;

  uint32_t uStack_38;

  uint32_t uStack_34;

  uint32_t uStack_30;

  uint32_t uStack_2c;

  uint32_t uStack_28;

  uint32_t uStack_24;

  uint32_t uStack_20;

  uint32_t uStack_1c;

  

  uStack_40 = 0;

  iStack_3c = 0;

  uStack_38 = 0;

  uStack_34 = 0;

  uStack_30 = 0;

  uStack_2c = 0;

  uStack_28 = 0;

  uStack_24 = 0;

  uStack_20 = 0;

  uStack_1c = 0;

  iVar1 = redAmIActive(0x34);

  if (iVar1 == 0) {

    return;

  }

  uStack_40 = *param_1;

  iStack_3c = param_3;

  memcpy(&uStack_38,param_2,0x1c);

  uStack_1c = param_4;

  if (((param_1[0x1b] & 0x100000) != 0) &&

     (iVar1 = isisDebugCheck(param_1,0x100000,0,0), iVar1 != 0)) {

    if (_IsisLogger == 0) {

      uVar2 = *param_2;

      tracePrint(_MOD_ISIS,0xa1ad70c,0,0,0xa1ad768,uVar2 >> 0x18,uVar2 >> 0x10 & 0xff,

                 uVar2 >> 8 & 0xff,uVar2 & 0xff);

    }

    else {

      uVar2 = *param_2;

      logEvent_debug_fmt(*param_1,0xa1ac4d0,&isisTitleStr,0xa1ad768,uVar2 >> 0x18,

                         uVar2 >> 0x10 & 0xff,uVar2 >> 8 & 0xff,uVar2 & 0xff);

    }

  }

  if (isisTunlDebug == '\0') {

    redSendUpdate(0x34,0xf,&uStack_40,0x28);

    return;

  }

  uVar2 = *param_2;

                    /* WARNING: Subroutine does not return */

  printf(0xa1ad720,uVar2 >> 0x18,uVar2 >> 0x10 & 0xff,uVar2 >> 8 & 0xff,uVar2 & 0xff,

         (&isisTunlOrtActionStr)[iStack_3c],param_4);

}



