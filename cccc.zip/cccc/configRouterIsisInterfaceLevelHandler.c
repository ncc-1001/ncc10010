#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int configRouterIsisInterfaceLevelHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uintptr_t auStack_18 [4];

  uintptr_t auStack_14 [4];

  uintptr_t auStack_10 [8];

  

  RCC_DB_RetrieveParam(param_2,0,1,auStack_18);

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,auStack_14);

  if (iVar1 != 0) {

    return iVar1;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,4,auStack_10);

  return iVar1;

}



