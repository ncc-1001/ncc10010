#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisAdjModifyBfd(uint32_t *param_1,char param_2)



{

  int iVar1;

  uint32_t uVar2;

  int aiStack_18 [2];

  

  aiStack_18[0] = 0;

  iVar1 = isisAdjSnmpGetNext(param_1,0,aiStack_18);

  while (((iVar1 == 0 && (aiStack_18[0] != 0)) &&

         (*(uint32_t **)(aiStack_18[0] + 0x68) == param_1))) {

    if (param_2 == '\0') {

      isisAdjBfdDel(*(uint32_t *)*param_1,aiStack_18[0]);

      uVar2 = **(uint32_t **)(aiStack_18[0] + 0x6c);

    }

    else {

      isisAdjBfdAdd(*(uint32_t *)*param_1);

      isisRedSendAdjDbToInactive(param_1,*(uint32_t *)(aiStack_18[0] + 0x4c),aiStack_18[0],1,0);

      uVar2 = **(uint32_t **)(aiStack_18[0] + 0x6c);

    }

    iVar1 = isisAdjSnmpGetNext(param_1,uVar2,aiStack_18);

  }

  return;

}



