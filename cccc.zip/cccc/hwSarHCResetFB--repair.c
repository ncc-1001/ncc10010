#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

// Added: External declaration for sarmFpgaInitialized to fix compilation error
extern char sarmFpgaInitialized;

void hwSarHCResetFB(void)

{

  if (sarmFpgaInitialized != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}