#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added declaration for undeclared variable ___chk_strnum
int ___chk_strnum;

uint32_t

configRouterIsisNoSummAddress

          (uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4)


{

  int iVar1;

  int iVar2;

  uint32_t uVar3;

  uintptr_t *puVar4;

  uint uVar5;

  uint uVar6;

  uintptr_t auStack_338 [136];

  uintptr_t auStack_2b0 [200];

  uintptr_t auStack_1e8 [200];

  uintptr_t uStack_120;

  uintptr_t uStack_11f;

  uintptr_t uStack_11e;

  uintptr_t uStack_11d;

  uintptr_t uStack_11c;

  uintptr_t uStack_11b;

  uintptr_t uStack_11a;

  uintptr_t uStack_119;

  uintptr_t uStack_118;

  uintptr_t uStack_117;

  uintptr_t uStack_116;

  uintptr_t uStack_115;

  uintptr_t uStack_114;

  uintptr_t uStack_113;

  uintptr_t uStack_112;

  uintptr_t uStack_111;

  uintptr_t uStack_110;

  uintptr_t uStack_10f;

  uintptr_t uStack_10e;

  uintptr_t uStack_10d;

  uintptr_t auStack_108 [200];

  uint uStack_40;

  uint32_t uStack_3c;

  uint uStack_38;

  uint uStack_34;

  uintptr_t auStack_30 [8];

  

  iVar1 = getVRtrId();

  if (iVar1 == 0) {

    return 0xffffffff;

  }

  iVar2 = strToIpPrefix(param_3,param_4,&uStack_40,&uStack_3c);

  if (iVar2 == 0) {

    uStack_38 = netMaskToLen(uStack_3c);

    uVar5 = uStack_40 >> 0x10 & 0xff;

    puVar4 = (uintptr_t *)(uStack_40 >> 0x18);

    uVar3 = 1;

    uVar6 = 4;

    snprintf(auStack_338,0x82,0xa07d1a4,iVar1,1,4,puVar4,uVar5,uStack_40 >> 8 & 0xff,

             uStack_40 & 0xff,uStack_38);

  }

  else {

    iVar2 = strToInetPrefixAndLength(param_3,&uStack_120,0x14,&uStack_34,&uStack_38);

    if (iVar2 != 0) {

      cliErrorMesg(param_1,0xa07d2b8);

      return 0xffffffff;

    }

    if (uStack_34 == 0x10) {

      snprintf(auStack_108,200,0xa07d27c,uStack_120,uStack_11f,uStack_11e,uStack_11d,uStack_11c,

               uStack_11b,uStack_11a,uStack_119,uStack_118,uStack_117,uStack_116,uStack_115,

               uStack_114,uStack_113,uStack_112,uStack_111);

      uVar3 = 2;

    }

    else if (uStack_34 < 0x11) {

      if (uStack_34 != 4) {

LAB_03a95650:

        cliErrorMesg(param_1,0xa07d210);

        return 0xffffffff;

      }

      snprintf(auStack_108,200,0xa07d2ac,uStack_120,uStack_11f,uStack_11e,uStack_11d);

      uVar3 = 1;

    }

    else {

      if (uStack_34 != 0x14) goto LAB_03a95650;

      snprintf(auStack_108,200,0xa07d228,uStack_120,uStack_11f,uStack_11e,uStack_11d,uStack_11c,

               uStack_11b,uStack_11a,uStack_119,uStack_118,uStack_117,uStack_116,uStack_115,

               uStack_114,uStack_113,uStack_112,uStack_111,uStack_110,uStack_10f,uStack_10e,

               uStack_10d);

      uVar3 = 4;

    }

    puVar4 = auStack_108;

    uVar5 = uStack_38;

    snprintf(auStack_338,0x82,0xa07d264,iVar1,uVar3,uStack_34,puVar4,uStack_38);

    uVar6 = uStack_34;

  }

  snprintf(auStack_2b0,200,0xa07d1c0,auStack_338,uVar3,uVar6,puVar4,uVar5);

  iVar1 = RCC_RCB_ReadValueFromRCB(param_1,auStack_2b0,0,auStack_1e8,auStack_30);

  if (iVar1 == 0) {

    iVar1 = strcmp(auStack_1e8,0xa07cc5c);

    if (iVar1 == 0) {

      return 0;

    }

    ___chk_strnum = 6;

    iVar1 = RCC_RCB_WriteValueToRCB(param_1,auStack_2b0,0,0xa07d2c8);

    if (iVar1 < 0) {

      return 0xffffffff;

    }

  }

  return 0;

}