#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

uint32_t isisRtmEnable2(uint32_t *param_1,int param_2,int param_3)
{
  int iVar1;
  uint32_t uVar2;
  
  if ((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x800) == 0)) {
    uVar2 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];
  }
  else {
    iVar1 = isisDebugCheck(param_1,0x800,0,0);
    if (iVar1 == 0) {
      uVar2 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];
    }
    else if (_IsisLogger == 0) {
      tracePrint(_MOD_ISIS,0xa1af4ac,0,0,0xa1af4bc,param_2,param_3);
      uVar2 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];
    }
    else {
      logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af4bc,param_2,param_3);
      uVar2 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];
    }
  }
  RTMD_ExecuteCommand(uVar2,1,4,param_1 + param_2 * 0xe + param_3 * 7 + 0x22d);
  return 0;
}