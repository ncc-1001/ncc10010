#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */



void hwCN6xxxPciEConfigSpaceInit(uintptr_t param_1)



{

  hwCN6xxxConfigSpaceWrite(4,0x146,param_1);

  hwCN6xxxConfigSpaceWrite(0x18,0,param_1);

  hwCN6xxxConfigSpaceWrite(0x20,0x200030,param_1);

  hwCN6xxxConfigSpaceWrite(0x24,0x200030,param_1);

  hwCN6xxxConfigSpaceWrite(0x28,3,param_1);

  hwCN6xxxConfigSpaceWrite(0x2c,2,param_1);

  hwCN6xxxConfigSpaceWrite(0x78,0x800,param_1);

  hwCN6xxxConfigSpaceWrite(0x80,0x10000048,param_1);

  hwCN6xxxConfigSpaceWrite(0x88,0x3c0,param_1);

  hwCN6xxxConfigSpaceWrite(0x8c,0,param_1);

  hwCN6xxxConfigSpaceWrite(0x108,0,param_1);

  hwCN6xxxConfigSpaceWrite(0x10c,0x62010,param_1);

  hwCN6xxxConfigSpaceWrite(0x114,0x2000,param_1);

  hwCN6xxxConfigSpaceWrite(0x118,0,param_1);

  hwCN6xxxConfigSpaceWrite(300,0,param_1);

                    /* WARNING: Bad instruction - Truncating control flow here */

  halt_baddata();

}



