// Modified: Added missing declarations for compilation
#include <inttypes.h> // Modified: Added for uintptr_t definition
int _IsisLogger = 0; // Modified: Added declaration for _IsisLogger
const int _MOD_ISIS = 0; // Modified: Added declaration for _MOD_ISIS
const char *isisTitleStr = ""; // Modified: Added declaration for isisTitleStr
const uintptr_t uRam0d92c3d0 = 0; // Modified: Added declaration for uRam0d92c3d0

#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t isisAddLspToCsnpPkt(uint32_t *param_1,int param_2,int param_3)

{

  bool bVar1;

  int iVar2;

  short sVar5;

  uint16_t uVar6;

  int iVar3;

  uint32_t uVar4;

  int **ppiVar7;

  uintptr_t *puVar8;

  int *piVar9;

  uint uVar10;

  int iVar11;

  int *piVar12;

  int **ppiVar13;

  int iStack_30;

  int *piStack_2c;
  
  iStack_30 = 0;
  bVar1 = false;
  if (param_3 == 1) {
    ppiVar7 = (int **)param_1[0x222];
  }
  else {
    ppiVar7 = (int **)param_1[0x224];
  }
  if (*(int *)(param_2 + 0x10) == 0) {
    if (param_1 == (uint32_t *)0x0) {
      return 0;
    }
    if ((param_1[0x1b] & 0x400) == 0) {
      return 0;
    }
    iVar3 = isisDebugCheck(param_1,0x400,0,0);
    if (iVar3 == 0) {
      return 0;
    }
    if (_IsisLogger == 0) {
      uVar4 = isisDumpLspId(param_2 + 4,param_1 + 0x6a1,0x400,0);
      tracePrint(_MOD_ISIS,0xa1a9840,0,0,0xa1a985c,uVar4,*(uint32_t *)(param_2 + 0x10));
      return 0;
    }
    uVar4 = isisDumpLspId(param_2 + 4,param_1 + 0x6a1,0x400,0);
    logEvent_debug_fmt(*param_1,0xa1a9854,&isisTitleStr,0xa1a985c,uVar4,
                       *(uint32_t *)(param_2 + 0x10));
    return 0;
  }
  ppiVar13 = (int **)0x0;
  if (ppiVar7 == (int **)0x0) {
LAB_04209298:
    ppiVar7 = (int **)fsmem_calloc(uRam0d92c3d0,1,0x2c);
    if (ppiVar7 == (int **)0x0) {
      return 6;
    }
    piVar12 = (int *)isisAllocPacket(0x5e5);
    if (piVar12 == (int *)0x0) {
      fsmem_free(uRam0d92c3d0,ppiVar7);
      return 6;
    }
    ppiVar7[6] = piVar12;
    isisSetStartLspId(ppiVar7,ppiVar13);
    memset((int)ppiVar7 + 0xe,0,8);
    iVar2 = piVar12[2];
    piStack_2c = (int *)((int)piVar12 + iVar2 + 0xb1);
    ppiVar7[7] = piStack_2c;
    uVar4 = 0x18;
    if (param_3 != 1) {
      uVar4 = 0x19;
    }
    isisInitPduHdr(0x21,uVar4,3,&piStack_2c,&iStack_30);
    *(uintptr_t *)piStack_2c = 0;
    *(uintptr_t *)((int)piStack_2c + 1) = 0;
    piStack_2c = (int *)((int)piStack_2c + 2);
    iStack_30 = iStack_30 + 2;
    memcpy(piStack_2c,param_1 + 8,6);
    iVar3 = (int)ppiVar7 + 6;
    *(uintptr_t *)((int)piStack_2c + 6) = 0;
    piStack_2c = (int *)((int)piStack_2c + 7);
    iStack_30 = iStack_30 + 7;
    memcpy(piStack_2c,iVar3,8);
    *(uintptr_t *)((int)piStack_2c + 0xf) = 0xff;
    *(uintptr_t *)(piStack_2c + 2) = 0xff;
    *(uintptr_t *)((int)piStack_2c + 9) = 0xff;
    *(uintptr_t *)((int)piStack_2c + 10) = 0xff;
    *(uintptr_t *)((int)piStack_2c + 0xb) = 0xff;
    *(uintptr_t *)(piStack_2c + 3) = 0xff;
    *(uintptr_t *)((int)piStack_2c + 0xd) = 0xff;
    *(uintptr_t *)((int)piStack_2c + 0xe) = 0xff;
    ppiVar7[9] = piStack_2c + 4;
    *(uintptr_t *)(piStack_2c + 4) = 9;
    *(uintptr_t *)((int)piStack_2c + 0x11) = 0;
    piStack_2c = (int *)((int)piStack_2c + 0x12);
    iStack_30 = iStack_30 + 2;
    ppiVar7[8] = piStack_2c;
    *(char *)((int)piVar12 + iVar2 + 0xba) = (char)iStack_30;
    *(char *)((int)piVar12 + iVar2 + 0xb9) = (char)((uint)iStack_30 >> 8);
    if (param_3 == 1) {
      if (ppiVar13 == (int **)0x0) {
        *ppiVar7 = (int *)param_1[0x221];
        param_1[0x221] = ppiVar7;
        param_1[0x222] = ppiVar7;
      }
      else {
        *ppiVar13 = (int *)ppiVar7;
        param_1[0x222] = ppiVar7;
      }
    }
    else if (ppiVar13 == (int **)0x0) {
      *ppiVar7 = (int *)param_1[0x223];
      param_1[0x223] = ppiVar7;
      param_1[0x224] = ppiVar7;
    }
    else {
      *ppiVar13 = (int *)ppiVar7;
      param_1[0x224] = ppiVar7;
    }
  }
  else {
    iVar3 = (int)ppiVar7 + 6;
    if (0x45 < *(ushort *)(ppiVar7 + 1)) {
      memcpy((int)ppiVar7[7] + 0x19,(int)ppiVar7 + 0xe,8);
      ppiVar13 = ppiVar7;
      goto LAB_04209298;
    }
  }
  iVar11 = param_2 + 4;
  piVar12 = ppiVar7[7];
  iVar2 = memcmp(iVar3,iVar11,8);
  if (iVar2 < 1) {
    iVar3 = (int)ppiVar7 + 0xe;
    iVar2 = memcmp(iVar3,iVar11,8);
    if (iVar2 < 0) goto LAB_04208f9c;
  }
  else {
LAB_04208f9c:
    memcpy(iVar3,iVar11,8);
  }
  iVar2 = (int)piVar12 + 0x11;
  iVar3 = memcmp(iVar2,iVar11,8);
  if (iVar3 < 1) {
    iVar2 = (int)piVar12 + 0x19;
    iVar3 = memcmp(iVar2,iVar11,8);
    if (-1 < iVar3) {
      piStack_2c = ppiVar7[8];
      goto LAB_04208fd4;
    }
  }
  memcpy(iVar2,iVar11,8);
  piStack_2c = ppiVar7[8];
LAB_04208fd4:
  if (*(ushort *)(ppiVar7 + 1) == 0) {
    piStack_2c = ppiVar7[8];
  }
  else if ((uint)*(ushort *)(ppiVar7 + 1) % 0xf == 0) {
    ppiVar7[9] = piStack_2c;
    bVar1 = true;
    *(uintptr_t *)piStack_2c = 9;
    *(uintptr_t *)((int)piStack_2c + 1) = 0;
    piStack_2c = (int *)((int)piStack_2c + 2);
    ppiVar7[8] = piStack_2c;
  }
  else {
    piStack_2c = ppiVar7[8];
  }
  iVar3 = isisLspIsZeroLife(param_1,param_2);
  if (iVar3 == 1) {
    puVar8 = (uintptr_t *)((int)piStack_2c + 1);
    *(uintptr_t *)piStack_2c = 0;
    *puVar8 = 0;
  }
  else {
    uVar6 = isisLspGetRemLife(param_1,param_2);
    puVar8 = (uintptr_t *)((int)piStack_2c + 1);
    *(char *)piStack_2c = (char)((ushort)uVar6 >> 8);
    *puVar8 = (char)uVar6;
  }
  piStack_2c = (int *)(puVar8 + 1);
  memcpy(piStack_2c,iVar11,8);
  if (((*(ushort *)(param_2 + 0xc) & 4) == 0) || (iVar3 = *(int *)(param_2 + 0x34), iVar3 == 0)) {
    uVar10 = *(uint *)(param_2 + 0x10);
  }
  else {
    uVar10 = (uint)*(byte *)(iVar3 + 0x14) << 0x18 | (uint)*(byte *)(iVar3 + 0x15) << 0x10 |
             (uint)*(byte *)(iVar3 + 0x16) << 8 | (uint)*(byte *)(iVar3 + 0x17);
  }
  *(char *)(piStack_2c + 2) = (char)(uVar10 >> 0x18);
  *(char *)((int)piStack_2c + 9) = (char)(uVar10 >> 0x10);
  *(char *)((int)piStack_2c + 10) = (char)(uVar10 >> 8);
  *(char *)((int)piStack_2c + 0xb) = (char)uVar10;
  uVar6 = *(uint16_t *)(param_2 + 0xe);
  piVar9 = (int *)((int)piStack_2c + 0xe);
  *(char *)(piStack_2c + 3) = (char)((ushort)uVar6 >> 8);
  *(char *)((int)piStack_2c + 0xd) = (char)uVar6;
  piStack_2c = piVar9;
  if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x400) != 0)) &&
     (iVar3 = isisDebugCheck(param_1,0x400,0,0), iVar3 != 0)) {
    if (_IsisLogger == 0) {
      uVar4 = isisDumpLspId(iVar11,param_1 + 0x6a1,0x400,0);
      tracePrint(_MOD_ISIS,0xa1a9840,0,0,0xa1a9888,uVar4,uVar10);
    }
    else {
      uVar4 = isisDumpLspId(iVar11,param_1 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*param_1,0xa1a9854,&isisTitleStr,0xa1a9888,uVar4,uVar10);
    }
  }
  ppiVar7[8] = piStack_2c;
  *(char *)((int)ppiVar7[9] + 1) = *(char *)((int)ppiVar7[9] + 1) + '\x10';
  sVar5 = *(short *)(piVar12 + 2) + 0x10;
  if (bVar1) {
    sVar5 = *(short *)(piVar12 + 2) + 0x12;
  }
  *(char *)(piVar12 + 2) = (char)((ushort)sVar5 >> 8);
  *(char *)((int)piVar12 + 9) = (char)sVar5;
  *(short *)(ppiVar7 + 1) = *(short *)(ppiVar7 + 1) + 1;
  return 0;
}