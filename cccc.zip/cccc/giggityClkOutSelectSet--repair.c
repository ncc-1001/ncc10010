#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Added: Declaration for undeclared global variable uRam000000ec
extern uint uRam000000ec;

void giggityClkOutSelectSet(uint param_1,int param_2,uint param_3,int param_4,char param_5)

{

  int iVar1;

  uint uVar2;

  int iVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint uVar6;

  int iVar7;

  

  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {

    timosAssert(0xa8eb200,0xa8eb21c,0x1ae,0xa8eb4ac,0xa8eb1fc);

  }

  iVar1 = fpgaIsValidMda(param_1);

  if (iVar1 == 0) {

    return;

  }

  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {

    timosAssert(0xa8eb200,0xa8eb21c,0x1b5,0xa8eb4ac,0xa8eb1fc);

  }

  iVar1 = *(int *)(param_1 * 4 + 0xccb630c);

  if (iVar1 == 0) {

    timosAssert(0xa8eb5b8,0xa8eb21c,0x1b5,0xa8eb4ac,0xa8eb1fc);

    uVar2 = uRam000000ec;

  }

  else {

    uVar2 = *(uint *)(iVar1 + 0xec);

  }

  if (uVar2 <= param_3) {

    timosAssert(0xa8eb50c,0xa8eb21c,0x1b5,0xa8eb4ac,0xa8eb1fc);

  }

  if (param_4 == 0) {

    if (_traceEnabled == 0) {

      if (_tracepointsActive == 0) {

        return;

      }

      iVar1 = traceTest(_MOD_MDADRV,0xa8eb4ac,4,0);

      if (iVar1 == 0) {

        return;

      }

    }

    tracePrintVRtr(_MOD_MDADRV,0xa8eb4ac,4,0,1,0xa8eb4c4,param_1,0);

    return;

  }

  if ((_tracepointsActive != 0) && (iVar7 = traceTest(_MOD_MDADRV,0xa8eb4ac,1,0), iVar7 != 0)) {

    uVar4 = fpgaFmtRecClkMode(param_2);

    uVar5 = 0xa8eb568;

    if (param_5 == '\0') {

      uVar5 = 0xa8eb570;

    }

    tracePrintVRtr(_MOD_MDADRV,0xa8eb4ac,1,0,1,0xa8eb528,param_1,param_3,uVar4,param_4,uVar5);

  }

  uVar2 = fpgaRegRead(param_1,0x3c);

  iVar7 = 8;

  if (param_4 != 2) {

    iVar7 = (uint)(param_4 != 1) << 4;

  }

  uVar2 = uVar2 & ~(0xff << iVar7);

  if (param_5 == '\0') goto LAB_0640de28;

  uVar2 = uVar2 | 0x40 << iVar7;

  iVar3 = 10;

  if (param_2 == 2) {

LAB_0640df38:

    uVar6 = iVar3 << iVar7;

  }

  else {

    if ((_tracepointsActive != 0) && (iVar3 = traceTest(_MOD_MDADRV,0xa8eb4ac,1,0), iVar3 != 0)) {

      tracePrintVRtr(_MOD_MDADRV,0xa8eb4ac,1,0,1,0xa8eb5bc,param_1,*(uint32_t *)(iVar1 + 0x10c),

                     *(uint32_t *)(iVar1 + 0x110));

    }

    switch(param_3) {

    case 0:

    case 1:

      if (param_4 == 1) {

        uVar6 = 8 << iVar7;

      }

      else {

        if (param_4 != 2) {

          if ((_traceEnabled != 0) ||

             ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8eb4ac,4,0), iVar1 != 0)

              ))) {

            uVar4 = fpgaFmtRecClkMode(param_2);

            tracePrintVRtr(_MOD_MDADRV,0xa8eb4ac,4,0,1,0xa8eb578,param_1,param_3,uVar4,param_4);

            fpgaRegWrite(param_1,0x3c,uVar2);

            return;

          }

          goto LAB_0640de28;

        }

        uVar6 = 9 << iVar7;

      }

      break;

    case 2:

      uVar6 = 6 << iVar7;

      break;

    case 3:

    case 5:

      iVar3 = 7;

      goto LAB_0640df38;

    case 4:

      if (*(int *)(param_3 * 0x1a60 + iVar1 + 0x1274) != 1) goto LAB_0640de28;

      uVar6 = 1 << iVar7;

      break;

    default:

      if ((_traceEnabled != 0) ||

         ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8eb4ac,4,0), iVar1 != 0))))

      {

        tracePrintVRtr(_MOD_MDADRV,0xa8eb4ac,4,0,1,0xa8eb4ec,param_1,param_3);

      }

LAB_0640de28:

      fpgaRegWrite(param_1,0x3c,uVar2);

      return;

    }

  }

  fpgaRegWrite(param_1,0x3c,uVar2 | uVar6);

  return;

}