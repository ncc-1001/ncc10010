#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void dumpStdoutDirectToTmd(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uintptr_t auStack_10 [8];

  

  iVar1 = macMdaRemoved();

  if (iVar1 == 0) {

    while (iVar1 = strtok_r(param_2,0xa95ff80,auStack_10), iVar1 != 0) {

      traceMemPrintf(0xa95ff84,iVar1);

      param_2 = 0;

    }

    return;

  }

  return;

}



