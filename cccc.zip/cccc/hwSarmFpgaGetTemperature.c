#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */



void hwSarmFpgaGetTemperature(int param_1)



{

  if (param_1 != 0) {

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

                    /* WARNING: Subroutine does not return */

  printf(0x69c156c,0x69c1550);

}



