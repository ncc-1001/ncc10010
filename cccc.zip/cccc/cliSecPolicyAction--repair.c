#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _MOD_FIREWALL; // Modified: Added extern declaration for undeclared identifier _MOD_FIREWALL

uint32_t

cliSecPolicyAction(uint32_t param_1,uint32_t param_2,uint32_t param_3,int param_4,int param_5,

                  int param_6)

{

  uint32_t uVar1;

  int iVar2;

  uint32_t auStackX_8 [2];

  uint32_t uStack_f0;

  int iStack_ec;

  int iStack_30;

  uint32_t uStack_2c;

  int iStack_28;

  

  auStackX_8[0] = param_3;

  iStack_ec = strtol(param_3,auStackX_8,10);

  if ((iStack_ec == 0 || iStack_ec == 0x7fffffff) || (iStack_ec == -0x80000000)) {

    if (_tracepointsActive == 0) {

      return 0xffffffff;

    }

    iVar2 = traceTest(_MOD_FIREWALL,0xa12773c,1,0);

    if (iVar2 == 0) {

      return 0xffffffff;

    }

    tracePrintVRtr(_MOD_FIREWALL,0xa12773c,1,0,1,0xa12753c,iStack_ec);

    return 0xffffffff;

  }

  memset(&uStack_f0,0,0xd4);

  uStack_f0 = firemgrLookupPolicyId(param_2);

  if (param_4 == 0) {

LAB_03e758e4:

    iStack_30 = 2;

  }

  else {

    uVar1 = FmtFireAction(1);

    iVar2 = strcmp(param_4,uVar1);

    iStack_30 = 1;

    if (iVar2 != 0) {

      uVar1 = FmtFireAction(4);

      iVar2 = strcmp(param_4,uVar1);

      iStack_30 = 4;

      if (iVar2 != 0) {

        uVar1 = FmtFireAction(3);

        iVar2 = strcmp(param_4,uVar1);

        iStack_30 = 3;

        if (iVar2 != 0) goto LAB_03e758e4;

      }

    }

  }

  if (param_5 == 0) {

    uStack_2c = 0;

LAB_03e75760:

    if (param_6 == 0) {

      iStack_28 = 0;

    }

    else {

      if (iStack_30 != 4) goto LAB_03e75954;

      if (param_5 == 0) {

LAB_03e7596c:

        cliErrorMesg(param_1,0xa12777c);

        return 0xffffffff;

      }

      iStack_28 = strtol(param_6,&param_6,10);

      if ((iStack_28 == 0 || iStack_28 == 0x7fffffff) || (iStack_28 == -0x80000000)) {

        if (_tracepointsActive == 0) {

          return 0xffffffff;

        }

        iVar2 = traceTest(_MOD_FIREWALL,0xa12773c,1,0);

        if (iVar2 == 0) {

          return 0xffffffff;

        }

        tracePrintVRtr(_MOD_FIREWALL,0xa12773c,1,0,1,0xa12753c,iStack_28);

        return 0xffffffff;

      }

    }

    iVar2 = sia_aluSecPlcyParamsConfigEntryCheck(0xc8000000,&uStack_f0);

    if ((iVar2 == 0) &&

       (iVar2 = sia_aluSecPlcyParamsConfigEntrySet(0xc8000000,&uStack_f0), iVar2 == 0)) {

      return 0;

    }

  }

  else {

    if (iStack_30 == 4) {

      if (param_6 == 0) goto LAB_03e7596c;

      ipStrToIpAddr(param_5,&uStack_2c);

      goto LAB_03e75760;

    }

LAB_03e75954:

    cliErrorMesg(param_1,0xa127750);

  }

  return 0xffffffff;

}
