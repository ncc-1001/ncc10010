#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void cliPrintFunc(uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4)



{

  uint32_t uStackX_8;

  uint32_t uStackX_c;

  uintptr_t auStack_2d8 [720];

  

  uStackX_8 = param_3;

  uStackX_c = param_4;

  vsnprintfTruncate(auStack_2d8,0x2d0,param_2,&uStackX_8);

  cliPrintf(param_1,auStack_2d8);

  return;

}



