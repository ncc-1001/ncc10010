#include "nokia.h"
#include <stdint.h>

extern int PRId; // Modified: Added extern declaration for PRId

void hwRchipTestReadWriteSpeeds(uintptr_t param_1)
{
  unsigned int uVar1; // Modified: Replaced uint with unsigned int
  unsigned int uVar2; // Modified: Replaced uint with unsigned int
  unsigned int uVar3; // Modified: Replaced uint with unsigned int
  uintptr_t *puVar4;
  
  uVar1 = getRchipBaseAddress(param_1);
  if (0xfffffff < uVar1) {
    uVar3 = PRId >> 8 & 0xffff;
    uVar2 = uVar3 ^ 0xd01;
    if ((((uVar2 != 0) && (uVar2 = uVar3 ^ 0xd06, uVar2 != 0)) &&
        (uVar2 = uVar3 ^ 0xd04, uVar2 != 0)) && (uVar2 = uVar3 ^ 0xd93, uVar2 != 0)) {
      uVar2 = uVar3 ^ 0xd90;
    }
    puVar4 = (uintptr_t *)(uVar1 | 0xa0000000);
    if (uVar2 == 0) goto LAB_02dc5100;
  }
  if ((uVar1 < 0x800000) ||
     (puVar4 = (uintptr_t *)(uVar1 | 0xc0000000), (PRId >> 0x10 & 0xff) != 0xd)) {
    puVar4 = (uintptr_t *)(uVar1 | 0xa0000000);
  }
LAB_02dc5100:
                    /* WARNING: Subroutine does not return */
  printf(0x9cad1b4,uVar1,*puVar4);
}