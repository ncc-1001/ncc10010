#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern int _currentAlarmRelay;

uint hwSarmFpgaSetAlarmRelay(uint param_1)
{
  int in_zero;
  uint uVar1;
  int iVar2;
  
  iVar2 = 0;
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
    }
    else {
      iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
    }
  }
  if (*(char *)(iVar2 + 0x10c8f925) != -0x13) {
    iVar2 = 0;
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
      }
      else {
        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
      }
    }
    if (*(char *)(iVar2 + 0x10c8f925) != -0x17) {
      iVar2 = 0;
      if (_TgtHw == 1) {
        if (_kernelIsSmp == 0) {
          iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
        }
        else {
          iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
        }
      }
      if (*(char *)(iVar2 + 0x10c8f925) != -0x15) {
        iVar2 = 0;
        if (_TgtHw == 1) {
          if (_kernelIsSmp == 0) {
            iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
          }
          else {
            iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
          }
        }
        if (*(char *)(iVar2 + 0x10c8f925) != -0x16) {
          iVar2 = 0;
          if (_TgtHw == 1) {
            if (_kernelIsSmp == 0) {
              iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
            }
            else {
              iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
            }
          }
          if (*(char *)(iVar2 + 0x10c8f925) != -0x24) {
            iVar2 = 0;
            if (_TgtHw == 1) {
              if (_kernelIsSmp == 0) {
                iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
              }
              else {
                iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
              }
            }
            if (*(char *)(iVar2 + 0x10c8f925) != -0x23) {
              iVar2 = 0;
              if (_TgtHw == 1) {
                if (_kernelIsSmp == 0) {
                  iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                }
                else {
                  iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                }
              }
              if (*(char *)(iVar2 + 0x10c8f925) != -0x12) {
                return 0x80000000;
              }
              return;
            }
                    /* WARNING: Bad instruction - Truncating control flow here */
            halt_baddata();
          }
        }
      }
    }
  }
  uVar1 = (param_1 & 4) << 1;
  if (_currentAlarmRelay ==
      (_currentAlarmRelay & 0xfffffff1 | (param_1 & 1) << 1 | (param_1 & 2) << 1 | uVar1)) {
    return uVar1;
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}