#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern int _MOD_DDP;
extern void ddpFree(void *);
extern void ddpTick(int);

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


void ddpTask(int param_1)

{

  int iVar1;

  int iVar2;

  

  if (*(int *)(*(int *)(param_1 + 0x88) + 0x9c) == 0) {

    trap(0x1c00);

  }

  iVar1 = semSCreateX(1,0x9fc877c,0,*(uint32_t *)(param_1 + 0xac));

  if (iVar1 == 0) {

    timosAssert(0x9fc877c,0x9fc778c,0x11bd,0x9fc8774,0x9fc79a0);

  }

  tmMsgQInit(param_1 + 8,iVar1);

  iVar2 = ddpMalloc(0xc);

  *(int *)(param_1 + 0x40) = iVar2;

  if (iVar2 == 0) {

    timosAssert(0x9fc8814,0x9fc778c,0x11c8,0x9fc8774,0x9fc79a0);

    iVar2 = *(int *)(param_1 + 0x40);

  }

  *(uint32_t *)(iVar2 + 4) = 1;

  *(int *)(*(int *)(param_1 + 0x40) + 8) = param_1;

  iVar2 = timerMgrCreateExt(_MOD_DDP,100,0,ddpMalloc,ddpFree,_MOD_DDP);

  *(int *)(param_1 + 0x44) = iVar2;

  if (iVar2 == 0) {

    timosAssert(0x9fc8800,0x9fc778c,0x11d6,0x9fc8774,0x9fc79a0);

  }

  iVar2 = wdCreate();

  *(int *)(param_1 + 0x3c) = iVar2;

  if (iVar2 == 0) {

    timosAssert(0x9fc87f0,0x9fc778c,0x11dc,0x9fc8774,0x9fc79a0);

    iVar2 = *(int *)(param_1 + 0x3c);

  }

  iVar2 = wdStart(iVar2,10,ddpTick,param_1);

  if (iVar2 != 0) {

    timosAssert(0x9fc87ec,0x9fc778c,0x11df,0x9fc8774,0x9fc79a0);

  }

  ddpProcessSubscribeReq(param_1);

                    /* WARNING: Subroutine does not return */

  semTake(iVar1,0xffffffff);

}
