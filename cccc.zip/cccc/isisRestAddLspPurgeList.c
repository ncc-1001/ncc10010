#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisRestAddLspPurgeList(uint32_t *param_1,int param_2)



{

  uint32_t *puVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t *puVar4;

  int aiStack_18 [2];

  

  puVar1 = (uint32_t *)isisMalloc(0xc);

  if (puVar1 == (uint32_t *)0x0) {

    if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x400000) != 0)) &&

       (iVar2 = isisDebugCheck(param_1,0x400000,0,0), iVar2 != 0)) {

      if (_IsisLogger == 0) {

        tracePrint(_MOD_ISIS,0xa1ae508,0,0,0xa1ae554);

      }

      else {

        logEvent_debug_fmt(*param_1,0xa1ae068,&isisTitleStr,0xa1ae554);

      }

    }

  }

  else {

    uVar3 = *(uint32_t *)(param_2 + 0x10);

    *puVar1 = *(uint32_t *)(param_2 + 0xc);

    puVar1[1] = uVar3;

    puVar1[2] = (uint)*(byte *)(param_2 + 0x14) << 0x18 | (uint)*(byte *)(param_2 + 0x15) << 0x10 |

                (uint)*(byte *)(param_2 + 0x16) << 8 | (uint)*(byte *)(param_2 + 0x17);

    puVar4 = param_1 + 0x811;

    if (*(char *)(param_2 + 4) != '\x12') {

      puVar4 = param_1 + 0x812;

    }

    iVar2 = avlpInsertUnique(*puVar4,puVar1,puVar1,aiStack_18);

    if (iVar2 != 0) {

      if (iVar2 == 1) {

        if (*(uint *)(aiStack_18[0] + 8) < (uint)puVar1[2]) {

          *(uint32_t *)(aiStack_18[0] + 8) = puVar1[2];

          isisFree(puVar1);

          return;

        }

      }

      else if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x400000) != 0)) &&

              (iVar2 = isisDebugCheck(param_1,0x400000,0,0), iVar2 != 0)) {

        if (_IsisLogger != 0) {

          logEvent_debug_fmt(*param_1,0xa1ae068,&isisTitleStr,0xa1ae520);

          isisFree(puVar1);

          return;

        }

        tracePrint(_MOD_ISIS,0xa1ae508,0,0,0xa1ae520);

        isisFree(puVar1);

        return;

      }

      isisFree(puVar1);

    }

  }

  return;

}



