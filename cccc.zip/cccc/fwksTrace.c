#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint fwksTrace(uintptr_t *param_1,int param_2)



{

  int *piVar1;

  uintptr_t auStack_90 [16];

  uint32_t uStack_80;

  uintptr_t *puStack_7c;

  uint16_t uStack_78;

  uint16_t uStack_76;

  uintptr_t auStack_70 [4];

  uint32_t uStack_6c;

  code *pcStack_58;

  uint32_t uStack_54;

  uint32_t *puStack_50;

  uint32_t uStack_4c;

  uintptr_t *puStack_48;

  int iStack_3c;

  int *piStack_30;

  uint uStack_2c;

  

  puStack_48 = auStack_90;

  pcStack_58 = __gxx_personality_sj0;

  uStack_54 = 0xbff859e;

  puStack_50 = &uStack_80;

  uStack_4c = 0x40e80b8;

  _Unwind_SjLj_Register(auStack_70);

  iStack_3c = 0;

  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == (int *)0x0) {

    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||

       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==

         (uint)(uRam0c9594cc < uRam0c9594c4) &&

        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {

      uRam0c9594cc = uRam0c9594cc + 1;

      uRam0c959610 = uRam0c959610 + 1;

      __ZN8Firewall10FwksFilter6m_uNewE =

           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);

      iRam0c959614 = iRam0c959614 + 1;

      iRam0c95960c = iRam0c95960c + 0xb6d5f0;

      if (uRam0c959618 < uRam0c959610) {

        uRam0c959618 = uRam0c959610;

      }

      uStack_6c = 0xffffffff;

      piStack_30 = (int *)firewallMalloc(0xb6d5f0);

    }

    else {

      piStack_30 = (int *)0x0;

      iRam0c95961c = iRam0c95961c + 1;

    }

    uStack_6c = 1;

    _ZN8Firewall10FwksFilterC1Ev();

    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = piStack_30;

    piVar1 = (int *)0x0;

    if (piStack_30 == (int *)0x0) goto LAB_040e7f84;

  }

  piVar1 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;

LAB_040e7f84:

  if ((piVar1 != (int *)0x0) && (param_1 != (uintptr_t *)0x0 && param_2 != 0)) {

    uStack_80 = 0xa17dc08;

    uStack_78 = (uint16_t)param_2;

    uStack_76 = 0;

    if (param_1 != (uintptr_t *)0x0) {

      *param_1 = 0;

    }

    uStack_6c = 0xffffffff;

    puStack_7c = param_1;

    (**(code **)(*piVar1 + 0x2c))(piVar1,&uStack_80);

    iStack_3c = 1;

  }

  uStack_2c = (uint)(iStack_3c != 0);

  _Unwind_SjLj_Unregister(auStack_70);

  return uStack_2c;

}



