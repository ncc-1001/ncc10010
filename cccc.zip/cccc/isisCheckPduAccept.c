#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int isisCheckPduAccept(int param_1,int param_2,int param_3,int param_4,int param_5,uint param_6)



{

  byte bVar1;

  bool bVar2;

  uint32_t uVar3;

  int iVar4;

  

  uVar3 = isisGetAuthInfo(param_1,param_2,param_5,1);

  switch(param_5) {

  case 0xf:

  case 0x10:

  case 0x11:

    if (param_5 == 0x11) {

      iVar4 = 2;

    }

    else {

      iVar4 = 1;

    }

    if (*(int *)(param_2 + 0x2f4) == iVar4) {

      return 0x19;

    }

    iVar4 = memcmp(param_4 + 9,param_1 + 0x20,6);

    if (iVar4 == 0) {

      return 0x1f;

    }

    iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2);

    if (iVar4 != 0) {

      *(uint *)(param_1 + 0x1ea8) = 2 - (uint)(param_5 != 0x10);

    }

    if (2 < (byte)(*(char *)(param_4 + 8) - 1U)) {

      return 0x24;

    }

    break;

  case 0x12:

    if (*(int *)(param_1 + 0x1c) == 2) {

      return 0x1a;

    }

    if (*(int *)(param_2 + 0x2f4) == 2 && param_3 != 0) {

      iVar4 = isisAdjCheck(param_1,param_2,param_3,1);

      if (iVar4 != 0) {

        bVar2 = (int)param_6 < 0x5d5;

        goto LAB_0421f874;

      }

    }

    else if (*(int *)(param_2 + 0x2f4) == 1) {

      iVar4 = *(int *)(param_2 + 0x3d8);

      if (iVar4 == 0) {

        return 0x1e;

      }

      if (*(int *)(iVar4 + 0x44) != 2) {

        return 0x1e;

      }

      if (*(int *)(iVar4 + 0x50) != 2 && *(int *)(iVar4 + 0x50) != 4) {

        return 0x1e;

      }

    }

    iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2);

    if (iVar4 != 0) {

      *(uint32_t *)(param_1 + 0x1ea8) = 1;

    }

    bVar2 = (int)param_6 < 0x5d5;

    goto LAB_0421f874;

  case 0x13:

  case 0x15:

  case 0x16:

  case 0x17:

    return 0x14;

  case 0x14:

    if (*(int *)(param_1 + 0x1c) == 1) {

      return 0x1a;

    }

    if (*(int *)(param_2 + 0x2f4) == 2 && param_3 != 0) {

      iVar4 = isisAdjCheck(param_1,param_2,param_3,2);

      if (iVar4 != 0) {

        bVar2 = (int)param_6 < 0x5d5;

        goto LAB_0421f914;

      }

    }

    else if (*(int *)(param_2 + 0x2f4) == 1) {

      iVar4 = *(int *)(param_2 + 0x3d8);

      if ((iVar4 == 0) || (*(int *)(iVar4 + 0x44) != 2)) {

        return 0x1e;

      }

      if (1 < *(int *)(iVar4 + 0x50) - 3U) {

        return 0x1e;

      }

    }

    iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2);

    if (iVar4 != 0) {

      *(uint32_t *)(param_1 + 0x1ea8) = 2;

    }

    bVar2 = (int)param_6 < 0x5d5;

    goto LAB_0421f914;

  case 0x18:

    if (*(int *)(param_1 + 0x1c) == 2) {

      return 0x1b;

    }

    if (((*(int *)(param_2 + 0x2f4) != 2 || param_3 == 0) ||

        (iVar4 = isisAdjCheck(param_1,param_2,param_3,1), iVar4 == 0)) &&

       (iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2), iVar4 != 0)) {

      *(uint32_t *)(param_1 + 0x1ea8) = 1;

    }

    bVar2 = (int)param_6 < 0x27fe;

LAB_0421f874:

    if (!bVar2) {

      *(uint *)(param_1 + 0x1f04) = param_6;

      memcpy(param_1 + 0x1e98,param_4 + 0xc,8);

      *(uint32_t *)(param_1 + 0x1ea8) = 1;

      return 0x12;

    }

    break;

  case 0x19:

    if (*(int *)(param_1 + 0x1c) == 1) {

      return 0x1b;

    }

    if (((*(int *)(param_2 + 0x2f4) != 2 || param_3 == 0) ||

        (iVar4 = isisAdjCheck(param_1,param_2,param_3,2), iVar4 == 0)) &&

       (iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2), iVar4 != 0)) {

      *(uint32_t *)(param_1 + 0x1ea8) = 2;

    }

    bVar2 = (int)param_6 < 0x27fe;

LAB_0421f914:

    if (!bVar2) {

      *(uint *)(param_1 + 0x1f04) = param_6;

      memcpy(param_1 + 0x1e98,param_4 + 0xc,8);

      *(uint32_t *)(param_1 + 0x1ea8) = 2;

      return 0x12;

    }

    break;

  case 0x1a:

    if (*(int *)(param_1 + 0x1c) == 2) {

      return 0x1c;

    }

    if ((*(int *)(param_2 + 0x2f4) == 2) && (((*(uint *)(param_2 + 0x43c) ^ 1) & 1) != 0)) {

      return 0x1d;

    }

    if ((*(int *)(param_2 + 0x2f4) == 2 && param_3 != 0) &&

       (iVar4 = isisAdjCheck(param_1,param_2,param_3,1), iVar4 != 0)) {

      return iVar4;

    }

    iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2);

    uVar3 = 1;

    if (iVar4 == 0) goto LAB_0421f9a0;

LAB_0421f69c:

    *(uint32_t *)(param_1 + 0x1ea8) = uVar3;

    break;

  case 0x1b:

    if (*(int *)(param_1 + 0x1c) == 1) {

      return 0x1c;

    }

    if (((param_5 == 0x1b) && (*(int *)(param_2 + 0x2f4) == 2)) &&

       (((*(uint *)(param_2 + 0x60c) ^ 1) & 1) != 0)) {

      return 0x1d;

    }

    if ((*(int *)(param_2 + 0x2f4) == 2 && param_3 != 0) &&

       (iVar4 = isisAdjCheck(param_1,param_2,param_3,2), iVar4 != 0)) {

      return iVar4;

    }

    iVar4 = isisCheckAuth(param_1,param_4,param_5,param_6,uVar3,param_2);

    if (iVar4 != 0) {

      uVar3 = 2;

      goto LAB_0421f69c;

    }

LAB_0421f9a0:

    bVar1 = *(byte *)(param_4 + 7);

    goto LAB_0421f9a4;

  default:

    return 0x14;

  }

  if (iVar4 == 0) {

    bVar1 = *(byte *)(param_4 + 7);

LAB_0421f9a4:

    if ((bVar1 != 0) && ((uint)bVar1 != *(uint *)(param_1 + 0x50))) {

      *(int *)(param_1 + 0x2b8) = *(int *)(param_1 + 0x2b8) + 1;

      isisUpdateNtfyPduFrag(param_1,param_4,param_2,param_6 & 0xffff);

      isisSendMaxAreaAddrMismatchTrap(param_1,param_2,param_4,param_6);

      iVar4 = 0x18;

    }

  }

  return iVar4;

}



