#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void configRouterIsisLevelHandler(uint32_t param_1,uint32_t param_2)



{

  uintptr_t auStack_10 [4];

  uintptr_t auStack_c [4];

  

  RCC_DB_RetrieveParam(param_2,0,1,auStack_10);

  RCC_DB_RetrieveParam(param_2,0,2,auStack_c);

  return;

}



