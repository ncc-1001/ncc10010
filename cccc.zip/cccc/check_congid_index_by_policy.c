#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void check_congid_index_by_policy(uint param_1,int param_2)



{

  param_1 = param_1 & 0xff;

  if ((int)((param_1 - 1) * 0x1000000) >> 0x18 < 0) {

                    /* WARNING: Subroutine does not return */

    printf(0xa793190);

  }

  if (param_2 - 2U < 0x3b) {

                    /* WARNING: Subroutine does not return */

    printf(0xa7930e4,param_1,0,param_1 * 0x10 + 0x38,param_1 * 0x10 + 0x39);

  }

                    /* WARNING: Subroutine does not return */

  printf(0xa793160,2,0x3c);

}



