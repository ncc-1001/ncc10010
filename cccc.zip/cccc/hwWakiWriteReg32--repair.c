#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern char cRam10c8f925;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t hwWakiWriteReg32(uint param_1,uint param_2,uint32_t param_3)



{

  int iVar1;

  int iVar2;

  

  if ((param_2 & 3) != 0) {

    timosAssert(0xa7afed0,0xa7afee4,0x68,0xa7aff70,0xa7afeb0,param_2);

  }

  iVar2 = param_2 + param_1 * 0x100000;

  if ((byte)(cRam10c8f925 + 0x1eU) < 6) {

    if ((param_1 < 8) && ((1 << (param_1 & 0x1f) & 0x91U) != 0)) {

                    /* WARNING: Bad instruction - Truncating control flow here */

      halt_baddata();

    }

    if ((_traceEnabled != 0) ||

       ((_tracepointsActive != 0 && (iVar2 = traceTest(_MOD_MDADRV,0xa7aff70,4,0), iVar2 != 0)))) {

      tracePrintVRtr(_MOD_MDADRV,0xa7aff70,4,0,1,0xa7aff10,param_1);

    }

    return 0;

  }

  if (8 < param_1) {

    if (_traceEnabled == 0) {

      if (_tracepointsActive == 0) {

        return 0xffffffff;

      }

      iVar2 = traceTest(_MOD_MDADRV,0xa7aff70,4,0);

      if (iVar2 == 0) {

        return 0xffffffff;

      }

    }

    tracePrintVRtr(_MOD_MDADRV,0xa7aff70,4,0,1,0xa7aff10,param_1);

    return 0xffffffff;

  }

  iVar1 = hwSarmFpgaMciWrite(0,iVar2,param_3);

  if (iVar1 != -1) {

    return 0;

  }

  if (_traceEnabled == 0) {

    if (_tracepointsActive == 0) {

      return 0xffffffff;

    }

    iVar1 = traceTest(_MOD_MDADRV,0xa7aff70,4,0);

    if (iVar1 == 0) {

      return 0xffffffff;

    }

  }

  tracePrintVRtr(_MOD_MDADRV,0xa7aff70,4,0,1,0xa7aff84,param_1,iVar2,param_3);

  return 0xffffffff;

}


