#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

uint32_t isisRtmDestroy(uint32_t *param_1)
{
  uint32_t *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint32_t uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  uint uVar10;
  
  if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x800) == 0)) ||
     (iVar4 = isisDebugCheck(param_1,0x800,0,0), iVar4 == 0)) {
    uVar10 = 0;
    iVar4 = 0;
  }
  else if (_IsisLogger == 0) {
    uVar10 = 0;
    tracePrint(_MOD_ISIS,0xa1af530,0,0,0xa1af540);
    iVar4 = 0;
  }
  else {
    logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af540);
    uVar10 = 0;
    iVar4 = 0;
  }
  do {
    puVar1 = param_1 + iVar4 * 2 + 0x22c;
    iVar7 = 1;
    do {
      iVar7 = iVar7 + -1;
      *puVar1 = 0;
      puVar1 = puVar1 + 7;
    } while (-1 < iVar7);
    uVar10 = uVar10 + 1;
    iVar4 = iVar4 + 7;
  } while (uVar10 < 2);
  param_1[0x245] = 0;
  param_1[0x247] = 0;
  uVar10 = 0;
  iVar4 = 0;
  do {
    puVar1 = param_1 + iVar4 * 2 + 0x22e;
    iVar7 = 1;
    uVar5 = *puVar1;
    while( true ) {
      iVar7 = iVar7 + -1;
      puVar1 = puVar1 + 7;
      timerDelete(uVar5);
      if (iVar7 < 0) break;
      uVar5 = *puVar1;
    }
    uVar10 = uVar10 + 1;
    iVar4 = iVar4 + 7;
  } while (uVar10 < 2);
  uVar10 = 0;
  puVar1 = param_1;
  do {
    iVar4 = rtGetFirstRoute(puVar1[0x1c1]);
    while (iVar4 != 0) {
      iVar7 = rtGetNextRoute(puVar1[0x1c1],iVar4);
      isisSummWalkSnmpDelete(iVar4,param_1,0);
      iVar4 = iVar7;
    }
    uVar10 = uVar10 + 1;
    rtDeleteRouteTable(puVar1[0x1c1]);
    puVar1[0x1c1] = 0;
    puVar1 = puVar1 + 1;
  } while (uVar10 < 2);
  iVar4 = 0;
  do {
    uVar10 = 0;
    iVar7 = iVar4 << 1;
    do {
      puVar1 = param_1 + iVar7 * 2;
      iVar8 = 1;
      do {
        iVar8 = iVar8 + -1;
        rtDeleteRouteTable(puVar1[0x1b9]);
        puVar1[0x1b9] = 0;
        puVar1 = puVar1 + 1;
      } while (-1 < iVar8);
      uVar10 = uVar10 + 1;
      iVar7 = iVar7 + 1;
    } while (uVar10 < 2);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 2);
  iVar7 = 0;
  iVar4 = 0;
  do {
    iVar4 = iVar4 + (int)param_1;
    uVar10 = 0;
    do {
      piVar9 = (int *)(iVar4 + 0x6bc);
      iVar8 = 1;
      do {
        iVar6 = *piVar9;
        if (iVar6 != 0) {
          iVar2 = rtGetFirstRoute(iVar6);
          while (iVar2 != 0) {
            iVar3 = rtGetNextRoute(iVar6,iVar2);
            isisRouteWalkDelete(iVar2,param_1,(iVar7 != 0) + '\x01',uVar10);
            rtRemoveRoute(iVar6,iVar2);
            iVar2 = iVar3;
          }
          rtDeleteRouteTable(iVar6);
          *piVar9 = 0;
        }
        iVar8 = iVar8 + -1;
        piVar9 = piVar9 + 1;
      } while (-1 < iVar8);
      uVar10 = uVar10 + 1;
      iVar4 = iVar4 + 8;
    } while (uVar10 < 2);
    iVar7 = iVar7 + 1;
    iVar4 = iVar7 * 0x10;
  } while (iVar7 < 2);
  return 0;
}