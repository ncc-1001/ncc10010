#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undefined global variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern unsigned int _currentSfpCtrlStatus;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwSarmFpgaSfpTxLaserEnableAll(unsigned int param_1) // Modified: Changed 'uint' to 'unsigned int' for compilation


{

  int in_zero;

  int iVar1;

  unsigned int uVar2; // Modified: Changed 'uint' to 'unsigned int' for compilation

  unsigned int auStack_10 [2]; // Modified: Changed 'uint' to 'unsigned int' for compilation
  
  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) != -0x23) {

    iVar1 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    uVar2 = param_1 & 1;

    if (*(char *)(iVar1 + 0x10c8f925) != -0x12) {

      if (_currentSfpCtrlStatus ==

          (_currentSfpCtrlStatus & 0x77777777 | uVar2 << 3 | uVar2 << 7 | uVar2 << 0xb |

           uVar2 << 0xf | uVar2 << 0x13 | uVar2 << 0x17 | uVar2 << 0x1b | (param_1 & 0xff) << 0x1f))

      {

        return;

      }

                    /* WARNING: Bad instruction - Truncating control flow here */

      halt_baddata();

    }

  }

  auStack_10[0] = 0;

  hwSarmFpgaMciRead(0,0x24,auStack_10);

  uVar2 = auStack_10[0] | 0xc00;

  if ((param_1 & 0xff) == 0) {

    uVar2 = auStack_10[0] & 0xfffff3ff;

  }

  if (auStack_10[0] == uVar2) {

    return;

  }

  auStack_10[0] = uVar2;

  hwSarmFpgaMciWrite(0,0x24);

  return;

}
