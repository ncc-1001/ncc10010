#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t configRouterIsisAuthPerMessage(uint32_t param_1,uint32_t param_2,uint32_t param_3)



{

  int iVar1;

  uint32_t uVar2;

  uintptr_t auStack_d8 [200];

  

  iVar1 = strcmp(param_3,0xa07d0f4);

  uVar2 = 0xa07d104;

  if (iVar1 != 0) {

    iVar1 = strcmp(param_3,0xa07d0fc,0xa07d104);

    uVar2 = 0xa07d128;

    if (iVar1 != 0) {

      iVar1 = strcmp(param_3,0xa07d120,0xa07d128);

      uVar2 = 0xa07d164;

      if (iVar1 != 0) {

        return 0xffffffff;

      }

    }

  }

  snprintf(auStack_d8,200,uVar2);

  ___chk_strnum = 1;

  iVar1 = cfgRouterIndexElements(param_1,param_2,auStack_d8,0,0xa07cc30);

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07d144);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}



