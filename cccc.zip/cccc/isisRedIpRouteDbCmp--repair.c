#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _isisMutex; // Modified: Added extern declaration for '_isisMutex'

void isisRedIpRouteDbCmp(uint32_t param_1,uint32_t param_2,uint32_t param_3) // Modified: Replaced 'uint' with 'uint32_t' for consistency


{

  if (param_3 < 0x38) {

    timosAssert(0xa1ac98c,0xa1ac610,0x1533,0xa1ad64c,0xa1ac5b8);

  }

                    /* WARNING: Subroutine does not return */

  semTake(_isisMutex,0xffffffff);

}