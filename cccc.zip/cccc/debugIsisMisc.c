#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t debugIsisMisc(uint32_t param_1,uint32_t param_2,char param_3)



{

  uint auStack_128 [72];

  

  memset(auStack_128,0,0x120);

  auStack_128[0] = auStack_128[0] | 0x20000;

  if (param_3 != '\0') {

    isisDebugOff(1);

    return 0;

  }

  isisDebugOn(1,auStack_128);

  return 0;

}



