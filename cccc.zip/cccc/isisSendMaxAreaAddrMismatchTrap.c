#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendMaxAreaAddrMismatchTrap(uint32_t *param_1,int param_2,int param_3,int param_4)



{

  uintptr_t uVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uintptr_t auStack_1a8 [400];

  

  auStack_1a8[0] = 0;

  uVar1 = *(uintptr_t *)(param_3 + 7);

  if (0x40 < param_4) {

    param_4 = 0x40;

  }

  logger_OctetsHexDump(param_3,param_4,auStack_1a8,400);

  uVar2 = strlen(auStack_1a8);

  uVar3 = *param_1;

  logEvent_ISIS_vRtrIsisMaxAreaAddrsMismatch

            (uVar3,0xa1bba50,uVar3,uVar1,uVar3,*(uint32_t *)(param_2 + 8),param_3,param_4,

             auStack_1a8,uVar2);

  return;

}



