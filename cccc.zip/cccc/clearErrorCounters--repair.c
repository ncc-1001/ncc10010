#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern char err_code_str;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void clearErrorCounters(uint param_1)


{

  char cVar1;

  int in_zero;

  uint32_t *puVar2;

  int iVar3;

  uint32_t uVar4;

  char *pcVar5;

  

  iVar3 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if ((*(char *)(iVar3 + 0x10c8f925) != -0x24) || (uVar4 = 0x69b8efc, param_1 < 8)) {

    puVar2 = (uint32_t *)(param_1 * 0xeb8 + 0xc028520);

    pcVar5 = &err_code_str;

    iVar3 = 0x11;

    do {

      cVar1 = *pcVar5;

      iVar3 = iVar3 + -1;

      pcVar5 = pcVar5 + 0x1e;

      if (cVar1 != '\0') {

        *puVar2 = 0;

      }

      puVar2 = puVar2 + 1;

    } while (-1 < iVar3);

    iVar3 = param_1 * 0xeb8;

    uVar4 = 0x69b8ed8;

    *(uint32_t *)(iVar3 + 0xc0285c0) = 0;

    *(uint32_t *)(iVar3 + 0xc0285c4) = 0;

    *(uint32_t *)(iVar3 + 0xc02859c) = 0;

    *(uint32_t *)(iVar3 + 0xc0285a0) = 0;

    *(uint32_t *)(iVar3 + 0xc0285a4) = 0;

    *(uint32_t *)(iVar3 + 0xc0285a8) = 0;

    *(uint32_t *)(iVar3 + 0xc0285ac) = 0;

    *(uint32_t *)(iVar3 + 0xc0285b0) = 0;

    *(uint32_t *)(iVar3 + 0xc0285b4) = 0;

    *(uint32_t *)(iVar3 + 0xc0285b8) = 0;

    *(uint32_t *)(iVar3 + 0xc0285bc) = 0;

  }

                    /* WARNING: Subroutine does not return */

  printf(uVar4);

}


