#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendManAreaAddrDropTrap(uint32_t *param_1,uintptr_t *param_2)



{

  logEvent_ISIS_vRtrIsisManualAddressDrops

            (*param_1,0xa1bb9dc,*param_1,param_2 + 1,*param_2,(param_2[0xf] != '\x01') + '\x01');

  return;

}



