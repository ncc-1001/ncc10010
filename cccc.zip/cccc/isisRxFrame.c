#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t * isisRxFrame(int param_1,uint32_t param_2,char *param_3,int param_4,int param_5)



{

  uint32_t *puVar1;

  int iVar2;

  

  puVar1 = (uint32_t *)0x0;

  if (param_4 != 0 && param_5 != 0) {

    iVar2 = redAmIActive(0x34);

    if ((((iVar2 == 0) || (param_1 != 1)) || (1 < (byte)(*param_3 + 0x7eU))) ||

       (puVar1 = (uint32_t *)isisMalloc(0x14), puVar1 == (uint32_t *)0x0)) {

      pbufFree(param_5);

      return (uint32_t *)0x0;

    }

    *puVar1 = 1;

    puVar1[2] = 8;

    puVar1[3] = param_2;

    puVar1[4] = param_5;

    puVar1[1] = 0;

  }

  return puVar1;

}



