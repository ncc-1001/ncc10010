#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void cliConfigRouterIsisSummaryAddressHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t uVar6;

  uint32_t *puStack_38;

  uint32_t *puStack_34;

  uint32_t *puStack_30;

  uint32_t *puStack_2c;

  uint32_t *apuStack_28 [2];

  

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_38);

  uVar3 = 0;

  uVar5 = 0;

  uVar6 = 0;

  if (iVar1 == 0) {

    uVar3 = *puStack_38;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,&puStack_34);

  if (iVar1 == 0) {

    uVar4 = *puStack_34;

    iVar1 = RCC_DB_RetrieveParam(param_2,0,4,&puStack_30);

    if (iVar1 == 0) {

      uVar5 = *puStack_30;

    }

    iVar1 = RCC_DB_RetrieveParam(param_2,0,8,&puStack_2c);

    if (iVar1 == 0) {

      uVar2 = *puStack_2c;

      iVar1 = RCC_DB_RetrieveParam(param_2,0xa3975e0,0x10,apuStack_28);

      if (iVar1 == 0) {

        uVar6 = *apuStack_28[0];

      }

      configRouterIsisSummAddress(param_1,uVar3,uVar4,uVar5,uVar2,uVar6);

    }

  }

  return;

}



