#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int iRam00000298;
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

uint32_t isisGetL2Info(uint32_t *param_1,uint32_t *param_2)

{

  char cVar1;

  uint uVar2;

  uint32_t *puVar3;

  int iVar4;

  uint32_t uVar5;

  uint uVar6;

  int iVar7;

  uintptr_t auStack_18 [3];

  uintptr_t uStack_15;
  
  if (param_2[0xbc] == 0) {
    iVar4 = 1;
    if ((*(byte *)((int)param_2 + 0x1b2) & 4) == 0) {
      iVar4 = 2;
    }
    param_2[0xbd] = iVar4;
    if (iVar4 == 2) {
      cVar1 = *(char *)((int)param_2 + 0x2f9);
      goto LAB_04203874;
    }
LAB_042038f8:
    if (iVar4 != 1) goto LAB_0420389c;
    iVar4 = param_2[0xc4];
  }
  else {
    iVar4 = param_2[0xbd];
    if (iVar4 != 2) goto LAB_042038f8;
    cVar1 = *(char *)((int)param_2 + 0x2f9);
LAB_04203874:
    if (cVar1 == '\0') {
      iVar4 = bitMapGetFree(param_1[0xa9],auStack_18,0);
      if (iVar4 != 0) {
        iVar4 = iRam00000298;
        if (param_1 != (uint32_t *)0x0) {
          if ((param_1[0x1b] & 0x40) == 0) {
            iVar4 = param_1[0xa6];
          }
          else {
            iVar4 = isisDebugCheck(param_1,0x40,param_2,0);
            if (iVar4 == 0) {
              iVar4 = param_1[0xa6];
            }
            else if (_IsisLogger == 0) {
              tracePrint(_MOD_ISIS,0xa1a899c,0,0,0xa1a89ac,param_2[2]);
              iVar4 = param_1[0xa6];
            }
            else {
              logEvent_debug_fmt(*param_1,0xa1a7e00,&isisTitleStr,0xa1a89ac,param_2[2]);
              iVar4 = param_1[0xa6];
            }
          }
        }
        param_1[0xa6] = iVar4 + 1;
        isisSendMaxCircIDReachedTrap(param_1,param_2);
        return 0x23;
      }
      *(uintptr_t *)((int)param_2 + 0x2f9) = 1;
      *(uintptr_t *)(param_2 + 0xc5) = uStack_15;
      iVar4 = param_2[0xbd];
      *(uintptr_t *)((int)param_2 + 0x41e) = *(uintptr_t *)(param_2 + 0xc5);
      *(uintptr_t *)((int)param_2 + 0x5ee) = *(uintptr_t *)(param_2 + 0xc5);
    }
    else {
      iVar4 = param_2[0xbd];
      *(uintptr_t *)((int)param_2 + 0x41e) = *(uintptr_t *)(param_2 + 0xc5);
      *(uintptr_t *)((int)param_2 + 0x5ee) = *(uintptr_t *)(param_2 + 0xc5);
    }
    if (iVar4 != 1) goto LAB_0420389c;
    iVar4 = param_2[0xc4];
  }
  if ((iVar4 == 0) && (iVar4 = bitMapGetFree(param_1[0xaa],param_2 + 0xc4,0), iVar4 != 0)) {
    return 0x23;
  }
LAB_0420389c:
  isisCircGetTeInfo(param_1,param_2);
  iVar7 = 1;
  iVar4 = param_2[0xbf];
  do {
    if (iVar4 == iVar7) {
      uVar5 = *param_2;
LAB_04203934:
      uVar5 = isisCircGetDefaultMetric(uVar5,param_2,iVar7);
      uVar6 = 0;
      puVar3 = param_2 + 0x16e;
      if (iVar7 == 1) goto LAB_0420398c;
      uVar2 = (uint)*(byte *)(param_2 + 0x184);
      while( true ) {
        if (((int)uVar2 >> (uVar6 & 0x1f) & 1U) == 0) {
          if (iVar7 == 1) {
            puVar3[-0x74] = uVar5;
          }
          else {
            *puVar3 = uVar5;
          }
        }
        uVar6 = uVar6 + 1;
        puVar3 = puVar3 + 1;
        if (1 < uVar6) break;
        if (iVar7 == 1) {
LAB_0420398c:
          uVar2 = (uint)*(byte *)(param_2 + 0x110);
        }
        else {
          uVar2 = (uint)*(byte *)(param_2 + 0x184);
        }
      }
    }
    else if (iVar4 == 3) {
      uVar5 = *param_2;
      goto LAB_04203934;
    }
    iVar7 = iVar7 + 1;
    if (2 < iVar7) {
      return 0;
    }
    iVar4 = param_2[0xbf];
  } while( true );
}
