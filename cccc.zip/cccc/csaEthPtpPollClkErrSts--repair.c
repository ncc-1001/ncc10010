#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared global variable _gMdaInfo
extern int *_gMdaInfo;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void csaEthPtpPollClkErrSts(uint param_1)



{

  int iVar1;

  

  iVar1 = xmacRedIsCardActive();

  if ((iVar1 != 0) && (iVar1 = macMdaRemoved(param_1), iVar1 == 0)) {

    fpgaUBlazePollDiagErrSts(param_1);

    fpgaUBlazePollExcepIndSts(param_1);

    fpgaUBlazePollEccSts(param_1);

    if (param_1 != 0) {

      iVar1 = param_1 * 0x3a88;

      if ((((param_1 <= *_gMdaInfo) && (*(char *)(iVar1 + 0x10d260a8) != '\0')) &&

          ((char *)(iVar1 + 0x10d260a8) != (char *)0x0)) &&

         ((iVar1 != -0x10d260c0 && (*(char *)(iVar1 + 0x10d26100) != '\0')))) {

        fpgaUBlazePollClkErrSts(param_1);

        return;

      }

    }

  }

  return;

}
