#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared identifier _MOD_ATIC_L3
extern int _MOD_ATIC_L3;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t ARP_GetIfConfig(uint32_t param_1,uint32_t param_2,int param_3)



{

  int iVar1;

  

  ARP_Lock();

  iVar1 = arp_getObj(param_1);

  if (iVar1 != 0) {

    iVar1 = arp_getIf(iVar1,param_2);

    if (iVar1 != 0) {

      strncpy(param_3,iVar1 + 0x68,0x20);

      *(uintptr_t *)(param_3 + 0x1f) = 0;

      *(uint32_t *)(param_3 + 0x20) = *(uint32_t *)(iVar1 + 0x3c);

      *(uint32_t *)(param_3 + 0x24) = *(uint32_t *)(iVar1 + 0x40);

      *(uint32_t *)(param_3 + 0x28) = *(uint32_t *)(iVar1 + 0x44);

      *(uint32_t *)(param_3 + 0x2c) = *(uint32_t *)(iVar1 + 0x4c);

      *(uint *)(param_3 + 0x30) = (uint)*(byte *)(iVar1 + 0x9b);

      *(uint32_t *)(param_3 + 0x34) = *(uint32_t *)(iVar1 + 0x50);

      *(uint32_t *)(param_3 + 0x38) = *(uint32_t *)(iVar1 + 100);

      *(uint32_t *)(param_3 + 0x3c) = *(uint32_t *)(iVar1 + 0x88);

      *(uint32_t *)(param_3 + 0x40) = *(uint32_t *)(iVar1 + 0x90);

      *(uint32_t *)(param_3 + 0x44) = *(uint32_t *)(iVar1 + 0x94);

      ARP_UnLock();

      return 0;

    }

  }

  if ((_traceEnabled == 0) &&

     ((_tracepointsActive == 0 || (iVar1 = traceTest(_MOD_ATIC_L3,0x9f6365c,4,7), iVar1 == 0)))) {

    ARP_UnLock();

  }

  else {

    tracePrintVRtr(_MOD_ATIC_L3,0x9f6365c,4,7,1,0x9f6366c,param_2);

    ARP_UnLock();

  }

  return 3;

}
