#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared globals
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_FIREWALL;

uint32_t firewallWriteInterfacePlcy(int param_1)
{
  uint32_t *puVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  int iVar4;
  uintptr_t auStack_168 [264];
  uintptr_t auStack_60 [40];
  uintptr_t auStack_38 [40];
  
  puVar1 = (uint32_t *)firemgrGetZone(1,*(uint32_t *)(param_1 + 0x44));
  iVar4 = *(int *)(param_1 + 0x44);
  uVar2 = 0;
  if (iVar4 != 0) {
    if (puVar1 == (uint32_t *)0x0) {
      if (_traceEnabled == 0) {
        if (_tracepointsActive == 0) {
          return 0xffffffff;
        }
        iVar4 = traceTest(_MOD_FIREWALL,0xa17d884,4,0);
        if (iVar4 == 0) {
          return 0xffffffff;
        }
        iVar4 = *(int *)(param_1 + 0x44);
      }
      tracePrintVRtr(_MOD_FIREWALL,0xa17d884,4,0,1,0xa17d8c0,iVar4);
      uVar2 = 0xffffffff;
    }
    else {
      uVar2 = FmtPlcyZoneName(auStack_60,0x21,*puVar1);
      uVar3 = FmtPlcyInterfaceName(auStack_38,0x21,param_1);
      snprintf(auStack_168,0x101,0xa17d8a0,uVar2,uVar3);
      uVar2 = firewallWrite(0,auStack_168);
    }
  }
  return uVar2;
}