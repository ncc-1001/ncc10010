#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undefined global variables
extern int _traceEnabled;
extern int _tracepointsActive;
extern uint32_t _MOD_MDADRV;

uint32_t fpgaUBlazeGetRxCtbOffset(uint32_t param_1,uint32_t *param_2,uint32_t *param_3)

{

  int iVar1;

  uint32_t uVar2;

  

  if (param_2 != (uint32_t *)0x0 && param_3 != (uint32_t *)0x0) {

    uVar2 = _fpgaUBlazeRegRead(param_1,0xbc);

    *param_2 = uVar2;

    uVar2 = _fpgaUBlazeRegRead(param_1,0xc0);

    *param_3 = uVar2;

    return 0;

  }

  if (_traceEnabled == 0) {

    if (_tracepointsActive == 0) {

      *param_2 = 0;

      goto LAB_063b8f4c;

    }

    iVar1 = traceTest(_MOD_MDADRV,0xa8dd2dc,4,0);

    if (iVar1 == 0) {

      *param_2 = 0;

      goto LAB_063b8f4c;

    }

  }

  tracePrintVRtr(_MOD_MDADRV,0xa8dd2dc,4,0,1,0xa8dd298,param_1);

  *param_2 = 0;

LAB_063b8f4c:

  *param_3 = 0;

  return 0;

}
