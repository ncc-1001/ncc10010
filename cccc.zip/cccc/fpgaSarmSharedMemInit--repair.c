#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added declaration for undeclared variable cRam10c8f925
int cRam10c8f925;
// Modified: Added declaration for undeclared variable _gFpgaSarmSharedMem
uint32_t _gFpgaSarmSharedMem;
// Modified: Added declaration for undeclared variable _gFpgaSarmSharedMemWp3PcieAddr
uint32_t _gFpgaSarmSharedMemWp3PcieAddr;
// Modified: Added declaration for undeclared variable gFpgaSarmSharedMemWp3PcieAddr
uint32_t gFpgaSarmSharedMemWp3PcieAddr;


void fpgaSarmSharedMemInit(uint32_t param_1)

{

  int iVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  
  if ((cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12) ||
     (uVar3 = 0, (byte)(cRam10c8f925 + 0x1eU) < 6)) {
    uVar3 = 1;
  }
  if (_gFpgaSarmSharedMem != 0) {
    hwFreeCaviumRCInternalBAR1Region(uVar3,param_1,_MOD_MDADRV);
    _gFpgaSarmSharedMem = 0;
    _gFpgaSarmSharedMemWp3PcieAddr = 0;
  }
  _gFpgaSarmSharedMem =
       hwAllocCaviumRCInternalBAR1Region
                 (0x4000,uVar3,param_1,&gFpgaSarmSharedMemWp3PcieAddr,_MOD_MDADRV);
  if (_gFpgaSarmSharedMem == 0) {
    if ((_traceEnabled != 0) ||
       ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8d8744,4,0), iVar1 != 0)))) {
      uVar2 = 4;
      uVar3 = 0xa8d875c;
      goto LAB_063aa41c;
    }
  }
  else if ((_tracepointsActive != 0) && (iVar1 = traceTest(_MOD_MDADRV,0xa8d8744,1,0), iVar1 != 0))
  {
    uVar2 = 1;
    uVar3 = 0xa8d87a8;
LAB_063aa41c:
    tracePrintVRtr(_MOD_MDADRV,0xa8d8744,uVar2,0,1,uVar3,param_1,_gFpgaSarmSharedMem,
                   _gFpgaSarmSharedMemWp3PcieAddr);
    return;
  }
  return;
}