#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendMaxSeqExceedTrap(uint32_t *param_1,uint32_t param_2,uint32_t param_3)



{

  uint32_t uVar1;

  uintptr_t auStack_38 [40];

  

  auStack_38[0] = 0;

  FmtIsisLSPId(*param_1,param_3,8,auStack_38,0x21,1);

  uVar1 = strlen(auStack_38);

  logEvent_ISIS_vRtrIsisMaxSeqExceedAttempt

            (*param_1,0xa1bba14,*param_1,param_2,param_3,8,auStack_38,uVar1);

  return;

}



