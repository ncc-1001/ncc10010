#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t

debugIsisPacket(uint32_t param_1,uint32_t param_2,int param_3,int param_4,int param_5,

               char param_6)



{

  int iVar1;

  uint auStack_138 [21];

  uint uStack_e4;

  uint32_t uStack_e0;

  uintptr_t auStack_dc [196];

  

  memset(auStack_138,0,0x120);

  auStack_138[0] = auStack_138[0] | 8;

  if (param_3 != 0) {

    uStack_e0 = isisGetPktType(param_3);

    uStack_e4 = uStack_e4 | 1;

  }

  if (param_4 != 0) {

    iVar1 = getIndexFromInterface(1,param_4,auStack_dc);

    if (iVar1 != 0) {

      cliErrorMesg(param_1,0x9fffdf4);

      return 0xffffffff;

    }

    uStack_e4 = uStack_e4 | 2;

  }

  if (param_5 != 0) {

    uStack_e4 = uStack_e4 | 8;

  }

  if (param_6 == '\0') {

    isisDebugOn(1,auStack_138);

  }

  else {

    isisDebugOff(1,auStack_138);

  }

  return 0;

}



