#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added missing declaration for _traceEnabled
int _traceEnabled;
// Modified: Added missing declaration for _tracepointsActive
int _tracepointsActive;
// Modified: Added missing declaration for _MOD_MDADRV
int _MOD_MDADRV;

uint32_t csaEthPmcCdce6200xWinpath3Init(uint32_t param_1)

{

  uint32_t uVar1;

  uint uVar2;

  int iVar3;

  int iVar4;

  uint uVar5;

  uint auStack_28 [2];
  
  uVar1 = mdaGetAnyMda();
  uVar2 = mdaGetMdaHwType(uVar1);
  iVar3 = xmacRedIsCardActive(param_1);
  uVar1 = 0;
  if (iVar3 != 0) {
    iVar3 = macMdaRemoved(param_1);
    if (iVar3 == 0) {
      iVar3 = cdceWrite(param_1,6,0,0x205e027);
      uVar1 = 0xffffffff;
      if (iVar3 == 0) {
        iVar3 = cdceWrite(param_1,6,1,0x921b4f8);
        uVar1 = 0xffffffff;
        if (iVar3 == 0) {
          iVar3 = cdceWrite(param_1,6,2,0x180);
          uVar1 = 0xffffffff;
          if (iVar3 == 0) {
            iVar3 = cdceWrite(param_1,6,2,0x100);
            uVar1 = 0xffffffff;
            if (iVar3 == 0) {
              iVar3 = cdceWrite(param_1,6,2,0x180);
              uVar1 = 0xffffffff;
              if (iVar3 == 0) {
                iVar3 = cdceWrite(param_1,4,0,0xe2de027);
                uVar1 = 0xffffffff;
                if (iVar3 == 0) {
                  iVar3 = cdceWrite(param_1,4,1,0x9289c9e);
                  uVar1 = 0xffffffff;
                  if (iVar3 == 0) {
                    iVar3 = cdceWrite(param_1,4,2,0x180);
                    uVar1 = 0xffffffff;
                    if (iVar3 == 0) {
                      iVar3 = cdceWrite(param_1,4,2,0x100);
                      uVar1 = 0xffffffff;
                      if (iVar3 == 0) {
                        iVar3 = cdceWrite(param_1,4,2,0x180);
                        uVar1 = 0xffffffff;
                        if (iVar3 == 0) {
                          uVar5 = 0x526027;
                          if ((((uVar2 ^ 0xaa) == 0 || (uVar2 ^ 0x9b) == 0) ||
                              (uVar2 == 0x91 || uVar2 == 0x9a)) || (uVar2 == 0xae || uVar2 == 0xa9))
                          {
                            uVar5 = 0x1526027;
                          }
                          iVar3 = cdceWrite(param_1,5,0,uVar5 | 0x8000000);
                          uVar1 = 0xffffffff;
                          if (iVar3 == 0) {
                            if ((((uVar2 ^ 0xaa) == 0 || (uVar2 ^ 0x9b) == 0) ||
                                (uVar2 == 0x91 || uVar2 == 0x9a)) ||
                               (uVar2 == 0xae || uVar2 == 0xa9)) {
                              uVar2 = 0x389e02;
                            }
                            else {
                              uVar2 = 0x1389e02;
                            }
                            iVar3 = cdceWrite(param_1,5,1,uVar2 | 0x8000000);
                            uVar1 = 0xffffffff;
                            if (iVar3 == 0) {
                              iVar3 = cdceWrite(param_1,5,2,0x180);
                              uVar1 = 0xffffffff;
                              if (iVar3 == 0) {
                                iVar3 = cdceWrite(param_1,5,2,0x100);
                                uVar1 = 0xffffffff;
                                if (iVar3 == 0) {
                                  iVar3 = cdceWrite(param_1,5,2,0x180);
                                  uVar1 = 0xffffffff;
                                  if (iVar3 == 0) {
                                    auStack_28[0] = 0;
                                    iVar3 = 10;
                                    do {
                                      taskDelay(1);
                                      iVar3 = iVar3 + -1;
                                      auStack_28[0] = 0;
                                      iVar4 = mdaSpiderStatusGet(param_1,0xe00000,0,auStack_28);
                                      if ((iVar4 != 0) || (iVar3 == 0)) break;
                                    } while ((auStack_28[0] & 0xe00000) != 0xe00000);
                                    uVar1 = 0;
                                    if ((auStack_28[0] & 0xe00000) != 0xe00000) {
                                      iVar3 = macMdaRemoved(param_1);
                                      uVar1 = 0xffffffff;
                                      if (iVar3 == 0) {
                                        if (_traceEnabled == 0) {
                                          if (_tracepointsActive == 0) {
                                            return 0xffffffff;
                                          }
                                          iVar3 = traceTest(_MOD_MDADRV,0xa8ec878,4,0);
                                          if (iVar3 == 0) {
                                            return 0xffffffff;
                                          }
                                        }
                                        tracePrintVRtr(_MOD_MDADRV,0xa8ec878,4,0,1,0xa8ec898,param_1
                                                       ,auStack_28[0]);
                                        uVar1 = 0xffffffff;
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    else {
      uVar1 = 0;
    }
  }
  return uVar1;
}
