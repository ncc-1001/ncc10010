#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int ___chk_strnum; // Modified: Added extern declaration for undeclared global variable

uint32_t

configRouterIsisSpfWait(uint32_t param_1,uint32_t param_2,int param_3,int param_4,int param_5)

{

  int iVar1;

  uint32_t uVar2;

  

  if (param_3 == 0) {

    ___chk_strnum = 10;

    param_3 = 0xa07d524;

  }

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d49c,0,param_3);

  uVar2 = 0xa07d4ac;

  if (iVar1 == 0) {

    if (param_4 == 0) {

      ___chk_strnum = 1000;

      param_4 = 0xa07d528;

    }

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d4cc,0,param_4);

    uVar2 = 0xa07d4e4;

    if (iVar1 == 0) {

      if (param_5 == 0) {

        ___chk_strnum = 1000;

        param_5 = 0xa07d528;

      }

      iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d50c,0,param_5);

      if (iVar1 == 0) {

        return 0;

      }

      uVar2 = 0xa07d530;

    }

  }

  cliErrorMesg(param_1,uVar2);

  return 0xffffffff;

}
