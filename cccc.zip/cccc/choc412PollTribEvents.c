#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void choc412PollTribEvents(uint32_t param_1)



{

  uint *puVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t uVar6;

  uint uVar7;

  ushort uStack_30;

  ushort uStack_2e;

  ushort uStack_28;

  ushort uStack_26;

  

  puVar1 = (uint *)posMdaTribGetStateSonet();

  iVar2 = posMdaTribGetPort(param_1);

  uVar3 = posMdaTribGetChanType(param_1);

  switch(uVar3) {

  case 6:

    uVar3 = csaOcnUtilsTribStm1Number(param_1);

    uVar4 = csaOcnUtilsTribAu3Tug3Number(param_1);

    ufe4SonetSdhHoppPathPerfMon(iVar2,uVar3,uVar4,&uStack_30);

    if (uStack_30 == 0) {

      uVar7 = *puVar1;

    }

    else {

      puVar1[9] = puVar1[9] + (uint)uStack_30;

      *(uintptr_t *)(iVar2 + 0x1af) = 1;

      uVar7 = *puVar1;

    }

    uVar7 = uVar7 & 0xf7ffffff;

    *puVar1 = uVar7;

    uStack_26 = uStack_2e;

    break;

  default:

    goto LAB_06438afc;

  case 9:

  case 10:

    uVar3 = csaOcnUtilsTribStm1Number(param_1);

    uVar4 = csaOcnUtilsTribAu3Tug3Number(param_1);

    uVar5 = csaOcnUtilsTribTug2Number(param_1);

    uVar6 = csaOcnUtilsTribTuNumber(param_1);

    ufe4SonetSdhLoppPathPerfMon(iVar2,uVar3,uVar4,uVar5,uVar6,&uStack_28);

    if (uStack_28 == 0) {

      uVar7 = *puVar1;

    }

    else {

      puVar1[9] = puVar1[9] + (uint)uStack_28;

      *(uintptr_t *)(iVar2 + 0x1af) = 1;

      uVar7 = *puVar1;

    }

    uVar7 = uVar7 & 0xf7ffffff;

    *puVar1 = uVar7;

    break;

  case 0xe:

  case 0xf:

  case 0x10:

  case 0x11:

    ufe4PdhPollTribEvents(param_1);

    return;

  case 0x12:

    iVar2 = posMdaTribGetFwdChan(param_1);

    uVar3 = 0;

    if (iVar2 != 0) {

      uVar3 = posMdaFwdChanGetEncapType(iVar2);

    }

    iVar2 = encapIsCEM(uVar3);

    if ((iVar2 != 0) && (iVar2 = miniTdmCsaTribPresentInWinpath(param_1), iVar2 != 0)) {

      miniTdmCsaTribUpdatePwe3TdmPmonSample(param_1,1);

    }

    goto LAB_06438afc;

  }

  if (uStack_26 != 0) {

    *puVar1 = uVar7 | 0x8000000;

    puVar1[8] = puVar1[8] + (uint)uStack_26;

    *(uintptr_t *)(iVar2 + 0x1af) = 1;

  }

LAB_06438afc:

  return;

}



