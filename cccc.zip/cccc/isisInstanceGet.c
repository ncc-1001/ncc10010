#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisInstanceGet(int param_1,int param_2)



{

  int iVar1;

  uint32_t auStack_10 [2];

  

  auStack_10[0] = 0;

  if (param_1 != 2) {

    if (2 < param_1) {

      return 0;

    }

    if (param_1 != 1) {

      return 0;

    }

    if (param_2 != 1) {

      return 0;

    }

  }

  iVar1 = isisGetNode(1,auStack_10);

  if (iVar1 == 0) {

    return auStack_10[0];

  }

  return 0;

}



