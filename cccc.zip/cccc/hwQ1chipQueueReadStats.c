#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwQ1chipQueueReadStats(int param_1,uint param_2)



{

  int iVar1;

  uint32_t uVar2;

  

  if (_MyChassisType == 0x11) {

    if (param_2 < 0x4000) {

LAB_02e32724:

      memset(*(int *)(param_2 * 4 + param_1 + 0x2118) + 0xe0,0,0x80);

      return;

    }

    if (_tracepointsActive == 0) {

      return;

    }

    iVar1 = traceTest(_MOD_RCHIPS,0x9ccd188,1,0x1c);

    if (iVar1 == 0) {

      return;

    }

    uVar2 = 0x9ccd1a0;

  }

  else {

    if (param_2 < 0x2400) goto LAB_02e32724;

    if (_tracepointsActive == 0) {

      return;

    }

    iVar1 = traceTest(_MOD_RCHIPS,0x9ccd188,1,0x1c);

    if (iVar1 == 0) {

      return;

    }

    uVar2 = 0x9ccd1d0;

  }

  tracePrintVRtr(_MOD_RCHIPS,0x9ccd188,1,0x1c,1,uVar2,param_2);

  return;

}



