#include "nokia.h"
#include <stdint.h>

extern int _isisMutex; // Modified: Added extern declaration for undeclared identifier _isisMutex

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisAdjSnmpGetNext(void)


{

                    /* WARNING: Subroutine does not return */

  semTake(_isisMutex,0xffffffff);

}
