#include "nokia.h"
#include <stdint.h>

void isisDumpPktTESrlgs(uint32_t param_1,void (*param_2)(),uint32_t param_3,int param_4,byte param_5

                       ,byte param_6)


{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  byte *pbVar7;
  uintptr_t auStack_70 [80];
  
  (*param_2)(param_1,0xa1b762c);
  FmtIsisNodeId(param_3,param_4,param_5 + 1,auStack_70,0x50,0);
  (*param_2)(param_1,0xa1b73c0,auStack_70);
  (*param_2)(param_1,0xa1b53b4);
  (*param_2)(param_1,0xa1b763c,*(uintptr_t *)(param_4 + 8),*(uintptr_t *)(param_4 + 9),
             *(uintptr_t *)(param_4 + 10),*(uintptr_t *)(param_4 + 0xb));
  uVar3 = (uint)*(byte *)(param_4 + 0xe);
  uVar4 = (uint)*(byte *)(param_4 + 0xf);
  (*param_2)(param_1,0xa1b765c,*(uintptr_t *)(param_4 + 0xc),*(uintptr_t *)(param_4 + 0xd),uVar3,
             uVar4);
  iVar1 = param_6 - 0x10;
  pbVar7 = (byte *)(param_4 + 0x10);
  uVar5 = 0;
  if (iVar1 < 0) {
    iVar1 = param_6 - 0xd;
  }
  uVar6 = iVar1 >> 2 & 0xffff;
  (*param_2)(param_1,0xa1b767c,uVar6);
  uVar2 = 0;
  if (uVar6 != 0) {
    while( true ) {
      if (uVar2 == 0) {
        (*param_2)(param_1,0xa1b5734);
        (*param_2)(param_1,0xa1b572c,
                   (uint)*pbVar7 << 0x18 | (uint)pbVar7[1] << 0x10 | (uint)pbVar7[2] << 8 |
                   (uint)pbVar7[3],(uint)pbVar7[3],uVar3,uVar4);
      }
      else {
        (*param_2)(param_1,0xa1b572c,
                   (uint)*pbVar7 << 0x18 | (uint)pbVar7[1] << 0x10 | (uint)pbVar7[2] << 8 |
                   (uint)pbVar7[3],(uint)pbVar7[3],uVar3,uVar4);
      }
      uVar2 = uVar5 + 1;
      uVar5 = uVar2 & 0xffff;
      if (uVar6 <= uVar5) break;
      pbVar7 = pbVar7 + 4;
      uVar2 = uVar2 & 3;
    }
  }
  (*param_2)(param_1,0xa1b53b4);
  return;
}