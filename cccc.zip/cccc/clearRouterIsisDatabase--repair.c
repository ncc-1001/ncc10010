#include "nokia.h"
#include <stdint.h>

extern unsigned char *___ctype; // Modified: Added extern declaration for undeclared identifier

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t clearRouterIsisDatabase(uint32_t param_1,byte *param_2,int param_3)

{

  int iVar1;

  uint32_t uVar2;

  uintptr_t auStack_110 [256];
  
  iVar1 = strToRtrId(param_2,2 - (uint)((*(byte *)((uint)*param_2 + ___ctype) & 4) == 0));
  if (iVar1 < 1) {
    uVar2 = 0x9ff7cf8;
    if (iVar1 != -0xd) {
      cliErrorMesg(param_1,0x9ff7d18,param_2,param_2);
      return 0xffffffff;
    }
  }
  else {
    if (param_3 == 0) {
      param_3 = 0x9ff8038;
    }
    snprintf(auStack_110,0xff,0x9ff8704,param_2,param_3);
    iVar1 = clearAction(param_1,0x9ff8724,0x9ff8764,auStack_110);
    uVar2 = 0x9ff877c;
    if (iVar1 == 0) {
      return 0;
    }
  }
  cliErrorMesg(param_1,uVar2);
  return 0xffffffff;
}