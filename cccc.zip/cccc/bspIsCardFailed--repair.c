#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern int hwTypeInfo;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t bspIsCardFailed(void)


{

  int in_zero;

  int iVar1;

  

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) == -5) {

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) != -0x13) {

    iVar1 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar1 + 0x10c8f925) != -0x17) {

      iVar1 = 0;

      if (_TgtHw == 1) {

        if (_kernelIsSmp == 0) {

          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

        }

        else {

          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

        }

      }

      if (*(char *)(iVar1 + 0x10c8f925) != -0x15) {

        iVar1 = 0;

        if (_TgtHw == 1) {

          if (_kernelIsSmp == 0) {

            iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

          }

          else {

            iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

          }

        }

        if (*(char *)(iVar1 + 0x10c8f925) != -0x16) {

          iVar1 = 0;

          if (_TgtHw == 1) {

            if (_kernelIsSmp == 0) {

              iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

            }

            else {

              iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

            }

          }

          if (*(char *)(iVar1 + 0x10c8f925) != -0xd) {

            iVar1 = 0;

            if (_TgtHw == 1) {

              if (_kernelIsSmp == 0) {

                iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

              }

              else {

                iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

              }

            }

            if (*(char *)(iVar1 + 0x10c8f925) != -0xf) {

              iVar1 = 0;

              if (_TgtHw == 1) {

                if (_kernelIsSmp == 0) {

                  iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                }

                else {

                  iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                }

              }

              if (*(char *)(iVar1 + 0x10c8f925) != -8) {

                iVar1 = 0;

                if (_TgtHw == 1) {

                  if (_kernelIsSmp == 0) {

                    iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                  }

                  else {

                    iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                  }

                }

                if (*(char *)(iVar1 + 0x10c8f925) != -9) {

                  iVar1 = 0;

                  if (_TgtHw == 1) {

                    if (_kernelIsSmp == 0) {

                      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                    }

                    else {

                      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                    }

                  }

                  if (*(char *)(iVar1 + 0x10c8f925) != -10) {

                    iVar1 = 0;

                    if (_TgtHw == 1) {

                      if (_kernelIsSmp == 0) {

                        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                      }

                      else {

                        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                      }

                    }

                    if (*(char *)(iVar1 + 0x10c8f925) != -0x10) {

                      iVar1 = 0;

                      if (_TgtHw == 1) {

                        if (_kernelIsSmp == 0) {

                          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                        }

                        else {

                          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                        }

                      }

                      if (*(char *)(iVar1 + 0x10c8f925) != -0xe) {

                        iVar1 = 0;

                        if (_TgtHw == 1) {

                          if (_kernelIsSmp == 0) {

                            iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                          }

                          else {

                            iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                          }

                        }

                        if (*(char *)(iVar1 + 0x10c8f925) != -0x24) {

                          iVar1 = 0;

                          if (_TgtHw == 1) {

                            if (_kernelIsSmp == 0) {

                              iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                            }

                            else {

                              iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                            }

                          }

                          if (*(char *)(iVar1 + 0x10c8f925) != -0x23) {

                            iVar1 = 0;

                            if (_TgtHw == 1) {

                              if (_kernelIsSmp == 0) {

                                iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                              }

                              else {

                                iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                              }

                            }

                            if (*(char *)(iVar1 + 0x10c8f925) != -0x12) {

                              iVar1 = 0;

                              if (_TgtHw == 1) {

                                if (_kernelIsSmp == 0) {

                                  iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                }

                                else {

                                  iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                }

                              }

                              if (*(char *)(iVar1 + 0x10c8f925) != -0x1e) {

                                iVar1 = 0;

                                if (_TgtHw == 1) {

                                  if (_kernelIsSmp == 0) {

                                    iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                  }

                                  else {

                                    iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                  }

                                }

                                if (*(char *)(iVar1 + 0x10c8f925) != -0x1d) {

                                  iVar1 = 0;

                                  if (_TgtHw == 1) {

                                    if (_kernelIsSmp == 0) {

                                      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                    }

                                    else {

                                      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                    }

                                  }

                                  if (*(char *)(iVar1 + 0x10c8f925) != -0x1c) {

                                    iVar1 = 0;

                                    if (_TgtHw == 1) {

                                      if (_kernelIsSmp == 0) {

                                        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                      }

                                      else {

                                        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                      }

                                    }

                                    if (*(char *)(iVar1 + 0x10c8f925) != -0x1b) {

                                      iVar1 = 0;

                                      if (_TgtHw == 1) {

                                        if (_kernelIsSmp == 0) {

                                          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                        }

                                        else {

                                          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                        }

                                      }

                                      if (*(char *)(iVar1 + 0x10c8f925) != -0x1a) {

                                        iVar1 = 0;

                                        if (_TgtHw == 1) {

                                          if (_kernelIsSmp == 0) {

                                            iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                          }

                                          else {

                                            iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) *

                                                    3;

                                          }

                                        }

                                        if (*(char *)(iVar1 + 0x10c8f925) != -0x19) {

                                          iVar1 = 0;

                                          if (_TgtHw == 1) {

                                            if (_kernelIsSmp == 0) {

                                              iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                            }

                                            else {

                                              iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8)

                                                      * 3;

                                            }

                                          }

                                          if (*(char *)(iVar1 + 0x10c8f925) != -7) {

                                            iVar1 = 0;

                                            if (_TgtHw == 1) {

                                              if (_kernelIsSmp == 0) {

                                                iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                              }

                                              else {

                                                iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8

                                                                ) * 3;

                                              }

                                            }

                                            iVar1 = hwCardTypeIsRialzi((&hwTypeInfo)[iVar1]);

                                            if (iVar1 != 0) {

                                              return;

                                            }

                    /* WARNING: Bad instruction - Truncating control flow here */

                                            halt_baddata();

                                          }


                                        }

                                      }

                                    }

                                  }

                                }

                              }

                            }

                          }

                        }

                      }

                    }

                  }

                }

              }

            }

          }

        }

      }

    }

  }

  return 0;

}