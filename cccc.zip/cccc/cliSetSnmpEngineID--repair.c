#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for undeclared global variable _v3_my_engine
extern uint32_t _v3_my_engine;

int cliSetSnmpEngineID(uint32_t param_1,uint32_t param_2)

{

  int iVar1;

  uint uVar2;

  uint32_t uVar3;

  uintptr_t auStack_58 [64];

  uint32_t *puStack_18;

  uint uStack_14;

  

  uStack_14 = 0x40;

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_18);

  if (iVar1 == 0) {

    uVar3 = *puStack_18;

    uVar2 = strlen(uVar3);

    if ((uVar2 < 10) || (iVar1 = snmpGetHexFromString(auStack_58,&uStack_14,uVar3), iVar1 != 1)) {

      return -0x2717;

    }

    iVar1 = 0;

    if (_v3_my_engine != 0) {

      iVar1 = snmpSecsGet();

      iVar1 = iVar1 - *(int *)(_v3_my_engine + 0x10);

    }

    uVar3 = 0;

    if (_v3_my_engine != 0) {

      uVar3 = *(uint32_t *)(_v3_my_engine + 0xc);

    }

    iVar1 = SNMP_Engine_Set_My_Info(auStack_58,uStack_14 & 0xffff,uVar3,iVar1);

    if (iVar1 == 0) {

      iVar1 = 0;

    }

    else {

      cliErrorMesg(param_1,0xa398c10);

      iVar1 = 0;

    }

  }

  return iVar1;

}