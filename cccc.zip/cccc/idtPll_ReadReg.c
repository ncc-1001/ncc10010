#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint idtPll_ReadReg(uint param_1)



{

  byte bVar1;

  int in_zero;

  byte *pbVar2;

  int iVar3;

  uint uVar4;

  uint uVar5;

  uint uVar6;

  

  iVar3 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar3 + 0x10c8f925) == -0x23) {

LAB_02998880:

    uVar6 = spi_read_reg8(param_1 & 0xff);

    return uVar6;

  }

  iVar3 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar3 + 0x10c8f925) == -0x12) goto LAB_02998880;

  uVar6 = (param_1 & 0xff) + 0x10030000;

  if (0xfffffff < uVar6) {

    uVar5 = PRId >> 8 & 0xffff;

    uVar4 = uVar5 ^ 0xd01;

    if ((((uVar4 != 0) && (uVar4 = uVar5 ^ 0xd06, uVar4 != 0)) &&

        (uVar4 = uVar5 ^ 0xd04, uVar4 != 0)) && (uVar4 = uVar5 ^ 0xd93, uVar4 != 0)) {

      uVar4 = uVar5 ^ 0xd90;

    }

    if (uVar4 == 0) {

      bVar1 = *(byte *)(uVar6 | 0xa0000000);

      goto LAB_0299881c;

    }

  }

  if ((uVar6 < 0x800000) || (pbVar2 = (byte *)(uVar6 | 0xc0000000), (PRId >> 0x10 & 0xff) != 0xd)) {

    pbVar2 = (byte *)(uVar6 | 0xa0000000);

  }

  bVar1 = *pbVar2;

LAB_0299881c:

  return (uint)bVar1;

}



