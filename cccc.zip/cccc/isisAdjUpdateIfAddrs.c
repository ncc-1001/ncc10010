#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisAdjUpdateIfAddrs(uint32_t *param_1,int param_2)



{

  char cVar1;

  char cVar2;

  bool bVar3;

  bool bVar4;

  int iVar5;

  uint uVar6;

  uint uStack_2c;

  uint uStack_28;

  uint uStack_24;

  uint uStack_20;

  

  cVar1 = *(char *)(param_2 + 0x1c);

  bVar4 = false;

  if (cVar1 == '\0') {

    uStack_28 = *(uint *)(param_2 + 0x24);

    uStack_24 = *(uint *)(param_2 + 0x28);

    uStack_20 = *(uint *)(param_2 + 0x2c);

    uVar6 = *(uint *)(param_2 + 0x20);

  }

  else {

    uVar6 = *(uint *)(param_2 + 0x20);

  }

  *(uintptr_t *)(param_2 + 0x1c) = 1;

  *(uint32_t *)(param_2 + 0x20) = 0;

  if (((param_1 != (uint32_t *)0xfffff854) && (iVar5 = param_1[0x1eb], iVar5 != 0)) &&

     (3 < *(byte *)(iVar5 + 1))) {

    *(uint *)(param_2 + 0x20) =

         (uint)*(byte *)(iVar5 + 2) << 0x18 | (uint)*(byte *)(iVar5 + 3) << 0x10 |

         (uint)*(byte *)(iVar5 + 4) << 8 | (uint)*(byte *)(iVar5 + 5);

  }

  if (((cVar1 == '\x01') && (*(uint *)(param_2 + 0x20) <= uVar6)) &&

     (uVar6 <= *(uint *)(param_2 + 0x20))) {

    cVar1 = *(char *)(param_2 + 0x30);

  }

  else {

    if (uVar6 == 0) {

      isisAdjBfdAdd(*param_1,param_2);

    }

    bVar4 = true;

    cVar1 = *(char *)(param_2 + 0x30);

  }

  if (cVar1 == '\0') {

    uStack_2c = *(uint *)(param_2 + 0x34);

    uStack_28 = *(uint *)(param_2 + 0x38);

    uStack_24 = *(uint *)(param_2 + 0x3c);

    uStack_20 = *(uint *)(param_2 + 0x40);

  }

  else {

    uStack_2c = *(uint *)(param_2 + 0x34);

  }

  *(uintptr_t *)(param_2 + 0x30) = 0;

  memset(param_2 + 0x34,0,0x10);

  if (param_1 == (uint32_t *)0xfffff7f4) {

LAB_041f1ce0:

    cVar2 = *(char *)(param_2 + 0x30);

  }

  else {

    iVar5 = param_1[0x203];

    if (iVar5 != 0) {

      if (0xf < *(byte *)(iVar5 + 1)) {

        *(uintptr_t *)(param_2 + 0x30) = 0;

        memcpy(param_2 + 0x34,iVar5 + 2,0x10);

      }

      goto LAB_041f1ce0;

    }

    cVar2 = *(char *)(param_2 + 0x30);

  }

  if (cVar1 == cVar2) {

    if (cVar1 == '\0') {

      if (((uStack_2c < *(uint *)(param_2 + 0x34)) || (*(uint *)(param_2 + 0x34) < uStack_2c)) ||

         ((uStack_28 < *(uint *)(param_2 + 0x38) ||

          ((((*(uint *)(param_2 + 0x38) < uStack_28 || (uStack_24 < *(uint *)(param_2 + 0x3c))) ||

            (*(uint *)(param_2 + 0x3c) < uStack_24)) || (uStack_20 < *(uint *)(param_2 + 0x40)))))))

      goto LAB_041f1cf0;

      bVar3 = *(uint *)(param_2 + 0x40) < uStack_20;

    }

    else {

      if (uStack_2c < *(uint *)(param_2 + 0x34)) goto LAB_041f1cf0;

      bVar3 = *(uint *)(param_2 + 0x34) < uStack_2c;

    }

    if ((!bVar3) && (!bVar4)) {

      return 0;

    }

  }

LAB_041f1cf0:

  isisSpfSchedule(param_1,1,0);

  return 0;

}



