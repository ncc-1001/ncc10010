#include "nokia.h"
#include <stdint.h>

// Added: Declaration of undeclared RAM variables
extern uint32_t uRam0c32ae50;
extern uint32_t uRam0c32ae54;
extern uint32_t uRam0c32ae58;
extern int iRam0c32ae5c;
extern uint32_t uRam0c32ae60;
extern int iRam0c32ae64;
extern int iRam0c32ae68;
extern int iRam0c32ae6c;

void aluSerialMddbEntry_test
               (uint32_t param_1,int param_2,uint32_t *param_3,uint32_t param_4,
               uint32_t *param_5)
{
  bool bVar1;
  int iVar2;
  uint32_t uVar3;
  uint32_t *puVar4;
  uint uVar5;
  uint uVar6;
  uint32_t uStack_40;
  uint32_t uStack_3c;
  uint32_t uStack_38;
  int iStack_34;
  uint32_t uStack_30;
  int iStack_2c;
  int iStack_28;
  int iStack_24;
  
  group_by_getproc_and_instance(param_4,param_5,param_2,param_3);
  uVar5 = 0;
  bVar1 = false;
  if (param_2 == 2) {
    uRam0c32ae50 = *param_3;
    uRam0c32ae54 = param_3[1];
    iVar2 = sia_aluSerialMddbEntryGet(1,0xc32ae50);
    puVar4 = param_5;
    if (iVar2 != 0 && iVar2 != 0x66) goto LAB_035a2bb4;
    uStack_40 = uRam0c32ae50;
    uStack_3c = uRam0c32ae54;
    uStack_38 = uRam0c32ae58;
    iStack_34 = iRam0c32ae5c;
    uStack_30 = uRam0c32ae60;
    iStack_2c = iRam0c32ae64;
    iStack_28 = iRam0c32ae68;
    iStack_24 = iRam0c32ae6c;
    param_5[0xe] = 0xc32ae50;
    if (param_5 != (uint32_t *)0x0) {
      uVar3 = param_5[6];
      do {
        switch(uVar3) {
        default:
          goto switchD_035a2ba0_caseD_0;
        case 1:
          uVar6 = puVar4[0xc] - puVar4[0xb] & 0xffff;
          if (uVar6 < 2) {
            memset(&uStack_38,0,1);
            memcpy(&uStack_38,puVar4[0xb],uVar6);
            // Modified: Changed structure member access to pointer dereference
            if (((*(char *)&uStack_38 != '@' && *(char *)&uStack_38 != ' ') && (*(char *)&uStack_38 != '`')) &&
               (*(char *)&uStack_38 != '\0')) goto LAB_035a2bf8;
            uVar5 = uVar5 | 2;
            testproc_good(param_4,puVar4);
            puVar4 = (uint32_t *)*puVar4;
          }
          else {
            uVar3 = 8;
LAB_035a2c00:
            bVar1 = true;
            testproc_error(param_4,puVar4,uVar3);
            puVar4 = (uint32_t *)*puVar4;
          }
          break;
        case 2:
          if (1 < puVar4[10] - 1) {
LAB_035a2bf8:
            uVar3 = 10;
            goto LAB_035a2c00;
          }
          uVar5 = uVar5 | 4;
          iStack_34 = puVar4[10];
          testproc_good(param_4,puVar4);
          puVar4 = (uint32_t *)*puVar4;
          break;
        case 4:
          if (1 < puVar4[10] - 1) goto LAB_035a2bf8;
          uVar5 = uVar5 | 0x10;
          iStack_2c = puVar4[10];
          testproc_good(param_4,puVar4);
          puVar4 = (uint32_t *)*puVar4;
          break;
        case 5:
          if (0x77 < puVar4[10] - 1) goto LAB_035a2bf8;
          uVar5 = uVar5 | 0x20;
          iStack_28 = puVar4[10];
          testproc_good(param_4,puVar4);
          puVar4 = (uint32_t *)*puVar4;
          break;
        case 6:
          if (1 < puVar4[10] - 1) goto LAB_035a2bf8;
          uVar5 = uVar5 | 0x40;
          iStack_24 = puVar4[10];
          testproc_good(param_4,puVar4);
          puVar4 = (uint32_t *)*puVar4;
        }
        if (puVar4 == (uint32_t *)0x0) break;
        uVar3 = puVar4[6];
      } while( true );
    }
    if ((!bVar1) && (iVar2 = sia_aluSerialMddbEntryCheck(uVar5,&uStack_40), iVar2 != 0)) {
      siaCheckError(param_4,param_5,0x7ed,iVar2);
    }
  }
  else {
    for (; param_5 != (uint32_t *)0x0; param_5 = (uint32_t *)*param_5) {
      testproc_error(param_4,param_5,0xb);
    }
  }
  return;

switchD_035a2ba0_caseD_0:
  iVar2 = 5;
LAB_035a2bb4:
  testproc_error(param_4,puVar4,iVar2);
  return;
}