#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: added extern declarations for missing globals
extern uint32_t uRam09e58954;
extern uint32_t uRam09e58958;
extern uint32_t uRam09e5895c;
extern uint32_t uRam09e58960;
extern uintptr_t uRam09e58964;
extern int _runtime_feature_7705ip6;

int aaaMgmtAccessNodeConfig

              (int (*param_1)(), uint32_t param_2, uint param_3, uintptr_t param_4, uintptr_t param_5) // Modified: changed param_1 to function pointer type with empty parameter list

{

  int iVar1;

  uint32_t uStack_30;

  uint32_t uStack_2c;

  uint32_t uStack_28;

  uint32_t uStack_24;

  uintptr_t uStack_20;

  

  uStack_30 = uRam09e58954;

  uStack_2c = uRam09e58958;

  uStack_28 = uRam09e5895c;

  uStack_24 = uRam09e58960;

  uStack_20 = uRam09e58964;

  if (param_3 < 3) {

    if (param_3 == 0) {

      iVar1 = (*param_1)(param_2,0x9e597ac,&uStack_30);

      if (-1 < iVar1) {

        aaaMgmtAccessNodeIpFltrConfig(param_1,param_2,1,param_4,param_5);

        (*param_1)(param_2,0x9e59790,&uStack_30);

        iVar1 = timosMgmtIsInDebugMode();

        if ((iVar1 != 0) || (_runtime_feature_7705ip6 == 0)) {

          iVar1 = (*param_1)(param_2,0x9e597bc,&uStack_30);

          if (iVar1 < 0) {

            return iVar1;

          }

          aaaMgmtAccessNodeIpFltrConfig(param_1,param_2,2,param_4,param_5);

          (*param_1)(param_2,0x9e59790,&uStack_30);

        }

        aaaMacMgmtAccessNodeConfig(param_1,param_2,param_4,1,param_5);

        iVar1 = 0;

      }

    }

    else {

      aaaMgmtAccessNodeIpFltrConfig();

      iVar1 = 0;

    }

  }

  else if (param_3 == 3) {

    aaaMacMgmtAccessNodeConfig(param_1,param_2,param_4,0,param_5);

    iVar1 = 0;

  }

  else {

    iVar1 = 0;

  }

  return iVar1;

}
