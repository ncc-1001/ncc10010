#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t hwSarmFpgaGetModuleFPGAConfigStatus(uint param_1)

{
  // Modified: Added declarations for undeclared variables
  int _TgtHw;
  int _kernelIsSmp;
  int _smpTaskIdCurrent;
  char cRam10c8f925;

  int in_zero;
  int iVar1;
  
  if (1 < param_1) {
    return 0;
  }
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8);
    }
    else {
      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8);
    }
    if (*(char *)(iVar1 * 3 + 0x10c8f925) == -0x17) {
      return 0;
    }
  }
  else if (cRam10c8f925 == -0x17) {
    return 0;
  }
  iVar1 = 0;
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
    }
    else {
      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
    }
  }
  if (*(char *)(iVar1 + 0x10c8f925) != -0x16) {
    iVar1 = 0;
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
      }
      else {
        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
      }
    }
    if (*(char *)(iVar1 + 0x10c8f925) != -0xd) {
      iVar1 = 0;
      if (_TgtHw == 1) {
        if (_kernelIsSmp == 0) {
          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
        }
        else {
          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
        }
      }
      if (*(char *)(iVar1 + 0x10c8f925) != -0xf) {
        iVar1 = 0;
        if (_TgtHw == 1) {
          if (_kernelIsSmp == 0) {
            iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
          }
          else {
            iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
          }
        }
        if (*(char *)(iVar1 + 0x10c8f925) != -8) {
          iVar1 = 0;
          if (_TgtHw == 1) {
            if (_kernelIsSmp == 0) {
              iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
            }
            else {
              iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
            }
          }
          if (*(char *)(iVar1 + 0x10c8f925) != -9) {
            iVar1 = 0;
            if (_TgtHw == 1) {
              if (_kernelIsSmp == 0) {
                iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
              }
              else {
                iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
              }
            }
            if (*(char *)(iVar1 + 0x10c8f925) != -10) {
              iVar1 = 0;
              if (_TgtHw == 1) {
                if (_kernelIsSmp == 0) {
                  iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                }
                else {
                  iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                }
              }
              if (*(char *)(iVar1 + 0x10c8f925) != -0x10) {
                iVar1 = 0;
                if (_TgtHw == 1) {
                  if (_kernelIsSmp == 0) {
                    iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                  }
                  else {
                    iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                  }
                }
                if (*(char *)(iVar1 + 0x10c8f925) != -0xe) {
                  iVar1 = 0;
                  if (_TgtHw == 1) {
                    if (_kernelIsSmp == 0) {
                      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                    }
                    else {
                      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                    }
                  }
                  if (*(char *)(iVar1 + 0x10c8f925) != -0x23) {
                    iVar1 = 0;
                    if (_TgtHw == 1) {
                      if (_kernelIsSmp == 0) {
                        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                      }
                      else {
                        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                      }
                    }
                    if (*(char *)(iVar1 + 0x10c8f925) != -0x12) {
                      iVar1 = 0;
                      if (_TgtHw == 1) {
                        if (_kernelIsSmp == 0) {
                          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                        }
                        else {
                          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                        }
                      }
                      if (*(char *)(iVar1 + 0x10c8f925) != -0x1e) {
                        iVar1 = 0;
                        if (_TgtHw == 1) {
                          if (_kernelIsSmp == 0) {
                            iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                          }
                          else {
                            iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                          }
                        }
                        if (*(char *)(iVar1 + 0x10c8f925) != -0x1d) {
                          iVar1 = 0;
                          if (_TgtHw == 1) {
                            if (_kernelIsSmp == 0) {
                              iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                            }
                            else {
                              iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                            }
                          }
                          if (*(char *)(iVar1 + 0x10c8f925) != -0x1c) {
                            iVar1 = 0;
                            if (_TgtHw == 1) {
                              if (_kernelIsSmp == 0) {
                                iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                              }
                              else {
                                iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                              }
                            }
                            if (*(char *)(iVar1 + 0x10c8f925) != -0x1b) {
                              iVar1 = 0;
                              if (_TgtHw == 1) {
                                if (_kernelIsSmp == 0) {
                                  iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                                }
                                else {
                                  iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                                }
                              }
                              if (*(char *)(iVar1 + 0x10c8f925) != -0x1a) {
                                iVar1 = 0;
                                if (_TgtHw == 1) {
                                  if (_kernelIsSmp == 0) {
                                    iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
                                  }
                                  else {
                                    iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
                                  }
                                }
                                if (*(char *)(iVar1 + 0x10c8f925) != -0x19) {
                    /* WARNING: Bad instruction - Truncating control flow here */
                                  halt_baddata();
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return 0;
}