#include "nokia.h"
#include <stdint.h>

// Modified: Added declaration for undeclared variable 'ARPADR_Tic'
uintptr_t* ARPADR_Tic;

void ARPADR_Tic_Del(int param_1)
{
  int iVar1;

  if (*(int *)(param_1 + 0x18) == 0) {
    iVar1 = *(int *)(param_1 + 0x1c);
    ARPADR_Tic = *(uintptr_t **)(param_1 + 0x1c);
  }
  else {
    *(uintptr_t **)(*(int *)(param_1 + 0x18) + 0x1c) = *(uintptr_t **)(param_1 + 0x1c);
    iVar1 = *(int *)(param_1 + 0x1c);
  }
  if (iVar1 == 0) {
    *(uint32_t *)(param_1 + 0x1c) = 0;
  }
  else {
    *(uint32_t *)(iVar1 + 0x18) = *(uint32_t *)(param_1 + 0x18);
    *(uint32_t *)(param_1 + 0x1c) = 0;
  }
  *(uint32_t *)(param_1 + 0x18) = 0;
  return;
}