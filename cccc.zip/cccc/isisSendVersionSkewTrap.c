#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendVersionSkewTrap

               (uint32_t *param_1,uint32_t param_2,uint32_t param_3,int param_4,

               uint32_t param_5,int param_6)



{

  uint32_t uVar1;

  uint32_t uVar2;

  uintptr_t auStack_1b0 [400];

  

  auStack_1b0[0] = 0;

  if (0x40 < param_6) {

    param_6 = 0x40;

  }

  logger_OctetsHexDump(param_5,param_6,auStack_1b0,400);

  uVar1 = strlen(auStack_1b0);

  uVar2 = *param_1;

  logEvent_ISIS_vRtrIsisVersionSkew

            (uVar2,0xa1bbb88,uVar2,param_2,param_3,param_5,param_6,auStack_1b0,uVar1,uVar2,

             *(uint32_t *)(param_4 + 8));

  return;

}



