#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int cfgRouterISISLevelElements

              (uint32_t param_1,int param_2,int param_3,int param_4,uint32_t param_5,int param_6

              )



{

  int iVar1;

  int iVar2;

  uintptr_t auStack_400 [1000];

  

  if ((param_2 == 0 || param_3 == 0) || (param_4 == 0 || param_6 == 0)) {

    timosAssert(0xa07cd94,0xa07cd10,0x174,0xa07cd78,0xa07cd74);

  }

  iVar1 = getVRtrId(param_1,param_2);

  iVar2 = -1;

  if (iVar1 != 0) {

    snprintf(auStack_400,1000,0xa07cde8,param_4,iVar1,param_3);

    iVar2 = RCC_RCB_WriteValueToRCB(param_1,auStack_400,param_5,param_6);

    iVar2 = -(uint)(iVar2 < 0);

  }

  return iVar2;

}



