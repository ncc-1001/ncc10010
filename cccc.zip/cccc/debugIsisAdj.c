#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t debugIsisAdj(uint32_t param_1,uint32_t param_2,int param_3,char param_4)



{

  int iVar1;

  uint uStack_130;

  uint uStack_12c;

  uintptr_t auStack_128 [24];

  uintptr_t auStack_110 [256];

  

  memset(&uStack_130,0,0x120);

  uStack_130 = uStack_130 | 0x10;

  if (param_3 != 0) {

    iVar1 = getIndexFromInterface(1,param_3,auStack_128);

    if (iVar1 == 0) {

      uStack_12c = uStack_12c | 1;

    }

    else {

      iVar1 = strToIsisSystemId(param_3,auStack_110);

      if (iVar1 != 0) {

        cliErrorMesg(param_1,0x9fffdf4);

        return 0xffffffff;

      }

      uStack_12c = uStack_12c | 4;

    }

  }

  if (param_4 == '\0') {

    isisDebugOn(1,&uStack_130);

  }

  else {

    isisDebugOff(1,&uStack_130);

  }

  return 0;

}



