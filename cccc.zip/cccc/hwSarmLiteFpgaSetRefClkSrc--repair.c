#include "nokia.h"
#include <stdint.h>

// Modified: Adjusted 'code' type definition to match expected function signature
typedef void (*code)(void*, uint, uintptr_t);

void hwSarmLiteFpgaSetRefClkSrc(uint param_1,uint param_2,uintptr_t param_3)



{

  code *UNRECOVERED_JUMPTABLE;

  

  if (1 < param_1 || 0x2e < param_2) {

                    /* WARNING: Subroutine does not return */

    printf(0x69c17f0,0x69c17b4,param_1,param_2);

  }

  if (param_2 < 9) {

    UNRECOVERED_JUMPTABLE = *(code **)(param_2 * 4 + 0x69c1810);

                    /* WARNING: Could not recover jumptable at 0x02961918. Too many branches */

                    /* WARNING: Treating indirect jump as call */

    (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,param_2,param_3);

    return;

  }

                    /* WARNING: Subroutine does not return */

  printf(0x69c17d0,0x69c17b4,param_2);

}



