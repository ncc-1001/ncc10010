#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisCircDel(uint32_t param_1,uint32_t param_2)



{

  isisSendInterfaceMsg(param_1,param_2,2);

  return;

}



