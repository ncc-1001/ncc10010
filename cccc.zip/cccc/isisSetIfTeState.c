#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSetIfTeState(uint32_t param_1,uint32_t param_2,uintptr_t param_3)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t uStack_18;

  uint32_t *puStack_14;

  

  uStack_18 = 0;

  iVar1 = isisGetNode(param_1,&uStack_18);

  if ((iVar1 == 0) && (puStack_14 = (uint32_t *)isisMalloc(0x14), puStack_14 != (uint32_t *)0x0)

     ) {

    *puStack_14 = param_1;

    puStack_14[1] = 6;

    puStack_14[2] = 0x14;

    *(uintptr_t *)(puStack_14 + 4) = param_3;

    puStack_14[3] = param_2;

    uVar2 = isisGetTDGenMsgQId();

    iVar1 = msgQSend(uVar2,&puStack_14,4,0,0);

    if (iVar1 == -1) {

      isisFree(puStack_14);

      isisIncTDGenMsgQSendErr();

    }

  }

  return;

}



