#include "nokia.h"
#include <stdint.h>

// Modified: Added typedef for 'byte' to fix undeclared identifier
typedef unsigned char byte;
// Modified: Added extern declaration for 'cRam10c8f925' to fix undeclared identifier
extern uint32_t cRam10c8f925;

int hwWakiSetMciConfig(uint32_t param_1)
{
  int iVar1;
  
  iVar1 = -1;
  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {
    iVar1 = hwWakiWriteReg32(0,8,param_1);
    iVar1 = (iVar1 == 0) - 1;
  }
  return iVar1;
}