#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t configRouterIsisTE(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  

  ___chk_strnum = 1;

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07da00,0,0xa07cc30);

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07da14);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}



