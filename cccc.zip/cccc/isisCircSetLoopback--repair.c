#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _isisMutex; // Modified: Added extern declaration for undeclared variable

void isisCircSetLoopback(uint32_t param_1)
{

  int iVar1;
  uintptr_t auStack_18 [8];
  
  iVar1 = isisGetNode(param_1,auStack_18);
  if (iVar1 != 0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  semTake(_isisMutex,0xffffffff);
}