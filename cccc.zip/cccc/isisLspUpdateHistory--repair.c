#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for missing variables
extern char gIsisHistoryEnabled;
extern int iRam0c98c054;
extern uint32_t _vxSecs;

void isisLspUpdateHistory
               (uint32_t param_1,int param_2,uint32_t param_3,int *param_4,uint32_t param_5,
               uint32_t param_6)
{
  int iVar1;
  uint32_t uVar2;
  int iVar3;
  
  if (((gIsisHistoryEnabled != '\0') && ((*(ushort *)(param_2 + 0xc) & 4) != 0)) &&
     ((*(ushort *)(param_2 + 0xc) & 0x80) == 0)) {
    isisLspHistUpdateIndicies(0xc98c050,0xc98c054,0xc98c058,5000);
    *(uint32_t *)(iRam0c98c054 * 0x28 + 0xc95b320) = param_3;
    iVar3 = iRam0c98c054 * 0x28;
    iVar1 = redAmIActive(0x34);
    *(uint *)(iVar3 + 0xc95b324) = *(uint *)(iVar3 + 0xc95b324) & 0x7fffffff | iVar1 << 0x1f;
    *(uint32_t *)(iRam0c98c054 * 0x28 + 0xc95b328) = _vxSecs;
    uVar2 = *(uint32_t *)(param_2 + 4);
    iVar1 = iRam0c98c054 * 0x28;
    *(uint32_t *)(iVar1 + 0xc95b318) = *(uint32_t *)(param_2 + 8);
    *(uint32_t *)(iVar1 + 0xc95b314) = uVar2;
    *(char *)(iRam0c98c054 * 0x28 + 0xc95b31c) = (char)*(uint32_t *)(param_2 + 0x24);
    *(uint32_t *)(iRam0c98c054 * 0x28 + 0xc95b32c) = param_6;
    *(uint *)(iRam0c98c054 * 0x28 + 0xc95b334) = (uint)*(ushort *)(param_2 + 0xc);
    *(uint32_t *)(iRam0c98c054 * 0x28 + 0xc95b330) = *(uint32_t *)(param_2 + 0x10);
    iVar1 = redAmIActive(0x34);
    if (iVar1 == 0) {
      *(uint32_t *)(iRam0c98c054 * 0x28 + 0xc95b310) = param_5;
    }
    else {
      *(int *)(iRam0c98c054 * 0x28 + 0xc95b310) = *param_4;
      *param_4 = *param_4 + 1;
    }
  }
  return;
}