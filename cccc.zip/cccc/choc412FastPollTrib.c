#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void choc412FastPollTrib(uint32_t param_1)



{

  ushort uVar1;

  int *piVar2;

  int iVar3;

  int iVar4;

  ushort *puVar5;

  int iVar6;

  uint16_t uVar9;

  uint16_t uVar10;

  short sVar11;

  short sVar12;

  uint *puVar7;

  uint uVar8;

  uint uVar13;

  uint uVar14;

  uint uVar15;

  int iVar16;

  

  piVar2 = (int *)posMdaTribGetPort();

  iVar3 = posMdaTribGetChanType(param_1);

  iVar16 = piVar2[1];

  if (iVar16 == 0) {

    return;

  }

  iVar4 = accessErrorThresholdExceed(*(uint32_t *)(iVar16 + 0x36ca24),0);

  if (iVar4 != 0) {

    return;

  }

  iVar4 = *piVar2;

  switch(iVar3) {

  case 6:

    uVar9 = csaOcnUtilsTribStm1Number(param_1);

    uVar10 = csaOcnUtilsTribAu3Tug3Number(param_1);

    iVar3 = choc412GetSts1Info(*(uint32_t *)(iVar16 + 0x36ca24),*(uintptr_t *)(iVar4 + 100),uVar9,

                               uVar10);

    puVar7 = (uint *)posMdaTribGetStateSonet(param_1);

    uVar14 = *puVar7;

    uVar15 = (uint)*(ushort *)(iVar3 + 8) << 0x1f;

    *puVar7 = uVar14 & 0x7fffffff | uVar15;

    uVar8 = (*(uint *)(iVar3 + 8) >> 0x11 & 1) << 0x1e;

    *puVar7 = uVar14 & 0x3fffffff | uVar15 | uVar8;

    uVar13 = (*(uint *)(iVar3 + 8) >> 0x12 & 1) << 0x1a;

    *puVar7 = uVar14 & 0x3bffffff | uVar15 | uVar8 | uVar13;

    if ((uVar15 | uVar8) != 0) {

      return;

    }

    uVar8 = uVar14 & 0x1bffffff | uVar15 | uVar8 | uVar13 |

            (*(uint *)(iVar3 + 8) >> 0x15 & 1) << 0x1d;

    *puVar7 = uVar8;

    uVar15 = *(uint *)(iVar3 + 8) >> 0x16;

    break;

  default:

    goto LAB_064383f4;

  case 9:

  case 10:

    uVar9 = csaOcnUtilsTribStm1Number(param_1);

    uVar10 = csaOcnUtilsTribAu3Tug3Number(param_1);

    sVar11 = csaOcnUtilsTribTug2Number(param_1);

    sVar12 = csaOcnUtilsTribTuNumber(param_1);

    if (iVar3 == 10) {

      puVar5 = (ushort *)

               choc412GetVtInfo(*(uint32_t *)(iVar16 + 0x36ca24),*(uintptr_t *)(iVar4 + 100),uVar9

                                ,uVar10,sVar11 * 3 + sVar12);

    }

    else {

      puVar5 = (ushort *)

               choc412GetVtInfo(*(uint32_t *)(iVar16 + 0x36ca24),*(uintptr_t *)(iVar4 + 100),uVar9

                                ,uVar10,sVar11 * 4 + sVar12);

    }

    puVar7 = (uint *)posMdaTribGetStateSonet(param_1);

    uVar14 = *puVar7;

    uVar15 = (uint)*puVar5 << 0x1f;

    *puVar7 = uVar14 & 0x7fffffff | uVar15;

    uVar8 = (*puVar5 >> 1 & 1) << 0x1e;

    *puVar7 = uVar14 & 0x3fffffff | uVar15 | uVar8;

    uVar13 = (*puVar5 >> 2 & 1) << 0x1a;

    *puVar7 = uVar14 & 0x3bffffff | uVar15 | uVar8 | uVar13;

    if ((uVar15 | uVar8) != 0) {

      return;

    }

    uVar8 = uVar14 & 0x1bffffff | uVar15 | uVar8 | uVar13 | (*puVar5 >> 5 & 1) << 0x1d;

    *puVar7 = uVar8;

    uVar15 = (uint)(*puVar5 >> 6);

    break;

  case 0x12:

    csaOcnUtilsPwe3TdmPollTrib(param_1);

  case 0x10:

  case 0x11:

    iVar6 = posMdaTribGetT1E1Framing(param_1);

    uVar9 = csaOcnUtilsTribStm1Number(param_1);

    uVar10 = csaOcnUtilsTribAu3Tug3Number(param_1);

    sVar11 = csaOcnUtilsTribTug2Number(param_1);

    sVar12 = csaOcnUtilsTribTuNumber(param_1);

    puVar7 = (uint *)posMdaTribGetStateT1E1(param_1);

    if (1 < iVar6 - 5U) {

      if (iVar3 == 0x10) {

        piVar2 = (int *)choc412GetT1E1Info(*(uint32_t *)(iVar16 + 0x36ca24),

                                           *(uintptr_t *)(iVar4 + 100),uVar9,uVar10,

                                           sVar11 * 4 + sVar12);

        uVar15 = *puVar7;

      }

      else {

        piVar2 = (int *)choc412GetT1E1Info(*(uint32_t *)(iVar16 + 0x36ca24),

                                           *(uintptr_t *)(iVar4 + 100),uVar9,uVar10,

                                           sVar11 * 3 + sVar12);

        uVar15 = *puVar7;

      }

      *puVar7 = uVar15 & 0x7fffffff;

      uVar1 = *(ushort *)piVar2;

      *puVar7 = uVar15 & 0x3fffffff | (uVar1 & 1) << 0x1e;

      uVar8 = ((uint)(piVar2[1] << 6) >> 0x1f | uVar1 & 1) << 0x1e;

      *puVar7 = uVar15 & 0x3fffffff | uVar8;

      uVar13 = ((uint)(*piVar2 << 0xe) >> 0x1f) << 0x1d;

      *puVar7 = uVar15 & 0x1fffffff | uVar8 | uVar13;

      *puVar7 = uVar15 & 0xfffffff | uVar8 | uVar13 | ((uint)(*piVar2 << 0xc) >> 0x1f) << 0x1c;

      return;

    }

    memset(puVar7,0,0x1b4);

    return;

  }

  *puVar7 = uVar8 & 0xefffffff | (uVar15 & 1) << 0x1c;

LAB_064383f4:

  return;

}



