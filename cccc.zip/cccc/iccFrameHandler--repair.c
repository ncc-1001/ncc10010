#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern uint Status;
extern uint _vxAbsTicks;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern int _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern char pbufMarkHistoryTrack;
extern int _pbufMarkHistoryOffStart;
extern int _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern char pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern char pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern char pbufMarkHistoryVal3;
extern char pbufMarkHistoryMatchLocation1;
extern int _pbufMarkHistoryLocationVal1;
extern int pbufMarkHistoryLock;
extern char pbufMarkHistoryTable;
extern char IccLogEnabled;
extern int IccLockIncoming;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void iccFrameHandler(int param_1)


{

  bool bVar1;

  int iVar2;

  int in_zero;

  uint uVar3;

  int iVar4;

  uint uVar5;

  uint uVar6;

  uint uVar7;

  uint uVar8;

  char *pcVar9;

  int *piVar10;

  uint16_t uVar11;

  
  uVar5 = Status;
  uVar6 = _vxAbsTicks;
  piVar10 = (int *)(param_1 + 0x88);
  uVar8 = (uint)*(ushort *)(param_1 + 0x94);
  uVar3 = _vxAbsTicks / 100;
  if (uVar8 == 0) goto LAB_02ad5708;
  if (_kernelIsSmp == 0) {
    if (_smpIntCnt == 0) {
LAB_02ad6628:
      *piVar10 = _smpTaskIdCurrent;
    }
    else {
      *piVar10 = 0;
    }
  }
  else {
    Status = Status & 0xfffffffe;
    setCopReg(0,Status,uVar5,0);
    if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
      if (_kernelIsSmp == 0) goto LAB_02ad6628;
      *piVar10 = *(int *)(in_zero + -0x8000);
    }
    else {
      *piVar10 = 0;
    }
  }
  uVar5 = Status;
  uVar7 = (uVar3 & 0xffff) - (uint)*(ushort *)(param_1 + 0x96) & 0xffff;
  uVar11 = (uint16_t)uVar3;
  if ((uVar7 != 0) && (uVar8 < 0xab)) {
    if (8 < uVar7) {
      uVar7 = 8;
    }
    iVar4 = (uVar8 * 0x558 + uVar7) * 8;
    piVar10 = (int *)(iVar4 + 0xecd476c);
    *(uint16_t *)(iVar4 + 0xecd4770) = uVar11;
    *piVar10 = *piVar10 + 1;
  }
  if (pbufMarkHistoryTrack != '\0') {
    if ((*(uint *)(param_1 + 0x9c) & 0x8000) == 0) {
      iVar4 = *(int *)(param_1 + 8) + param_1 + 0xa0;
      bVar1 = false;
      uVar6 = *(uint *)(param_1 + 0xc);
      if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {
        uVar5 = _pbufMarkHistoryOffStart;
        do {
          if ((((_pbufMarkHistoryOff1 == -1) ||
               ((_pbufMarkHistoryOff1 + uVar5 < uVar6 &&
                (*(char *)(_pbufMarkHistoryOff1 + iVar4 + uVar5) == pbufMarkHistoryVal1)))) &&
              ((_pbufMarkHistoryOff2 == -1 ||
               ((_pbufMarkHistoryOff2 + uVar5 < uVar6 &&
                (*(char *)(_pbufMarkHistoryOff2 + iVar4 + uVar5) == pbufMarkHistoryVal2)))))) &&
             ((_pbufMarkHistoryOff3 == -1 ||
              ((_pbufMarkHistoryOff3 + uVar5 < uVar6 &&
               (*(char *)(_pbufMarkHistoryOff3 + iVar4 + uVar5) == pbufMarkHistoryVal3)))))) {
            bVar1 = true;
          }
          uVar5 = uVar5 + 1;
        } while (!bVar1 && uVar5 <= _pbufMarkHistoryOffEnd);
      }
      if (bVar1) {
        if ((pbufMarkHistoryMatchLocation1 == '\0') || (_pbufMarkHistoryLocationVal1 == 0x19))
        goto LAB_02ad55a8;
      }
      else if (bVar1) {
LAB_02ad55a8:
                    /* WARNING: Subroutine does not return */
        intLockProtect(&pbufMarkHistoryLock);
      }
    }
    else {
      iVar4 = (uint)*(ushort *)(param_1 + 0x9c) * 0x408;
      pcVar9 = &pbufMarkHistoryTable + iVar4;
      if (*pcVar9 == '\0') {
        *pcVar9 = '\x01';
        *(uint32_t *)(iVar4 + 0xe58e868) = 0;
        uVar3 = *(uint *)(iVar4 + 0xe58e868);
      }
      else {
        uVar3 = *(uint *)(iVar4 + 0xe58e868);
      }
      iVar2 = _kernelIsSmp;
      if (uVar3 < 0x3f) {
        piVar10 = (int *)(pcVar9 + uVar3 * 0x10 + 8);
        if (_kernelIsSmp == 0) {
          if (_smpIntCnt == 0) {
LAB_02ad6e70:
            *piVar10 = _smpTaskIdCurrent;
          }
          else {
            *piVar10 = 0;
          }
        }
        else {
          Status = Status & 0xfffffffe;
          setCopReg(0,Status,uVar5,0);
          if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
            if (_kernelIsSmp == 0) goto LAB_02ad6e70;
            *piVar10 = *(int *)(in_zero + -0x8000);
          }
          else {
            *piVar10 = 0;
          }
        }
        *(uint16_t *)(pcVar9 + uVar3 * 0x10 + 0xc) = 0x19;
        if (iVar2 == 0) {
          uVar5 = *(uint *)(_smpTaskIdCurrent + 0x2b8);
        }
        else {
          uVar5 = *(uint *)(*(int *)(in_zero + -0x8000) + 0x2b8);
        }
        if (iVar2 == 0) {
          uVar8 = *(uint *)(_smpTaskIdCurrent + 700);
        }
        else {
          uVar8 = *(uint *)(*(int *)(in_zero + -0x8000) + 700);
        }
        *(uint *)(pcVar9 + uVar3 * 0x10 + 0x10) = uVar6;
        *(uint16_t *)(pcVar9 + uVar3 * 0x10 + 0xe) = uVar11;
        *(uint *)(pcVar9 + uVar3 * 0x10 + 0x14) = (uVar5 & 7) << 8 | uVar8;
        *(int *)(iVar4 + 0xe58e868) = *(int *)(iVar4 + 0xe58e868) + 1;
      }
    }
  }
  *(uint16_t *)(param_1 + 0x94) = 0x19;
  if (_kernelIsSmp == 0) {
    uVar6 = *(uint *)(_smpTaskIdCurrent + 0x2b8);
  }
  else {
    uVar6 = *(uint *)(*(int *)(in_zero + -0x8000) + 0x2b8);
  }
  uVar6 = (uVar6 & 7) << 8;
  if (_kernelIsSmp == 0) {
    uVar5 = *(uint *)(_smpTaskIdCurrent + 700);
    *(uint16_t *)(param_1 + 0x96) = uVar11;
    *(uint *)(param_1 + 0x98) = uVar6 | uVar5;
  }
  else {
    uVar5 = *(uint *)(*(int *)(in_zero + -0x8000) + 700);
    *(uint16_t *)(param_1 + 0x96) = uVar11;
    *(uint *)(param_1 + 0x98) = uVar6 | uVar5;
  }
LAB_02ad5708:
  if (IccLogEnabled != '\0') {
    iccLogEvent(param_1,4);
  }
                    /* WARNING: Subroutine does not return */
  intLockProtect(&IccLockIncoming);
}