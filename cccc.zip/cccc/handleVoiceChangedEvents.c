#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void handleVoiceChangedEvents(uint16_t *param_1)



{

  int iVar1;

  uint32_t uVar2;

  uint16_t uVar3;

  int iVar4;

  int iVar5;

  int aiStack_180 [92];

  

  iVar4 = *(int *)(param_1 + 0xc);

  iVar5 = *(int *)(iVar4 + 4);

  if (*(char *)(param_1 + 0x26) == '\0') {

    aiStack_180[0] = *(int *)(param_1 + 0x28);

    if (aiStack_180[0] == *(int *)(param_1 + 0x2a)) {

      return;

    }

  }

  else {

    aiStack_180[0] = *(int *)(param_1 + 0x28);

  }

  if (_tracepointsActive == 0) {

    uVar3 = *param_1;

  }

  else {

    iVar1 = traceTest(_MOD_MDADRV,0xa971ff8,1,0);

    if (iVar1 == 0) {

      uVar3 = *param_1;

    }

    else {

      uVar2 = 0xa964dfc;

      if (aiStack_180[0] != 3) {

        uVar2 = 0xa964e00;

      }

      tracePrintVRtr(_MOD_MDADRV,0xa971ff8,1,0,1,0xa965138,uVar2,*(uint32_t *)(iVar5 + 0x36ca24),

                     *(int *)(iVar4 + 0xcb8) + 1,*param_1,*(uint32_t *)(param_1 + 0x2a),

                     *(uint32_t *)(param_1 + 0x28));

      uVar3 = *param_1;

    }

  }

  posPortEventFn(iVar4,1,uVar3,1,aiStack_180,0);

  if (*(uint16_t **)(iVar4 + 0x7e8) == param_1) {

    posPortEventFn(iVar4,0,0,1,aiStack_180,0);

  }

  return;

}



