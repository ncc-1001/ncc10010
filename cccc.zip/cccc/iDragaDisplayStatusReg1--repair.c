#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added missing declarations
extern int _gHwPlatform;
extern int _traceEnabled;
extern int _tracepointsActive;
typedef int (*code)(uint32_t, int, uintptr_t*);
#define _MOD_MDADRV 0  // Modified: Added missing constant

uint32_t iDragaDisplayStatusReg1(uint32_t param_1,int param_2)
{
  int iVar1;
  int iVar2;
  uintptr_t auStack_18 [8];
  
  iVar1 = _gHwPlatform * 0x34;
  iVar2 = *(int *)(iVar1 + 0xbbfd940) + *(int *)(iVar1 + 0xbbfd924) * param_2;
  if (_gHwPlatform - 1U < 3) {
    iVar1 = (**(code **)(iVar1 + 0xbbfd94c))(param_1,iVar2,auStack_18);
    if (iVar1 == 0) {
                    /* WARNING: Subroutine does not return */
      printf(0xa8e2560,iVar2);
    }
    iVar1 = macMdaRemoved(param_1);
    if ((iVar1 == 0) &&
       ((_traceEnabled != 0 ||
        ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8e2548,4,0), iVar1 != 0))))))
    {
      tracePrintVRtr(_MOD_MDADRV,0xa8e2548,4,0,1,0xa8e1650,param_1,iVar2);
    }
  }
  else {
    iVar1 = macMdaRemoved();
    if ((iVar1 == 0) &&
       ((_traceEnabled != 0 ||
        ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8e2548,4,0), iVar1 != 0))))))
    {
      tracePrintVRtr(_MOD_MDADRV,0xa8e2548,4,0,1,0xa8e1634,_gHwPlatform);
    }
  }
  return 0xffffffff;
}