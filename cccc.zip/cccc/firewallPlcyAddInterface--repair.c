#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_FIREWALL;

uint32_t firewallPlcyAddInterface(uint32_t *param_1)
{
  int iVar1;
  uintptr_t auStack_30 [40];
  
  FmtPlcyInterfaceName(auStack_30,0x21,param_1);
  firewallSetInterrupt();
  iVar1 = fwksAddIdxIfc(auStack_30,*param_1,param_1[1]);
  if (iVar1 != 1) {
    firewallClearInterrupt();
    if ((_traceEnabled != 0) ||
       ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_FIREWALL,0xa17d7b8,4,0), iVar1 != 0))))
    {
      tracePrintVRtr(_MOD_FIREWALL,0xa17d7b8,4,0,1,0xa17d7d4,auStack_30);
    }
    return 0xffffffff;
  }
  firewallClearInterrupt();
  return 0;
}