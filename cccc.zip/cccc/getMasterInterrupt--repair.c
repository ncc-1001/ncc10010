#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared variable
extern char cRam10c8f925;
// Modified: Added extern declaration for undeclared variable
extern uint32_t uRam00000004;

uintptr_t getMasterInterrupt(void)

{

  int iVar1;

  uintptr_t uVar2;

  uint32_t uVar3;

  int iVar4;

  

  iVar1 = utilCometqDeviceHandle2Ddb();

  iVar4 = *(int *)(iVar1 + 0x10) + 0x2f0;

  if (cRam10c8f925 != -0x24) {

    iVar4 = *(int *)(iVar1 + 0x10) + 0xbc;

  }

  if (*(int *)(iVar1 + 0x14) == 0) {

    timosAssert(0xa98547c,0xa9847d0,0x174f,0xa985470,0xa9847c0);

    uVar3 = uRam00000004;

  }

  else {

    uVar3 = *(uint32_t *)(*(int *)(iVar1 + 0x14) + 4);

  }

  uVar2 = fpgaFramerRead(uVar3,iVar4);

  return uVar2;

}