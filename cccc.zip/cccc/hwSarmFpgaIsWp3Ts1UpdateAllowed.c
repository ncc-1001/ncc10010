#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwSarmFpgaIsWp3Ts1UpdateAllowed(void)



{

                    /* WARNING: Bad instruction - Truncating control flow here */

  halt_baddata();

}



