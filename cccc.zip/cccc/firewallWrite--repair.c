#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern uintptr_t *FirewallPlcyDebug; // Modified: Added extern declaration for undeclared identifier
extern int _tracepointsActive; // Modified: Added extern declaration for undeclared identifier
extern int _MOD_FIREWALL; // Modified: Added extern declaration for undeclared identifier

int firewallWrite(uintptr_t param_1,uint32_t param_2)
{
  int iVar1;
  uint32_t uVar2;
  int iVar3;
  uintptr_t auStack_288 [8];
  int iStack_280;
  uintptr_t auStack_228 [264];
  uintptr_t auStack_120 [264];
  
  memset(auStack_288,0,0x60);
  snprintf(auStack_228,0x101,0xa17d64c,param_1,param_2);
  iVar1 = fwksCommand(auStack_288,auStack_228,0,0,auStack_120,0x101);
  iVar3 = 0;
  if (iVar1 != 1) {
    iVar3 = -1;
    firewallSetErrorBuffer(auStack_228);
  }
  if (((FirewallPlcyDebug != (uintptr_t *)0x0) && (_tracepointsActive != 0)) &&
     (iVar1 = traceTest(_MOD_FIREWALL,0xa17d63c,1,0), iVar1 != 0)) {
    uVar2 = 0xa17d678;
    if (iVar3 != -1) {
      uVar2 = 0xa17d680;
    }
    tracePrintVRtr(_MOD_FIREWALL,0xa17d63c,1,0,1,0xa17d654,param_1,param_2,uVar2,iStack_280);
  }
  if (iStack_280 != 0) {
    firemgrNotifyPlcyEvents(auStack_288);
    return iVar3;
  }
  return iVar3;
}