#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisSendInterfaceMsg(uint32_t param_1,uint32_t param_2,uint32_t param_3)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t *apuStack_18 [2];

  

  iVar1 = redAmIActive(0x34);

  uVar2 = 0;

  if (iVar1 != 0) {

    apuStack_18[0] = (uint32_t *)isisMalloc(0x14);

    uVar2 = 6;

    if (apuStack_18[0] != (uint32_t *)0x0) {

      *apuStack_18[0] = 1;

      apuStack_18[0][1] = 3;

      apuStack_18[0][2] = 8;

      apuStack_18[0][4] = param_3;

      apuStack_18[0][3] = param_2;

      uVar2 = isisGetTDGenMsgQId();

      iVar1 = msgQSend(uVar2,apuStack_18,4,0,0);

      uVar2 = 0;

      if (iVar1 == -1) {

        isisFree(apuStack_18[0]);

        isisIncTDGenMsgQSendErr();

        uVar2 = 0xd;

      }

    }

  }

  return uVar2;

}



