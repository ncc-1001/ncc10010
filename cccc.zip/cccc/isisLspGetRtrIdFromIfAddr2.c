#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisLspGetRtrIdFromIfAddr2(uint32_t *param_1,int param_2,int param_3)



{

  uint32_t uVar1;

  

  uVar1 = 0xffffffff;

  if (param_3 != 0) {

    if (param_2 == 0 || param_2 == 3) {

      if (param_1[7] != 2) {

        isisTryGetFromIntf2RtrIdCache(*param_1,param_3,1,0xa1aafc4);

      }

      uVar1 = 0;

      if (*(int *)(param_3 + 4) == 0) {

        if (param_1[7] == 1) {

          return 0xffffffff;

        }

        isisTryGetFromIntf2RtrIdCache(*param_1,param_3,2,0xa1aafc4);

        if (*(int *)(param_3 + 4) == 0) {

          return 0xffffffff;

        }

        uVar1 = 0;

      }

    }

    else {

      isisTryGetFromIntf2RtrIdCache(*param_1,param_3,param_2,0xa1aafc4);

      uVar1 = 0;

      if (*(int *)(param_3 + 4) == 0) {

        return 0xffffffff;

      }

    }

  }

  return uVar1;

}



