#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int _bgp_af_vpn_network_addr_index;
extern int bgp_af_vpn_network_addr_index;
extern int _MyHwFamily;

void bgp_vrtm_rr_cluster_change(int param_1,int param_2)
{

  int iVar1;
  int *piVar2;
  int iVar3;
  
  if (param_2 != 0) {
    bgp_orf_become_rr();
    return;
  }
  if (_bgp_af_vpn_network_addr_index != 0) {
    piVar2 = (int *)&bgp_af_vpn_network_addr_index;
    iVar3 = 1;
    iVar1 = _bgp_af_vpn_network_addr_index;
    while( true ) {
      bgp_vpn_rib_in_purge_remote(param_1,0,2,iVar1,0,0);
      piVar2 = piVar2 + 1;
      if ((3 < iVar3) || (iVar1 = *piVar2, iVar1 == 0)) break;
      iVar3 = iVar3 + 1;
    }
  }
  timerReset(*(uint32_t *)(param_1 + 0xdd8),10);
  if ((_MyHwFamily == 3) && (iVar1 = redAmIActive(0x39), iVar1 == 0)) {
    return;
  }
  bgp_orf_become_non_rr(param_1);
  return;
}