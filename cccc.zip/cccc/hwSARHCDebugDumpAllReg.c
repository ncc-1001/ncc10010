#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */



void hwSARHCDebugDumpAllReg(void)



{

  int iVar1;

  int iVar2;

  int iVar3;

  int iVar4;

  int *piVar5;

  int *piVar6;

  int aiStack_120 [64];

  

  piVar6 = aiStack_120;

  piVar5 = (int *)0x69c2398;

  do {

    iVar1 = *piVar5;

    iVar2 = piVar5[1];

    iVar3 = piVar5[2];

    iVar4 = piVar5[3];

    piVar5 = piVar5 + 4;

    *piVar6 = iVar1;

    piVar6[1] = iVar2;

    piVar6[2] = iVar3;

    piVar6[3] = iVar4;

    piVar6 = piVar6 + 4;

  } while (piVar5 != (int *)0x69c2498);

  if (aiStack_120[0] != 0xffff) {

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

  return;

}



