#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern char *isisTitleStr;
extern int _MOD_ISIS;

void isisSpfAddPsdonodeToTent(uint32_t *param_1,int param_2,int param_3,int param_4)

{

  int iVar1;

  uint uVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint uVar5;

  uint32_t *puVar6;

  uintptr_t auStack_28 [8];
  
  if (param_3 == 1) {
    iVar1 = *(int *)(param_2 + 0x44c);
  }
  else {
    iVar1 = *(int *)(param_2 + 0x61c);
  }
  if (iVar1 == 0) {
    return;
  }
  if (param_3 == 1) {
    iVar1 = *(int *)(param_2 + 0x448);
  }
  else {
    iVar1 = *(int *)(param_2 + 0x618);
  }
  if (iVar1 == 0) {
    if (param_3 == 1) {
      uVar2 = *(uint *)(param_2 + 0x43c);
    }
    else {
      uVar2 = *(uint *)(param_2 + 0x60c);
    }
    if (((uVar2 ^ 1) & 1) != 0) {
      return;
    }
  }
  if (param_3 == 1) {
    iVar1 = *(int *)(param_2 + 0x448);
  }
  else {
    iVar1 = *(int *)(param_2 + 0x618);
  }
  if ((iVar1 != 0) && (*(char *)(iVar1 + 0x93) == '\x01')) {
    if (param_1 == (uint32_t *)0x0) {
      return;
    }
    if ((param_1[0x1b] & 0x100) == 0) {
      return;
    }
    iVar1 = isisDebugCheck(param_1,0x100,param_3,0);
    if (iVar1 == 0) {
      return;
    }
    if (_IsisLogger != 0) {
      uVar3 = isisXlateMtId(param_4);
      uVar4 = isisDumpSysId(auStack_28,param_1 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b140c,param_3,uVar3,
                         *(uint32_t *)(param_2 + 8),uVar4);
      return;
    }
    uVar3 = isisXlateMtId(param_4);
    uVar4 = isisDumpSysId(auStack_28,param_1 + 0x6a1,0x400,0);
    tracePrint(_MOD_ISIS,0xa1b13f0,0,0,0xa1b140c,param_3,uVar3,*(uint32_t *)(param_2 + 8),uVar4);
    return;
  }
  iVar1 = param_2 + 0x418;
  if (param_3 != 1) {
    iVar1 = param_2 + 0x5e8;
  }
  memcpy(auStack_28,iVar1,7);
  if (param_3 == 1) {
    uVar2 = *(uint *)(param_4 * 4 + param_2 + 1000);
  }
  else {
    uVar2 = *(uint *)(param_4 * 4 + param_2 + 0x5b8);
  }
  if (0xfffffe < uVar2) {
    return;
  }
  if (param_3 == 1) {
    if (*(char *)((int)param_1 + 0x2059) != '\x01') {
LAB_0424ffb0:
      if (0x3f < uVar2) {
        uVar2 = 0x3f;
      }
      if (*(uint *)(param_2 + 0x3c8) < 3) {
        uVar2 = 0x3f;
      }
      goto LAB_0424ffc8;
    }
    uVar5 = *(uint *)(param_2 + 0x3c8);
  }
  else {
    if (*(char *)((int)param_1 + 0x205a) != '\x01') goto LAB_0424ffb0;
    uVar5 = *(uint *)(param_2 + 0x3c8);
  }
  if (uVar5 < 3) {
    uVar2 = 0xfffffe;
  }
  if (0xfffffe < uVar2) {
    return;
  }
LAB_0424ffc8:
  if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x100) != 0)) &&
     (iVar1 = isisDebugCheck(param_1,0x100,param_3,0), iVar1 != 0)) {
    if (_IsisLogger == 0) {
      uVar3 = isisXlateMtId(param_4);
      uVar4 = isisDumpSysId(auStack_28,param_1 + 0x6a1,0x400,0);
      tracePrint(_MOD_ISIS,0xa1b13f0,0,0,0xa1b14c0,param_3,uVar3,*(uint32_t *)(param_2 + 8),uVar4,
                 uVar2);
    }
    else {
      uVar3 = isisXlateMtId(param_4);
      uVar4 = isisDumpSysId(auStack_28,param_1 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b14c0,param_3,uVar3,
                         *(uint32_t *)(param_2 + 8),uVar4,uVar2);
    }
  }
  iVar1 = isisSpfFindDestInTent(param_1,auStack_28,param_3);
  if (iVar1 == 0) {
    puVar6 = (uint32_t *)isisSpfPathAlloc(param_1);
    if (puVar6 != (uint32_t *)0x0) {
      *puVar6 = 2;
      memcpy(puVar6 + 2,auStack_28,7);
      puVar6[1] = uVar2;
      isisSpfAddToTent(param_1,param_3,puVar6,1);
    }
  }
  else if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x100) != 0)) &&
          (iVar1 = isisDebugCheck(param_1,0x100,param_3,0), iVar1 != 0)) {
    if (_IsisLogger == 0) {
      uVar3 = isisXlateMtId(param_4);
      uVar4 = isisDumpSysId(auStack_28,param_1 + 0x6a1,0x400,0);
      tracePrint(_MOD_ISIS,0xa1b13f0,0,0,0xa1b1458,param_3,uVar3,*(uint32_t *)(param_2 + 8),uVar4,
                 uVar2);
    }
    else {
      uVar3 = isisXlateMtId(param_4);
      uVar4 = isisDumpSysId(auStack_28,param_1 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1458,param_3,uVar3,
                         *(uint32_t *)(param_2 + 8),uVar4,uVar2);
    }
  }
  return;
}