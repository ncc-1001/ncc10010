#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern uint32_t Status;
extern uint32_t _vxAbsTicks;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern uint32_t _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern char pbufMarkHistoryTrack;
extern int _pbufMarkHistoryOffStart;
extern int _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern char pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern char pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern char pbufMarkHistoryVal3;
extern char pbufMarkHistoryMatchLocation1;
extern int _pbufMarkHistoryLocationVal1;
extern int pbufMarkHistoryLock;
extern char pbufMarkHistoryTable;
extern int Dot1agPktQ;
extern int _Dot1agPktQueueSize;
extern int iRam10cae71c;

uint32_t dot1agEnqueueCsaEgressFrame(int param_1)
{

  bool bVar1;

  int in_zero;

  uint uVar2;

  int iVar3;

  int *piVar4;

  uint uVar5;

  uint uVar6;

  uint uVar7;

  uint uVar8;

  char *pcVar9;

  uint32_t *puVar10;

  uint16_t uVar11;

  

  uVar7 = Status;

  uVar5 = _vxAbsTicks;

  puVar10 = (uint32_t *)(param_1 + 0x88);

  uVar8 = (uint)*(ushort *)(param_1 + 0x94);

  uVar2 = _vxAbsTicks / 100;

  if (uVar8 == 0) goto LAB_03ff66ec;

  if (_kernelIsSmp == 0) {

    if (_smpIntCnt == 0) {

LAB_03ff67bc:

      *puVar10 = _smpTaskIdCurrent;

    }

    else {

      *puVar10 = 0;

    }

  }

  else {

    Status = Status & 0xfffffffe;

    setCopReg(0,Status,uVar7,0);

    if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {

      if (_kernelIsSmp == 0) goto LAB_03ff67bc;

      *puVar10 = *(uint32_t *)(in_zero + -0x8000);

    }

    else {

      *puVar10 = 0;

    }

  }

  uVar7 = Status;

  uVar6 = (uVar2 & 0xffff) - (uint)*(ushort *)(param_1 + 0x96) & 0xffff;

  uVar11 = (uint16_t)uVar2;

  if ((uVar6 != 0) && (uVar8 < 0xab)) {

    if (8 < uVar6) {

      uVar6 = 8;

    }

    iVar3 = (uVar8 * 0x558 + uVar6) * 8;

    piVar4 = (int *)(iVar3 + 0xecd666c);

    *(uint16_t *)(iVar3 + 0xecd6670) = uVar11;

    *piVar4 = *piVar4 + 1;

  }

  if (pbufMarkHistoryTrack != '\0') {

    if ((*(uint *)(param_1 + 0x9c) & 0x8000) == 0) {

      iVar3 = *(int *)(param_1 + 8) + param_1 + 0xa0;

      bVar1 = false;

      uVar5 = *(uint *)(param_1 + 0xc);

      if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {

        uVar7 = _pbufMarkHistoryOffStart;

        do {

          if ((((_pbufMarkHistoryOff1 == -1) ||

               ((_pbufMarkHistoryOff1 + uVar7 < uVar5 &&

                (*(char *)(_pbufMarkHistoryOff1 + iVar3 + uVar7) == pbufMarkHistoryVal1)))) &&

              ((_pbufMarkHistoryOff2 == -1 ||

               ((_pbufMarkHistoryOff2 + uVar7 < uVar5 &&

                (*(char *)(_pbufMarkHistoryOff2 + iVar3 + uVar7) == pbufMarkHistoryVal2)))))) &&

             ((_pbufMarkHistoryOff3 == -1 ||

              ((_pbufMarkHistoryOff3 + uVar7 < uVar5 &&

               (*(char *)(_pbufMarkHistoryOff3 + iVar3 + uVar7) == pbufMarkHistoryVal3)))))) {

            bVar1 = true;

          }

          uVar7 = uVar7 + 1;

        } while (!bVar1 && uVar7 <= _pbufMarkHistoryOffEnd);

      }

      if (bVar1) {

        if ((pbufMarkHistoryMatchLocation1 == '\0') || (_pbufMarkHistoryLocationVal1 == 0x95))

        goto LAB_03ff65e0;

        *(uint16_t *)(param_1 + 0x96) = uVar11;

        *(uint16_t *)(param_1 + 0x94) = 0x95;

        *(uint32_t *)(param_1 + 0x98) = 0;

        goto LAB_03ff66ec;

      }

      if (bVar1) {

LAB_03ff65e0:

                    /* WARNING: Subroutine does not return */

        intLockProtect(&pbufMarkHistoryLock);

      }

    }

    else {

      iVar3 = (uint)*(ushort *)(param_1 + 0x9c) * 0x408;

      pcVar9 = &pbufMarkHistoryTable + iVar3;

      if (*pcVar9 == '\0') {

        *pcVar9 = '\x01';

        *(uint32_t *)(iVar3 + 0xe58e868) = 0;

        uVar2 = *(uint *)(iVar3 + 0xe58e868);


      }

      else {

        uVar2 = *(uint *)(iVar3 + 0xe58e868);

      }

      if (uVar2 < 0x3f) {

        puVar10 = (uint32_t *)(pcVar9 + uVar2 * 0x10 + 8);

        if (_kernelIsSmp == 0) {

          if (_smpIntCnt == 0) {

LAB_03ff6834:

            *puVar10 = _smpTaskIdCurrent;

          }

          else {

            *puVar10 = 0;

          }

        }

        else {

          Status = Status & 0xfffffffe;

          setCopReg(0,Status,uVar7,0);

          if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {

            if (_kernelIsSmp == 0) goto LAB_03ff6834;

            *puVar10 = *(uint32_t *)(in_zero + -0x8000);

          }

          else {

            *puVar10 = 0;

          }

        }

        *(uint *)(pcVar9 + uVar2 * 0x10 + 0x10) = uVar5;

        *(uint16_t *)(pcVar9 + uVar2 * 0x10 + 0xc) = 0x95;

        *(uint32_t *)(pcVar9 + uVar2 * 0x10 + 0x14) = 0;

        *(uint16_t *)(pcVar9 + uVar2 * 0x10 + 0xe) = uVar11;

        *(int *)(iVar3 + 0xe58e868) = *(int *)(iVar3 + 0xe58e868) + 1;

      }

    }

  }

  *(uint16_t *)(param_1 + 0x96) = uVar11;

  *(uint16_t *)(param_1 + 0x94) = 0x95;

  *(uint32_t *)(param_1 + 0x98) = 0;

LAB_03ff66ec:

  *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x800;

  uVar5 = tmMsgQGetCount(&Dot1agPktQ);

  if (_Dot1agPktQueueSize <= uVar5) {

    iRam10cae71c = iRam10cae71c + 1;

    pbufFree(param_1);

    return 0;

  }

  performCsaUpMepPacketManipulations(param_1);

  tmMsgQSend(&Dot1agPktQ,param_1 + 0x14);

  return 0;
}