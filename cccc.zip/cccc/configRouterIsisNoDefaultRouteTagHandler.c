#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int configRouterIsisNoDefaultRouteTagHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t *apuStack_10 [2];

  

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,apuStack_10);

  if (iVar1 != 0) {

    return iVar1;

  }

  iVar1 = configRouterIsisNoDefaultRouteTag(param_1,*apuStack_10[0]);

  return iVar1;

}



