#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int *_gMdaInfo;
extern int cRam10c8f925;
extern uint32_t uRam00000004;

void comet8FastPoll(uint param_1,int param_2,char param_3,char param_4)
{

  uint uVar1;
  uint32_t uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  
  iVar8 = 0;
  if (((param_1 == 0) || (*_gMdaInfo < param_1)) ||
     (iVar8 = *(int *)(param_1 * 4 + 0xccb422c), iVar8 == 0)) {
    timosAssert(0xa9847c4,0xa9847d0,0x1456,0xa9855f4,0xa9847c0);
  }
  iVar5 = *(int *)(param_2 * 4 + iVar8 + 0x94);
  if (iVar5 == 0) {
    timosAssert(0xa985604,0xa9847d0,0x1458,0xa9855f4,0xa9847c0);
  }
  iVar5 = utilCometqDeviceHandle2Ddb(iVar5);
  iVar7 = *(int *)(iVar5 + 0x10) + 0x2f0;
  if (cRam10c8f925 != -0x24) {
    iVar7 = *(int *)(iVar5 + 0x10) + 0xbc;
  }
  if (*(int *)(iVar5 + 0x14) == 0) {
    timosAssert(0xa98547c,0xa9847d0,0x174f,0xa985470,0xa9847c0);
    uVar2 = uRam00000004;
  }
  else {
    uVar2 = *(uint32_t *)(*(int *)(iVar5 + 0x14) + 4);
  }
  uVar6 = 0;
  uVar1 = fpgaFramerRead(uVar2,iVar7);
  uVar4 = (uint)*(byte *)(iVar8 + 0xc);
  uVar3 = (uint)*(byte *)(iVar8 + 0xd);
  if (uVar4 + uVar3 != 0) {
    do {
      if ((1 << (uVar6 & 0x1f) & uVar1 & 0xff) != 0) {
        if (param_3 != '\0') {
          comet8FastPortPoll(param_1,param_2,uVar6);
        }
        if (param_4 == '\0') {
          uVar4 = (uint)*(byte *)(iVar8 + 0xc);
        }
        else if (*(char *)((uVar6 + param_2 * 8 & 0xff) * 0x8c + iVar8 + 0x139) == '\0') {
          uVar4 = (uint)*(byte *)(iVar8 + 0xc);
        }
        else {
          comet8FdlPortPoll(param_1,param_2,uVar6);
          uVar4 = (uint)*(byte *)(iVar8 + 0xc);
        }
        uVar3 = (uint)*(byte *)(iVar8 + 0xd);
      }
      uVar6 = uVar6 + 1 & 0xff;
    } while (uVar6 < uVar4 + uVar3);
  }
  return;
}