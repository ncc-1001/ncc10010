#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendRejectedAdjTrap(uint32_t *param_1,uint32_t param_2,int param_3)



{

  uint32_t uVar1;

  

  uVar1 = *param_1;

  logEvent_ISIS_vRtrIsisRejectedAdjacency

            (uVar1,0xa1bbbb0,uVar1,param_2,uVar1,*(uint32_t *)(param_3 + 8));

  return;

}



