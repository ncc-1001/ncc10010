#include "nokia.h"
#include <stdint.h>

int hwWakiGetMciAlarm(uint32_t param_1)



{

  int iVar1;

  

  iVar1 = -1;

  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {

    iVar1 = hwWakiReadReg32(0,0xc,param_1);

    iVar1 = (iVar1 == 0) - 1;

  }

  return iVar1;

}



