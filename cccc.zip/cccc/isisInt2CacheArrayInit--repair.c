#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared global variables
extern uint32_t uRam0c98c080;
extern uint32_t uRam0c98c088;

void isisInt2CacheArrayInit(void)
{
  uRam0c98c080 = 0;
  uRam0c98c088 = 0;
  return;
}