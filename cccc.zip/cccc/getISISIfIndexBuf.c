#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int getISISIfIndexBuf(uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,

                     uint32_t param_5)



{

  int iVar1;

  int iVar2;

  uintptr_t auStack_7f0 [1000];

  uintptr_t auStack_408 [1000];

  uintptr_t auStack_20 [8];

  

  iVar1 = getVRtrId();

  iVar2 = -1;

  if (iVar1 != 0) {

    iVar2 = pipGetRtrIfIndex(iVar1,param_3);

    if (iVar2 == 0) {

      cliErrorMesg(param_1,0xa07cc68,param_3,iVar1);

      iVar2 = -1;

    }

    else {

      snprintf(param_4,param_5,0xa07cc3c,iVar1,iVar2);

      snprintf(auStack_7f0,1000,0xa07cc44,param_4);

      iVar1 = RCC_RCB_ReadValueFromRCB(param_1,auStack_7f0,0,auStack_408,auStack_20);

      if (iVar1 == 0) {

        iVar1 = strcmp(auStack_408,0xa07cc5c);

        iVar2 = 2 - (uint)(iVar1 != 0);

      }

      else {

        cliErrorMesg(param_1,0xa07cc88);

        iVar2 = -1;

      }

    }

  }

  return iVar2;

}



