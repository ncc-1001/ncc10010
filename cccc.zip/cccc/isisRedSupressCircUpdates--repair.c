#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

void isisRedSupressCircUpdates(uint32_t *param_1,char param_2)

{

  int iVar1;
  
  if (param_1 != (uint32_t *)0x0) {
    if (param_2 != '\0') {
      param_1[0x843] = param_1[0x843] + 1;
      return;
    }
    iVar1 = param_1[0x843] + -1;
    if (iVar1 < 0) {
      if ((param_1[0x1b] & 2) == 0) {
        param_1[0x843] = 0;
      }
      else {
        param_1[0x843] = iVar1;
        iVar1 = isisDebugCheck(param_1,2,0,0);
        if (iVar1 == 0) {
          param_1[0x843] = 0;
        }
        else if (_IsisLogger == 0) {
          tracePrint(_MOD_ISIS,0xa1addc0,0,0,0xa1adddc);
          param_1[0x843] = 0;
        }
        else {
          logEvent_debug_fmt(*param_1,0xa1ac4d0,&isisTitleStr,0xa1adddc);
          param_1[0x843] = 0;
        }
      }
      return;
    }
    param_1[0x843] = iVar1;
  }
  return;
}