#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Update typedef for 'code' type to match usage
typedef int (*code)(void*, void*);
typedef int (*code_single)(void*);

// Modified: Add extern declaration for '_gMdaInfo'
extern uint32_t *_gMdaInfo;

void csaEthHwMdaHandlePoeReset(int param_1,uintptr_t param_2,char param_3)


{

  int iVar1;

  char *pcVar2;

  code *pcVar3;

  int iVar4;

  uint uVar5;

  uint uVar6;

  

  if ((((param_1 != 0) && (iVar1 = xmacRedIsCardActive(*(uint32_t *)(param_1 + 8)), iVar1 != 0))

      && (iVar1 = macMdaRemoved(*(uint32_t *)(param_1 + 8)), iVar1 == 0)) &&

     ((uVar5 = *(uint *)(param_1 + 8), uVar5 != 0 && (uVar5 <= *_gMdaInfo)))) {

    iVar1 = uVar5 * 0x3a88;

    pcVar2 = (char *)(iVar1 + 0x10d260a8);

    if (((*pcVar2 != '\0') && ((pcVar2 != (char *)0x0 && (*(int *)(iVar1 + 0x10d260bc) != 0)))) &&

       ((pcVar3 = (code *)(*(int *)(iVar1 + 0x10d260bc) + 8), *pcVar3 != (code)0x0 &&

        (iVar4 = (*pcVar3)((void*)param_1,(void*)param_2), iVar4 == 0)))) {

      uVar5 = *(uint *)(param_1 + 0xec);

      uVar6 = 0;

      if (uVar5 != 0) {

        iVar4 = *(int *)(param_1 + 0x63b28);

        while( true ) {

          if ((((iVar4 != 0) && (*(char *)(iVar4 + uVar6) != '\0')) && (pcVar2 != (char *)0x0)) &&

             ((*(int *)(iVar1 + 0x10d260bc) != 0 &&

              (*(int *)(*(int *)(iVar1 + 0x10d260bc) + 0x14) != 0)))) {

            iVar4 = *(int *)(iVar1 + 0x10d29b18);

            uVar5 = (uint)*(byte *)(*(int *)(iVar4 + 0xc) + (uVar6 - *(byte *)(iVar4 + 6)));

            iVar4 = uVar5 * 0xc + (uint)*(byte *)(*(int *)(iVar4 + 8) + uVar5) * 0x34 + iVar4;

            *(uint32_t *)(iVar4 + 0x20) = 1;

            *(uint32_t *)(iVar4 + 0x1c) = 1;

            *(uint32_t *)(iVar4 + 0x18) = 1;

            iVar4 = (*(code_single *)(*(int *)(*(int *)(iVar1 + 0x10d260bc) + 0x14)))((void*)param_1);

            if (iVar4 == 0) {

              if (param_3 == '\0') {

                uVar5 = *(uint *)(param_1 + 0xec);

              }


              else {


                csaEthPortPoeConfig(param_1,uVar6 * 0x1a60 + param_1 + 0x9c8);

                uVar5 = *(uint *)(param_1 + 0xec);

              }

            }

            else {

              uVar5 = *(uint *)(param_1 + 0xec);

            }

          }

          uVar6 = uVar6 + 1 & 0xff;

          if (uVar5 <= uVar6) break;

          iVar4 = *(int *)(param_1 + 0x63b28);

        }

      }

    }

  }

  return;

}