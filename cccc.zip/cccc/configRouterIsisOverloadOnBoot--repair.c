#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int ___chk_strnum; // Modified: Added extern declaration for undeclared identifier ___chk_strnum

uint32_t

configRouterIsisOverloadOnBoot(uint32_t param_1,uint32_t param_2,int param_3,int param_4)

{

  int iVar1;

  uint32_t uVar2;

  

  uVar2 = 0xa07cc38;

  if (param_4 == 0) {

    uVar2 = 0xa07cc34;

    ___chk_strnum = 2;

  }

  else {

    ___chk_strnum = 3;

  }

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d958,0,uVar2);

  if (iVar1 == 0) {

    if (param_3 == 0) {

      param_3 = 0xa07d274;

      ___chk_strnum = 0;

    }

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d970,0,param_3);

    if (iVar1 == 0) {

      return 0;

    }

  }

  cliErrorMesg(param_1,0xa07d8fc);

  return 0xffffffff;

}
