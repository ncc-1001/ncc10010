#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for variables that are likely defined elsewhere
// These are required for compilation but don't affect the original logic
extern int *_pIomSessionBuffer;
extern uint32_t *_pIcc;
extern int _MOD_FIREWALL;
extern int _traceEnabled;
extern int _tracepointsActive;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t firemgrAddSessionToIOMBuffer(uint32_t *param_1)


{

  ushort uVar1;

  uint16_t uVar2;

  int *piVar3;

  int iVar4;

  int iVar5;

  uint32_t uVar6;

  int iVar7;

  

  iVar4 = chMgrGetOnlineIomBitmap();

  iVar7 = 2 - (uint)(*(char *)(param_1 + 2) == '\0');

  iVar5 = firemgrAmIActive();

  if (iVar5 == 0) {

    return 0;

  }

  if (iVar4 == 0) {

    return 0;

  }

  if (_pIomSessionBuffer != (int *)0x0) {

    if (*_pIomSessionBuffer != iVar7) {

      firemgrFlushSessionBufferToIOM();

    }

    if (_pIomSessionBuffer != (int *)0x0) {

      uVar1 = *(ushort *)(_pIomSessionBuffer + 2);

      goto LAB_040cdda4;

    }

  }

  _pIcc = (uint32_t *)iccNewTransactionAlloc(_MOD_FIREWALL,0x4ec,1);

  if (_pIcc == (uint32_t *)0x0) {

    if (_traceEnabled == 0) {

      if (_tracepointsActive == 0) {

        return 0xffffffff;

      }

      iVar4 = traceTest(_MOD_FIREWALL,0xa179ae0,4,0);

      if (iVar4 == 0) {

        return 0xffffffff;

      }

    }

    tracePrintVRtr(_MOD_FIREWALL,0xa179ae0,4,0,1,0xa179a78);

    return 0xffffffff;

  }

  _pIomSessionBuffer = (int *)_pIcc[8];

  *_pIcc = 1;

  *(uint16_t *)(_pIcc + 1) = 0x70;

  _pIcc[0x1e3] = 0;

  _pIcc[6] = 1;

  _pIcc[7] = 0x4ec;

  _pIomSessionBuffer[1] = 1;

  *_pIomSessionBuffer = iVar7;

  *(uint16_t *)(_pIomSessionBuffer + 2) = 0;

  uVar1 = *(ushort *)(_pIomSessionBuffer + 2);

LAB_040cdda4:

  piVar3 = _pIomSessionBuffer;

  *(uint32_t *)((int)_pIomSessionBuffer + (uint)uVar1 * 0x4e + 10) = *param_1;

  uVar2 = *(uint16_t *)((int)param_1 + 0x32);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x30) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x31) = (char)uVar2;

  uVar2 = *(uint16_t *)((int)param_1 + 0x22);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x2e) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x2f) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0xe) = param_1[0xd];

  uVar2 = *(uint16_t *)((int)param_1 + 0x16);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x20) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x21) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x22) = param_1[6];

  uVar2 = *(uint16_t *)((int)param_1 + 0x1e);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x2b) = (char)uVar2;

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x2a) = (char)((ushort)uVar2 >> 8);

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x26) = param_1[9];

  uVar2 = *(uint16_t *)((int)param_1 + 0x2a);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x2c) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x2d) = (char)uVar2;

  uVar2 = *(uint16_t *)((int)param_1 + 0x2e);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x1e) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x1f) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x12) = param_1[0xe];

  uVar2 = *(uint16_t *)((int)param_1 + 0x3e);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x1a) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x1b) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x16) = param_1[0x10];

  uVar2 = *(uint16_t *)((int)param_1 + 0x46);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x1c) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x1d) = (char)uVar2;

  uVar2 = *(uint16_t *)((int)param_1 + 0x6a);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x54) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x55) = (char)uVar2;

  uVar2 = *(uint16_t *)((int)param_1 + 0x5a);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x53) = (char)uVar2;

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x52) = (char)((ushort)uVar2 >> 8);

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x32) = param_1[0x1b];

  uVar2 = *(uint16_t *)((int)param_1 + 0x4e);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x44) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x45) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x46) = param_1[0x14];

  uVar2 = *(uint16_t *)((int)param_1 + 0x56);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x4e) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x4f) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x4a) = param_1[0x17];

  uVar2 = *(uint16_t *)((int)param_1 + 0x62);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x50) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x51) = (char)uVar2;

  uVar2 = *(uint16_t *)((int)param_1 + 0x66);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x43) = (char)uVar2;

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x42) = (char)((ushort)uVar2 >> 8);

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x36) = param_1[0x1c];

  uVar2 = *(uint16_t *)((int)param_1 + 0x76);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x3e) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x3f) = (char)uVar2;

  *(uint32_t *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x3a) = param_1[0x1e];

  uVar2 = *(uint16_t *)((int)param_1 + 0x7e);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x41) = (char)uVar2;

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x40) = (char)((ushort)uVar2 >> 8);

  uVar2 = *(uint16_t *)(param_1 + 0x3e);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x56) = (char)((ushort)uVar2 >> 8);

  *(char *)((int)piVar3 + (uint)uVar1 * 0x4e + 0x57) = (char)uVar2;

  *(short *)(_pIomSessionBuffer + 2) = *(short *)(_pIomSessionBuffer + 2) + 1;

  uVar6 = 0;

  if (*(short *)(_pIomSessionBuffer + 2) == 0x10) {

    uVar6 = firemgrFlushSessionBufferToIOM();

  }

  return uVar6;

}
