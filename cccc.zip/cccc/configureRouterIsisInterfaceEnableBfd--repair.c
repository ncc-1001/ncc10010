#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t

configureRouterIsisInterfaceEnableBfd(uint32_t param_1,uint32_t param_2,uint32_t param_3)


{

  int iVar1;

  uint32_t uVar2;

  

  ___chk_strnum = 1;

  iVar1 = cfgRouterISISInterfaceElements();

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07db6c); // Modified: Removed param_3 to match function declaration in nokia.h

    uVar2 = 0xffffffff;

  }

  return uVar2;

}
