#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added missing variable declarations to fix compilation errors
int _IsisLogger;
int _MOD_ISIS;
char isisTitleStr;
char isisPolChangePrefixV4;
char isisPolChangePrefixV6;
int uRam0b7620d8;
int uRam0b7620d4;
int uRam0b7620cc;
int uRam0b7620d0;
int uRam0b7620b0;
int uRam0b7620ac;
int uRam0b7620a4;
int uRam0b7620a8;

void isisPolChangeRtmCallback(uint32_t *param_1)
{
  bool bVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  char *pcVar5;
  int iVar6;
  uint32_t *puVar7;
  
  puVar7 = (uint32_t *)*param_1;
  uVar4 = isisGetTDRtmMsgList();
  if (((puVar7 != (uint32_t *)0x0) && ((puVar7[0x1b] & 0x10000) != 0)) &&
     (iVar6 = isisDebugCheck(puVar7,0x10000,0,0), iVar6 != 0)) {
    if (_IsisLogger == 0) {
      tracePrint(_MOD_ISIS,0xa1ac338,0,0,0xa1ac3c4,param_1[1],param_1[2],param_1[3]);
    }
    else {
      logEvent_debug_fmt(*puVar7,0xa1ac378,&isisTitleStr,0xa1ac3c4,param_1[1],param_1[2],param_1[3])
      ;
    }
  }
  pcVar5 = (char *)dlistAllocateNodeExt(uVar4,0x44,1);
  if (pcVar5 == (char *)0x0) {
    if (((puVar7 != (uint32_t *)0x0) && ((puVar7[0x1b] & 0x10000) != 0)) &&
       (iVar6 = isisDebugCheck(puVar7,0x10000,0,0), iVar6 != 0)) {
      if (_IsisLogger == 0) {
        tracePrint(_MOD_ISIS,0xa1ac338,0,0,0xa1ac3fc);
      }
      else {
        logEvent_debug_fmt(*puVar7,0xa1ac378,&isisTitleStr,0xa1ac3fc);
      }
    }
    return;
  }
  uVar4 = param_1[1];
  pcVar5[0x14] = '\0';
  *(uint32_t *)(pcVar5 + 0x24) = uVar4;
  if (param_1[2] == 0) {
    bVar1 = isisPolChangePrefixV4 == '\0';
    *pcVar5 = isisPolChangePrefixV4;
    uVar3 = uRam0b7620d8;
    uVar2 = uRam0b7620d4;
    uVar4 = uRam0b7620cc;
    if (bVar1) {
      *(uint32_t *)(pcVar5 + 8) = uRam0b7620d0;
      *(uint32_t *)(pcVar5 + 0xc) = uVar2;
      *(uint32_t *)(pcVar5 + 4) = uVar4;
      *(uint32_t *)(pcVar5 + 0x10) = uVar3;
    }
    else {
      *(uint32_t *)(pcVar5 + 4) = uRam0b7620cc;
    }
  }
  else {
    bVar1 = isisPolChangePrefixV6 == '\0';
    *pcVar5 = isisPolChangePrefixV6;
    uVar3 = uRam0b7620b0;
    uVar2 = uRam0b7620ac;
    uVar4 = uRam0b7620a4;
    if (bVar1) {
      *(uint32_t *)(pcVar5 + 8) = uRam0b7620a8;
      *(uint32_t *)(pcVar5 + 0xc) = uVar2;
      *(uint32_t *)(pcVar5 + 4) = uVar4;
      *(uint32_t *)(pcVar5 + 0x10) = uVar3;
    }
    else {
      *(uint32_t *)(pcVar5 + 4) = uRam0b7620a4;
    }
  }
  uVar4 = isisGetTDRtmMsgListSem();
                    /* WARNING: Subroutine does not return */
  semTake(uVar4,0xffffffff);
}