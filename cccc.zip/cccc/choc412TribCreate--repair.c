#include "nokia.h"
#include <stdint.h>

// Added: extern declarations for undeclared identifiers
extern int _MOD_MDADRV;
extern int _TgtSys;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


void choc412TribCreate(uint32_t param_1)
{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint32_t uVar5;
  uint32_t uVar6;
  int *piVar7;
  uint32_t uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  
  iVar1 = posMdaTribGetChanType();
  iVar2 = posMdaTribGetPort(param_1);
  iVar11 = *(int *)(iVar2 + 4);
  if ((_tracepointsActive != 0) && (iVar4 = traceTest(_MOD_MDADRV,0xa8f31b8,1,0), iVar4 != 0)) {
    uVar5 = posMdaTribGetPhysOffset(param_1);
    uVar6 = FmtChanType(iVar1);
    tracePrintVRtr(_MOD_MDADRV,0xa8f31b8,1,0,1,0xa8f31cc,*(uint32_t *)(iVar2 + 0xcb8),uVar5,uVar6)
    ;
  }
  uVar3 = csaOcnUtilsTribStm1Number(param_1);
  switch(iVar1) {
  case 4:
    piVar7 = (int *)posMdaTribGetPort(param_1);
    iVar1 = *piVar7;
    *(uint16_t *)(iVar1 + 0x66) = 1;
    *(uintptr_t *)
     (*(int *)(((uint)*(byte *)(iVar1 + 100) + *(int *)(iVar11 + 0x36ca24)) * 4 + 0xcca8798) + 1) =
         0;
    *(uint16_t *)
     (*(int *)(((uint)*(byte *)(iVar1 + 100) + *(int *)(iVar11 + 0x36ca24)) * 4 + 0xcca8798) + 2) =
         4;
  case 5:
    pelhamSts3IntMask(*(uint32_t *)(iVar11 + 0x36ca24),0,uVar3 & 0xff);
LAB_064394b0:
    posMdaTribSetPollTime(param_1,0x2ee);
    return;
  case 6:
  case 7:
    uVar9 = csaOcnUtilsTribAu3Tug3Number(param_1);
    ufe4SonetSdhHoCreate(*(uint32_t *)(iVar11 + 0x36ca24),uVar3,uVar9,iVar1 == 6,_TgtSys != 8);
    pelhamSts1IntMask(*(uint32_t *)(iVar11 + 0x36ca24),0,uVar3 & 0xff,uVar9 & 0xff);
    goto LAB_064394b0;
  case 8:
  case 0x12:
    posMdaTribSetPollTime(param_1,500);
    return;
  case 9:
  case 10:
    uVar9 = csaOcnUtilsTribAu3Tug3Number(param_1);
    iVar2 = csaOcnUtilsTribTug2Number(param_1);
    iVar4 = csaOcnUtilsTribTuNumber(param_1);
    ufe4SonetSdhLoCreate(*(uint32_t *)(iVar11 + 0x36ca24),uVar3,uVar9,iVar2,iVar4,iVar1 == 9,1);
    posMdaTribSetPollTime(param_1,500);
    if (iVar1 == 9) {
      iVar2 = iVar2 << 2;
    }
    else {
      iVar2 = iVar2 * 3;
    }
    pelhamVTxIntMask(*(uint32_t *)(iVar11 + 0x36ca24),0,uVar3 & 0xff,uVar9 & 0xff,
                     1 << (iVar2 + iVar4 & 0x1fU));
    break;
  case 0xd:
    uVar5 = csaOcnUtilsTribAu3Tug3Number(param_1);
    ufe4SonetSdhTU3Init(*(uint32_t *)(iVar11 + 0x36ca24),uVar3,uVar5);
    goto LAB_064394b0;
  case 0xe:
  case 0xf:
    uVar5 = tdmSpeNumber(param_1);
    uVar9 = csaOcnUtilsTribAu3Tug3Number(param_1);
    uVar6 = posMdaTribGetTdmClkSource(param_1);
    uVar8 = miniCsaTribIsClkSourceLineOrNode(param_1);
    ufe4PdhSetupT3E3(*(uint32_t *)(iVar11 + 0x36ca24),uVar5,uVar3,uVar9,iVar1 == 0xe,uVar6,uVar8);
    posMdaTribSetPollTime(param_1,500);
    pelhamT3E3IntMask(*(uint32_t *)(iVar11 + 0x36ca24),0,uVar3 & 0xff,uVar9 & 0xff);
    break;
  case 0x10:
  case 0x11:
    uVar9 = csaOcnUtilsTribParentChanType(param_1);
    tdmSpeNumber(param_1);
    uVar10 = csaOcnUtilsTribAu3Tug3Number(param_1);
    iVar2 = csaOcnUtilsTribTug2Number(param_1);
    iVar4 = csaOcnUtilsTribTuNumber(param_1);
    if (uVar9 < 9) {
LAB_064396c0:
      uVar5 = FmtChanType(uVar9);
      uVar6 = FmtChanType(iVar1);
      timosAssert(0xa8f3208,0xa8f2c7c,0x627,0xa8f31b8,0xa8f31e8,uVar5,uVar6);
    }
    else {
      if (uVar9 < 0xb) {
        ufe4SonetSdhPdhCreate
                  (*(uint32_t *)(iVar11 + 0x36ca24),uVar3,uVar10,iVar2,iVar4,iVar1 == 0x10,1);
      }
      else if (uVar9 != 0xe) goto LAB_064396c0;
      posMdaTribSetPollTime(param_1,500);
      if (iVar1 == 0x10) {
        uVar5 = *(uint32_t *)(iVar11 + 0x36ca24);
        iVar2 = iVar2 << 2;
      }
      else {
        uVar5 = *(uint32_t *)(iVar11 + 0x36ca24);
        iVar2 = iVar2 * 3;
      }
      pelhamT1E1IntMask(uVar5,0,uVar3 & 0xff,uVar10 & 0xff,1 << (iVar2 + iVar4 & 0x1fU));
    }
  }
  return;
}