#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_ISIS;

void isisSendBecomeActiveMsg(void)
{
  int iVar1;
  uint32_t uVar2;
  uint32_t *apuStack_10 [2];
  
  apuStack_10[0] = (uint32_t *)isisMalloc(0xc);
  if (apuStack_10[0] == (uint32_t *)0x0) {
    if ((_traceEnabled != 0) ||
       ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_ISIS,0xa1adca4,4,0x1a), iVar1 != 0)))) {
      tracePrintVRtr(_MOD_ISIS,0xa1adca4,4,0x1a,1,0xa1ac7ac);
      return;
    }
  }
  else {
    *apuStack_10[0] = 1;
    apuStack_10[0][1] = 0xe;
    apuStack_10[0][2] = 0xc;
    uVar2 = isisGetTDGenMsgQId();
    iVar1 = msgQSend(uVar2,apuStack_10,4,0,1);
    if (iVar1 == -1) {
      isisFree(apuStack_10[0]);
      isisIncTDGenMsgQSendErr();
      if ((_traceEnabled != 0) ||
         ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_ISIS,0xa1adca4,4,0x1a), iVar1 != 0)))) {
        tracePrintVRtr(_MOD_ISIS,0xa1adca4,4,0x1a,1,0xa1adcbc);
        return;
      }
    }
  }
  return;
}