#include "nokia.h"
#include <stdint.h>

extern int cRam10c8f925; // Modified: Added extern declaration for undeclared variable

void csaEthXcmFxWpHwDumpRegs(int param_1,int param_2)

{

  uint32_t uVar1;

  int iVar2;

  int iVar3;

  int iVar4;

  int aiStack_18 [2];

  

  csaEthGetMda(*(uint32_t *)(param_1 + 8),1);

  iVar2 = *(int *)(param_2 + 0x10) * 8;

  iVar4 = iVar2 + 4;

  iVar3 = iVar4;

  if ((((((cRam10c8f925 != -0x13 && cRam10c8f925 != -0x17) && (1 < (byte)(cRam10c8f925 + 0x16U))) &&

        (cRam10c8f925 != -0xd && cRam10c8f925 != -0xf)) &&

       ((cRam10c8f925 != -8 && (cRam10c8f925 != -9)))) &&

      (((cRam10c8f925 != -10 && cRam10c8f925 != -0x10 &&

        ((cRam10c8f925 != -0xe && (cRam10c8f925 != -0x24)))) &&

       (cRam10c8f925 != -0x23 && cRam10c8f925 != -0x12)))) &&

     ((5 < (byte)(cRam10c8f925 + 0x1eU) && (iVar3 = iVar2 + 0x4004, cRam10c8f925 == -7)))) {

    iVar3 = iVar4;

  }

  uVar1 = fpgaPCIeRegRead(*(uint32_t *)(param_1 + 8),iVar3,aiStack_18);

  if (aiStack_18[0] == 0) {

    iVar2 = *(int *)(param_2 + 0x10) * 8;

    iVar3 = iVar2;

    if (((((cRam10c8f925 != -0x13 && cRam10c8f925 != -0x17) && (1 < (byte)(cRam10c8f925 + 0x16U)))

         && (cRam10c8f925 != -0xd && cRam10c8f925 != -0xf)) &&

        (((cRam10c8f925 != -8 && (cRam10c8f925 != -9)) &&

         ((cRam10c8f925 != -10 && cRam10c8f925 != -0x10 &&

          ((cRam10c8f925 != -0xe && (cRam10c8f925 != -0x24)))))))) &&

       ((cRam10c8f925 != -0x23 && cRam10c8f925 != -0x12 &&

        ((5 < (byte)(cRam10c8f925 + 0x1eU) && (iVar3 = iVar2 + 0x4000, cRam10c8f925 == -7)))))) {

      iVar3 = iVar2;

    }

    fpgaPCIeRegRead(*(uint32_t *)(param_1 + 8),iVar3,aiStack_18);

    if (aiStack_18[0] == 0) {

                    /* WARNING: Subroutine does not return */

      printf(0xa8e7604,uVar1);

    }

  }

                    /* WARNING: Subroutine does not return */

  printf(0xa8e75b0);

}