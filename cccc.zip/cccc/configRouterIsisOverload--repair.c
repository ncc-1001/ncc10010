#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added declaration for undeclared variable ___chk_strnum
int ___chk_strnum;

uint32_t configRouterIsisOverload(uint32_t param_1,uint32_t param_2,int param_3)

{

  int iVar1;

  
  ___chk_strnum = 3;
  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d8d0,0,0xa07cc38);
  if (iVar1 == 0) {
    if (param_3 == 0) {
      param_3 = 0xa07d274;
      ___chk_strnum = 0;
    }
    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d8e4,0,param_3);
    if (iVar1 == 0) {
      return 0;
    }
  }
  cliErrorMesg(param_1,0xa07d8fc);
  return 0xffffffff;
}
