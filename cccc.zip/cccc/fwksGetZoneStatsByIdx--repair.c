#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Add extern declarations for undeclared variables
extern void *__gxx_personality_sj0;
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern uint __ZN8Firewall10FwksFilter8m_uLimitE;
extern uint __ZN8Firewall10FwksFilter6m_uNewE;
extern uint __ZN8Firewall10FwksFilter9m_uDeleteE;
extern uint uRam0c9594cc;
extern uint uRam0c9594c4;
extern uint uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern uint uRam0c959618;
extern int iRam0c95961c;

uint fwksGetZoneStatsByIdx(int param_1,uint param_2)
{
  int iVar1;
  int iVar2;
  uintptr_t auStack_88 [16];
  uintptr_t auStack_78 [4];
  uint32_t uStack_74;
  // Modified: Replace unknown type 'code' with 'void*'
  void *pcStack_60;
  uint32_t uStack_5c;
  uintptr_t *puStack_58;
  uint32_t uStack_54;
  uintptr_t *puStack_50;
  uint uStack_44;
  uint uStack_40;
  int iStack_34;
  uint uStack_30;
  
  puStack_50 = auStack_88;
  puStack_58 = auStack_78;
  pcStack_60 = __gxx_personality_sj0;
  uStack_44 = param_2 & 0xffff;
  uStack_54 = 0x40f3798;
  uStack_5c = 0xbff8732;
  _Unwind_SjLj_Register(puStack_58);
  uStack_40 = 0;
  if (param_1 == 0) goto LAB_040f3628;
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4)) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_74 = 0xffffffff;
      iStack_34 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_34 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_74 = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_34;
    iVar2 = 0;
    if (iStack_34 != 0) goto LAB_040f35cc;
  }
  else {
LAB_040f35cc:
    iVar2 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
  }
  if (iVar2 != 0) {
    iVar1 = 0xb6b950;
    if (*(int *)(iVar2 + 0xb2f190) == 0) {
      iVar1 = 0xb6a070;
    }
    uStack_74 = 0xffffffff;
    uStack_40 = _ZN8Firewall9ZoneTable14zoneStatisticsERNS_19StatsTrafficZoneDefER13FwksZoneStatst
                          (iVar2 + iVar1,iVar2 + 0xb42b80,param_1,uStack_44);
    uStack_40 = uStack_40 & 0xff;
  }
LAB_040f3628:
  uStack_30 = (uint)(uStack_40 != 0);
  _Unwind_SjLj_Unregister(auStack_78);
  return uStack_30;
}