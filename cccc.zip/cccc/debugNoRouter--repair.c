#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for ___ctype to fix compilation error
extern char *___ctype;

uint32_t debugNoRouter(uint32_t param_1,byte *param_2)

{

  int iVar1;

  uint32_t uVar2;

  int aiStack_3e8 [3];

  uintptr_t auStack_3dc [588];

  int iStack_190;

  uint32_t uStack_18c;

  uint32_t uStack_188;

  uintptr_t auStack_28 [16];

  

  memset(aiStack_3e8,0,600);

  if ((param_2 == (byte *)0x0) ||

     (aiStack_3e8[0] =

           strToRtrId(param_2,2 - (uint)((*(byte *)((uint)*param_2 + ___ctype) & 4) == 0)),

     aiStack_3e8[0] != 0)) {

    do {

      while( true ) {

        iVar1 = siaEsasVRtrEntryGet(3,aiStack_3e8);

        if (iVar1 != 0) goto LAB_03bdcd34;

        debugNoIp(param_1,auStack_3dc);

        iVar1 = checkIfRouterMgmt(auStack_3dc);

        if (iVar1 == 0) break;

        if (param_2 != (byte *)0x0) {

          return 0;

        }

      }

      iVar1 = checkIfRouterBase(auStack_3dc);

      if (iVar1 != 0) {

        debugNoMpls(param_1,auStack_3dc);

        debugNoLdp(param_1,auStack_3dc);

        debugNoRsvp(param_1,auStack_3dc);

        debugIsis(param_1,auStack_3dc,1);

        debugMsdp(param_1,auStack_3dc,1);

        debugRouterL2tpNoDebug(param_1,auStack_3dc,0);

      }

      memset(&iStack_190,0,0x168);

      memset(auStack_28,0,10);

      iStack_190 = aiStack_3e8[0];

      while ((iVar1 = sia_tmnxOspfGeneralEntryGet(3,&iStack_190), iVar1 == 0 &&

             (iStack_190 == aiStack_3e8[0]))) {

        snprintf(auStack_28,10,0xa0c2140,uStack_188);

        debugNoOspf_ng(param_1,auStack_3dc,uStack_18c,auStack_28);

      }

      debugNoBgp(param_1,auStack_3dc);

      debugIgmp(param_1,auStack_3dc,1,0);

      debugIgmp(param_1,auStack_3dc,1,1);

      debugPim(param_1,auStack_3dc,1);

      debugMtrace(param_1,auStack_3dc,1);

      debugNoRip(param_1,auStack_3dc);

      debugNoVrrp(param_1,auStack_3dc);

      debugNoSrrp(param_1,auStack_3dc);

      debugNoLocalDhcpServer(param_1,auStack_3dc);

    } while (param_2 == (byte *)0x0);

LAB_03bdcd34:

    uVar2 = 0;

  }

  else {

    cliErrorMesg(param_1,0xa0c2144,param_2);

    uVar2 = 0xffffffff;

  }

  return uVar2;
}
