#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */



int hwSarmFpgaResetRxGTXPcsPma(int param_1)



{

  if (param_1 - 1U < 8) {

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

  return (param_1 - 1U >> 1) << 2;

}



