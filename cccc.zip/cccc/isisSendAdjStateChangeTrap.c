#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendAdjStateChangeTrap

               (uint32_t *param_1,int param_2,uint32_t param_3,int param_4,uint32_t param_5)



{

  uint32_t uVar1;

  uint32_t uVar2;

  uintptr_t auStack_48 [6];

  uintptr_t uStack_42;

  uintptr_t uStack_41;

  uintptr_t auStack_40 [40];

  

  memcpy(auStack_48,param_4 + 6,6);

  uStack_41 = 0;

  uStack_42 = 0;

  auStack_40[0] = 0;

  FmtIsisLSPId(*param_1,auStack_48,8,auStack_40,0x21,1);

  uVar1 = strlen(auStack_40);

  uVar2 = *param_1;

  logEvent_ISIS_vRtrIsisAdjacencyChange

            (uVar2,0xa1bbc30,uVar2,param_3,uVar2,*(uint32_t *)(param_2 + 8),auStack_48,8,

             auStack_40,uVar1,*(uint32_t *)(param_2 + 8),**(uint32_t **)(param_4 + 0x6c),param_5

            );

  return;

}



