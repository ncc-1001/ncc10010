#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_FIREWALL;

uint32_t firemgrHandlePlcyEvents(int param_1)
{
  uint32_t uVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  
  uVar6 = *(uint *)(param_1 + 0x20);
  uVar8 = 0;
  iVar7 = param_1;
  if (uVar6 != 0) {
LAB_040c5258:
    do {
      if (_traceEnabled == 0) {
        if (_tracepointsActive == 0) {
          uVar8 = uVar8 + 1;
          iVar7 = iVar7 + 0x10;
          if (uVar6 <= uVar8) break;
          goto LAB_040c5258;
        }
        iVar5 = traceTest(_MOD_FIREWALL,0xa177444,4,0);
        if (iVar5 == 0) {
          uVar6 = *(uint *)(param_1 + 0x20);
        }
        else {
          uVar1 = FmtFirewallEventCode(*(uint16_t *)(iVar7 + 0x2a));
          uVar2 = FmtFirewallEventSubCode(*(uint16_t *)(iVar7 + 0x2c));
          uVar3 = FmtFirewallEventLevel(*(uint16_t *)(iVar7 + 0x28));
          uVar4 = firewallGetErrorBuffer();
          tracePrintVRtr(_MOD_FIREWALL,0xa177444,4,0,1,0xa17745c,uVar1,uVar2,uVar3,
                         *(uint32_t *)(iVar7 + 0x34),uVar4);
          uVar6 = *(uint *)(param_1 + 0x20);
        }
      }
      else {
        uVar1 = FmtFirewallEventCode(*(uint16_t *)(iVar7 + 0x2a));
        uVar2 = FmtFirewallEventSubCode(*(uint16_t *)(iVar7 + 0x2c));
        uVar3 = FmtFirewallEventLevel(*(uint16_t *)(iVar7 + 0x28));
        uVar4 = firewallGetErrorBuffer();
        tracePrintVRtr(_MOD_FIREWALL,0xa177444,4,0,1,0xa17745c,uVar1,uVar2,uVar3,
                       *(uint32_t *)(iVar7 + 0x34),uVar4);
        uVar6 = *(uint *)(param_1 + 0x20);
      }
      uVar8 = uVar8 + 1;
      iVar7 = iVar7 + 0x10;
    } while (uVar8 < uVar6);
  }
  firewallClearErrorBuffer();
  return 0;
}