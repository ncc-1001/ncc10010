#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t iDragaDisplayModeReg3(uint32_t param_1,int param_2)


{

  int iVar1;

  int iVar2;

  uintptr_t auStack_18 [8];

  

  iVar1 = _gHwPlatform * 0x34;

  iVar2 = *(int *)(iVar1 + 0xbbfd930) + *(int *)(iVar1 + 0xbbfd924) * param_2;

  if (_gHwPlatform - 1U < 3) {

    // Modified: Changed function pointer call to use a typedef for clarity
    typedef int (*func_type)(uint32_t, int, uintptr_t*);
    func_type func = *(func_type *)(iVar1 + 0xbbfd94c);
    iVar1 = func(param_1, iVar2, auStack_18);

    if (iVar1 == 0) {

                    /* WARNING: Subroutine does not return */

      printf(0xa8e23f4,iVar2);

    }

    iVar1 = macMdaRemoved(param_1);

    if ((iVar1 == 0) &&

       ((_traceEnabled != 0 ||

        ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8e23dc,4,0), iVar1 != 0))))))

    {

      tracePrintVRtr(_MOD_MDADRV,0xa8e23dc,4,0,1,0xa8e1650,param_1,iVar2);

    }

  }

  else {

    iVar1 = macMdaRemoved();

    if ((iVar1 == 0) &&

       ((_traceEnabled != 0 ||

        ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8e23dc,4,0), iVar1 != 0))))))

    {

      tracePrintVRtr(_MOD_MDADRV,0xa8e23dc,4,0,1,0xa8e1634,_gHwPlatform);

    }

  }

  return 0xffffffff;

}
