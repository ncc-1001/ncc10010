#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t hwSarmFpgaSetPll2ForClockRecFreq(int param_1)



{

  int in_zero;

  int iVar1;

  

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) == -0x13) {

LAB_0296e98c:

    if (param_1 == 25000) {

                    /* WARNING: Bad instruction - Truncating control flow here */

      halt_baddata();

    }

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) == -0x17) goto LAB_0296e98c;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8);

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8);

    }

    if (*(char *)(iVar1 * 3 + 0x10c8f925) == -0xd) goto LAB_0296eb18;

  }

  else if (cRam10c8f925 == -0xd) goto LAB_0296eb18;

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) != -0xf) {

    iVar1 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar1 + 0x10c8f925) != -8) {

      return 0;

    }

  }

LAB_0296eb18:

  if (param_1 == 25000) {

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

                    /* WARNING: Bad instruction - Truncating control flow here */

  halt_baddata();

}



