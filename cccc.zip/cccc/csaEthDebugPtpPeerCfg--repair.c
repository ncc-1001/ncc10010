#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Update typedef for 'code' type to match actual usage
typedef int (*code)(uint, uint, uint32_t*);

// Modified: Add extern declaration for '_gMdaInfo'
extern uint *_gMdaInfo;

void csaEthDebugPtpPeerCfg
               (uint param_1,uint param_2,uint16_t param_3,uint32_t param_4,uint16_t param_5,
               uint32_t param_6,uint32_t param_7,uintptr_t param_8,uintptr_t param_9,
               uint32_t param_10)
{
  bool bVar1;
  char *pcVar2;
  int iVar3;
  code *pcVar4;
  uint32_t uStack_48;
  uintptr_t uStack_44;
  uintptr_t uStack_43;
  uintptr_t uStack_42;
  uintptr_t uStack_41;
  uintptr_t uStack_40;
  uintptr_t uStack_3f;
  uintptr_t uStack_3e;
  uintptr_t uStack_3d;
  uint16_t uStack_3c;
  uint16_t uStack_3a;
  uintptr_t uStack_38;
  uintptr_t uStack_37;
  uintptr_t uStack_36;
  uintptr_t uStack_35;
  uint32_t uStack_34;
  int iStack_30;
  
  param_2 = param_2 & 0xffff;
  if ((param_1 != 0) && (param_1 <= *_gMdaInfo)) {
    bVar1 = param_2 - 1 < 10;
    if (bVar1) {
      iStack_30 = *(int *)(param_1 * 4 + 0xccb630c);
      if (iStack_30 == 0) {
        timosAssert(0xa8c39e8,0xa8c3970,0x1dfd,0xa8c7034,0xa8c3960);
      }
      if (((param_1 <= *_gMdaInfo) &&
          (pcVar2 = (char *)(param_1 * 0x3a88 + 0x10d260a8), *pcVar2 != '\0')) &&
         (pcVar2 != (char *)0x0)) {
        uStack_44 = (uintptr_t)((uint)param_6 >> 0x18);
        uStack_43 = (uintptr_t)((uint)param_6 >> 0x10);
        uStack_34 = param_10;
        uStack_42 = (uintptr_t)((uint)param_6 >> 8);
        uStack_41 = (uintptr_t)param_6;
        uStack_40 = (uintptr_t)((uint)param_7 >> 0x18);
        uStack_3f = (uintptr_t)((uint)param_7 >> 0x10);
        uStack_3e = (uintptr_t)((uint)param_7 >> 8);
        uStack_3d = (uintptr_t)param_7;
        uStack_3c = param_5;
        uStack_35 = param_9;
        uStack_37 = param_8;
        uStack_38 = 0;
        uStack_48 = param_4;
        uStack_3a = param_3;
        uStack_36 = bVar1;
        if (((*(int *)(iStack_30 + 0x63a60) != 0) &&
            (iVar3 = *(int *)(*(int *)(iStack_30 + 0x63a60) + 0xa4), iVar3 != 0)) &&
           ((pcVar4 = *(code **)(iVar3 + 0x58), pcVar4 != (code *)0x0 &&
            (iVar3 = (*pcVar4)(param_1,param_2,&uStack_48), iVar3 == 0)))) {
          return;
        }
                    /* WARNING: Subroutine does not return */
        printf(0xa8c7290,param_2,param_1);
      }
                    /* WARNING: Subroutine does not return */
      printf(0xa8c700c,param_1);
    }
  }
                    /* WARNING: Subroutine does not return */
  printf(0xa8c704c,0xa8c7034);
}