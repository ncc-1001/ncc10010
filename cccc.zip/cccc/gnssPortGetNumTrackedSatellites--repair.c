#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
// These are likely defined elsewhere in the original codebase
extern int Status;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern int smpIntCnt;
extern int EBase;
extern int *_gMdaInfo;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void gnssPortGetNumTrackedSatellites(int param_1,uintptr_t *param_2)



{

  uint uVar1;

  int iVar2;

  int iVar3;

  

  uVar1 = Status;

  iVar3 = *(int *)(param_1 + 0xcb8);

  if (_kernelIsSmp == 0) {

    iVar2 = *(int *)(param_1 + 4);

    if (_smpIntCnt != 0) goto LAB_066eefc8;

  }

  else {

    Status = Status & 0xfffffffe;

    setCopReg(0,Status,uVar1,0);

    iVar2 = *(int *)(param_1 + 4);

    if (0 < *(int *)(&smpIntCnt + (EBase & 0xff) * 4)) goto LAB_066eefc8;

  }

  if ((*(uint *)(iVar2 + 0x36ca24) == 0) || (*_gMdaInfo < *(uint *)(iVar2 + 0x36ca24))) {

    timosAssert(0xa9be018,0xa9bde9c,0x3d6,0xa9be254,0xa9bde74,*(uint32_t *)(iVar2 + 0x36ca24));

    iVar2 = *(int *)(param_1 + 4);

  }

  if (*(int *)(*(int *)(iVar2 + 0x36ca24) * 4 + 0xeb6f544) == 0) {

    timosAssert(0xa9be04c,0xa9bde9c,0x3d6,0xa9be254,0xa9be048);

    iVar2 = *(int *)(param_1 + 4);

  }

LAB_066eefc8:

  iVar3 = *(int *)(*(int *)(iVar2 + 0x36ca24) * 4 + 0xeb6f544) + iVar3 * 0x1b0;

  if (*(int *)(iVar3 + 0x3678) - 8U < 2) {

    *param_2 = 0;

  }

  else {

    *param_2 = *(uintptr_t *)(iVar3 + 0x3685);

  }

  if ((_tracepointsActive != 0) && (iVar3 = traceTest(_MOD_MDADRV,0xa9be254,1,0), iVar3 != 0)) {

    tracePrintVRtr(_MOD_MDADRV,0xa9be254,1,0,1,0xa9be274,

                   *(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24),*(int *)(param_1 + 0xcb8) + 1,

                   *param_2);

  }

  return;

}