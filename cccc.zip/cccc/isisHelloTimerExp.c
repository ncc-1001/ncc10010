#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisHelloTimerExp(uint32_t param_1,int param_2,int param_3)



{

  int iVar1;

  uint uVar2;

  uint32_t auStack_18 [2];

  

  iVar1 = isisGetNode(param_1,auStack_18);

  if (iVar1 == 0) {

    if (param_3 == 1) {

      uVar2 = *(uint *)(param_2 + 0x43c);

    }

    else {

      uVar2 = *(uint *)(param_2 + 0x60c);

    }

    if ((uVar2 & 0x20) == 0) {

      isisSendIIH(auStack_18[0],param_2,param_3,0);

    }

  }

  return;

}



