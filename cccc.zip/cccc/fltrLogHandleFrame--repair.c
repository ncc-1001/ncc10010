#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int _FLRxDump;
extern int Status;
extern int _vxAbsTicks;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern int _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern char pbufMarkHistoryTrack;
extern int _pbufMarkHistoryOffStart;
extern int _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern char pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern char pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern char pbufMarkHistoryVal3;
extern char pbufMarkHistoryMatchLocation1;
extern int _pbufMarkHistoryLocationVal1;
extern int pbufMarkHistoryLock;
extern char pbufMarkHistoryTable;
extern int _FltrLogUnknownPkts;

void fltrLogHandleFrame(void)
{
  ushort uVar1;
  bool bVar2;
  int in_zero;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  uint uVar10;
  uint uVar11;
  char *pcVar12;
  uint32_t *puVar13;
  int *piVar14;
  uint16_t uVar15;
  uintptr_t auStack_228 [40];
  uintptr_t auStack_200 [480];
  
  iVar3 = fltrLogDequeueFrame();
  if (iVar3 == 0) {
    return;
  }
  if (_FLRxDump != 0) {
    pbufDump(iVar3,1);
  }
  getLocalTime(0,auStack_228);
  uVar8 = Status;
  uVar11 = _vxAbsTicks;
  puVar13 = (uint32_t *)(iVar3 + 0x88);
  uVar10 = (uint)*(ushort *)(iVar3 + 0x94);
  uVar4 = _vxAbsTicks / 100;
  if (uVar10 != 0) {
    if (_kernelIsSmp == 0) {
      if (_smpIntCnt == 0) {
LAB_0408f658:
        *puVar13 = _smpTaskIdCurrent;
      }
      else {
        *puVar13 = 0;
      }
    }
    else {
      Status = Status & 0xfffffffe;
      setCopReg(0,Status,uVar8,0);
      if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
        if (_kernelIsSmp == 0) goto LAB_0408f658;
        *puVar13 = *(uint32_t *)(in_zero + -0x8000);
      }
      else {
        *puVar13 = 0;
      }
    }
    uVar8 = Status;
    uVar7 = (uVar4 & 0xffff) - (uint)*(ushort *)(iVar3 + 0x96) & 0xffff;
    uVar15 = (uint16_t)uVar4;
    if ((uVar7 != 0) && (uVar10 < 0xab)) {
      if (8 < uVar7) {
        uVar7 = 8;
      }
      iVar5 = (uVar10 * 0x558 + uVar7) * 8;
      piVar9 = (int *)(iVar5 + 0xecd4fac);
      *(uint16_t *)(iVar5 + 0xecd4fb0) = uVar15;
      *piVar9 = *piVar9 + 1;
    }
    if (pbufMarkHistoryTrack != '\0') {
      if ((*(uint *)(iVar3 + 0x9c) & 0x8000) == 0) {
        iVar5 = *(int *)(iVar3 + 8) + iVar3 + 0xa0;
        bVar2 = false;
        uVar11 = *(uint *)(iVar3 + 0xc);
        if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {
          uVar8 = _pbufMarkHistoryOffStart;
          do {
            if ((((_pbufMarkHistoryOff1 == -1) ||
                 ((_pbufMarkHistoryOff1 + uVar8 < uVar11 &&
                  (*(char *)(_pbufMarkHistoryOff1 + iVar5 + uVar8) == pbufMarkHistoryVal1)))) &&
                ((_pbufMarkHistoryOff2 == -1 ||
                 ((_pbufMarkHistoryOff2 + uVar8 < uVar11 &&
                  (*(char *)(_pbufMarkHistoryOff2 + iVar5 + uVar8) == pbufMarkHistoryVal2)))))) &&
               ((_pbufMarkHistoryOff3 == -1 ||
                ((_pbufMarkHistoryOff3 + uVar8 < uVar11 &&
                 (*(char *)(_pbufMarkHistoryOff3 + iVar5 + uVar8) == pbufMarkHistoryVal3)))))) {
              bVar2 = true;
            }
            uVar8 = uVar8 + 1;
          } while (!bVar2 && uVar8 <= _pbufMarkHistoryOffEnd);
        }
        if (bVar2) {
          if ((pbufMarkHistoryMatchLocation1 == '\0') || (_pbufMarkHistoryLocationVal1 == 0x3a))
          goto LAB_0408f690;
          *(uint16_t *)(iVar3 + 0x96) = uVar15;
          *(uint16_t *)(iVar3 + 0x94) = 0x3a;
          *(uint32_t *)(iVar3 + 0x98) = 0;
          goto LAB_0408f3a0;
        }
        if (bVar2) {
LAB_0408f690:
                    /* WARNING: Subroutine does not return */
          intLockProtect(&pbufMarkHistoryLock);
        }
      }
      else {
        iVar5 = (uint)*(ushort *)(iVar3 + 0x9c) * 0x408;
        pcVar12 = &pbufMarkHistoryTable + iVar5;
        if (*pcVar12 == '\0') {
          *pcVar12 = '\x01';
          *(uint32_t *)(iVar5 + 0xe58e868) = 0;
          uVar4 = *(uint *)(iVar5 + 0xe58e868);
        }
        else {
          uVar4 = *(uint *)(iVar5 + 0xe58e868);
        }
        if (uVar4 < 0x3f) {
          puVar13 = (uint32_t *)(pcVar12 + uVar4 * 0x10 + 8);
          if (_kernelIsSmp == 0) {
            if (_smpIntCnt == 0) {
LAB_0408f890:
              *puVar13 = _smpTaskIdCurrent;
            }
            else {
              *puVar13 = 0;
            }
          }
          else {
            Status = Status & 0xfffffffe;
            setCopReg(0,Status,uVar8,0);
            if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
              if (_kernelIsSmp == 0) goto LAB_0408f890;
              *puVar13 = *(uint32_t *)(in_zero + -0x8000);
            }
            else {
              *puVar13 = 0;
            }
          }
          *(uint *)(pcVar12 + uVar4 * 0x10 + 0x10) = uVar11;
          *(uint16_t *)(pcVar12 + uVar4 * 0x10 + 0xc) = 0x3a;
          *(uint32_t *)(pcVar12 + uVar4 * 0x10 + 0x14) = 0;
          *(uint16_t *)(pcVar12 + uVar4 * 0x10 + 0xe) = uVar15;
          *(int *)(iVar5 + 0xe58e868) = *(int *)(iVar5 + 0xe58e868) + 1;
        }
      }
    }
    *(uint16_t *)(iVar3 + 0x96) = uVar15;
    *(uint16_t *)(iVar3 + 0x94) = 0x3a;
    *(uint32_t *)(iVar3 + 0x98) = 0;
  }
LAB_0408f3a0:
  uVar1 = *(ushort *)(iVar3 + 0x1e);
  if (0x7ff < uVar1) goto LAB_0408f404;
  fltrLogLock();
  iVar5 = (uint)uVar1 * 0xc;
  piVar9 = (int *)(iVar5 + 0xc91bcf0);
  if ((((piVar9 == (int *)0x0) || (*piVar9 == 0)) ||
      (piVar14 = *(int **)(iVar5 + 0xc91bcf4), piVar14 == (int *)0x0)) || (piVar14[0x2a] != 1)) {
LAB_0408f3fc:
    fltrLogUnlock();
  }
  else {
    if (((*piVar14 == 2) && (*(byte *)(piVar14 + 0x2b) != 0)) &&
       (*(char *)((uint)*(byte *)(piVar14 + 0x2b) * 0xd4 + 0xdc91915) != '\0')) {
      iVar5 = fltrLogSummarizeFrame(iVar3);
      if (iVar5 != 0) goto LAB_0408f3fc;
    }
    else {
      iVar5 = fltrLogDecodeFrame(iVar3,piVar9,auStack_200);
      if (0 < iVar5) {
        iVar6 = *piVar14;
        if (iVar6 == 2) {
          fltrLogSendToSysLog(piVar14,auStack_228,auStack_200,iVar5);
          fltrLogUnlock();
          goto LAB_0408f404;
        }
        if ((iVar6 < 3) && (iVar6 == 1)) {
          fltrLogSendToMemory(piVar14,auStack_228,auStack_200);
          fltrLogUnlock();
          goto LAB_0408f404;
        }
        goto LAB_0408f3fc;
      }
    }
    _FltrLogUnknownPkts = _FltrLogUnknownPkts + 1;
    fltrLogUnlock();
  }
LAB_0408f404:
  pbufFree(iVar3);
  return;
}