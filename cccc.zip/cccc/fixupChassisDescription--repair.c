#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added declarations for undeclared variables found during compilation
int _TgtPf; // Appears to be an integer variable used in comparisons
char cRam10c8f925; // Appears to be a char variable used in comparisons
uint32_t uRam06a129e0; // Memory address variable
uint32_t uRam06a12ac4; // Memory address variable
uint32_t uRam06a12734; // Memory address variable
uint32_t uRam06a12bc9; // Memory address variable
uint32_t uRam06a12ba8; // Memory address variable
uint32_t uRam06a12bac; // Memory address variable
int hwTypeInfo; // Appears to be an integer parameter for hwCardTypeIsSparrow

uint32_t fixupChassisDescription(void)

{

  int iVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t uVar6;

  uint32_t *puVar7;

  uint32_t *puVar8;

  uint32_t *puVar9;

  uint32_t *puVar10;

  uint32_t *puVar11;

  int iVar12;

  uint uVar13;

  uint32_t auStack_100 [58];
  
  puVar7 = auStack_100;
  memset(puVar7,0,0xe4);
  iVar12 = 0x6a1258b;
  uVar13 = 0;
  do {
    uVar13 = uVar13 + 1;
    iVar2 = pfFixupString(iVar12);
    iVar1 = _TgtPf;
    iVar12 = iVar12 + 0xe4;
    if (iVar2 != 0) {
      return 0xffffffff;
    }
  } while (uVar13 < 0x22);
  if (_TgtPf == 1) {
    puVar8 = (uint32_t *)0x6a12d68;
    puVar11 = auStack_100 + 0x38;
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar8 = uVar3;
      puVar8[1] = uVar4;
      puVar8[2] = uVar5;
      puVar8[3] = uVar6;
      puVar8 = puVar8 + 4;
    } while (puVar9 != puVar11);
    puVar10 = (uint32_t *)0x6a12c84;
    *puVar8 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar10 = uVar3;
      puVar10[1] = uVar4;
      puVar10[2] = uVar5;
      puVar10[3] = uVar6;
      puVar10 = puVar10 + 4;
    } while (puVar9 != puVar11);
    puVar8 = (uint32_t *)0x6a12e4c;
    *puVar10 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar8 = uVar3;
      puVar8[1] = uVar4;
      puVar8[2] = uVar5;
      puVar8[3] = uVar6;
      puVar8 = puVar8 + 4;
    } while (puVar9 != puVar11);
    *puVar8 = auStack_100[0x38];
  }
  if (iVar1 == 2) {
    puVar8 = (uint32_t *)0x6a12d68;
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar8 = uVar3;
      puVar8[1] = uVar4;
      puVar8[2] = uVar5;
      puVar8[3] = uVar6;
      puVar8 = puVar8 + 4;
    } while (puVar9 != auStack_100 + 0x38);
    puVar11 = (uint32_t *)0x6a12ba0;
    *puVar8 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar11 = uVar3;
      puVar11[1] = uVar4;
      puVar11[2] = uVar5;
      puVar11[3] = uVar6;
      puVar11 = puVar11 + 4;
    } while (puVar9 != auStack_100 + 0x38);
    *puVar11 = auStack_100[0x38];
  }
  if (((((iVar1 == 3) || (cRam10c8f925 == -2 || cRam10c8f925 == -0x18)) ||
       ((byte)(cRam10c8f925 + 4U) < 2 || cRam10c8f925 == -6)) ||
      (((cRam10c8f925 == -5 || (cRam10c8f925 == -0x13 || cRam10c8f925 == -0x17)) ||
       (((byte)(cRam10c8f925 + 0x16U) < 2 ||
        ((cRam10c8f925 == -0xd || cRam10c8f925 == -0xf || (cRam10c8f925 == -8)))))))) ||
     ((cRam10c8f925 == -9 ||
      (((((cRam10c8f925 == -10 || cRam10c8f925 == -0x10 || (cRam10c8f925 == -0xe)) ||
         (cRam10c8f925 == -0x24)) ||
        ((cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12 || ((byte)(cRam10c8f925 + 0x1eU) < 6)))) ||
       (cRam10c8f925 == -7)))))) {
    if (iVar1 == 4) {
      puVar8 = (uint32_t *)0x6a12ba0;
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != auStack_100 + 0x38);
      puVar11 = (uint32_t *)0x6a12d68;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar11 = uVar3;
        puVar11[1] = uVar4;
        puVar11[2] = uVar5;
        puVar11[3] = uVar6;
        puVar11 = puVar11 + 4;
      } while (puVar9 != auStack_100 + 0x38);
      *puVar11 = auStack_100[0x38];
    }
    else {
      puVar8 = (uint32_t *)0x6a133a4;
      puVar11 = auStack_100 + 0x38;
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a132c0;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a13488;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a1356c;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a13650;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a13818;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a138fc;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a139e0;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a12f30;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a13014;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a130f8;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a131dc;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a13ac4;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a13ba8;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a13c8c;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a13d70;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a13e54;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a13f38;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a1401c;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a14100;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      puVar8 = (uint32_t *)0x6a141e4;
      *puVar10 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar8 = uVar3;
        puVar8[1] = uVar4;
        puVar8[2] = uVar5;
        puVar8[3] = uVar6;
        puVar8 = puVar8 + 4;
      } while (puVar9 != puVar11);
      puVar10 = (uint32_t *)0x6a142c8;
      *puVar8 = auStack_100[0x38];
      puVar9 = puVar7;
      do {
        uVar3 = *puVar9;
        uVar4 = puVar9[1];
        uVar5 = puVar9[2];
        uVar6 = puVar9[3];
        puVar9 = puVar9 + 4;
        *puVar10 = uVar3;
        puVar10[1] = uVar4;
        puVar10[2] = uVar5;
        puVar10[3] = uVar6;
        puVar10 = puVar10 + 4;
      } while (puVar9 != puVar11);
      *puVar10 = auStack_100[0x38];
    }
    puVar11 = auStack_100 + 0x38;
    puVar8 = (uint32_t *)0x6a1272c;
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar8 = uVar3;
      puVar8[1] = uVar4;
      puVar8[2] = uVar5;
      puVar8[3] = uVar6;
      puVar8 = puVar8 + 4;
    } while (puVar9 != puVar11);
    puVar10 = (uint32_t *)0x6a128f4;
    *puVar8 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar10 = uVar3;
      puVar10[1] = uVar4;
      puVar10[2] = uVar5;
      puVar10[3] = uVar6;
      puVar10 = puVar10 + 4;
    } while (puVar9 != puVar11);
    puVar8 = (uint32_t *)0x6a129d8;
    *puVar10 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar8 = uVar3;
      puVar8[1] = uVar4;
      puVar8[2] = uVar5;
      puVar8[3] = uVar6;
      puVar8 = puVar8 + 4;
    } while (puVar9 != puVar11);
    puVar10 = (uint32_t *)0x6a12abc;
    *puVar8 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar10 = uVar3;
      puVar10[1] = uVar4;
      puVar10[2] = uVar5;
      puVar10[3] = uVar6;
      puVar10 = puVar10 + 4;
    } while (puVar9 != puVar11);
    puVar8 = (uint32_t *)0x6a12c84;
    *puVar10 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar8 = uVar3;
      puVar8[1] = uVar4;
      puVar8[2] = uVar5;
      puVar8[3] = uVar6;
      puVar8 = puVar8 + 4;
    } while (puVar9 != puVar11);
    puVar10 = (uint32_t *)0x6a12e4c;
    *puVar8 = auStack_100[0x38];
    puVar9 = puVar7;
    do {
      uVar3 = *puVar9;
      uVar4 = puVar9[1];
      uVar5 = puVar9[2];
      uVar6 = puVar9[3];
      puVar9 = puVar9 + 4;
      *puVar10 = uVar3;
      puVar10[1] = uVar4;
      puVar10[2] = uVar5;
      puVar10[3] = uVar6;
      puVar10 = puVar10 + 4;
    } while (puVar9 != puVar11);
    *puVar10 = *puVar9;
  }
  if (iVar1 == 2) {
    uRam06a129e0 = 0xaee19b4;
    uRam06a12ac4 = 0xaee19dc;
    uRam06a12734 = 0xaee1a08;
  }
  iVar12 = hwCardTypeIsSparrow(hwTypeInfo);
  if (iVar12 != 0) {
    uRam06a12bc9 = 0x35;
    uRam06a12ba8 = 0xaee1a3c;
    uRam06a12bac = 0xaee1aec;
    puVar9 = (uint32_t *)0x6a12d68;
    do {
      uVar3 = *puVar7;
      uVar4 = puVar7[1];
      uVar5 = puVar7[2];
      uVar6 = puVar7[3];
      puVar7 = puVar7 + 4;
      *puVar9 = uVar3;
      puVar9[1] = uVar4;
      puVar9[2] = uVar5;
      puVar9[3] = uVar6;
      puVar9 = puVar9 + 4;
    } while (puVar7 != auStack_100 + 0x38);
    *puVar9 = *puVar7;
  }
  return 0;
}