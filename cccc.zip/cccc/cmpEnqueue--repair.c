#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for all undeclared global variables
extern int _CmpRxFrames;
extern int _CmpRxOctets;
extern int _CmpRxDump;
extern int Status;
extern int _vxAbsTicks;
extern int _CmpRxDecodeFailed;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern int _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern int pbufMarkHistoryTrack;
extern int _pbufMarkHistoryOffStart;
extern int _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern int pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern int pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern int pbufMarkHistoryVal3;
extern int pbufMarkHistoryMatchLocation1;
extern int _pbufMarkHistoryLocationVal1;
extern int pbufMarkHistoryLock;
extern int pbufMarkHistoryTable;
extern int _CmpRxCpmCode;
extern int _tracepointsActive;
extern int _MOD_CMP;
extern int _MyHwFamily;
extern int CmpRxRawFramesPerCode;
extern int RawPacketHandlers;
extern int _CmpRxPipAddFailed;

typedef int (*code)(); // Modified: Added typedef for code pointer type

bool cmpEnqueue(int param_1)
{
  ushort uVar1;
  int in_zero;
  int iVar2;
  uint uVar3;
  int *piVar4;
  bool bVar6;
  uint uVar5;
  uint uVar7;
  uint uVar8;
  char *pcVar9;
  uint32_t *puVar10;
  uint16_t uVar11;
  uint uStack_68;
  uint32_t uStack_64;
  uint uStack_60;
  int iStack_5c;
  uint32_t uStack_58;
  uint32_t uStack_54;
  uint32_t uStack_50;
  uint32_t uStack_4c;
  uint32_t uStack_48;
  uint32_t uStack_44;
  uint32_t uStack_40;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  
  _CmpRxFrames = _CmpRxFrames + 1;
  uStack_68 = 0;
  _CmpRxOctets = *(int *)(param_1 + 0xc) + _CmpRxOctets;
  uStack_64 = 0;
  uStack_60 = 0;
  iStack_5c = 0;
  uStack_58 = 0;
  uStack_54 = 0;
  uStack_50 = 0;
  uStack_4c = 0;
  uStack_48 = 0;
  uStack_44 = 0;
  uStack_40 = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  if (_CmpRxDump != 0) {
    pbufDump(param_1,1);
  }
  iVar2 = sfDecodeRawPktHdr(param_1,&uStack_68);
  uVar5 = Status;
  uVar8 = _vxAbsTicks;
  if (iVar2 != 0) {
    _CmpRxDecodeFailed = _CmpRxDecodeFailed + 1;
    return false;
  }
  puVar10 = (uint32_t *)(param_1 + 0x88);
  uVar7 = (uint)*(ushort *)(param_1 + 0x94);
  uVar3 = _vxAbsTicks / 100;
  if (uVar7 == 0) goto LAB_03e92d54;
  uVar11 = (uint16_t)uVar3;
  if (_kernelIsSmp == 0) {
    if (_smpIntCnt == 0) {
LAB_03e93230:
      *puVar10 = _smpTaskIdCurrent;
      goto LAB_03e92e3c;
    }
    uVar1 = *(ushort *)(param_1 + 0x96);
LAB_03e9317c:
    *puVar10 = 0;
    uVar5 = Status;
  }
  else {
    Status = Status & 0xfffffffe;
    setCopReg(0,Status,uVar5,0);
    if (0 < *(int *)(&smpIntCnt + (EBase & 0xff) * 4)) {
      uVar1 = *(ushort *)(param_1 + 0x96);
      goto LAB_03e9317c;
    }
    if (_kernelIsSmp == 0) goto LAB_03e93230;
    *puVar10 = *(uint32_t *)(in_zero + -0x8000);
LAB_03e92e3c:
    uVar1 = *(ushort *)(param_1 + 0x96);
    uVar5 = Status;
  }
  uVar3 = (uVar3 & 0xffff) - (uint)uVar1 & 0xffff;
  if ((uVar3 != 0) && (uVar7 < 0xab)) {
    if (8 < uVar3) {
      uVar3 = 8;
    }
    iVar2 = (uVar7 * 0x558 + uVar3) * 8;
    piVar4 = (int *)(iVar2 + 0xecd472c);
    *(uint16_t *)(iVar2 + 0xecd4730) = uVar11;
    *piVar4 = *piVar4 + 1;
  }
  Status = uVar5;
  if (pbufMarkHistoryTrack != '\0') {
    if ((*(uint *)(param_1 + 0x9c) & 0x8000) == 0) {
      iVar2 = *(int *)(param_1 + 8) + param_1 + 0xa0;
      bVar6 = false;
      uVar8 = *(uint *)(param_1 + 0xc);
      if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {
        uVar5 = _pbufMarkHistoryOffStart;
        do {
          if ((((_pbufMarkHistoryOff1 == -1) ||
               ((_pbufMarkHistoryOff1 + uVar5 < uVar8 &&
                (*(char *)(_pbufMarkHistoryOff1 + iVar2 + uVar5) == pbufMarkHistoryVal1)))) &&
              ((_pbufMarkHistoryOff2 == -1 ||
               ((_pbufMarkHistoryOff2 + uVar5 < uVar8 &&
                (*(char *)(_pbufMarkHistoryOff2 + iVar2 + uVar5) == pbufMarkHistoryVal2)))))) &&
             ((_pbufMarkHistoryOff3 == -1 ||
              ((_pbufMarkHistoryOff3 + uVar5 < uVar8 &&
               (*(char *)(_pbufMarkHistoryOff3 + iVar2 + uVar5) == pbufMarkHistoryVal3)))))) {
            bVar6 = true;
          }
          uVar5 = uVar5 + 1;
        } while (!bVar6 && uVar5 <= _pbufMarkHistoryOffEnd);
      }
      if (bVar6) {
        if ((pbufMarkHistoryMatchLocation1 == '\0') || (_pbufMarkHistoryLocationVal1 == 0x18))
        goto LAB_03e93254;
        *(uint16_t *)(param_1 + 0x96) = uVar11;
        *(uint16_t *)(param_1 + 0x94) = 0x18;
        *(uint32_t *)(param_1 + 0x98) = 0;
        goto LAB_03e92d54;
      }
      if (bVar6) {
LAB_03e93254:
                    /* WARNING: Subroutine does not return */
        intLockProtect(&pbufMarkHistoryLock);
      }
    }
    else {
      iVar2 = (uint)*(ushort *)(param_1 + 0x9c) * 0x408;
      pcVar9 = &pbufMarkHistoryTable + iVar2;
      if (*pcVar9 == '\0') {
        *pcVar9 = '\x01';
        *(uint32_t *)(iVar2 + 0xe58e868) = 0;
        uVar3 = *(uint *)(iVar2 + 0xe58e868);
      }
      else {
        uVar3 = *(uint *)(iVar2 + 0xe58e868);
      }
      if (uVar3 < 0x3f) {
        puVar10 = (uint32_t *)(pcVar9 + uVar3 * 0x10 + 8);
        if (_kernelIsSmp == 0) {
          if (_smpIntCnt == 0) {
LAB_03e934e0:
            *puVar10 = _smpTaskIdCurrent;
          }
          else {
            *puVar10 = 0;
          }
        }
        else {
          Status = uVar5 & 0xfffffffe;
          setCopReg(0,Status,uVar5,0);
          if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
            if (_kernelIsSmp == 0) goto LAB_03e934e0;
            *puVar10 = *(uint32_t *)(in_zero + -0x8000);
          }
          else {
            *puVar10 = 0;
          }
        }
        *(uint *)(pcVar9 + uVar3 * 0x10 + 0x10) = uVar8;
        *(uint16_t *)(pcVar9 + uVar3 * 0x10 + 0xc) = 0x18;
        *(uint32_t *)(pcVar9 + uVar3 * 0x10 + 0x14) = 0;
        *(uint16_t *)(pcVar9 + uVar3 * 0x10 + 0xe) = uVar11;
        *(int *)(iVar2 + 0xe58e868) = *(int *)(iVar2 + 0xe58e868) + 1;
      }
    }
  }
  *(uint16_t *)(param_1 + 0x96) = uVar11;
  *(uint16_t *)(param_1 + 0x94) = 0x18;
  *(uint32_t *)(param_1 + 0x98) = 0;
LAB_03e92d54:
  *(uint *)(param_1 + 0x2c) =
       *(uint *)(param_1 + 0x2c) & 0xff01ffff | 0x80000000 | (uStack_68 & 0x7f) << 0x11;
  *(uint32_t *)(param_1 + 0x18) = uStack_64;
  if (uStack_68 == 0) {
    _CmpRxCpmCode = _CmpRxCpmCode + 1;
    return false;
  }
  if ((uStack_60 & 0xffff) == 0) {
    if (uStack_68 == 0x1b) {
      uStack_68 = 0x40;
    }
  }
  else {
    smgrGetIfFromTlsInstance(uStack_60 & 0xffff,(int)&uStack_48 + 2,&uStack_48);
    if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_CMP,0xa12c630,1,0x16), iVar2 != 0)) {
      tracePrintVRtr(_MOD_CMP,0xa12c630,1,0x16,1,0xa12c63c,uStack_60 & 0xffff,uStack_48 & 0xffff,
                     uStack_48 >> 0x10);
    }
    if (((uStack_68 == 0x1b) && ((uStack_48 >> 16) != 0)) && ((uStack_48 & 0xffff) != 0)) {
      uStack_68 = 0x40;
    }
  }
  iVar2 = _MyHwFamily;
  if (_MyHwFamily == 3) {
    uStack_34 = uStack_48 >> 0x10;
    uStack_38 = uStack_48 & 0xffff;
  }
  *(int *)(&CmpRxRawFramesPerCode + uStack_68 * 4) =
       *(int *)(&CmpRxRawFramesPerCode + uStack_68 * 4) + 1;
  if ((uStack_68 < 0x41) && (*(code **)(&RawPacketHandlers + uStack_68 * 4) != (code *)0x0)) {
    iVar2 = (**(code **)(&RawPacketHandlers + uStack_68 * 4))(param_1,&uStack_68);
    bVar6 = iVar2 == 0;
  }
  else {
    if (uStack_68 - 9 < 2) {
      iVar2 = cmpRxTcpPackets(param_1,&uStack_68);
      if (iVar2 != 0x11) {
        return true;
      }
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) - iStack_5c;
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + iStack_5c;
      iVar2 = _MyHwFamily;
    }
    if ((iVar2 == 3) && ((uStack_68 == 5 || uStack_68 == 0xc || (uStack_68 == 0xb)))) {
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) - iStack_5c;
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + iStack_5c;
    }
    bVar6 = false;
    if (((1 < uStack_68 - 0x25) && (uStack_68 != 0x2f)) &&
       (1 < uStack_68 - 0x28 && uStack_68 != 0x33)) {
      if (uStack_68 == 3) {
        uStack_30 = uStack_30 | 0x2000000;
      }
      if (uStack_68 == 0x34) {
        uStack_30 = uStack_30 | 0x3000000;
      }
      if (uStack_68 - 0xe < 2) {
        uStack_30 = uStack_30 | 0x20000000;
      }
      if (uStack_68 == 0x10) {
        uStack_30 = uStack_30 | 0x10000000;
        *(uint *)(param_1 + 0x1c) = uStack_50 >> 0x18;
        if (((uStack_50 >> 8) & 0xff) == '\0') {
          *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 8;
        }
        else {
          *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 2;
        }
      }
      if (uStack_68 == 0x15) {
        uStack_30 = uStack_30 | 0x800000;
        *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x100000;
      }
      if (uStack_68 == 0x16) {
        uStack_30 = uStack_30 | 0x400000;
        *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x200000;
      }
      if (uStack_68 == 0x14) {
        uStack_30 = uStack_30 | 0x400000;
        *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x200000;
      }
      if (uStack_68 == 0x1d) {
        uStack_30 = uStack_30 | 0x80000000;
      }
      if (uStack_68 == 0x1f) {
        *(uint32_t *)(param_1 + 0x1c) = uStack_4c;
        *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x1000;
      }
      if (uStack_68 == 0x21) {
        uStack_30 = uStack_30 | 0x40000000;
      }
      if (uStack_68 - 4 < 5) {
        uStack_30 = uStack_30 | 0x4000000;
      }
      if (uStack_68 == 8) {
        uStack_30 = uStack_30 | 0x100000;
      }
      if (uStack_68 == 0x11) {
        uStack_30 = uStack_30 | 0x200000;
      }
      if ((_MyHwFamily == 3) && (((uStack_44 >> 16) & 0xff) != '\0')) {
        uStack_30 = ((uStack_30 & 0xffff0000) | (uStack_40 & 0xffff)) | 0x80000;
      }
      if (uStack_68 == 0x3b) {
        uStack_30 = uStack_30 | 0x40000;
      }
      iVar2 = pbufAddToStart(param_1,&uStack_38,0xc);
      if (iVar2 == 0xc) {
        *(uint *)(param_1 + 0x10) = *(uint *)(param_1 + 0x10) | 0x40000;
        pipRxFrame(param_1);
        bVar6 = true;
      }
      else {
        _CmpRxPipAddFailed = _CmpRxPipAddFailed + 1;
        bVar6 = false;
      }
    }
  }
  return bVar6;
}