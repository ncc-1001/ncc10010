#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared global variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwSarwxFpgaGpsIsDpllLocked(int param_1,int param_2)



{

  int in_zero;

  int iVar1;

  
  if (param_2 == 0) {
                    /* WARNING: Subroutine does not return */
    printf(0x69c1eb8,0x69c1fd0,0x15ff);
  }
  iVar1 = 0;
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
    }
    else {
      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
    }
  }
  if (*(char *)(iVar1 + 0x10c8f925) != -0x1d) {
    iVar1 = 0;
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
      }
      else {
        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
      }
    }
    if (*(char *)(iVar1 + 0x10c8f925) != -0x1b) {
      iVar1 = 0;
      if (_TgtHw == 1) {
        if (_kernelIsSmp == 0) {
          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
        }
        else {
          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
        }
      }
      if (*(char *)(iVar1 + 0x10c8f925) != -0x19) {
                    /* WARNING: Subroutine does not return */
        printf(0x69c1ea0,0x69c1fd0);
      }
    }
  }
  if (param_1 != 3) {
                    /* WARNING: Subroutine does not return */
    printf(0x69c1e7c,0x69c1fd0);
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}
