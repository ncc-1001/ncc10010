#include "nokia.h"
#include <stdint.h>

/* WARNING: Removing unreachable block (ram,0x041f081c) */

/* WARNING: Removing unreachable block (ram,0x041f0790) */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisAdjGRHelperDisabled(uint32_t *param_1)



{

  char cVar1;

  int iVar2;

  int iVar3;

  uint uVar4;

  

  iVar2 = dlistGetFirst(param_1[0xa8]);

  if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x400000) != 0)) &&

     (iVar3 = isisDebugCheck(param_1,0x400000,0,0), iVar3 != 0)) {

    if (_IsisLogger == 0) {

      tracePrint(_MOD_ISIS,0xa1a6f50,0,0,0xa1a6f68);

    }

    else {

      logEvent_debug_fmt(*param_1,0xa1a69b0,&isisTitleStr,0xa1a6f68);

    }

  }

  if (iVar2 == 0) {

    return;

  }

  iVar3 = *(int *)(iVar2 + 0x304);

  do {

    if (iVar3 == 1) {

      if ((*(int *)(iVar2 + 0x2f4) == 1) && (iVar3 = *(int *)(iVar2 + 0x3d8), iVar3 != 0)) {

        if ((*(char *)(iVar3 + 0x94) == '\0') && (*(char *)(iVar3 + 0x93) == '\0'))

        goto LAB_041f06c4;

        if (*(char *)(iVar3 + 0x94) == '\x01') {

          *(uintptr_t *)(iVar3 + 0x94) = 0;

          isisSendAdjRestartStatusChangeTrap

                    (param_1,iVar2,*(uint *)(iVar3 + 0x4c) & *(uint *)(iVar2 + 0x2fc) & param_1[7],

                     iVar3,1);

          cVar1 = *(char *)(iVar3 + 0x93);

        }

        else {

          cVar1 = *(char *)(iVar3 + 0x93);

        }

        if (cVar1 == '\x01') {

          *(uintptr_t *)(iVar3 + 0x93) = 0;

        }

        *(uintptr_t *)(iVar3 + 0x95) = 0;

        redTransModuleX(0x34,1,0xa1a688c,0xfda);

        isisRedSendAdjDbToInactive(iVar2,*(uint32_t *)(iVar3 + 0x4c),iVar3,1,0);

        if (cVar1 == '\x01') {

          isisAdjProcessSuppressChange(param_1,iVar3,1);

        }

        redTransModuleX(0x34,0,0xa1a688c,0xfe0);

        iVar2 = dlistGetNext(iVar2);

      }

      else {

        uVar4 = 1;

        if (*(int *)(iVar2 + 0x2f4) != 2) goto LAB_041f06c4;

        do {

          if (uVar4 == 1) {

            iVar3 = dlistGetFirst(*(uint32_t *)(iVar2 + 0x420));

          }

          else {

            iVar3 = dlistGetFirst(*(uint32_t *)(iVar2 + 0x5f0));

          }

          for (; iVar3 != 0; iVar3 = dlistGetNext(iVar3)) {

            while ((*(char *)(iVar3 + 0x94) != '\0' || (*(char *)(iVar3 + 0x93) != '\0'))) {

              if (*(char *)(iVar3 + 0x94) == '\x01') {

                *(uintptr_t *)(iVar3 + 0x94) = 0;

                isisSendAdjRestartStatusChangeTrap(param_1,iVar2,uVar4,iVar3,1);

                cVar1 = *(char *)(iVar3 + 0x93);

              }

              else {

                cVar1 = *(char *)(iVar3 + 0x93);

              }

              if (cVar1 == '\x01') {

                *(uintptr_t *)(iVar3 + 0x93) = 0;

                *(uintptr_t *)(iVar3 + 0x95) = 0;

                redTransModuleX(0x34,1,0xa1a688c,0xffd);

                isisRedSendAdjDbToInactive(iVar2,*(uint32_t *)(iVar3 + 0x4c),iVar3,1,0);

                isisAdjProcessSuppressChange(param_1,iVar3,1);

              }

              else {

                *(uintptr_t *)(iVar3 + 0x95) = 0;

                redTransModuleX(0x34,1,0xa1a688c,0xffd);

                isisRedSendAdjDbToInactive(iVar2,*(uint32_t *)(iVar3 + 0x4c),iVar3,1,0);

              }

              redTransModuleX(0x34,0,0xa1a688c,0x1003);

              iVar3 = dlistGetNext(iVar3);

              if (iVar3 == 0) goto LAB_041f07c8;

            }

          }

LAB_041f07c8:

          uVar4 = uVar4 + 1;

        } while (uVar4 < 3);

        iVar2 = dlistGetNext(iVar2);

      }

    }

    else {

LAB_041f06c4:

      iVar2 = dlistGetNext(iVar2);

    }

    if (iVar2 == 0) {

      return;

    }

    iVar3 = *(int *)(iVar2 + 0x304);

  } while( true );

}



