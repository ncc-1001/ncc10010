#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisAdjUpdateSuppProto(int param_1,int param_2)



{

  byte bVar1;

  uint32_t *puVar2;

  int iVar3;

  char cVar4;

  uint *puVar5;

  byte *pbVar6;

  int *piVar7;

  

  piVar7 = (int *)(param_1 + 0x788);

  *(uint32_t *)(param_2 + 0x80) = 0;

  puVar2 = (uint32_t *)(param_2 + 0x84);

  iVar3 = 2;

  do {

    iVar3 = iVar3 + -1;

    *puVar2 = 0;

    puVar2 = puVar2 + 1;

  } while (-1 < iVar3);

  if (piVar7 != (int *)0x0) {

    iVar3 = *piVar7;

    while (iVar3 != 0) {

      cVar4 = *(char *)(iVar3 + 1);

      pbVar6 = (byte *)(iVar3 + 2);

      if (cVar4 != '\0') {

        iVar3 = *(int *)(param_2 + 0x80);

        if (iVar3 < 3) {

          puVar5 = (uint *)(iVar3 * 4 + param_2 + 0x84);

          bVar1 = *pbVar6;

          while( true ) {

            cVar4 = cVar4 + -1;

            iVar3 = iVar3 + 1;

            *puVar5 = (uint)bVar1;

            puVar5 = puVar5 + 1;

            *(int *)(param_2 + 0x80) = iVar3;

            pbVar6 = pbVar6 + 1;

            if ((cVar4 == '\0') || (2 < iVar3)) break;

            bVar1 = *pbVar6;

          }

        }

      }

      piVar7 = (int *)piVar7[2];

      if (piVar7 == (int *)0x0) {

        return 0;

      }

      iVar3 = *piVar7;

    }

  }

  return 0;

}



