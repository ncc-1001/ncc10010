#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void idtPll_WriteReg(uintptr_t param_1,uint param_2)



{

  int in_zero;

  uintptr_t *puVar1;

  int iVar2;

  uint uVar3;

  uint uVar4;

  uint uVar5;

  uintptr_t auStackX_0 [16];

  

  iVar2 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar2 + 0x10c8f925) != -0x23) {

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) != -0x12) {

      uVar5 = (param_2 & 0xff) + 0x10030000;

      if (0xfffffff < uVar5) {

        uVar4 = PRId >> 8 & 0xffff;

        uVar3 = uVar4 ^ 0xd01;

        if ((((uVar3 != 0) && (uVar3 = uVar4 ^ 0xd06, uVar3 != 0)) &&

            (uVar3 = uVar4 ^ 0xd04, uVar3 != 0)) && (uVar3 = uVar4 ^ 0xd93, uVar3 != 0)) {

          uVar3 = uVar4 ^ 0xd90;

        }

        if (uVar3 == 0) {

          *(uintptr_t *)(uVar5 | 0xa0000000) = param_1;

          return;

        }

      }

      if ((uVar5 < 0x800000) ||

         (puVar1 = (uintptr_t *)(uVar5 | 0xc0000000), (PRId >> 0x10 & 0xff) != 0xd)) {

        puVar1 = (uintptr_t *)(uVar5 | 0xa0000000);

      }

      *puVar1 = param_1;

      return;

    }

  }

  auStackX_0[0] = param_1;

  spi_write_reg(auStackX_0);

  return;

}



