#include "nokia.h"
#include <stdint.h>

// Modified: Added typedef for 'byte' as uint8_t
typedef uint8_t byte;

// Modified: Added extern declaration for 'cRam10c8f925'
extern uint32_t cRam10c8f925;

int hwWakiSetMasterReset(uint32_t param_1)
{
  int iVar1;
  
  iVar1 = -1;
  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {
    iVar1 = hwWakiWriteReg32(0,0x1c,param_1);
    iVar1 = (iVar1 == 0) - 1;
  }
  return iVar1;
}
