#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undefined globals
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern uint32_t uRam0aed206c;
extern int iRam0aed1fc8;
// Modified: Changed array declarations to pointers
extern int *hwTypeInfo;
extern int *deviceNames;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


// Modified: Changed 'uint' to 'uint32_t' to fix unknown type name error
uint32_t adm1069GetResetCause(uint32_t param_1,int *param_2)


{

  int in_zero;

  int iVar1;

  int *piVar2;

  uint32_t uVar3;

  int iVar4;

  // Modified: Changed 'byte' to 'uint8_t'
  uint8_t bStack_20;

  // Modified: Changed 'byte' to 'uint8_t'
  uint8_t abStack_1f [3];

  int iStack_1c;

  

  if (8 < param_1) {
switchD_02956448_caseD_0:

                    /* WARNING: Subroutine does not return */

    printf(0x69bf90c,0x69bf990,param_1);

  }

  switch(param_1) {

  case 0:

    goto switchD_02956448_caseD_0;

  case 1:

    iVar4 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    piVar2 = (int *)0xaed208c;

    if (*(char *)(iVar4 + 0x10c8f925) != -0xe) {

      piVar2 = (int *)0xaed206c;

      iVar4 = 0;

      if (_TgtHw == 1) {

        if (_kernelIsSmp == 0) {

          iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

        }

        else {

          iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

        }

      }

      if (*(char *)(iVar4 + 0x10c8f925) != -0xd) {

        iVar4 = 0;

        if (_TgtHw == 1) {

          if (_kernelIsSmp == 0) {

            iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

          }

          else {

            iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

          }

        }

        if (*(char *)(iVar4 + 0x10c8f925) != -0xf) {

          iVar4 = 0;

          if (_TgtHw == 1) {

            if (_kernelIsSmp == 0) {

              iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

            }

            else {

              iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

            }

          }

          if (*(char *)(iVar4 + 0x10c8f925) != -8) {

            iVar4 = 0;

            if (_TgtHw == 1) {

              if (_kernelIsSmp == 0) {

                iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

              }

              else {

                iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

              }

            }

            if (*(char *)(iVar4 + 0x10c8f925) != -9) {

              iVar4 = 0;

              if (_TgtHw == 1) {

                if (_kernelIsSmp == 0) {

                  iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                }

                else {

                  iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                }

              }

              if (*(char *)(iVar4 + 0x10c8f925) != -10) {

                iVar4 = 0;

                if (_TgtHw == 1) {

                  if (_kernelIsSmp == 0) {

                    iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                  }

                  else {

                    iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                  }

                }

                if (*(char *)(iVar4 + 0x10c8f925) != -0x10) {

                  iVar4 = 0;

                  if (_TgtHw == 1) {

                    if (_kernelIsSmp == 0) {

                      iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                    }

                    else {

                      iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                    }

                  }

                  if (*(char *)(iVar4 + 0x10c8f925) != -0xe) break;

                }

              }

            }

          }

        }

      }

      uRam0aed206c = 1;

    }

    break;

  default:

    uVar3 = 1;

    goto LAB_02956770;

  case 3:

    iVar4 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar4 + 0x10c8f925) == -2) {
LAB_02956820:

      iVar4 = 0;

      if (_TgtHw == 1) {

        if (_kernelIsSmp == 0) {

          iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

        }

        else {

          iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

        }

      }

      piVar2 = (int *)0xaed1fec;

      // Modified: Changed array access to pointer arithmetic
      iVar4 = hwCardTypeIsRialzi(hwTypeInfo + iVar4);

      if (iVar4 != 0) break;

    }

    else {

      iVar4 = 0;

      if (_TgtHw == 1) {

        if (_kernelIsSmp == 0) {

          iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

        }

        else {

          iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

        }

      }

      if (*(char *)(iVar4 + 0x10c8f925) == -0x18) goto LAB_02956820;

    }

    iVar4 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    piVar2 = (int *)0xaed1fcc;

    if (*(char *)(iVar4 + 0x10c8f925) != -5) goto LAB_02956618;

    break;

  case 4:

    piVar2 = (int *)0xaed204c;

    break;

  case 5:

    piVar2 = (int *)0xaed202c;

    if (iRam0aed1fc8 != 0x1c) {

      *param_2 = iRam0aed1fc8;

      return 0;

    }

    goto LAB_02956690;

  case 6:

    piVar2 = (int *)0xaed200c;

    break;

  case 8:

    uVar3 = 2;

LAB_02956770:

    piVar2 = (int *)getModuleResetCause(uVar3);

    if (piVar2 == (int *)0x0) {
LAB_02956618:

                    /* WARNING: Subroutine does not return */

      printf(0x69bf9a8,0x69bf990,param_1);

    }

  }

  if (iRam0aed1fc8 != 0x1c) {

    *param_2 = iRam0aed1fc8;

    return 0;

  }
LAB_02956690:

  iVar4 = iRam0aed1fc8;

  iVar1 = adm1069GetCurrentSeState(param_1,&iStack_1c);

  if (iVar1 != 0) {

                    /* WARNING: Subroutine does not return */

    // Modified: Changed array access to pointer arithmetic
    printf(0x69bf9d0,0x69bf990,*(uint32_t *)(deviceNames + param_1 * 4));

  }

  if (param_1 == 3) {
LAB_029566d8:

    adm1069ReadRamRegister(param_1,0xe0,&bStack_20);

    adm1069ReadRamRegister(param_1,0xe1,abStack_1f);

    if ((bStack_20 & 2) == 0) {

      if ((bStack_20 & 4) == 0) {

        if ((bStack_20 & 8) == 0) {

          if ((bStack_20 & 0x10) == 0) {

            if ((bStack_20 & 0x40) == 0) {

              if ((char)bStack_20 < ' ') {

                iRam0aed1fc8 = piVar2[1];

              }

              else if ((abStack_1f[0] & 1) == 0) {

                if ((abStack_1f[0] & 2) == 0) {

                  if (param_1 != 3) {

                    iRam0aed1fc8 = 0;

                  }

                }

                else {

                  iRam0aed1fc8 = piVar2[3];

                }

              }

              else {

                iRam0aed1fc8 = piVar2[2];

              }

            }

            else {

              iRam0aed1fc8 = *piVar2;

            }

          }

          else {

            iRam0aed1fc8 = piVar2[7];

          }

        }

        else {

          iRam0aed1fc8 = piVar2[6];

        }

      }

      else {

        iRam0aed1fc8 = piVar2[5];

      }

    }

    else {

      iRam0aed1fc8 = piVar2[4];

    }

    if ((param_1 == 1 || param_1 == 4) || (param_1 == 5 || param_1 == 6)) {

      if (iRam0aed1fc8 == 0x17) {

        iVar4 = -0x7ffe8000;

        if (_TgtHw == 1) {

          if (_kernelIsSmp == 0) {

            iVar4 = *(int *)(_smpTaskIdCurrent + 0x2b8);

          }

          else {

            iVar4 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8);

          }

          iVar4 = iVar4 * 0xba4 + -0x7ffe8000;

        }

        // Modified: Changed 'uint' to 'uint32_t'
        if ((*(uint32_t *)(iVar4 + 0xa40) & 0x20000000) != 0) {

          iRam0aed1fc8 = 0x18;

          *param_2 = 0x18;

          return 0;

        }

      }

      *param_2 = iRam0aed1fc8;

    }

    else {

      *param_2 = iRam0aed1fc8;

    }

    return 0;

  }

  if (iStack_1c == 1) {

    iRam0aed1fc8 = iVar4;

    *param_2 = iVar4;

  }

  else {

    if (iStack_1c - 2U < 2) {

      iRam0aed1fc8 = 0;

      *param_2 = 0;

      return 0;

    }

    if (iStack_1c - 4U < 2) goto LAB_029566d8;

  }

                    /* WARNING: Subroutine does not return */

  printf(0x69bfa00,0x69bf990);
}