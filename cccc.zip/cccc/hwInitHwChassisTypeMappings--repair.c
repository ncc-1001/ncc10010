#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for _TgtPf to resolve compilation error
extern int _TgtPf;

void hwInitHwChassisTypeMappings(void)
{
  if (_TgtPf == 3) {
    tmHwModifyTapAllocation(6);
    hwValidateChassisDescr(6);
    hwValidateChassisDescr(8);
    return;
  }
  if (_TgtPf != 4) {
    hwValidateChassisDescr(2);
    hwValidateChassisDescr(3);
    hwValidateChassisDescr(4);
    hwValidateChassisDescr(5);
    hwValidateChassisDescr(7);
    hwValidateChassisDescr(10);
    return;
  }
  hwValidateChassisDescr(0xfd);
  hwValidateChassisDescr(0xfc);
  hwValidateChassisDescr(0xfa);
  hwValidateChassisDescr(0xfe);
  hwValidateChassisDescr(0xe8);
  hwValidateChassisDescr(0xfb);
  hwValidateChassisDescr(0xed);
  hwValidateChassisDescr(0xeb);
  hwValidateChassisDescr(0xe9);
  hwValidateChassisDescr(0xea);
  hwValidateChassisDescr(0xf3);
  hwValidateChassisDescr(0xf1);
  hwValidateChassisDescr(0xf8);
  hwValidateChassisDescr(0xf7);
  hwValidateChassisDescr(0xf6);
  hwValidateChassisDescr(0xf0);
  hwValidateChassisDescr(0xf2);
  hwValidateChassisDescr(0xdc);
  hwValidateChassisDescr(0xdd);
  hwValidateChassisDescr(0xee);
  hwValidateChassisDescr(0xe2);
  hwValidateChassisDescr(0xe3);
  hwValidateChassisDescr(0xe4);
  hwValidateChassisDescr(0xe5);
  hwValidateChassisDescr(0xe6);
  hwValidateChassisDescr(0xe7);
  return;
}