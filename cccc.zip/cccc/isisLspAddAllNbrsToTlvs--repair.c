#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

void isisLspAddAllNbrsToTlvs(uint32_t *param_1,int param_2,uintptr_t param_3)
{

  int iVar1;

  int iVar2;

  int iVar3;

  uint32_t uVar4;

  

  if (param_2 == 1) {

    uVar4 = param_1[0x1a5];

  }

  else {

    uVar4 = param_1[0x1a6];

  }

  iVar1 = dlistGetFirst(uVar4);

  while( true ) {

    if (iVar1 == 0) {

      return;

    }

    iVar2 = dlistAllocateNodeExt(param_1[0x82e],4,1);

    if (iVar2 == 0) break;

    isisLspAddNbrToNode(param_1,iVar1,iVar2,param_2,param_3,0,0);

    iVar2 = *(int *)(iVar1 + 0xc) + 4;

    if (*(int *)(iVar1 + 0xc) == 0) {

      iVar2 = 0;

    }

    iVar3 = *(int *)(iVar1 + 0x1c) + 4;

    if (*(int *)(iVar1 + 0x1c) == 0) {

      iVar3 = 0;

    }

    isisRedSendNbrToInactive

              (param_1,1,iVar1,param_2,*(uint32_t *)(iVar1 + 0x14),*(uint32_t *)(iVar1 + 0x18),

               *(uint32_t *)(iVar1 + 0x24),*(uint32_t *)(iVar1 + 0x28),

               *(uint32_t *)(iVar1 + 0x2c),*(uint32_t *)(iVar1 + 0x30),

               *(uint32_t *)(iVar1 + 0x34),*(uint32_t *)(iVar1 + 0x38),

               *(uint32_t *)(iVar1 + 0x3c),*(uint32_t *)(iVar1 + 0x40),

               *(uint32_t *)(iVar1 + 0x44),*(uint32_t *)(iVar1 + 0x48),

               *(uint32_t *)(iVar1 + 8),iVar2,iVar3,1,param_3,0);

    iVar1 = dlistGetNext(iVar1);

  }

  if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x200) == 0)) ||

     (iVar1 = isisDebugCheck(param_1,0x200,0,0), iVar1 == 0)) {

    isisHandleMemFail(param_1);

  }

  else if (_IsisLogger == 0) {

    tracePrint(_MOD_ISIS,0xa1ab418,0,0,0xa1ab430);

    isisHandleMemFail(param_1);

  }

  else {

    logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1ab430);

    isisHandleMemFail(param_1);

  }

  return;
}