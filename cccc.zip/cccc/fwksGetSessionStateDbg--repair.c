#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared symbols
extern void *__gxx_personality_sj0;
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern uint __ZN8Firewall10FwksFilter8m_uLimitE;
extern uint __ZN8Firewall10FwksFilter6m_uNewE;
extern uint __ZN8Firewall10FwksFilter9m_uDeleteE;
extern uint uRam0c9594cc;
extern uint uRam0c9594c4;
extern uint uRam0c959610;
extern uint uRam0c959618;
extern int iRam0c959614;
extern int iRam0c95960c;
extern int iRam0c95961c;

void fwksGetSessionStateDbg(uint param_1,uint32_t param_2,uint32_t param_3)
{
  int iVar1;
  int iVar2;
  uintptr_t auStack_498 [16];
  uint32_t uStack_488;
  uint32_t uStack_484;
  uint32_t uStack_480;
  uintptr_t uStack_47c;
  uint16_t uStack_7c;
  uint16_t uStack_7a;
  uintptr_t auStack_78 [2];
  uint16_t uStack_76;
  uintptr_t uStack_74;
  uintptr_t auStack_70 [4];
  uint32_t uStack_6c;
  // Modified: Replaced 'code *' with 'void *'
  void *pcStack_58;
  uint32_t uStack_54;
  uint32_t *puStack_50;
  uint32_t uStack_4c;
  uintptr_t *puStack_48;
  uint uStack_3c;
  int iStack_30;

  puStack_48 = auStack_498;
  uStack_3c = param_1 & 0xffff;
  pcStack_58 = __gxx_personality_sj0;
  uStack_54 = 0xbff860e;
  puStack_50 = &uStack_480;
  uStack_4c = 0x40eb2b4;
  _Unwind_SjLj_Register(auStack_70);
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_6c = 0xffffffff;
      iStack_30 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_30 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_6c = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_30;
    iVar2 = 0;
    if (iStack_30 == 0) goto LAB_040eb170;
  }
  iVar2 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
LAB_040eb170:
  if (iVar2 != 0) {
    uStack_480 = 0xa17ddb0;
    uStack_7c = 0x400;
    auStack_78[0] = 1;
    uStack_74 = 1;
    uStack_7a = 0;
    uStack_47c = 0;
    uStack_76 = 0;
    iVar1 = 0xb6b950;
    if (*(int *)(iVar2 + 0xb2f190) == 0) {
      iVar1 = 0xb6a070;
    }
    uStack_6c = 0xffffffff;
    uStack_488 = param_2;
    uStack_484 = param_3;
    _ZN8Firewall9ZoneGroup15getSessionStateERNS_12OutputStreamERNS_6IndentEtPcj
              (iVar2 + iVar1,&uStack_480,auStack_78,uStack_3c);
  }
  _Unwind_SjLj_Unregister(auStack_70);
  return;
}