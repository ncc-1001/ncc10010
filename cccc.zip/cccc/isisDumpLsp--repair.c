#include "nokia.h"
#include <stdint.h>

// Modified: Added declaration for undeclared global variable iRam0c98c1e0
int iRam0c98c1e0;

uintptr_t * isisDumpLsp(uint32_t *param_1,int param_2,uintptr_t *param_3,int param_4)



{

  int iVar1;

  uint32_t uVar2;

  uint uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t uVar6;

  uintptr_t *puVar7;

  uintptr_t *puVar8;

  uintptr_t auStack_2360 [8096];

  uintptr_t auStack_3c0 [512];

  uintptr_t auStack_1c0 [128];

  uintptr_t auStack_140 [264];

  uint32_t uStack_38;

  uint32_t uStack_34;

  uint32_t uStack_30;

  

  uStack_30 = 0;

  if (param_1 == (uint32_t *)0x0) {

                    /* WARNING: Subroutine does not return */

    printf(0xa1b5a2c);

  }

  iVar1 = isisGetNode(1,&uStack_38);

  if (iVar1 == 0) {

    puVar7 = param_3;

    if (param_3 == (uintptr_t *)0x0) {

      puVar7 = auStack_2360;

      param_4 = 0x1fa0;

    }

    auStack_3c0[0] = 0;

    isisDumpLspId(param_1 + 1,auStack_3c0,0x200,1);

    iVar1 = param_1[0xd];

    uVar2 = isisDumpLspFlags(*(uint16_t *)(param_1 + 3),auStack_1c0,0x80);

    uVar5 = param_1[9];

    uVar6 = param_1[7];

    uVar3 = (uint)*(byte *)(iVar1 + 0x1a);

    iVar1 = snprintfTruncate(puVar7,param_4,0xa1b58e0,auStack_3c0,param_1,uVar5,uVar2,uVar3,uVar6);

    puVar8 = puVar7;

    if (iRam0c98c1e0 == 1) {

      puVar8 = puVar7 + iVar1;

      if ((*(ushort *)(param_1 + 3) & 4) == 0) {

        iVar1 = snprintfTruncate(puVar8,param_4 - ((int)puVar8 - (int)puVar7),0xa1b5b18,param_1,

                                 *param_1,uVar5,uVar2,uVar3,uVar6);

      }

      else {

        uVar2 = param_1[0x44];

        iVar1 = snprintfTruncate(puVar8,param_4 - ((int)puVar8 - (int)puVar7),0xa1b5ad8,param_1,

                                 *param_1,param_1[0x43],uVar2,uVar3,uVar6);

      }

    }

    if (1 < param_2) {

      puVar8 = puVar8 + iVar1;

      timerGetCallback(param_1[5],&uStack_34);

      uVar5 = isisLspGetRemLife(uStack_38,param_1);

      uVar4 = FmtSymbol(uStack_34,auStack_140,0x101);

      uVar2 = param_1[4];

      uVar3 = (uint)*(ushort *)((int)param_1 + 0xe);

      iVar1 = snprintfTruncate(puVar8,param_4 - ((int)puVar8 - (int)puVar7),0xa1b5a9c,uVar5,

                               param_1[5],uVar4,uVar2,uVar3);

    }

    if (2 < param_2) {

      snprintfTruncate(puVar8 + iVar1,param_4 - ((int)(puVar8 + iVar1) - (int)puVar7),0xa1b5a3c,

                       *(uint16_t *)(param_1 + 10),*(uint16_t *)((int)param_1 + 0x2a),

                       param_1[0x44],uVar2,uVar3,uVar6);

                    /* WARNING: Subroutine does not return */

      printf(0xa1b5a6c,*(uint16_t *)(param_1 + 10),*(uint16_t *)((int)param_1 + 0x2a),

             param_1[0x44]);

    }

    if (param_3 == (uintptr_t *)0x0) {

                    /* WARNING: Subroutine does not return */

      printf(0xa1b5828,puVar7);

    }

    if (3 < param_2) {

                    /* WARNING: Subroutine does not return */

      printf(0xa1b5920);

    }

  }

  return param_3;

}