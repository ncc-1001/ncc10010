#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

uint32_t isisSpfAddSelfToPaths(uint32_t *param_1,int param_2,int param_3)
{

  uint32_t *puVar1;
  int iVar2;
  uint32_t uVar3;
  uintptr_t auStack_20 [8];
  
  puVar1 = (uint32_t *)isisSpfPathAlloc();
  uVar3 = 6;
  if (puVar1 != (uint32_t *)0x0) {
    *puVar1 = 0;
    memcpy(puVar1 + 2,param_1 + 8,6);
    *(uintptr_t *)((int)puVar1 + 0xe) = 0;
    puVar1[1] = 0;
    if (param_2 == 1) {
      uVar3 = param_1[param_3 + 0x271];
    }
    else {
      uVar3 = param_1[param_3 + 0x273];
    }
    iVar2 = avlpInsertUnique(uVar3,puVar1 + 2,puVar1,auStack_20);
    uVar3 = 0;
    if (iVar2 != 0) {
      if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x100) != 0)) &&
         (iVar2 = isisDebugCheck(param_1,0x100,param_2,0), iVar2 != 0)) {
        if (_IsisLogger == 0) {
          uVar3 = isisXlateMtId(param_3);
          tracePrint(_MOD_ISIS,0xa1b1748,0,0,0xa1b1760,param_2,uVar3);
        }
        else {
          uVar3 = isisXlateMtId(param_3);
          logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1760,param_2,uVar3);
        }
      }
      isisSpfPathFree(puVar1);
      isisHandleMemFail(param_1);
      uVar3 = 8;
    }
  }
  return uVar3;
}