#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwSarmFpgaGetSystemTime(uint32_t param_1,uint32_t param_2,char param_3)



{

  int in_zero;

  int iVar1;

  

  if (param_3 != '\0') {

                    /* WARNING: Subroutine does not return */

    intLockProtect(&intRwLock);

  }

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) != -0x23) {

    iVar1 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar1 + 0x10c8f925) != -0x12) {

                    /* WARNING: Bad instruction - Truncating control flow here */

      halt_baddata();

    }

  }

                    /* WARNING: Bad instruction - Truncating control flow here */

  halt_baddata();

}



