#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int *_gMdaInfo;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

void fpgaUBlazeDebugCounterShow(uint param_1,char param_2)
{

  int iVar1;
  char *pcVar2;
  
  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
                    /* WARNING: Subroutine does not return */
    printf(0xa8dc49c,0xa8dc480);
  }
  iVar1 = fpgaIsValidMda();
  if ((iVar1 == 0) || (pcVar2 = (char *)fpgaGetMda(param_1), pcVar2 == (char *)0x0)) {
    if (((param_1 <= *_gMdaInfo) && (iVar1 = macMdaRemoved(param_1), iVar1 == 0)) &&
       ((_traceEnabled != 0 ||
        ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8dc480,4,0), iVar1 != 0))))))
    {
      tracePrintVRtr(_MOD_MDADRV,0xa8dc480,4,0,1,0xa8d9798,param_1);
    }
  }
  else if (*pcVar2 != '\0') {
    iVar1 = *(int *)(pcVar2 + 8);
    if (((((((iVar1 != 0x8c && iVar1 != 0x93) && (iVar1 != 0x8f)) && (iVar1 != 0x94)) &&
          ((iVar1 != 0xa2 && iVar1 != 0x90 && (iVar1 != 0x91)))) &&
         ((iVar1 != 0x9a && ((iVar1 != 0x80 && iVar1 != 0xae && (iVar1 != 0xa3 && iVar1 != 0xaa)))))
         ) && ((iVar1 != 0x9b &&
               (((iVar1 != 0xa9 && (iVar1 != 0xac)) && (iVar1 != 0x7e && iVar1 != 0xaf)))))) &&
       (((((iVar1 != 0xb2 && (iVar1 != 0xb4)) &&
          ((iVar1 != 0xb0 && ((iVar1 != 0xb6 && (2 < iVar1 - 0xbbU)))))) && (iVar1 != 0xc2)) &&
        (iVar1 != 0x9c)))) {
      if (param_2 != '\0') {
        memset(pcVar2 + 0x1110,0,0x30);
        memset(pcVar2 + 0x10f0,0,0x20);
        memset(pcVar2 + 0x1140,0,0x40);
        memset(pcVar2 + 0x1180,0,0x18);
        memset(pcVar2 + 0x1198,0,0x20);
        memset(pcVar2 + 0x11b8,0,0x2c);
        iVar1 = _fpgaUBlazeIsExcepIndSupported(param_1);
        if (iVar1 != 0) {
          memset(pcVar2 + 0x11e4,0,0x38);
        }
        iVar1 = _fpgaUBlazeIsEccSupported(param_1);
        if (iVar1 != 0) {
          memset(pcVar2 + 0x121c,0,0xc);
        }
      }
      return;
    }
                    /* WARNING: Subroutine does not return */
    printf(0xa8dc4e4);
  }
                    /* WARNING: Subroutine does not return */
  printf(0xa8dc4d4);
}