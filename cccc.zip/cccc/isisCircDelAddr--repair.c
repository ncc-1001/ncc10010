#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for _isisMutex to fix compilation error
extern int _isisMutex;

void isisCircDelAddr(uint32_t param_1)
{
  int iVar1;
  uintptr_t auStack_28 [8];
  
  iVar1 = isisGetNode(param_1,auStack_28);
  if (iVar1 != 0) {
    return;
  }
                    /* WARNING: Subroutine does not return */
  semTake(_isisMutex,0xffffffff);
}