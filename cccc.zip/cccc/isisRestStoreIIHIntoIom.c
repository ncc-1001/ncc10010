#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisRestStoreIIHIntoIom(uint32_t *param_1,int param_2,int param_3,uint32_t param_4)



{

  uint16_t uVar1;

  int iVar2;

  int iVar3;

  int iVar4;

  

  iVar2 = pbufCopy(param_4,0);

  if (iVar2 != 0) {

    uVar1 = *(uint16_t *)((int)param_1 + 0x201e);

    iVar3 = *(int *)(iVar2 + 8) + iVar2;

    *(char *)(iVar3 + 0xc1) = (char)uVar1;

    *(char *)(iVar3 + 0xc0) = (char)((ushort)uVar1 >> 8);

    iVar3 = pipGetPipObj(*param_1);

    if (((iVar3 != 0) && (*(int *)(iVar3 + 0xab0) != 0)) &&

       (iVar3 = pipGetPipRec(iVar3,*(uint32_t *)(param_2 + 8)), iVar3 != 0)) {

      iVar3 = pMgrPortEncapPPP(*(uint32_t *)(iVar3 + 0x34));

      if (iVar3 != 0) {

        iVar3 = *(int *)(iVar2 + 8) + 0xf;

        *(int *)(iVar2 + 0xc) = *(int *)(iVar2 + 0xc) + -0xf;

        iVar4 = iVar3 + iVar2;

        *(int *)(iVar2 + 8) = iVar3;

        *(uintptr_t *)(iVar4 + 0xa1) = 0x23;

        *(uintptr_t *)(iVar4 + 0xa0) = 0;

      }

      pipIomSendPrePackagedPkt

                (0xc,*(uint32_t *)(param_2 + 8),param_3 != 1,1,0,

                 *(int *)(iVar2 + 8) + iVar2 + 0xa0,*(uint32_t *)(iVar2 + 0xc));

    }

    pbufFree(iVar2);

  }

  return;

}



