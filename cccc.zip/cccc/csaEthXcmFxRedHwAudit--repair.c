#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int *_gMdaInfo;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

uint32_t csaEthXcmFxRedHwAudit(uint param_1)
{
  int iVar1;
  void (*pcVar2)(void); // Modified: Changed to function pointer type
  uint uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint auStackX_0 [4];
  uint32_t auStack_18 [2];
  
  auStack_18[0] = 0;
  auStackX_0[0] = param_1;
  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
    timosAssert(0xa8e732c,0xa8e7348,0xf65,0xa8e7a08,0xa8e7328);
  }
  iVar6 = *(int *)(auStackX_0[0] * 4 + 0xccb630c);
  if (iVar6 == 0) {
    timosAssert(0xa8e73b4,0xa8e7348,0xf65,0xa8e7a08,0xa8e7328);
  }
  if ((_tracepointsActive != 0) && (iVar1 = traceTest(_MOD_MDADRV,0xa8e7a08,1,0), iVar1 != 0)) {
    tracePrintVRtr(_MOD_MDADRV,0xa8e7a08,1,0,1,0xa8e7a44,auStackX_0[0]);
  }
  if (iVar6 == 0) {
    return auStack_18[0];
  }
  iVar1 = csaEthGetMda(*(uint32_t *)(iVar6 + 8),1);
  if (iVar1 != 0) {
    if ((*(int *)(iVar1 + 8) != 0) &&
       (pcVar2 = (void (*)(void))(*(int *)(iVar1 + 8) + 100), pcVar2 != (void (*)(void))0x0)) { // Modified: Adjusted cast
      ((void (*)(uint *, uint32_t *))pcVar2)(auStackX_0, auStack_18); // Modified: Adjusted call
    }
    uVar5 = 0;
    if (iVar1 == 0) goto LAB_063fc76c;
    if (*(int *)(iVar1 + 0xc) == 0) {
      iVar1 = 0;
      goto LAB_063fc770;
    }
    pcVar2 = (void (*)(void))(*(int *)(iVar1 + 0xc) + 8); // Modified: Adjusted cast
    if (pcVar2 != (void (*)(void))0x0) { // Modified: Adjusted cast
      ((void (*)(uint))pcVar2)(auStackX_0[0]); // Modified: Adjusted call
      uVar5 = 0;
      goto LAB_063fc76c;
    }
  }
  uVar5 = 0;
LAB_063fc76c:
  do {
    iVar1 = uVar5 << 1;
LAB_063fc770:
    iVar1 = iVar1 * 0x800 + uVar5 * 0xa60 + iVar6;
    if (*(char *)(iVar1 + 0xb72) == '\0') {
      uVar3 = *(uint *)(iVar6 + 0xec);
    }
    else if (*(char *)(iVar1 + 0x9e1) == '\0') {
      uVar3 = *(uint *)(iVar6 + 0xec);
    }
    else {
      uVar3 = fpgaRegRead(*(uint32_t *)(iVar6 + 8),*(int *)(iVar1 + 0xb64) + 4);
      if ((uVar3 & 4) == 0) {
        *(uintptr_t *)(iVar1 + 0x2390) = 0;
      }
      else {
        *(uintptr_t *)(iVar1 + 0x2390) = 1;
      }
      if ((_tracepointsActive == 0) || (iVar4 = traceTest(_MOD_MDADRV,0xa8e7a08,1,0), iVar4 == 0)) {
        uVar3 = *(uint *)(iVar6 + 0xec);
      }
      else {
        tracePrintVRtr(_MOD_MDADRV,0xa8e7a08,1,0,1,0xa8e7a20,*(uint32_t *)(iVar6 + 8),
                       *(uint16_t *)(iVar1 + 0x9dc),*(uint16_t *)(iVar1 + 0xb84));
        uVar3 = *(uint *)(iVar6 + 0xec);
      }
    }
    uVar5 = uVar5 + 1 & 0xffff;
  } while (uVar5 <= uVar3);
  return auStack_18[0];
}