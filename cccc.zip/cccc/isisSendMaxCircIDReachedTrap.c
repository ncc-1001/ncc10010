#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendMaxCircIDReachedTrap(uint32_t *param_1,int param_2)



{

  logEvent_ISIS_vRtrIsisCircIdExhausted(*param_1,0xa1bbc18,*param_1,*(uint32_t *)(param_2 + 8));

  return;

}



