#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for undeclared global variable _gMdaInfo
extern int *_gMdaInfo;

void csaEthWp3MdaDisableTimestamp(uint param_1)

{

  char *pcVar1;

  char *pcVar2;

  

  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {

    timosAssert(0xa8c399c,0xa8c3970,0xfad,0xa8c4a64,0xa8c3960);

  }

  if (*(int *)(param_1 * 4 + 0xccb630c) == 0) {

    timosAssert(0xa8c39e8,0xa8c3970,0xfad,0xa8c4a64,0xa8c3960);

  }

  pcVar2 = (char *)0x0;

  if ((param_1 != 0) && (param_1 <= *_gMdaInfo)) {

    pcVar1 = (char *)(param_1 * 0x3a88 + 0x10d260a8);

    if ((*pcVar1 != '\0') && (pcVar2 = pcVar1, pcVar1 != (char *)0x0)) {

      *(uintptr_t *)(param_1 * 0x3a88 + 0x10d29b1d) = 0;

      return;

    }

  }

  timosAssert(0xa8c3964,0xa8c3970,0xfae,0xa8c4a64,0xa8c3960);

  pcVar2[0x3a75] = '\0';

  return;

}
