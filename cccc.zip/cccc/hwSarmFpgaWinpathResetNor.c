#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */



void hwSarmFpgaWinpathResetNor(void)



{

                    /* WARNING: Bad instruction - Truncating control flow here */

  halt_baddata();

}



