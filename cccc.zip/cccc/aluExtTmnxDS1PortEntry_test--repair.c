#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared hardware registers
extern uint32_t uRam0c328130;
extern uint32_t uRam0c328134;
extern uint32_t uRam0c328150;

void aluExtTmnxDS1PortEntry_test
               (uint32_t param_1,int param_2,uint32_t *param_3,uint32_t param_4,
               uint32_t *param_5)
{
  int iVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  uint32_t uVar5;
  uint32_t *puVar6;
  uint32_t uVar7;
  uint32_t *puVar8;
  uint32_t auStack_48 [8];
  int iStack_28;
  
  group_by_getproc_and_instance(param_4,param_5,param_2,param_3);
  uVar7 = 0;
  if (param_2 == 2) {
    uRam0c328130 = *param_3;
    puVar8 = (uint32_t *)0xc328130;
    uRam0c328134 = param_3[1];
    iVar1 = sia_tmnxDS1PortEntryGet(1,0xc328130);
    puVar6 = auStack_48;
    if (iVar1 == 0) {
      do {
        uVar2 = *puVar8;
        uVar3 = puVar8[1];
        uVar4 = puVar8[2];
        uVar5 = puVar8[3];
        puVar8 = puVar8 + 4;
        *puVar6 = uVar2;
        puVar6[1] = uVar3;
        puVar6[2] = uVar4;
        puVar6[3] = uVar5;
        puVar6 = puVar6 + 4;
      } while (puVar8 != (uint32_t *)0xc328150);
      *puVar6 = uRam0c328150;
      param_5[0xe] = 0xc328130;
      puVar8 = param_5;
      if (param_5 == (uint32_t *)0x0) {
        uVar7 = 0;
      }
      else {
        do {
          if (puVar8[6] != 1) {
            testproc_error(param_4,puVar8,5);
            return;
          }
          if (puVar8[10] - 1 < 3) {
            uVar7 = 0x8000;
            iStack_28 = puVar8[10];
            testproc_good();
            puVar8 = (uint32_t *)*puVar8;
          }
          else {
            testproc_error(param_4,puVar8,10);
            puVar8 = (uint32_t *)*puVar8;
          }
        } while (puVar8 != (uint32_t *)0x0);
      }
      iVar1 = sia_tmnxDS1PortEntryCheck(uVar7,auStack_48);
      if (iVar1 != 0) {
        siaCheckError(param_4,param_5,0x3e9,iVar1);
      }
    }
    else {
      testproc_error(param_4,param_5,2);
    }
  }
  else {
    for (; param_5 != (uint32_t *)0x0; param_5 = (uint32_t *)*param_5) {
      testproc_error(param_4,param_5,0xb);
    }
  }
  return;
}