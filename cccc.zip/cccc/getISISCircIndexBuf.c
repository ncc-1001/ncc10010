#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int getISISCircIndexBuf(uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,

                       uint32_t param_5)



{

  int iVar1;

  int iVar2;

  uintptr_t auStack_7f0 [1000];

  uintptr_t auStack_408 [1000];

  int iStack_20;

  uintptr_t auStack_1c [4];

  

  iVar1 = getVRtrId();

  if (iVar1 == 0) {

    return -1;

  }

  iStack_20 = pipGetRtrIfIndex(iVar1,param_3);

  if (iStack_20 == 0) {

    cliErrorMesg(param_1,0xa07cc68,param_3);

  }

  else {

    iVar2 = isisGetCircIdFromIfId(iVar1,iStack_20,&iStack_20);

    if (iVar2 == 0) {

      snprintf(param_4,param_5,0xa07cc3c,iVar1,iStack_20);

      snprintf(auStack_7f0,1000,0xa07ccac,param_4);

      iVar1 = RCC_RCB_ReadValueFromRCB(param_1,auStack_7f0,0,auStack_408,auStack_1c);

      if (iVar1 == 0) {

        iVar1 = strcmp(auStack_408,0xa07cc5c);

        return 2 - (uint)(iVar1 != 0);

      }

      cliErrorMesg(param_1,0xa07cc88);

    }

    else {

      cliErrorMesg(param_1,0xa07ccc4,param_3,iVar1);

    }

  }

  return -1;

}



