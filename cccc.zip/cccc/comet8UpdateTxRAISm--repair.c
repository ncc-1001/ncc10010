#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing variables
extern int *_gMdaInfo;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _vxAbsTicks;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void comet8UpdateTxRAISm(uint param_1,int param_2)


{

  ushort uVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  int iVar4;

  int iVar5;

  int iVar6;

  

  iVar6 = 0;

  if ((((param_1 == 0) || (*_gMdaInfo < param_1)) ||

      (iVar6 = *(int *)(param_1 * 4 + 0xccb422c), iVar6 == 0)) &&

     (iVar4 = macMdaRemoved(param_1), iVar4 == 0)) {

    if (_traceEnabled == 0) {

      if (_tracepointsActive == 0) {

        return;

      }

      iVar6 = traceTest(_MOD_MDADRV,0xa9849e4,4,0);

      if (iVar6 == 0) {

        return;

      }

    }

    tracePrintVRtr(_MOD_MDADRV,0xa9849e4,4,0,1,0xa9849f8,param_1);

    return;

  }

  iVar4 = param_2 * 0x8c + iVar6;

  if (*(char *)(iVar4 + 0xb4) != '\x02') {

    return;

  }

  iVar5 = *(int *)(iVar4 + 0xcc);

  uVar1 = *(ushort *)(param_2 * 2 + iVar6 + 0x14);

  if (iVar5 == 1) {

    if ((uVar1 & 0x1000) != 0) {

      *(int *)(iVar4 + 0xd0) = _vxAbsTicks;

      return;

    }

    if ((_tracepointsActive != 0) && (iVar6 = traceTest(_MOD_MDADRV,0xa984974,1,0), iVar6 != 0)) {

      uVar2 = comet8FmtTxRAIState(*(uint32_t *)(iVar4 + 0xcc));

      uVar3 = comet8FmtTxRAIState(2);

      tracePrintVRtr(_MOD_MDADRV,0xa984974,1,0,1,0xa984990,param_1,param_2,uVar2,uVar3);

    }

    *(uint32_t *)(iVar4 + 0xcc) = 2;

    *(int *)(iVar4 + 0xd0) = _vxAbsTicks;

    return;

  }

  if (iVar5 == 0) {

    if ((uVar1 & 0x1000) == 0) {

      return;

    }

    comet8SetTxRAI(param_1,param_2,1);

    if ((_tracepointsActive == 0) || (iVar6 = traceTest(_MOD_MDADRV,0xa984974,1,0), iVar6 == 0))

    goto LAB_065a12a4;

    uVar2 = comet8FmtTxRAIState(*(uint32_t *)(iVar4 + 0xcc));

    uVar3 = comet8FmtTxRAIState(1);

  }

  else {

    if (iVar5 != 2) {

      return;

    }

    if ((uVar1 & 0x1000) == 0) {

      if ((uint)(_vxAbsTicks - *(int *)(iVar4 + 0xd0)) < 0x4e2) {

        return;

      }

      comet8SetTxRAI(param_1,param_2,0);

      if (_tracepointsActive == 0) {

        *(uint32_t *)(iVar4 + 0xcc) = 0;

      }

      else {

        iVar6 = traceTest(_MOD_MDADRV,0xa984974,1,0);

        if (iVar6 == 0) {

          *(uint32_t *)(iVar4 + 0xcc) = 0;

        }

        else {

          uVar2 = comet8FmtTxRAIState(*(uint32_t *)(iVar4 + 0xcc));

          uVar3 = comet8FmtTxRAIState(0);

          tracePrintVRtr(_MOD_MDADRV,0xa984974,1,0,1,0xa984990,param_1,param_2,uVar2,uVar3);

          *(uint32_t *)(iVar4 + 0xcc) = 0;

        }

      }

      *(int *)(iVar4 + 0xd0) = _vxAbsTicks;

      return;

    }

    *(int *)(iVar4 + 0xd0) = _vxAbsTicks;

    if ((_tracepointsActive == 0) || (iVar6 = traceTest(_MOD_MDADRV,0xa984974,1,0), iVar6 == 0))

    goto LAB_065a12a4;

    uVar2 = comet8FmtTxRAIState(*(uint32_t *)(iVar4 + 0xcc));

    uVar3 = comet8FmtTxRAIState(1);

  }

  tracePrintVRtr(_MOD_MDADRV,0xa984974,1,0,1,0xa984990,param_1,param_2,uVar2,uVar3);

LAB_065a12a4:

  *(uint32_t *)(iVar4 + 0xcc) = 1;

  *(int *)(iVar4 + 0xd0) = _vxAbsTicks;

  return;

}