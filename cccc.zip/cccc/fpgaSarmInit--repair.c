#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables to fix compilation
extern uint32_t *_gMdaInfo;
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _traceEnabled;
extern int cRam10c8f925;

int fpgaSarmInit(uint param_1,uint32_t param_2,uint param_3)

{

  uint32_t uVar1;

  int iVar2;

  int iVar3;

  uint32_t uStack_20;

  uint32_t uStack_1c;

  uint32_t auStack_18 [2];

  

  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {

    timosAssert(0xa8d8658,0xa8d8328,0x1ec,0xa8d8648,0xa8d8318);

    if (_tracepointsActive == 0) goto LAB_063a9d08;

  }

  else if (_tracepointsActive == 0) goto LAB_063a9d08;

  iVar2 = traceTest(_MOD_MDADRV,0xa8d8648,1,0);

  if (iVar2 != 0) {

    tracePrintVRtr(_MOD_MDADRV,0xa8d8648,1,0,1,0xa8d8674,param_1,param_2,param_3);

  }

LAB_063a9d08:

  uVar1 = fpgaSarmGetMemMap(param_3);

  iVar2 = fpgaComnInit(param_1,param_2,param_3,uVar1);

  if (iVar2 == 0) {

    if ((((param_3 - 0x7c < 2 || param_3 == 0x7a) || (param_3 == 0xa5 || param_3 == 0x79)) ||

        (param_3 == 0xac)) || (param_3 == 0xb1 || param_3 == 0xba)) {

      uStack_20 = 0;

      uVar1 = 0;

      if (param_3 == 0x7d) {

        uVar1 = 0x11;

        iVar2 = hwHartlandReadReg32(0,0,&uStack_20);

        if (iVar2 != 0) {

          if (_traceEnabled == 0) {

            if (_tracepointsActive == 0) {

              return -1;

            }

            iVar2 = traceTest(_MOD_MDADRV,0xa8d8648,4,0);

            if (iVar2 == 0) {

              return -1;

            }

          }

          tracePrintVRtr(_MOD_MDADRV,0xa8d8648,4,0,1,0xa8d86f0);

          return -1;

        }

      }

      else if (param_3 < 0x7e) {

        if ((param_3 != 0x7a) && (param_3 != 0x7c)) {

          return 0;

        }

        uVar1 = 10;

        iVar2 = hwWakiGetFpgaVersion(&uStack_20);

        if (iVar2 != 0) {

          if (_traceEnabled == 0) {

            if (_tracepointsActive == 0) {

              return -1;

            }

            iVar2 = traceTest(_MOD_MDADRV,0xa8d8648,4,0);

            if (iVar2 == 0) {

              return -1;

            }

          }

          tracePrintVRtr(_MOD_MDADRV,0xa8d8648,4,0,1,0xa8d871c);

          return -1;

        }

      }

      else if (param_3 != 0xb1) {

        if (param_3 < 0xb2) {

          if (param_3 != 0xac) {

            return 0;

          }

          uVar1 = 3;

          iVar2 = hwPitaGetFpgaVersion(&uStack_20);

          if (iVar2 != 0) {

            if (_traceEnabled == 0) {

              if (_tracepointsActive == 0) {

                return -1;

              }

              iVar2 = traceTest(_MOD_MDADRV,0xa8d8648,4,0);

              if (iVar2 == 0) {

                return -1;

              }

            }

            tracePrintVRtr(_MOD_MDADRV,0xa8d8648,4,0,1,0xa8d86c8);

            return -1;

          }

        }

        else {

          if (param_3 != 0xba) {

            return 0;

          }

          uVar1 = 0x27;

          iVar2 = darnleyGetFpgaVersion(param_1,&uStack_20);

          if (iVar2 != 0) {

            if (_traceEnabled == 0) {

              if (_tracepointsActive == 0) {

                return -1;

              }

              iVar2 = traceTest(_MOD_MDADRV,0xa8d8648,4,0);

              if (iVar2 == 0) {

                return -1;

              }

            }

            tracePrintVRtr(_MOD_MDADRV,0xa8d8648,4,0,1,0xa8d86a0);

            return -1;

          }

        }

      }

      iVar2 = fpgaSarmRevisionCheck(param_1,0,uVar1,uStack_20);

    }

    else if (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12) {

      uStack_1c = 0;

      iVar3 = fpgaSarhcGetClockMonBitsMask(param_1,&uStack_1c);

      if (iVar3 == 0) {

        bspClearClockMonBits(uStack_1c);

      }

    }

    else {

      auStack_18[0] = 0;

      iVar3 = fpgaSarmGetClockMonBitsMask(param_1,auStack_18);

      if (iVar3 == 0) {

        bspClearClockMonBits(auStack_18[0]);

      }

    }

  }

  return iVar2;

}