#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added placeholder typedef for 'code' type
typedef struct {} code;

// Modified: Added extern declarations for undeclared identifiers
extern void *__gxx_personality_sj0;
extern void *__ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern unsigned int uRam0c959618;
extern int iRam0c959614;
extern int iRam0c95960c;
extern int iRam0c95961c;

uint fwksGetZonePolicy(int param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,

                      ushort param_5,byte param_6,uint32_t param_7,ushort param_8)



{
  int iVar1;
  uintptr_t auStack_98 [16];
  uint uStack_88;
  int iStack_84;
  uintptr_t auStack_80 [4];
  uint32_t uStack_7c;
  code *pcStack_68;
  uint32_t uStack_64;
  uintptr_t *puStack_60;
  uint32_t uStack_5c;
  uintptr_t *puStack_58;
  uint uStack_4c;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  int iStack_34;
  int iStack_30;
  uint uStack_2c;
  
  puStack_58 = auStack_98;
  uStack_4c = (uint)param_5;
  uStack_44 = (uint)param_8;
  uStack_48 = (uint)param_6;
  puStack_60 = auStack_80;
  pcStack_68 = __gxx_personality_sj0;
  uStack_5c = 0x40e6c88;
  uStack_64 = 0xbff8584;
  _Unwind_SjLj_Register(puStack_60);
  uStack_40 = 0;
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_7c = 0xffffffff;
      iStack_34 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_34 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_7c = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_34;
    iVar1 = 0;
    if (iStack_34 == 0) goto LAB_040e6b30;
  }
  iVar1 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
LAB_040e6b30:
  if ((iVar1 != 0) && (param_1 != 0)) {
    iStack_84 = iVar1 + 0xb2d458;
    *(uintptr_t *)(iVar1 + 0xb2d46d) = 0xff;
    *(uint32_t *)(iVar1 + 0xb2d4fc) = 0;
    *(uint32_t *)(iVar1 + 0xb2d464) = param_4;
    *(uint32_t *)(iVar1 + 0xb2d460) = param_3;
    *(uintptr_t *)(iVar1 + 0xb2d46c) = 0;
    *(uint32_t *)(iVar1 + 0xb2d468) = 0;
    uStack_88 = uStack_44;
    uStack_7c = 0xffffffff;
    iStack_30 = iStack_84;
    iVar1 = _ZN8Firewall10FwksFilter9getPolicyEtbPctPNS_9AuditableE
                      (iVar1,uStack_4c,uStack_48 != 0,param_7);
    uStack_40 = (uint)(iVar1 == 10);
    _Z13fwksSetEventsRN8Firewall9AuditableER15tFwksEventTablePNS_6PacketE(iStack_30,param_1,0);
  }
  uStack_2c = (uint)(uStack_40 != 0);
  _Unwind_SjLj_Unregister(auStack_80);
  return uStack_2c;
}