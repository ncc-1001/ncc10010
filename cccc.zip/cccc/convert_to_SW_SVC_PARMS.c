#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void convert_to_SW_SVC_PARMS(uint *param_1,uintptr_t *param_2,uint param_3)



{

  byte bVar1;

  byte bVar2;

  uint uVar3;

  uint uVar4;

  uint uVar5;

  uint uVar6;

  uint32_t uVar7;

  uint uVar8;

  uint extraout_v1;

  int extraout_v1_00;

  uint extraout_v1_01;

  uint16_t extraout_v1_09;

  uint extraout_v1_02;

  uint16_t extraout_v1_10;

  uint extraout_v1_03;

  uint extraout_v1_04;

  uint extraout_v1_05;

  uint extraout_v1_06;

  uint extraout_v1_07;

  int extraout_v1_08;

  uint uVar9;

  uint uVar10;

  uint32_t uVar11;

  

  *(uintptr_t *)param_1 = *param_2;

  uVar8 = *param_1;

  uVar9 = (uint)((byte)param_2[1] >> 7) << 0x17;

  *param_1 = uVar8 & 0xff7fffff | uVar9;

  uVar10 = ((byte)param_2[1] >> 6 & 1) << 0x16;

  *param_1 = uVar8 & 0xff3fffff | uVar9 | uVar10;

  uVar3 = ((byte)param_2[1] & 0x20) << 10;

  *param_1 = uVar8 & 0xff3f7fff | uVar9 | uVar10 | uVar3;

  uVar4 = ((byte)param_2[1] & 0x10) << 10;

  *param_1 = uVar8 & 0xff3f3fff | uVar9 | uVar10 | uVar3 | uVar4;

  uVar5 = ((byte)param_2[1] & 8) << 4;

  *param_1 = uVar8 & 0xff3f3f7f | uVar9 | uVar10 | uVar3 | uVar4 | uVar5;

  uVar6 = ((byte)param_2[1] & 6) << 4;

  *param_1 = uVar8 & 0xff3f3f1f | uVar9 | uVar10 | uVar3 | uVar4 | uVar5 | uVar6;

  *param_1 = uVar8 & 0xff3f3f0f | uVar9 | uVar10 | uVar3 | uVar4 | uVar5 | uVar6 |

             ((byte)param_2[1] & 1) << 4;

  uVar4 = param_1[1];

  uVar3 = (uint)((byte)param_2[2] >> 7) << 0x1f;

  param_1[1] = uVar4 & 0x7fffffff | uVar3;

  param_1[1] = uVar4 & 0x7fff7fff | uVar3 | ((byte)param_2[2] & 0x40) << 9;

  extract_bits(param_2,0x12,0xe);

  param_1[1] = param_1[1] & 0xffff8001 | (extraout_v1 & 0x3fff) << 1;

  uVar3 = param_3 & 3;

  param_1[8] = param_1[8] & 0x7fffffff | (uint)((byte)param_2[0x10] >> 3) << 0x1f;

  if (uVar3 == 0) {

    if ((*param_1 & 0x8000) == 0) {

      uVar3 = param_3 & 3 | 2;

    }

    else {

      uVar3 = param_3 & 3 | 1;

    }

  }

  if (uVar3 == 1) {

    uVar4 = param_1[2];

    uVar3 = (uint)((byte)param_2[4] >> 7) << 0x1f;

    param_1[2] = uVar4 & 0x7fffffff | uVar3;

    param_1[2] = uVar4 & 0x3fffffff | uVar3 | ((byte)param_2[4] >> 6 & 1) << 0x1e;

    uVar4 = param_1[6];

    uVar3 = ((byte)param_2[0xc] & 0x20) << 10;

    param_1[6] = uVar4 & 0xffff7fff | uVar3;

    param_1[6] = uVar4 & 0xffff3fff | uVar3 | ((byte)param_2[0xc] & 0x10) << 10;

    extract_bits(param_2,0x66,0x14);

    param_1[7] = param_1[7] & 0xfff | extraout_v1_00 << 0xc;

    param_1[2] = param_1[2] & 0xffff3fff | ((byte)param_2[4] & 0xc) << 0xc;

    param_1[3] = param_1[3] & 0x3fffffff | (uint)(byte)param_2[4] << 0x1e;

    extract_bits(param_2,0x28,0xf);

    param_1[3] = param_1[3] & 0xffff0001 | (extraout_v1_01 & 0x7fff) << 1;

    uVar5 = param_1[4];

    uVar3 = (uint)(byte)param_2[6] << 0x1f;

    param_1[4] = uVar5 & 0x7fffffff | uVar3;

    uVar4 = (uint)((byte)param_2[7] >> 7) << 0x1e;

    param_1[4] = uVar5 & 0x3fffffff | uVar3 | uVar4;

    param_1[4] = uVar5 & 0x1fffffff | uVar3 | uVar4 | ((byte)param_2[7] >> 6 & 1) << 0x1d;

    extract_bits(param_2,0x3a,0x10);

    *(uint16_t *)((int)param_1 + 0x12) = extraout_v1_09;

    param_1[5] = param_1[5] & 0x3fffffff | (uint)((byte)param_2[9] >> 4) << 0x1e;

    extract_bits(param_2,0x4c,5);

    uVar5 = param_1[5];

    uVar3 = (extraout_v1_02 & 0x1f) << 0x19;

    param_1[5] = uVar5 & 0xc1ffffff | uVar3;

    bVar1 = param_2[10];

    uVar4 = param_3 & 0xc;

    param_1[5] = uVar5 & 0xc1ff7fff | uVar3 | (bVar1 & 0x40) << 9;

    if (uVar4 == 0) {

      if ((bVar1 & 0x40) == 0) {

        uVar4 = param_3 & 0xc | 8;

      }

      else {

        uVar4 = param_3 & 0xc | 4;

      }

    }

    if (uVar4 == 4) {

      extract_bits(param_2,0x52,0x10);

      *(uint16_t *)(param_1 + 6) = extraout_v1_10;

      goto LAB_02c88458;

    }

    uVar11 = 0xba3c;

    if (uVar4 == 8) {

      param_1[6] = param_1[6] & 0x7fffffff | (uint)((byte)param_2[10] >> 5) << 0x1f;

      extract_bits(param_2,0x53,0xf);

      param_1[6] = param_1[6] & 0x8000ffff | (extraout_v1_03 & 0x7fff) << 0x10;

      goto LAB_02c88458;

    }

    uVar7 = 0x9c7b014;

  }

  else {

    uVar11 = 0xba74;

    if (uVar3 == 2) {

      convert_to_LAG_DEST_PORT_AND_IDX(param_1 + 2,param_2 + 4,0);

      uVar3 = param_3 & 0xc;

      if (uVar3 == 0) {

        if ((*param_1 & 0x4000) == 0) {

          uVar3 = param_3 & 0xc | 8;

        }

        else {

          uVar3 = param_3 & 0xc | 4;

        }

      }

      if (uVar3 == 4) {

        *(ushort *)((int)param_1 + 10) = (ushort)(byte)param_2[6] * 0x100 + (ushort)(byte)param_2[7]

        ;

        convert_to_L2TP_TUNNEL_AND_SESSION(param_1 + 3,param_2 + 8,0);

        param_1[4] = param_1[4] & 0x3fffffff | (uint)((byte)param_2[0xc] >> 6) << 0x1e;

        extract_bits(param_2,0x62,0xc);

        param_1[4] = param_1[4] & 0xc003ffff | (extraout_v1_04 & 0xfff) << 0x12;

        extract_bits(param_2,0x6e,3);

        uVar5 = param_1[4];

        uVar4 = (extraout_v1_05 & 7) << 0xd;

        param_1[4] = uVar5 & 0xffff1fff | uVar4;

        uVar3 = ((byte)param_2[0xe] & 0x40) << 6;

        param_1[4] = uVar5 & 0xffff0fff | uVar4 | uVar3;

        param_1[4] = uVar5 & 0xffff0f7f | uVar4 | uVar3 | ((byte)param_2[0xe] & 0x20) << 2;

        goto LAB_02c88458;

      }

      if (uVar3 == 8) {

        param_1[2] = param_1[2] & 0xffff7fff | (uint)((byte)param_2[6] >> 7) << 0xf;

        extract_bits(param_2,0x31,0xf);

        param_1[2] = param_1[2] & 0xffff8000 | extraout_v1_06 & 0x7fff;

        convert_to_IP_ADDRESS((uintptr_t *)((int)param_1 + 0x12),param_2 + 0xc,0);

        bVar1 = param_2[0x10];

        uVar5 = param_1[5];

        uVar3 = (uint)(bVar1 >> 7) << 0xf;

        param_1[5] = uVar5 & 0xffff7fff | uVar3;

        uVar4 = ((byte)param_2[0x10] & 0x40) << 8;

        param_1[5] = uVar5 & 0xffff3fff | uVar3 | uVar4;

        bVar2 = param_2[0x10];

        uVar6 = param_3 & 0x30;

        param_1[5] = uVar5 & 0xffff1fff | uVar3 | uVar4 | (bVar2 & 0x20) << 8;

        if (uVar6 == 0) {

          if ((bVar2 & 0x20) == 0) {

            if (bVar1 >> 7 == 0) {

              param_3 = param_3 | 0x30;

            }

            else {

              param_3 = param_3 | 0x20;

            }

          }

          else {

            param_3 = param_3 | 0x10;

          }

          uVar6 = param_3 & 0x30;

        }

        if (uVar6 == 0x20) {

          convert_to_IP_ADDRESS(param_1 + 3,param_2 + 8,0);

          goto LAB_02c88458;

        }

        if (uVar6 < 0x21) {

          if (uVar6 == 0x10) {

            *(ushort *)(param_1 + 3) = (ushort)(byte)param_2[8] * 0x100 + (ushort)(byte)param_2[9];

            goto LAB_02c88458;

          }

        }

        else if (uVar6 == 0x30) {

          param_1[3] = param_1[3] & 0x7fffffff | (uint)((byte)param_2[8] >> 7) << 0x1f;

          extract_bits(param_2,0x41,0xf);

          param_1[3] = param_1[3] & 0xffff0001 | (extraout_v1_07 & 0x7fff) << 1;

          extract_bits(param_2,0x50,0xf);

          param_1[4] = param_1[4] & 0x1ffff | extraout_v1_08 << 0x11;

          goto LAB_02c88458;

        }

        uVar7 = 0x9c7b088;

        uVar11 = 0xba6c;

      }

      else {

        uVar7 = 0x9c7b058;

        uVar11 = 0xba70;

      }

    }

    else {

      uVar7 = 0x9c7a570;

    }

  }

  timosAssert(0x9c74c64,0x9c748e4,uVar11,0x9c7afd0,uVar7);

LAB_02c88458:

  uVar3 = param_3 & 0xc0;

  if (uVar3 == 0) {

    uVar3 = param_3 & 0xc0 | 0x40;

  }

  if (uVar3 == 0x40) {

    bVar1 = param_2[0x10];

    uVar5 = param_1[8];

    uVar3 = (bVar1 >> 2 & 1) << 0x17;

    uVar4 = param_3 & 0x300;

    param_1[8] = uVar5 & 0xff7fffff | uVar3;

    if (uVar4 == 0) {

      if ((bVar1 >> 2 & 1) == 0) {

        uVar4 = param_3 & 0x300 | 0x100;

      }

      else {

        uVar4 = param_3 & 0x300 | 0x200;

      }

    }

    if (uVar4 == 0x100) {

      param_1[8] = uVar5 & 0xff7f3fff | uVar3 | ((byte)param_2[0x10] & 3) << 0xe;

      convert_to_SW_SVC_VLL_CW_BITS((uintptr_t *)((int)param_1 + 0x23),param_2 + 0x11,0);

      return;

    }

    uVar11 = 0xba90;

    if (uVar4 == 0x200) {

      uVar4 = ((byte)param_2[0x10] & 3) << 0xe;

      param_1[8] = uVar5 & 0xff7f3fff | uVar3 | uVar4;

      bVar1 = param_2[0x11];

      param_1[8] = uVar5 & 0xff7f3f01 | uVar3 | uVar4 | bVar1 & 0xfe;

      param_1[8] = uVar5 & 0xff7f3f00 | uVar3 | uVar4 | bVar1 & 0xfe | (byte)param_2[0x11] & 1;

      return;

    }

    uVar7 = 0x9c7afe8;

  }

  else {

    uVar11 = 0xba97;

    if (uVar3 == 0x80) {

      param_1[8] = param_1[8] & 0xff1fffff | ((byte)param_2[0x10] & 7) << 0x15;

      return;

    }

    uVar7 = 0x9c7a570;

  }

  timosAssert(0x9c74c64,0x9c748e4,uVar11,0x9c7afd0,uVar7);

  return;

}



