#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendAdjRestartStatusChangeTrap

               (uint32_t *param_1,int param_2,uint32_t param_3,int param_4,uint32_t param_5)



{

  uint32_t uVar1;

  

  uVar1 = *param_1;

  logEvent_ISIS_vRtrIsisAdjRestartStatusChange

            (uVar1,0xa1bbc48,uVar1,param_3,uVar1,*(uint32_t *)(param_2 + 8),

             *(uint32_t *)(param_2 + 8),**(uint32_t **)(param_4 + 0x6c),param_5);

  return;

}



