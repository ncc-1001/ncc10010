#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisRtmUnRegister(uint32_t *param_1,uint32_t param_2,uint32_t param_3)



{

  int iVar1;

  uint32_t auStackX_8 [2];

  

  auStackX_8[0] = param_3;

  isisTedUnRegister();

  iVar1 = RTM_UnregisterRouteOwner(param_2,0xc,0);

  if ((((iVar1 != 0) && (param_1 != (uint32_t *)0x0)) && ((param_1[0x1b] & 4) != 0)) &&

     (iVar1 = isisDebugCheck(param_1,4,0,0), iVar1 != 0)) {

    if (_IsisLogger == 0) {

      tracePrint(_MOD_ISIS,0xa1af2b8,0,0,0xa1af2cc);

    }

    else {

      logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af2cc);

    }

  }

  iVar1 = RTM_UnregisterUser(param_2,auStackX_8);

  if (((iVar1 != 0) && (param_1 != (uint32_t *)0x0)) &&

     (((param_1[0x1b] & 4) != 0 && (iVar1 = isisDebugCheck(param_1,4,0,0), iVar1 != 0)))) {

    if (_IsisLogger == 0) {

      tracePrint(_MOD_ISIS,0xa1af2b8,0,0,0xa1af2e8);

    }

    else {

      logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af2e8);

    }

  }

  iVar1 = RTM_RemoveRoutingProtocol(param_2,param_1);

  if (((iVar1 != 0) && (param_1 != (uint32_t *)0x0)) &&

     (((param_1[0x1b] & 4) != 0 && (iVar1 = isisDebugCheck(param_1,4,0,0), iVar1 != 0)))) {

    if (_IsisLogger == 0) {

      tracePrint(_MOD_ISIS,0xa1af2b8,0,0,0xa1af300);

    }

    else {

      logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af300);

    }

  }

  return;

}



