#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t csaEthPtpSetPeerCfg(uint param_1,ushort param_2,int param_3)



{

  int iVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint uVar5;

  int iVar6;

  uint uVar7;

  int iVar8;

  int iVar9;

  

  uVar7 = (uint)param_2;

  iVar1 = macMdaRemoved();

  if (iVar1 != 0) {

    return 0;

  }

  if (9 < uVar7 - 1) {

    return 0xffffffff;

  }

  if ((param_1 != 0) && (param_1 <= *_gMdaInfo)) {

    iVar1 = param_1 * 0x3a88;

    if ((*(char *)(iVar1 + 0x10d260a8) != '\0') &&

       (((char *)(iVar1 + 0x10d260a8) != (char *)0x0 && (iVar8 = iVar1 + 0x10d260c0, iVar8 != 0))))

    {

      iVar2 = uVar7 * 0x5c8 + iVar8;

      iVar9 = iVar2 + -0x578;

      if (iVar9 != 0) {

        iVar6 = *(int *)(param_3 + 0x14);

        if (iVar6 == *(int *)(iVar2 + -0x564)) {

          uVar4 = 0;

        }

        else {

          if (_tracepointsActive != 0) {

            iVar6 = traceTest(_MOD_MDADRV,0xa8c52a0,1,0);

            if (iVar6 == 0) {

              iVar6 = *(int *)(param_3 + 0x14);

            }

            else {

              uVar4 = FmtPtpPeerStateType(*(uint32_t *)(iVar2 + -0x564));

              uVar3 = FmtPtpPeerStateType(*(uint32_t *)(param_3 + 0x14));

              tracePrintVRtr(_MOD_MDADRV,0xa8c52a0,1,0,1,0xa8c52b4,param_1,uVar7,uVar4,uVar3);

              iVar6 = *(int *)(param_3 + 0x14);

            }

          }

          if (iVar6 == 1) {

            uVar5 = (uint)*(ushort *)(iVar1 + 0x10d2610c);

            if (uVar5 != 0) {

              if (_tracepointsActive != 0) {

                iVar2 = traceTest(_MOD_MDADRV,0xa8c52a0,1,0);

                uVar5 = (uint)*(ushort *)(iVar1 + 0x10d2610c);

                if (iVar2 != 0) {

                  tracePrintVRtr(_MOD_MDADRV,0xa8c52a0,1,0,1,0xa8c52d8,param_1,uVar5,uVar7);

                  uVar5 = (uint)*(ushort *)(iVar1 + 0x10d2610c);

                }

              }

              iVar2 = uVar5 * 0x5c8 + iVar8;

              _csaEthPtpPeerInit(param_1,iVar2 + -0x578);

              *(uint32_t *)(iVar2 + -0x564) = 0;

              iVar9 = uVar7 * 0x5c8 + iVar8 + -0x578;

            }

            uVar4 = _csaEthPtpPeerCfgSlave(param_1,uVar7,param_3);

            *(ushort *)(iVar1 + 0x10d2610c) = param_2;

            *(uint32_t *)(iVar9 + 0x14) = *(uint32_t *)(param_3 + 0x14);

            return uVar4;

          }

          if (iVar6 == 0) {

            if ((*(ushort *)(iVar1 + 0x10d2610c) == uVar7) &&

               (*(char *)(iVar1 + 0x10d29b28) != '\0')) {

              fpgaUBlazeSetTodBias

                        (param_1,*(uint32_t *)(iVar1 + 0x10d29b20),

                         *(uint32_t *)(iVar1 + 0x10d29b24));

              uVar4 = _csaEthPtpPeerInit(param_1,iVar9);

            }

            else {

              uVar4 = _csaEthPtpPeerInit(param_1,iVar9);

            }

          }

          else {

            if (iVar6 != 2) {

              if (_traceEnabled == 0) {

                if (_tracepointsActive == 0) {

                  return 0xffffffff;

                }

                iVar1 = traceTest(_MOD_MDADRV,0xa8c52a0,4,0);

                if (iVar1 == 0) {

                  return 0xffffffff;

                }

                iVar6 = *(int *)(param_3 + 0x14);

              }

              tracePrintVRtr(_MOD_MDADRV,0xa8c52a0,4,0,1,0xa8c5304,param_1,uVar7,iVar6);

              return 0xffffffff;

            }

            if ((*(short *)(iVar1 + 0x10d2610c) == 0) && (*(char *)(iVar1 + 0x10d29b28) != '\0')) {

              fpgaUBlazeSetTodBias

                        (param_1,*(uint32_t *)(iVar1 + 0x10d29b20),

                         *(uint32_t *)(iVar1 + 0x10d29b24));

              uVar4 = _csaEthPtpPeerCfgMaster(param_1,uVar7,param_3);

            }

            else {

              uVar4 = _csaEthPtpPeerCfgMaster(param_1,uVar7,param_3);

            }

          }

          *(uint32_t *)(iVar2 + -0x564) = *(uint32_t *)(param_3 + 0x14);

        }

        return uVar4;

      }

    }

  }

  if ((_traceEnabled != 0) ||

     ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8c52a0,4,0), iVar1 != 0)))) {

    tracePrintVRtr(_MOD_MDADRV,0xa8c52a0,4,0,1,0xa8c4e38,param_1,uVar7);

  }

  return 0xffffffff;

}



