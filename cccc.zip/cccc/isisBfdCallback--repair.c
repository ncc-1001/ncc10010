#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared global variables
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;
extern int _traceEnabled;
extern int _tracepointsActive;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void isisBfdCallback(uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,
                    int param_5)
{
  int iVar1;
  uint uVar2;
  uintptr_t auStack_120 [128];
  uintptr_t auStack_a0 [128];
  uint32_t *apuStack_20 [2];
  
  if (param_5 != 0) {
    iVar1 = isisGetNode(param_1,apuStack_20);
    if (iVar1 == 0) {
      iVar1 = isisSendBfdMsg(apuStack_20[0],param_2,param_3,param_4,param_5);
      if ((((iVar1 != 0) && (apuStack_20[0] != (uint32_t *)0x0)) &&
          ((apuStack_20[0][0x1b] & 2) != 0)) &&
         (iVar1 = isisDebugCheck(apuStack_20[0],2,0,0), iVar1 != 0)) {
        if (_IsisLogger == 0) {
          uVar2 = getIpAddrType(param_3);
          if (uVar2 < 2) {
            formatIpAnyAddr(param_3,auStack_120,0x80);
          }
          else {
            snprintf(auStack_120,0x80,0xa1a7c90,0xa1a7c94);
          }
          uVar2 = getIpAddrType(param_4);
          if (uVar2 < 2) {
            formatIpAnyAddr(param_4,auStack_a0,0x80);
          }
          else {
            snprintf(auStack_a0,0x80,0xa1a7c90,0xa1a7c94);
          }
          tracePrint(_MOD_ISIS,0xa1a7c5c,0,0,0xa1a7ca0,param_1,param_2,auStack_120,auStack_a0);
        }
        else {
          uVar2 = getIpAddrType(param_3);
          if (uVar2 < 2) {
            formatIpAnyAddr(param_3,auStack_120,0x80);
          }
          else {
            snprintf(auStack_120,0x80,0xa1a7c90,0xa1a7c94);
          }
          uVar2 = getIpAddrType(param_4);
          if (uVar2 < 2) {
            formatIpAnyAddr(param_4,auStack_a0,0x80);
          }
          else {
            snprintf(auStack_a0,0x80,0xa1a7c90,0xa1a7c94);
          }
          logEvent_debug_fmt(*apuStack_20[0],0xa1a77f8,&isisTitleStr,0xa1a7ca0,param_1,param_2,
                             auStack_120,auStack_a0);
        }
      }
    }
    // Modified: Fixed unmatched parentheses in the else if condition
    else if ((_traceEnabled != 0) ||
            ((_tracepointsActive != 0) && (iVar1 = traceTest(_MOD_ISIS,0xa1a7c5c,4,0x1a), iVar1 != 0))) {
      tracePrintVRtr(_MOD_ISIS,0xa1a7c5c,4,0x1a,1,0xa1a7c6c,param_1);
    }
  }
  return;
}