#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _traceEnabled;

uint fpgaGetLedAddress(int param_1,int param_2)
{
  int iVar1;
  int iVar2;
  uint *puVar3;
  uint uVar4;
  
  iVar1 = fpgaIsValidMda();
  if (iVar1 == 0) {
    if (_tracepointsActive == 0) {
      return 0;
    }
    iVar1 = traceTest(_MOD_MDADRV,0xa8ca140,1,0);
    if (iVar1 == 0) {
      return 0;
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8ca140,1,0,1,0xa8ca154,param_1);
  }
  else {
    iVar1 = pfHwMdaToSwMdaType(*(uint32_t *)(param_1 * 0x26b0 + 0xcc255f8),0);
    puVar3 = *(uint **)((iVar1 - 1U & 0xff) * 4 + 0xbbf9b84);
    uVar4 = *puVar3 | puVar3[param_2 * 7 + 1];
    if ((uVar4 != 0) ||
       ((_traceEnabled == 0 &&
        ((_tracepointsActive == 0 || (iVar2 = traceTest(_MOD_MDADRV,0xa8ca140,4,0), iVar2 == 0))))))
    {
      return uVar4;
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8ca140,4,0,1,0xa8ca16c,param_2,iVar1);
  }
  return 0;
}