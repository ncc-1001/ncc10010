#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


void handleScadaPortChangedEvents(int param_1)


{

  int iVar1;

  uint32_t uVar2;

  int aiStack_178 [92];
  
  if ((*(char *)(param_1 + 0x1a9) != '\0') &&
     ((aiStack_178[0] = *(int *)(param_1 + 0xc78), *(char *)(param_1 + 0x1ac) != '\0' ||
      (aiStack_178[0] != *(int *)(param_1 + 0xc7c))))) {
    if ((_tracepointsActive != 0) && (iVar1 = traceTest(_MOD_MDADRV,0xa964dc0,1,0), iVar1 != 0)) {
      uVar2 = 0xa964dfc;
      if (aiStack_178[0] == 3) {
        iVar1 = *(int *)(param_1 + 4);
      }
      else {
        uVar2 = 0xa964e00;
        if (aiStack_178[0] == 2) {
          iVar1 = *(int *)(param_1 + 4);
        }
        else {
          uVar2 = 0xa964e08;
          if (aiStack_178[0] != 1) {
            uVar2 = 0xa964e14;
          }
          iVar1 = *(int *)(param_1 + 4);
        }
      }
      tracePrintVRtr(_MOD_MDADRV,0xa964dc0,1,0,1,0xa964de0,uVar2,*(uint32_t *)(iVar1 + 0x36ca24),
                     *(int *)(param_1 + 0xcb8) + 1);
    }
    posPortEventFn(param_1,0,0,1,aiStack_178,1);
  }
  return;
}