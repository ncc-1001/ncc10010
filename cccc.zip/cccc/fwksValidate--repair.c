#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Adjusted typedef for 'code' to match expected signature
typedef void (*code)(void*, int);

// Modified: Changed pcRam0a17dc10 to function pointer type
extern void* (*pcRam0a17dc10)(void*, uint32_t);

// Modified: Added extern declarations for undeclared identifiers
extern void *__gxx_personality_sj0;
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern uint __ZN8Firewall10FwksFilter8m_uLimitE;
extern uint __ZN8Firewall10FwksFilter6m_uNewE;
extern uint __ZN8Firewall10FwksFilter9m_uDeleteE;
extern uint uRam0c9594cc;
extern uint uRam0c9594c4;
extern uint uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern uint uRam0c959618;
extern int iRam0c95961c;

uint fwksValidate(uintptr_t *param_1,int param_2,uint param_3,uint param_4)
{
  int *piVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint32_t uVar5;
  uintptr_t auStack_90 [16];
  uint32_t uStack_80;
  uintptr_t *puStack_7c;
  uint16_t uStack_78;
  uint16_t uStack_76;
  uintptr_t auStack_70 [4];
  uint32_t uStack_6c;
  code *pcStack_58;
  uint32_t uStack_54;
  uint32_t *puStack_50;
  uint32_t uStack_4c;
  uintptr_t *puStack_48;
  int iStack_3c;
  int iStack_30;
  uint uStack_2c;

  puStack_48 = auStack_90;
  pcStack_58 = __gxx_personality_sj0;
  uStack_54 = 0xbff8646;
  puStack_50 = &uStack_80;
  uStack_4c = 0x40ecbcc;
  _Unwind_SjLj_Register(auStack_70);
  iStack_3c = 0;
  if (param_1 == (uintptr_t *)0x0 || param_2 == 0) goto LAB_040ecaf0;
  uStack_80 = 0xa17dc08;
  uStack_78 = (uint16_t)param_2;
  uStack_76 = 0;
  if (param_1 != (uintptr_t *)0x0) {
    *param_1 = 0;
  }
  puStack_7c = param_1;
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_6c = 0xffffffff;
      iStack_30 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_30 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_6c = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_30;
    iVar2 = 0;
    if (iStack_30 != 0) goto LAB_040eca20;
  }
  else {
LAB_040eca20:
    iVar2 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
  }
  if (iVar2 != 0) {
    uVar4 = 0;
    if (*(uint *)(iVar2 + 0x58) != 0) {
      iVar3 = iVar2 + 0x5c;
      do {
        iStack_3c = 0;
        if (*(ushort *)(iVar3 + 0xc) != uVar4) goto LAB_040ecaac;
        if ((*(uint *)(iVar3 + 0x28c) >> 0xc & 1) != 0) {
          iStack_3c = 0;
          if (*(uint *)(iVar3 + 0x240) < param_3) goto LAB_040ecaac;
          if ((*(uint *)(iVar3 + 0x240) == param_3) && (*(uint *)(iVar3 + 0x244) < param_4)) {
            iStack_3c = 0;
            goto LAB_040ecaac;
          }
        }
        uVar4 = uVar4 + 1;
        iVar3 = iVar3 + 0x3d0;
      } while (uVar4 < *(uint *)(iVar2 + 0x58));
    }
    iStack_3c = 1;
LAB_040ecaac:
    if (iStack_3c == 0) {
      uVar5 = 0xa17db80;
    }
    else {
      uVar5 = 0xa17db68;
    }
    uStack_6c = 0xffffffff;
    piVar1 = (int *)(*pcRam0a17dc10)(&uStack_80,uVar5);
    (**(code **)(*piVar1 + 4))(piVar1,0xff);
  }
LAB_040ecaf0:
  uStack_2c = (uint)(iStack_3c != 0);
  _Unwind_SjLj_Unregister(auStack_70);
  return uStack_2c;
}