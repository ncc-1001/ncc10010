#include "nokia.h"
#include <stdint.h>

extern byte cRam10c8f925; // Modified: Added extern declaration for undeclared variable

void hwWakiDumpEbimcConfig(void)
{
  int iVar1;
  uintptr_t auStack_10 [8];

  if ((5 < (byte)(cRam10c8f925 + 0x1eU)) &&
     (iVar1 = hwWakiReadReg32(0,0x11c,auStack_10), iVar1 == 0)) {
                    /* WARNING: Subroutine does not return */
    printf(0xa7b03b8);
  }
  return;
}