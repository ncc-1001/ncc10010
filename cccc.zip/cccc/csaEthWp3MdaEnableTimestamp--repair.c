#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int *_gMdaInfo;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

void csaEthWp3MdaEnableTimestamp(uint param_1)
{
  char *pcVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  uint auStackX_0 [4];
  int aiStack_18 [2];
  
  auStackX_0[0] = param_1;
  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
    timosAssert(0xa8c399c,0xa8c3970,0xf62,0xa8c49d8,0xa8c3960);
  }
  iVar3 = *(int *)(auStackX_0[0] * 4 + 0xccb630c);
  if (iVar3 == 0) {
    timosAssert(0xa8c39e8,0xa8c3970,0xf62,0xa8c49d8,0xa8c3960);
  }
  pcVar4 = (char *)0x0;
  if ((((auStackX_0[0] == 0) || (*_gMdaInfo < auStackX_0[0])) ||
      (pcVar1 = (char *)(auStackX_0[0] * 0x3a88 + 0x10d260a8), *pcVar1 == '\0')) ||
     (pcVar4 = pcVar1, pcVar1 == (char *)0x0)) {
    pcVar1 = pcVar4;
    timosAssert(0xa8c3964,0xa8c3970,0xf63,0xa8c49d8,0xa8c3960);
  }
  if (pcVar1[0x3a75] == '\0') {
    iVar2 = MdaSupportsTimeHwWrite(*(uint32_t *)(iVar3 + 0x10c));
    if (iVar2 != 0) {
LAB_0635d208:
      pcVar1[0x3a75] = '\x01';
      return;
    }
    iVar3 = MdaSupportsTimeHwAssist(*(uint32_t *)(iVar3 + 0x10c));
    if (iVar3 != 0) {
      winpathTimestampUnitSet(auStackX_0,1,0,aiStack_18);
      if (aiStack_18[0] == 0) goto LAB_0635d208;
      iVar3 = macMdaRemoved(auStackX_0[0]);
      if ((iVar3 == 0) &&
         ((_traceEnabled != 0 ||
          ((_tracepointsActive != 0 && (iVar3 = traceTest(_MOD_MDADRV,0xa8c49d8,4,0), iVar3 != 0))))
         )) {
        tracePrintVRtr(_MOD_MDADRV,0xa8c49d8,4,0,1,0xa8c49f4,auStackX_0[0],1);
      }
    }
  }
  return;
}