#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int _tracepointsActive;
extern int _MOD_ISIS;
extern char isisPolChangePrefixEcmpChange;
extern uint32_t uRam0b7620c4;
extern uint32_t uRam0b7620c0;
extern uint32_t uRam0b7620b8;
extern uint32_t uRam0b7620bc;
extern int _IsisLogger;
extern char* isisTitleStr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t isisRtmEcmpChange(uint32_t *param_1)

{

  bool bVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  char *pcVar4;

  int iVar5;

  uint32_t uVar6;

  

  param_1 = (uint32_t *)*param_1;

  uVar3 = isisGetTDRtmMsgList();

  if (param_1 == (uint32_t *)0x0) {

    if (_tracepointsActive == 0) {

      uVar6 = 3;

    }

    else {

      iVar5 = traceTest(_MOD_ISIS,0xa1af174,1,0x1a);

      if (iVar5 == 0) {

        uVar6 = 3;

      }

      else {

        tracePrintVRtr(_MOD_ISIS,0xa1af174,1,0x1a,1,0xa1aeec4);

        uVar6 = 3;

      }

    }

  }

  else {

    uVar6 = 0;

    if (param_1[3] != 0) {

      pcVar4 = (char *)dlistAllocateNodeExt(uVar3,0x44,1);

      if (pcVar4 != (char *)0x0) {

        bVar1 = isisPolChangePrefixEcmpChange == '\0';

        *pcVar4 = isisPolChangePrefixEcmpChange;

        uVar2 = uRam0b7620c4;

        uVar6 = uRam0b7620c0;

        uVar3 = uRam0b7620b8;

        if (bVar1) {

          *(uint32_t *)(pcVar4 + 8) = uRam0b7620bc;

          *(uint32_t *)(pcVar4 + 0xc) = uVar6;

          *(uint32_t *)(pcVar4 + 4) = uVar3;

          *(uint32_t *)(pcVar4 + 0x10) = uVar2;

        }

        else {

          *(uint32_t *)(pcVar4 + 4) = uRam0b7620b8;

        }

        uVar3 = isisGetTDRtmMsgListSem();

                    /* WARNING: Subroutine does not return */

        semTake(uVar3,0xffffffff);

      }

      if (((param_1[0x1b] & 0x800) == 0) || (iVar5 = isisDebugCheck(param_1,0x800,0,0), iVar5 == 0))

      {

        isisHandleMemFail(param_1);

        uVar6 = 3;

      }

      else if (_IsisLogger == 0) {

        tracePrint(_MOD_ISIS,0xa1af174,0,0,0xa1af1ac);

        isisHandleMemFail(param_1);

        uVar6 = 3;

      }

      else {

        logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af1ac);

        isisHandleMemFail(param_1);

        uVar6 = 3;

      }

    }

  }

  return uVar6;

}