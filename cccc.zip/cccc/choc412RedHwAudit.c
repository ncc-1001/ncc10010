#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t choc412RedHwAudit(void)



{

  csaOcnUtilsRedHwAudit();

  return 0;

}



