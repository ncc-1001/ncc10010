#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern uint32_t uRam0c95b308;
extern uint32_t uRam0c95b304;
extern void* uRam0c95b30c;
extern int _gIsisHoldTimerPendingExpired;
extern int _tracepointsActive;
extern int _MOD_ISIS;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


void isisPendingHoldTimerExp(uint32_t *param_1)

{

  int iVar1;

  int iVar2;

  uint32_t *puVar3;
  

  uRam0c95b308 = param_1[1];

  uRam0c95b304 = *param_1;

  while ((iVar1 = dlistGetFirst(uRam0c95b30c), iVar1 != 0 &&

         (iVar2 = tvdiff(0xc95b304,iVar1), -1 < iVar2))) {

    iVar2 = *(int *)(iVar1 + 8);

    if (*(char *)(iVar2 + 0x70) == '\x01') {

      *(uintptr_t *)(iVar2 + 0x70) = 0;

    }

    else {

      timosAssert(0xa1a7284,0xa1a688c,0xe5b,0xa1a726c,0xa1a68e8);

      *(uintptr_t *)(iVar2 + 0x70) = 0;

    }

    dlist_delete(uRam0c95b30c,iVar1,0,0xa1a688c,0xe5e);

    _gIsisHoldTimerPendingExpired = _gIsisHoldTimerPendingExpired + 1;

    if ((_tracepointsActive == 0) || (iVar1 = traceTest(_MOD_ISIS,0xa1a726c,1,0x1a), iVar1 == 0)) {

      puVar3 = *(uint32_t **)(iVar2 + 0x68);

    }

    else {

      tracePrintVRtr(_MOD_ISIS,0xa1a726c,1,0x1a,1,0xa1a72a0,

                     *(uint32_t *)(*(int *)(iVar2 + 0x68) + 8));

      puVar3 = *(uint32_t **)(iVar2 + 0x68);

    }

    isisHoldTimerExp(*(uint32_t *)*puVar3,iVar2,0);

  }

  return;

}