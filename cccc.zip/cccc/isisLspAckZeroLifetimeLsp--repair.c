#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern uint32_t uRam0d92c388;
extern uint32_t isisLspEventSeqNum;
extern uint32_t _IsisLogger;
extern uint32_t _MOD_ISIS;
extern char isisTitleStr[];

void isisLspAckZeroLifetimeLsp(uint32_t *param_1,int param_2,int param_3,uint32_t param_4)
{
  ushort uVar1;
  int iVar2;
  int iVar3;
  uint32_t uVar4;
  int iVar5;
  
  if ((*(int *)(param_3 + 0x2f4) != 2) && (iVar2 = fsmem_calloc(uRam0d92c388,1,0x160), iVar2 != 0))
  {
    iVar5 = iVar2 + 4;
    memcpy(iVar5,param_2 + 0xc,8);
    uVar1 = *(ushort *)(iVar2 + 0xc);
    *(uint32_t *)(iVar2 + 0x24) = param_4;
    if ((uVar1 & 0x20) == 0) {
      isisLspUpdateHistory(param_1,iVar2,5,&isisLspEventSeqNum,0,0x1fd);
      uVar1 = *(ushort *)(iVar2 + 0xc);
    }
    *(ushort *)(iVar2 + 0xc) = uVar1 | 0x20;
    if ((param_3 == 0) || ((uVar1 & 4) != 0)) {
      *(uint32_t *)(iVar2 + 0x15c) = 0;
    }
    else {
      *(uint32_t *)(iVar2 + 0x15c) = *(uint32_t *)(param_3 + 8);
    }
    if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x200) != 0)) &&
       (iVar3 = isisDebugCheck(param_1,0x200,iVar2,0), iVar3 != 0)) {
      if (_IsisLogger == 0) {
        uVar4 = isisDumpLspId(iVar5,param_1 + 0x6a1,0x400,0);
        tracePrint(_MOD_ISIS,0xa1aad64,0,0,0xa1aad80,uVar4);
      }
      else {
        uVar4 = isisDumpLspId(iVar5,param_1 + 0x6a1,0x400,0);
        logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1aad80,uVar4);
      }
    }
    iVar5 = isisLspAddPDU(param_1,iVar2,param_2);
    if (iVar5 == 0) {
      iVar5 = redAmIActive(0x34);
      if (iVar5 == 0) {
        *(ushort *)(iVar2 + 0xc) = *(ushort *)(iVar2 + 0xc) | 1;
      }
      else {
        isisSetSsnFlag(param_1,param_3,iVar2);
        *(ushort *)(iVar2 + 0xc) = *(ushort *)(iVar2 + 0xc) | 1;
      }
      return;
    }
    fsmem_free(uRam0d92c388,iVar2);
  }
  return;
}