#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t csaEthHwMdaGetPoePSStatus(int param_1)



{

  int iVar1;

  uint32_t *puVar2;

  uint32_t uVar3;

  char *pcVar4;

  uint uVar5;

  uint32_t uVar6;

  

  uVar6 = 0;

  uVar3 = uVar6;

  if ((param_1 != 0) && (iVar1 = xmacRedIsCardActive(*(uint32_t *)(param_1 + 8)), iVar1 != 0)) {

    iVar1 = macMdaRemoved(*(uint32_t *)(param_1 + 8));

    uVar3 = 0;

    if ((iVar1 == 0) && (uVar5 = *(uint *)(param_1 + 8), uVar3 = uVar6, uVar5 != 0)) {

      pcVar4 = (char *)(uVar5 * 0x3a88 + 0x10d260a8);

      uVar3 = 0;

      if (((uVar5 <= *_gMdaInfo) && (uVar3 = 0, *pcVar4 != '\0')) &&

         (uVar3 = uVar6, pcVar4 != (char *)0x0)) {

        puVar2 = *(uint32_t **)(uVar5 * 0x3a88 + 0x10d29b18);

        if (puVar2 == (uint32_t *)0x0) {

          uVar3 = 0;

        }

        else {

          uVar3 = hwSarmFpgaGetPoePsStatus(*puVar2);

        }

      }

    }

  }

  return uVar3;

}



