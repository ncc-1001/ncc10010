#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
// These are likely defined elsewhere in the system
extern int _CflowdMsgQ;
extern uint Status;
extern uint _vxAbsTicks;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern uint _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern char pbufMarkHistoryTrack;
extern int _pbufMarkHistoryOffStart;
extern int _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern char pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern char pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern char pbufMarkHistoryVal3;
extern char pbufMarkHistoryMatchLocation1;
extern int _pbufMarkHistoryLocationVal1;
extern int pbufMarkHistoryLock;
extern char pbufMarkHistoryTable;
extern int _CflowdGlobalPtr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t cflowdRxPacketInt(int param_1,int param_2)

{

  bool bVar1;

  int in_zero;

  int iVar2;

  uint uVar3;

  int *piVar4;

  uint uVar5;

  uint uVar6;

  uint uVar7;

  uint uVar8;

  char *pcVar9;

  uint32_t uVar10;

  uint32_t *puVar11;

  uint16_t uVar12;

  uint32_t auStack_38 [2];

  int iStack_30;

  uint32_t uStack_2c;

  

  if (_CflowdMsgQ == 0) {

    return 0xffffffff;

  }

  iVar2 = cflowdPreProcessPacket();

  uVar6 = Status;

  uVar8 = _vxAbsTicks;

  if (iVar2 == -1) {

    return 0xffffffff;

  }

  puVar11 = (uint32_t *)(param_1 + 0x88);

  uVar7 = (uint)*(ushort *)(param_1 + 0x94);

  uVar3 = _vxAbsTicks / 100;

  if (uVar7 == 0) goto LAB_03861720;

  if (_kernelIsSmp == 0) {

    if (_smpIntCnt == 0) {

LAB_038617a0:

      *puVar11 = _smpTaskIdCurrent;

    }

    else {

      *puVar11 = 0;

    }

  }

  else {

    Status = Status & 0xfffffffe;

    setCopReg(0,Status,uVar6,0);

    if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {

      if (_kernelIsSmp == 0) goto LAB_038617a0;

      *puVar11 = *(uint32_t *)(in_zero + -0x8000);

    }

    else {

      *puVar11 = 0;

    }

  }

  uVar6 = Status;

  uVar5 = (uVar3 & 0xffff) - (uint)*(ushort *)(param_1 + 0x96) & 0xffff;

  uVar12 = (uint16_t)uVar3;

  if ((uVar5 != 0) && (uVar7 < 0xab)) {

    if (8 < uVar5) {

      uVar5 = 8;

    }

    iVar2 = (uVar7 * 0x558 + uVar5) * 8;

    piVar4 = (int *)(iVar2 + 0xecd4dac);

    *(uint16_t *)(iVar2 + 0xecd4db0) = uVar12;

    *piVar4 = *piVar4 + 1;

  }

  if (pbufMarkHistoryTrack != '\0') {

    if ((*(uint *)(param_1 + 0x9c) & 0x8000) == 0) {

      iVar2 = *(int *)(param_1 + 8) + param_1 + 0xa0;

      bVar1 = false;

      uVar8 = *(uint *)(param_1 + 0xc);

      if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {

        uVar6 = _pbufMarkHistoryOffStart;

        do {

          if ((((_pbufMarkHistoryOff1 == -1) ||

               ((_pbufMarkHistoryOff1 + uVar6 < uVar8 &&

                (*(char *)(_pbufMarkHistoryOff1 + iVar2 + uVar6) == pbufMarkHistoryVal1)))) &&

              ((_pbufMarkHistoryOff2 == -1 ||

               ((_pbufMarkHistoryOff2 + uVar6 < uVar8 &&

                (*(char *)(_pbufMarkHistoryOff2 + iVar2 + uVar6) == pbufMarkHistoryVal2)))))) &&

             ((_pbufMarkHistoryOff3 == -1 ||

              ((_pbufMarkHistoryOff3 + uVar6 < uVar8 &&

               (*(char *)(_pbufMarkHistoryOff3 + iVar2 + uVar6) == pbufMarkHistoryVal3)))))) {

            bVar1 = true;

          }

          uVar6 = uVar6 + 1;

        } while (!bVar1 && uVar6 <= _pbufMarkHistoryOffEnd);

      }

      if (bVar1) {

        if ((pbufMarkHistoryMatchLocation1 == '\0') || (_pbufMarkHistoryLocationVal1 == 0x32))

        goto LAB_0386160c;

        *(uint16_t *)(param_1 + 0x96) = uVar12;

        *(uint16_t *)(param_1 + 0x94) = 0x32;

        *(uint32_t *)(param_1 + 0x98) = 0xffffffff;

        goto LAB_03861720;

      }

      if (bVar1) {

LAB_0386160c:

                    /* WARNING: Subroutine does not return */

        intLockProtect(&pbufMarkHistoryLock);

      }

    }

    else {

      iVar2 = (uint)*(ushort *)(param_1 + 0x9c) * 0x408;

      pcVar9 = &pbufMarkHistoryTable + iVar2;

      if (*pcVar9 == '\0') {

        *pcVar9 = '\x01';

        *(uint32_t *)(iVar2 + 0xe58e868) = 0;

        uVar3 = *(uint *)(iVar2 + 0xe58e868);

      }

      else {

        uVar3 = *(uint *)(iVar2 + 0xe58e868);

      }

      if (uVar3 < 0x3f) {

        puVar11 = (uint32_t *)(pcVar9 + uVar3 * 0x10 + 8);

        if (_kernelIsSmp == 0) {

          if (_smpIntCnt == 0) {

LAB_03861818:

            *puVar11 = _smpTaskIdCurrent;

          }

          else {

            *puVar11 = 0;

          }

        }

        else {

          Status = Status & 0xfffffffe;

          setCopReg(0,Status,uVar6,0);

          if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {

            if (_kernelIsSmp == 0) goto LAB_03861818;

            *puVar11 = *(uint32_t *)(in_zero + -0x8000);

          }

          else {

            *puVar11 = 0;

          }

        }

        *(uint *)(pcVar9 + uVar3 * 0x10 + 0x10) = uVar8;

        *(uint16_t *)(pcVar9 + uVar3 * 0x10 + 0xc) = 0x32;

        *(uint32_t *)(pcVar9 + uVar3 * 0x10 + 0x14) = 0xffffffff;

        *(uint16_t *)(pcVar9 + uVar3 * 0x10 + 0xe) = uVar12;

        *(int *)(iVar2 + 0xe58e868) = *(int *)(iVar2 + 0xe58e868) + 1;

      }

    }

  }

  *(uint16_t *)(param_1 + 0x96) = uVar12;

  *(uint16_t *)(param_1 + 0x94) = 0x32;

  *(uint32_t *)(param_1 + 0x98) = 0xffffffff;

LAB_03861720:

  uStack_2c = *(uint32_t *)(param_2 + 4);

  auStack_38[0] = 2;

  iStack_30 = param_1;

  iVar2 = msgQSend(_CflowdMsgQ,auStack_38,0x10,0,0);

  uVar10 = 0;

  if ((iVar2 != 0) && (uVar10 = 0xffffffff, _CflowdGlobalPtr != 0)) {

    *(int *)(_CflowdGlobalPtr + 0x6c668) = *(int *)(_CflowdGlobalPtr + 0x6c668) + 1;

  }

  return uVar10;

}
