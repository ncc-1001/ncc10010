#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for undeclared _isisMutex
extern int _isisMutex;

uint32_t isisIsAddrLocallyActive(uint32_t param_1)

{

  int iVar1;

  uint32_t auStack_18 [2];

  

  auStack_18[0] = 0;

  iVar1 = isisGetNode(param_1,auStack_18);

  if (iVar1 != 0) {

    return 0;

  }

                    /* WARNING: Subroutine does not return */

  semTake(_isisMutex,0xffffffff);

}

