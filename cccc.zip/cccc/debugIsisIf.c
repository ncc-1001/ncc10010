#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t debugIsisIf(uint32_t param_1,uint32_t param_2,int param_3,char param_4)



{

  int iVar1;

  uint auStack_130 [10];

  uint uStack_108;

  uintptr_t auStack_104 [244];

  

  memset(auStack_130,0,0x120);

  auStack_130[0] = auStack_130[0] | 0x40;

  if (param_3 != 0) {

    iVar1 = getIndexFromInterface(1,param_3,auStack_104);

    if (iVar1 != 0) {

      cliErrorMesg(param_1,0x9fffe14);

      return 0xffffffff;

    }

    uStack_108 = uStack_108 | 1;

  }

  if (param_4 == '\0') {

    isisDebugOn(1,auStack_130);

  }

  else {

    isisDebugOff(1,auStack_130);

  }

  return 0;

}



