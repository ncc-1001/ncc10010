#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern unsigned char *___ctype; // Modified: Added extern declaration for undeclared identifier ___ctype

uint32_t debugBgpGracefulRestart(uint32_t param_1,byte *param_2)

{

  if ((*(byte *)((uint)*param_2 + ___ctype) & 4) == 0) {

    cli_debug_bgp_enable();

    return 0;

  }

  cliErrorMesg(param_1,0x9fff728);

  return 0xffffffff;

}