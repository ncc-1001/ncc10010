#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared global variable
extern int ___chk_strnum;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t configureRouterIsisMultiTopology(uint32_t param_1,uint32_t param_2,char param_3)


{

  int iVar1;

  uint32_t uVar2;

  

  uVar2 = 0xa07cc30;

  if (param_3 == '\0') {

    uVar2 = 0xa07cc34;

    ___chk_strnum = 2;

  }

  else {

    ___chk_strnum = 1;

  }

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e308,0,uVar2);

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07e320);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}
