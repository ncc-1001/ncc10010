#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for allowWp3Access as it is used but not declared
extern char allowWp3Access;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void bspToggleSarmWP3Access(char param_1)
{
  char cVar1;
  
  cVar1 = allowWp3Access;
  allowWp3Access = param_1;
  SYNC(0);
  if ((param_1 == '\0') && (cVar1 != '\0')) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}