#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisGetNextNode(int param_1,uint32_t *param_2)



{

  uint32_t uVar1;

  

  *param_2 = 0;

  uVar1 = 5;

  if (param_1 < 1) {

    uVar1 = isisGetNode(1);

  }

  return uVar1;

}



