#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for _isisMutex to fix compilation error
extern int _isisMutex;

void isisAdjSnmpGetFirst(void)
{
                    /* WARNING: Subroutine does not return */
  semTake(_isisMutex,0xffffffff);
}