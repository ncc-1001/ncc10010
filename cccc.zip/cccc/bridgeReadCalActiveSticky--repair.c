#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for global variables
extern int _debugForceCalFailure;
extern int _debugFreezeCalActive;
// Modified: Defined PRId constant based on usage patterns
#define PRId 0x0000d000

ushort bridgeReadCalActiveSticky(int param_1)
{
  ushort *puVar1;
  uint uVar2;
  uint uVar3;
  ushort uVar4;
  uint uVar5;
  
  uVar4 = 0;
  if (_debugForceCalFailure == 0) {
    uVar5 = param_1 + 0x8004;
    uVar4 = 1;
    if (_debugFreezeCalActive == 0) {
      if (0xfffffff < uVar5) {
        uVar3 = PRId >> 8 & 0xffff;
        uVar2 = uVar3 ^ 0xd01;
        if ((((uVar2 != 0) && (uVar2 = uVar3 ^ 0xd06, uVar2 != 0)) &&
            (uVar2 = uVar3 ^ 0xd04, uVar2 != 0)) && (uVar2 = uVar3 ^ 0xd93, uVar2 != 0)) {
          uVar2 = uVar3 ^ 0xd90;
        }
        if (uVar2 == 0) {
          return *(ushort *)(uVar5 | 0xa0000000) >> 8 & 1;
        }
      }
      if ((uVar5 < 0x800000) ||
         (puVar1 = (ushort *)(uVar5 | 0xc0000000), (PRId >> 0x10 & 0xff) != 0xd)) {
        puVar1 = (ushort *)(uVar5 | 0xa0000000);
      }
      uVar4 = *puVar1 >> 8 & 1;
    }
  }
  return uVar4;
}