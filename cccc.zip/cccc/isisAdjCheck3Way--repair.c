#include "nokia.h"
#include <stdint.h>

// Modified: Added declaration for undeclared identifier
int _IsisLogger;
// Modified: Added declaration for undeclared identifier
int _MOD_ISIS;
// Modified: Added declaration for undeclared identifier
char *isisTitleStr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t isisAdjCheck3Way(uint32_t *param_1,int param_2)


{

  uint32_t uVar1;

  int iVar2;

  int iVar3;

  int iVar4;

  uint uVar5;

  

  if ((param_1 == (uint32_t *)0xfffff7c4) || (iVar3 = param_1[0x20f], iVar3 == 0)) {

    uVar1 = 0;

  }

  else {

    uVar1 = 0;

    if (10 < *(byte *)(iVar3 + 1)) {

      iVar4 = iVar3 + 7;

      iVar2 = memcmp(iVar4,param_1 + 8,6);

      if (iVar2 == 0) {

        uVar1 = 0;

        if (0xe < *(byte *)(param_1[0x20f] + 1)) {

          uVar5 = (uint)*(byte *)(iVar3 + 0xd) << 0x18 | (uint)*(byte *)(iVar3 + 0xe) << 0x10 |

                  (uint)*(byte *)(iVar3 + 0xf) << 8 | (uint)*(byte *)(iVar3 + 0x10);

          uVar1 = 0;

          if ((*(uint *)(param_2 + 0x310) != uVar5) &&

             (uVar1 = 0xffffffff, param_1 != (uint32_t *)0x0)) {

            if ((param_1[0x1b] & 0x10) == 0) {

              uVar1 = 0xffffffff;

            }

            else {

              iVar3 = isisDebugCheck(param_1,0x10,0,param_2);

              uVar1 = 0xffffffff;

              if (iVar3 != 0) {

                if (_IsisLogger == 0) {

                  tracePrint(_MOD_ISIS,0xa1a699c,0,0,0xa1a69b8,uVar5,*(uint32_t *)(param_2 + 8));

                  uVar1 = 0xffffffff;

                }

                else {

                  logEvent_debug_fmt(*param_1,0xa1a69b0,&isisTitleStr,0xa1a69b8,uVar5,

                                     *(uint32_t *)(param_2 + 8));

                  uVar1 = 0xffffffff;

                }

              }

            }

          }

        }

      }

      else {

        uVar1 = 0xffffffff;

        if ((param_1 != (uint32_t *)0x0) && (uVar1 = 0xffffffff, (param_1[0x1b] & 0x10) != 0)) {

          iVar3 = isisDebugCheck(param_1,0x10,0,param_2);

          uVar1 = 0xffffffff;

          if (iVar3 != 0) {

            if (_IsisLogger == 0) {

              uVar1 = isisDumpSysId(iVar4,param_1 + 0x6a1,0x400,0);

              tracePrint(_MOD_ISIS,0xa1a699c,0,0,0xa1a6a14,uVar1,*(uint32_t *)(param_2 + 8));

              uVar1 = 0xffffffff;

            }

            else {

              uVar1 = isisDumpSysId(iVar4,param_1 + 0x6a1,0x400,0);

              logEvent_debug_fmt(*param_1,0xa1a69b0,&isisTitleStr,0xa1a6a14,uVar1,

                                 *(uint32_t *)(param_2 + 8));

              uVar1 = 0xffffffff;

            }

          }

        }

      }

    }

  }

  return uVar1;

}