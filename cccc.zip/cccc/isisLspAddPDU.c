#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t isisLspAddPDU(uint32_t *param_1,int param_2,int param_3)



{

  ushort uVar1;

  ushort uVar4;

  int iVar2;

  uint32_t uVar3;

  uintptr_t auStack_148 [304];

  

  if ((ushort)((*(ushort *)(param_2 + 0xc) >> 2 ^ 1) & (ushort)(param_3 == 0)) == 0) {

    if (((*(ushort *)(param_2 + 0xc) & 4) != 0) && (*(int *)(param_2 + 0x34) == 0)) {

      iVar2 = isisMalloc(0x5d4);

      *(int *)(param_2 + 0x34) = iVar2;

      if (iVar2 == 0) {

        return 6;

      }

      *(uint16_t *)(param_2 + 0x28) = 0x5d4;

      *(uint32_t *)(param_2 + 0x110) = 0x5d4;

      *(uint16_t *)(param_2 + 0x2a) = 0;

    }

    if (param_3 == 0) {

      *(uint32_t *)(param_2 + 0x38) = 0;

      *(uint32_t *)(param_2 + 0x40) = 0;

      *(uint32_t *)(param_2 + 0x44) = 0;

      *(uint32_t *)(param_2 + 0x4c) = 0;

      *(uint32_t *)(param_2 + 0x50) = 0;

      *(uint32_t *)(param_2 + 0x58) = 0;

      *(uint32_t *)(param_2 + 0x5c) = 0;

      *(uint32_t *)(param_2 + 100) = 0;

      *(uint32_t *)(param_2 + 0x68) = 0;

      *(uint32_t *)(param_2 + 0x70) = 0;

      *(uint32_t *)(param_2 + 0x74) = 0;

      *(uint32_t *)(param_2 + 0x7c) = 0;

      *(uint32_t *)(param_2 + 0x80) = 0;

      *(uint32_t *)(param_2 + 0x88) = 0;

      *(uint32_t *)(param_2 + 0x8c) = 0;

      *(uint32_t *)(param_2 + 0x94) = 0;

      *(uint32_t *)(param_2 + 0x98) = 0;

      *(uint32_t *)(param_2 + 0xa0) = 0;

      *(uint32_t *)(param_2 + 0xa4) = 0;

      *(uint32_t *)(param_2 + 0xac) = 0;

      *(uint32_t *)(param_2 + 0xb0) = 0;

      *(uint32_t *)(param_2 + 0xb8) = 0;

      *(uint32_t *)(param_2 + 0xbc) = 0;

      *(uint32_t *)(param_2 + 0xc4) = 0;

      *(uint32_t *)(param_2 + 200) = 0;

      *(uint32_t *)(param_2 + 0xd0) = 0;

      *(uint32_t *)(param_2 + 0xd4) = 0;

      *(uint32_t *)(param_2 + 0xdc) = 0;

      *(uint32_t *)(param_2 + 0xe0) = 0;

      *(uint32_t *)(param_2 + 0xe8) = 0;

      *(uint32_t *)(param_2 + 0xec) = 0;

      *(uint32_t *)(param_2 + 0xf4) = 0;

      *(uint32_t *)(param_2 + 0xf8) = 0;

      *(uint32_t *)(param_2 + 0x100) = 0;

      *(uint16_t *)(param_2 + 0x2a) = 0;

    }

    else {

      uVar1 = *(ushort *)(param_3 + 8);

      *(uint *)(param_2 + 0x10) =

           (uint)*(byte *)(param_3 + 0x14) << 0x18 | (uint)*(byte *)(param_3 + 0x15) << 0x10 |

           (uint)*(byte *)(param_3 + 0x16) << 8 | (uint)*(byte *)(param_3 + 0x17);

      *(uint16_t *)(param_2 + 0xe) = *(uint16_t *)(param_3 + 0x18);

      if ((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x200) == 0)) {

        uVar4 = *(ushort *)(param_2 + 0x28);

      }

      else {

        iVar2 = isisDebugCheck(param_1,0x200,param_2,0);

        if (iVar2 == 0) {

          uVar4 = *(ushort *)(param_2 + 0x28);

        }

        else if (_IsisLogger == 0) {

          uVar3 = isisDumpLspId(param_2 + 4,auStack_148,300,0);

          tracePrint(_MOD_ISIS,0xa1aab58,0,0,0xa1aab68,uVar3,*(uint32_t *)(param_2 + 0x24),

                     *(uint32_t *)(param_2 + 0x10),*(uint16_t *)(param_2 + 0xe),uVar1);

          uVar4 = *(ushort *)(param_2 + 0x28);

        }

        else {

          uVar3 = isisDumpLspId(param_2 + 4,auStack_148,300,0);

          logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1aab68,uVar3,

                             *(uint32_t *)(param_2 + 0x24),*(uint32_t *)(param_2 + 0x10),

                             *(uint16_t *)(param_2 + 0xe),uVar1);

          uVar4 = *(ushort *)(param_2 + 0x28);

        }

      }

      if (uVar4 < uVar1) {

        iVar2 = isisMalloc(uVar1);

        if (iVar2 == 0) {

          return 6;

        }

        if (*(int *)(param_2 + 0x34) == 0) {

          *(int *)(param_2 + 0x34) = iVar2;

          *(ushort *)(param_2 + 0x28) = uVar1;

        }

        else {

          isisLspUpdateIntf2RtrIdCache(param_1,param_2,0);

          isisFree(*(uint32_t *)(param_2 + 0x34));

          *(int *)(param_2 + 0x34) = iVar2;

          *(ushort *)(param_2 + 0x28) = uVar1;

        }

      }

      else {

        iVar2 = *(int *)(param_2 + 0x34);

      }

      memcpy(iVar2,param_3,uVar1);

      *(ushort *)(param_2 + 0x2a) = uVar1;

      if ((*(ushort *)(param_2 + 0xc) & 0x1000) == 0) {

        isisLspUpdateTlvs(param_1,param_2);

      }

    }

  }

  return 0;

}



