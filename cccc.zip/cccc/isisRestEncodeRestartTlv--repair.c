#include "nokia.h" // Modified: Changed absolute path to relative path for compilation
#include <stdint.h>

// Modified: Added extern declarations for missing variables
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisRestEncodeRestartTlv(uint32_t *param_1,int param_2,uint32_t *param_3,int *param_4)


{

  byte bVar1;

  uintptr_t uVar3;

  int iVar2;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t uVar6;

  uintptr_t *puVar7;

  byte bVar8;

  uint uVar9;

  

  puVar7 = (uintptr_t *)*param_3;

  *puVar7 = 0xd3;

  *param_4 = *param_4 + 2;

  bVar1 = *(byte *)(param_2 + 0x2874) | *(byte *)(param_2 + 0x2875);

  puVar7[2] = bVar1;

  uVar9 = 0;

  bVar8 = 0;

  if (bVar1 == 0) {

LAB_042348a8:

    if (bVar8 != 0) {

      uVar9 = (uint)*(ushort *)(param_2 + 0x2876);

    }

  }

  else {

    bVar8 = bVar1 & 2;

    if ((bVar1 & 2) != 0) {

      if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x400000) != 0)) &&

         (iVar2 = isisDebugCheck(param_1,0x400000,param_2,0), iVar2 != 0)) {

        if (_IsisLogger == 0) {

          uVar4 = 0xa1ae05c;

          if ((bVar1 & 1) == 0) {

            uVar4 = 0xa1ae060;

          }

          uVar5 = 0xa1ae0a8;

          if ((bVar1 & 2) == 0) {

            uVar5 = 0xa1ae060;

          }

          uVar6 = 0xa1ae064;

          if ((bVar1 & 4) == 0) {

            uVar6 = 0xa1ae060;

          }

          tracePrint(_MOD_ISIS,0xa1ae040,0,0,0xa1ae0ac,uVar4,uVar5,uVar6,

                     *(uint32_t *)(param_2 + 8),*(uint16_t *)(param_2 + 0x2876));

        }

        else {

          uVar4 = 0xa1ae05c;

          if ((bVar1 & 1) == 0) {

            uVar4 = 0xa1ae060;

          }

          uVar5 = 0xa1ae0a8;

          if ((bVar1 & 2) == 0) {

            uVar5 = 0xa1ae060;

          }

          uVar6 = 0xa1ae064;

          if ((bVar1 & 4) == 0) {

            uVar6 = 0xa1ae060;

          }

          logEvent_debug_fmt(*param_1,0xa1ae068,&isisTitleStr,0xa1ae0ac,uVar4,uVar5,uVar6,

                             *(uint32_t *)(param_2 + 8),*(uint16_t *)(param_2 + 0x2876));

        }

      }

      goto LAB_042348a8;

    }

    if (param_1 != (uint32_t *)0x0) {

      uVar3 = 0;

      if ((param_1[0x1b] & 0x400000) != 0) {

        iVar2 = isisDebugCheck(param_1,0x400000,param_2,0);

        uVar3 = 0;

        if (iVar2 != 0) {

          if (_IsisLogger == 0) {

            uVar4 = 0xa1ae05c;

            if ((bVar1 & 1) == 0) {

              uVar4 = 0xa1ae060;

            }

            uVar5 = 0xa1ae064;

            if ((bVar1 & 4) == 0) {

              uVar5 = 0xa1ae060;

            }

            tracePrint(_MOD_ISIS,0xa1ae040,0,0,0xa1ae070,uVar4,0xa1ae060,uVar5,

                       *(uint32_t *)(param_2 + 8));

            uVar3 = 0;

          }

          else {

            uVar4 = 0xa1ae05c;

            if ((bVar1 & 1) == 0) {

              uVar4 = 0xa1ae060;

            }

            uVar5 = 0xa1ae064;

            if ((bVar1 & 4) == 0) {

              uVar5 = 0xa1ae060;

            }

            logEvent_debug_fmt(*param_1,0xa1ae068,&isisTitleStr,0xa1ae070,uVar4,0xa1ae060,uVar5,

                               *(uint32_t *)(param_2 + 8));

            uVar3 = 0;

          }

        }

      }

      goto LAB_042348b4;

    }

  }

  uVar3 = (uintptr_t)(uVar9 >> 8);

LAB_042348b4:

  puVar7[3] = uVar3;

  puVar7[4] = (char)uVar9;

  *param_4 = *param_4 + 3;

  puVar7[1] = 3;

  *param_3 = puVar7 + 5;

  return;

}