#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendOverloadTrap(uint32_t *param_1,uint32_t param_2,int param_3)



{

  uint32_t uVar1;

  int iVar2;

  int iVar3;

  uintptr_t auStack_40 [40];

  

  iVar3 = 1;

  if (param_1[7] != 2) {

    iVar3 = 3 - (uint)(*(char *)((int)param_1 + param_3 * 0x28 + 0x5ee) != '\x01');

  }

  iVar2 = 1;

  if (param_1[7] != 1) {

    iVar2 = 3 - (uint)(*(char *)((int)param_1 + param_3 * 0x28 + 0x63e) != '\x01');

  }

  uVar1 = isisXlateMtId(param_3);

  snprintf(auStack_40,0x28,0xa1bb9b8,uVar1);

  logEvent_ISIS_vRtrIsisDatabaseOverload(*param_1,auStack_40,*param_1,param_2,iVar3,iVar2);

  return;

}



