#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern void *uRam0d92c38c;
extern void *uRam0c95b30c;

void isisAdjDestroy(int param_1)
{
  uint32_t *puVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint32_t *puVar5;
  
  puVar5 = *(uint32_t **)(param_1 + 0x68);
  uVar2 = 0;
  puVar1 = puVar5;
  do {
    if (*(char *)(uVar2 + param_1 + 0x90) != '\0') {
      if (puVar5[0xbd] == 2) {
        if (*(int *)(param_1 + 0x4c) == 1) {
          puVar1[0x114] = puVar1[0x114] + -1;
        }
        else {
          puVar1[0x188] = puVar1[0x188] + -1;
        }
      }
      *(uintptr_t *)(uVar2 + param_1 + 0x90) = 0;
    }
    uVar2 = uVar2 + 1;
    puVar1 = puVar1 + 1;
  } while (uVar2 < 2);
  isisAdjBfdDel(*(uint32_t *)*puVar5,param_1);
  iVar3 = *(int *)(param_1 + 0x78);
  if (*(int *)(param_1 + 0x78) == 0) {
    iVar3 = *(int *)(param_1 + 0x7c);
  }
  else {
    do {
      iVar4 = *(int *)(iVar3 + 0x10);
      fsmem_free(uRam0d92c38c,iVar3);
      *(int *)(param_1 + 100) = *(int *)(param_1 + 100) + -1;
      iVar3 = iVar4;
    } while (iVar4 != 0);
    iVar3 = *(int *)(param_1 + 0x7c);
  }
  if (iVar3 == 0) {
    iVar3 = *(int *)(param_1 + 0x6c);
  }
  else {
    timerDelete();
    iVar3 = *(int *)(param_1 + 0x6c);
  }
  if (iVar3 != 0) {
    dlistFreeNodeExt(puVar5[0xf4]);
    *(uint32_t *)(param_1 + 0x6c) = 0;
  }
  if (*(int *)(param_1 + 0x74) != 0) {
    dlistFreeNodeExt(uRam0c95b30c);
    *(uint32_t *)(param_1 + 0x74) = 0;
    dlistFreeNodeExt(puVar5[0x108],param_1);
    return;
  }
  dlistFreeNodeExt(puVar5[0x108],param_1);
  return;
}