#include "nokia.h"
#include <stdint.h>

// Modified: Added missing type definition
typedef unsigned char byte;

// Modified: Added extern declarations for undeclared variables
extern uint32_t *_gMdaInfo;
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int cRam10c8f925;
extern uint32_t uRam00000004;
extern uint32_t uRam0a985e58;
extern uint32_t uRam0a985e5c;
extern uint32_t uRam0a985e60;
extern uint32_t uRam0a985e64;
extern int _traceEnabled;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void comet8UpdateTxSsmE1(uint param_1,uint param_2,char param_3,uint param_4)



{

  int iVar1;

  uint uVar2;

  uint32_t uVar3;

  int iVar4;

  int iVar5;

  int iVar6;

  uint32_t uStack_38;

  uint32_t uStack_34;

  uint32_t uStack_30;

  uint32_t uStack_2c;

  

  iVar4 = 0;

  if (((param_1 == 0) || (*_gMdaInfo < param_1)) ||

     (iVar4 = *(int *)(param_1 * 4 + 0xccb422c), iVar4 == 0)) {

    timosAssert(0xa9847c4,0xa9847d0,0x1969,0xa985f5c,0xa9847c0);

  }

  iVar4 = *(int *)((param_2 >> 3) * 4 + iVar4 + 0x94);

  if (iVar4 == 0) {

    timosAssert(0xa985e9c,0xa9847d0,0x196b,0xa985f5c,0xa9847c0);

  }

  if ((_tracepointsActive != 0) && (iVar1 = traceTest(_MOD_MDADRV,0xa985f5c,1,0), iVar1 != 0)) {

    uVar3 = 0xa985f98;

    if (param_3 == '\0') {

      uVar3 = 0xa985fa0;

    }

    tracePrintVRtr(_MOD_MDADRV,0xa985f5c,1,0,1,0xa985f70,param_1,param_2,uVar3,param_4 & 0xff);

  }

  iVar1 = posRedIsCardActive(param_1);

  if (iVar1 != 0) {

    iVar1 = utilCometqDeviceHandle2Ddb(iVar4);

    iVar6 = (param_2 & 7) * 0x100;

    iVar5 = *(int *)(iVar1 + 0x10);

    iVar4 = (iVar6 + 0x86) * 4;

    if (cRam10c8f925 != -0x24) {

      iVar4 = iVar6 + 0x86;

    }

    if (*(int *)(iVar1 + 0x14) == 0) {

      timosAssert(0xa98547c,0xa9847d0,0x174f,0xa985470,0xa9847c0);

      uVar3 = uRam00000004;

    }

    else {

      uVar3 = *(uint32_t *)(*(int *)(iVar1 + 0x14) + 4);

    }

    uVar2 = fpgaFramerRead(uVar3,iVar4 + iVar5);

    uVar2 = (uVar2 & 0xff) >> 5;

    iVar4 = uVar2 + 1;

    if (uVar2 - 3 < 5) {

      if (param_3 == '\0') {

        iVar4 = (iVar6 + 0x87) * 4;

        if (cRam10c8f925 != -0x24) {

          iVar4 = iVar6 + 0x87;

        }

        if (*(int *)(iVar1 + 0x14) == 0) {

          timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);

          uVar3 = uRam00000004;

        }

        else {

          uVar3 = *(uint32_t *)(*(int *)(iVar1 + 0x14) + 4);

        }

        fpgaFramerWrite(uVar3,iVar4 + iVar5,0xf);

      }

      else {

        param_4 = param_4 & 0xf;

        if (iVar4 == 8) {

          uStack_38 = uRam0a985e58;

          uStack_34 = uRam0a985e5c;

          uStack_30 = uRam0a985e60;

          uStack_2c = uRam0a985e64;

          param_4 = (uint)*(byte *)((int)&uStack_38 + param_4);

        }

        iVar4 = (iVar6 + 0x87) * 4;

        if (cRam10c8f925 != -0x24) {

          iVar4 = iVar6 + 0x87;

        }

        if (*(int *)(iVar1 + 0x14) == 0) {

          timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);

          uVar3 = uRam00000004;

        }

        else {

          uVar3 = *(uint32_t *)(*(int *)(iVar1 + 0x14) + 4);

        }

        fpgaFramerWrite(uVar3,iVar4 + iVar5,param_4 | 0xf0);

      }

      return;

    }

    if ((_traceEnabled != 0) ||

       ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa985f5c,4,0), iVar1 != 0)))) {

      tracePrintVRtr(_MOD_MDADRV,0xa985f5c,4,0,1,0xa985fac,param_1,param_2,iVar4);

    }

  }

  return;

}