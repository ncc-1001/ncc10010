#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisRedSendLspRxDbToInactive

               (uint32_t *param_1,uint32_t param_2,uint32_t *param_3,int param_4)



{

  uint32_t *puVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t *puVar6;

  uint32_t *puVar7;

  int iVar8;

  

  if (param_1[0x842] == 0) {

    iVar8 = 0x188;

    if (param_4 != 0) {

      iVar8 = *(ushort *)((int)param_3 + 0x2a) + 0x188;

    }

    puVar1 = (uint32_t *)isisCalloc(iVar8,1);

    if (puVar1 != (uint32_t *)0x0) {

      uVar2 = *param_1;

      puVar1[1] = param_2;

      *puVar1 = uVar2;

      puVar7 = puVar1 + 2;

      puVar6 = param_3;

      do {

        uVar2 = *puVar6;

        uVar3 = puVar6[1];

        uVar4 = puVar6[2];

        uVar5 = puVar6[3];

        puVar6 = puVar6 + 4;

        *puVar7 = uVar2;

        puVar7[1] = uVar3;

        puVar7[2] = uVar4;

        puVar7[3] = uVar5;

        puVar7 = puVar7 + 4;

      } while (puVar6 != param_3 + 0x58);

      puVar1[0x5a] = param_4;

      puVar1[0x10] = 0;

      puVar1[0x13] = 0;

      puVar1[0x16] = 0;

      puVar1[0x19] = 0;

      puVar1[0x1c] = 0;

      puVar1[0x1f] = 0;

      puVar1[0x22] = 0;

      puVar1[0x25] = 0;

      puVar1[0x28] = 0;

      puVar1[0x2b] = 0;

      puVar1[0x2e] = 0;

      puVar1[0x31] = 0;

      puVar1[0x34] = 0;

      puVar1[0x37] = 0;

      puVar1[0x3a] = 0;

      puVar1[0x3d] = 0;

      puVar1[0x40] = 0;

      if (param_4 == 0) {

        *(uint16_t *)((int)puVar1 + 0x32) = 0;

      }

      else {

        memcpy(puVar1 + 0x5b,param_3[0xd],*(uint16_t *)((int)param_3 + 0x2a));

      }

      redSendUpdate(0x34,0xc,puVar1,iVar8);

      isisFree(puVar1);

    }

  }

  return;

}



