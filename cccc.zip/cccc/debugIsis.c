#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t debugIsis(uint32_t param_1,uint32_t param_2,char param_3)



{

  uint32_t auStack_128 [72];

  

  memset(auStack_128,0,0x120);

  if (param_3 == '\0') {

    return 0;

  }

  auStack_128[0] = 0xffffffff;

  isisDebugOff(1,auStack_128);

  return 0;

}



