#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int *_gMdaInfo;
extern uint uRam000000ec;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;
// Modified: Updated typedef for 'code' to match actual function signatures
typedef void (*code1)(uint*, int*); // For the first function pointer call
typedef void (*code2)(uint, int, uint, uint32_t, char); // For the second function pointer call

void csaEthMixeHwPortLineRefEnable(uint param_1,uint param_2,char param_3)
{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  ushort uVar5;
  int iVar6;
  uint32_t uVar7;
  uint32_t uVar8;
  uint uStack_38;
  uint uStack_34;
  uint32_t uStack_30;
  int aiStack_28 [2];
  
  param_2 = param_2 & 0xffff;
  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
    timosAssert(0xa8ead48,0xa8ead64,0xf2,0xa8ead98,0xa8ead94);
  }
  iVar6 = *(int *)(param_1 * 4 + 0xccb630c);
  if (iVar6 == 0) {
    timosAssert(0xa8ead90,0xa8ead64,0xf2,0xa8ead98,0xa8ead94);
    uVar1 = uRam000000ec;
  }
  else {
    uVar1 = *(uint *)(iVar6 + 0xec);
  }
  if (uVar1 <= param_2) {
    timosAssert(0xa8eadb8,0xa8ead64,0xf2,0xa8ead98,0xa8ead94);
  }
  iVar2 = param_2 * 0x1a60 + iVar6;
  if (iVar6 == 0 || iVar2 == -0x9c8) {
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return;
      }
      iVar2 = traceTest(_MOD_MDADRV,0xa8ead98,4,0);
      if (iVar2 == 0) {
        return;
      }
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8ead98,4,0,1,0xa8eadd4,*(uint32_t *)(iVar6 + 0x108),param_2);
    return;
  }
  iVar3 = csaEthGetMda(param_1,1);
  iVar4 = csaEthGetPortType(iVar6,*(uint32_t *)(iVar2 + 0x9d8));
  uVar7 = *(uint32_t *)(iVar2 + 0x1290);
  if (iVar4 == 0x11) {
    if ((((*(char *)(*(int *)(iVar6 + 0x63b0c) + (uint)*(ushort *)(iVar2 + 0x9dc)) == '\0') &&
         (iVar3 != 0)) && (*(int *)(iVar3 + 8) != 0)) &&
       (*(int *)(*(int *)(iVar3 + 8) + 0x150) != 0)) {
      aiStack_28[0] = 0;
      uStack_30 = 0;
      if (param_3 != '\0') {
        uStack_30 = *(uint32_t *)(iVar2 + 0x1290);
      }
      uStack_38 = param_1;
      uStack_34 = param_2;
      (**(code1 **)(*(int *)(iVar3 + 8) + 0x150))(&uStack_38,aiStack_28);
      if (aiStack_28[0] != 0) {
        if (_traceEnabled == 0) {
          if (_tracepointsActive == 0) goto LAB_0640b5d4;
          iVar6 = traceTest(_MOD_MDADRV,0xa8ead98,4,0);
          if (iVar6 == 0) goto LAB_0640b5c4;
        }
        tracePrintVRtr(_MOD_MDADRV,0xa8ead98,4,0,1,0xa8eae58,param_1,param_2,
                       *(uint32_t *)(iVar2 + 0x1290));
      }
    }
  }
  else if (iVar4 == 0xb) {
    if (*(int *)(iVar2 + 0x1274) == 2) {
      uVar7 = *(uint32_t *)(iVar2 + 0x1688);
    }
    uVar5 = csaEthMdioRead(iVar6,*(uint16_t *)(iVar2 + 0x9dc),0xa008,1);
    if (param_3 == '\0') {
      uVar5 = uVar5 & 0xfff7;
    }
    else {
      uVar5 = uVar5 | 8;
    }
    csaEthMdioWrite(iVar6,*(uint16_t *)(iVar2 + 0x9dc),0xa008,uVar5,1);
  }
LAB_0640b5c4:
  if ((_tracepointsActive != 0) && (iVar6 = traceTest(_MOD_MDADRV,0xa8ead98,1,0), iVar6 != 0)) {
    if (param_3 == '\0') {
      uVar8 = 0xa8eae50;
    }
    else {
      uVar8 = 0xa8eae48;
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8ead98,1,0,1,0xa8eae0c,param_1,param_2,uVar7,uVar8,
                   *(uintptr_t *)(iVar2 + 0x9e1));
  }
LAB_0640b5d4:
  if (((iVar3 != 0) && (iVar6 = *(int *)(iVar3 + 4), iVar6 != 0)) && (*(int *)(iVar6 + 0x20) != 0))
  {
    (**(code2 **)(iVar6 + 0x20))(param_1,0,param_2,uVar7,param_3);
  }
  return;
}