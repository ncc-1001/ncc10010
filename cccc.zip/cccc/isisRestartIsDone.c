#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

bool isisRestartIsDone(uint32_t param_1)



{

  int iVar1;

  bool bVar2;

  int aiStack_10 [2];

  

  iVar1 = isisGetNode(param_1,aiStack_10);

  bVar2 = true;

  if (iVar1 == 0) {

    bVar2 = *(int *)(aiStack_10[0] + 0x2020) != 2;

  }

  return bVar2;

}



