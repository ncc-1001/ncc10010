#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t configRouterIsisUnicastImportDisable(uint32_t param_1,uint32_t param_2,int param_3)



{

  int iVar1;

  uint32_t uVar2;

  

  if (((param_3 == 0) || (iVar1 = strcmp(param_3,0xa07e164), iVar1 == 0)) ||

     (iVar1 = strcmp(param_3,0xa07e1b4), iVar1 == 0)) {

    ___chk_strnum = 2;

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e16c,0,0xa07cc34);

    uVar2 = 0xa07e184;

    if (iVar1 != 0) goto LAB_03a98f84;

  }

  if (param_3 == 0) {

    return 0;

  }

  iVar1 = strcmp(param_3,0xa07e1ac);

  if ((iVar1 != 0) && (iVar1 = strcmp(param_3,0xa07e1b4), iVar1 != 0)) {

    return 0;

  }

  ___chk_strnum = 2;

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e1bc,0,0xa07cc34);

  if (iVar1 == 0) {

    return 0;

  }

  uVar2 = 0xa07e1d8;

LAB_03a98f84:

  cliErrorMesg(param_1,uVar2);

  return 0xffffffff;

}



