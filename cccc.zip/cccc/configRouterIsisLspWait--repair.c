#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared global variable
extern int ___chk_strnum;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t

configRouterIsisLspWait(uint32_t param_1,uint32_t param_2,int param_3,int param_4,int param_5)


{

  int iVar1;

  uint32_t uVar2;

  

  if (param_3 == 0) {

    ___chk_strnum = 5;

    param_3 = 0xa07d5dc;

  }

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d554,0,param_3);

  uVar2 = 0xa07d568;

  if (iVar1 == 0) {

    if (param_4 == 0) {

      param_4 = 0xa07d274;

      ___chk_strnum = 0;

    }

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d584,0,param_4);

    uVar2 = 0xa07d59c;

    if (iVar1 == 0) {

      if (param_5 == 0) {

        ___chk_strnum = 1;

        param_5 = 0xa07cc30;

      }

      iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d5c4,0,param_5);

      if (iVar1 == 0) {

        return 0;

      }

      uVar2 = 0xa07d5e0;

    }

  }

  cliErrorMesg(param_1,uVar2);

  return 0xffffffff;

}
