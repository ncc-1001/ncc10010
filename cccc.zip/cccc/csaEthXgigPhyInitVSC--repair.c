#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _traceEnabled;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t csaEthXgigPhyInitVSC(int param_1,int param_2)

{

  int iVar1;

  int iVar2;

  ushort uVar5;

  uint uVar3;

  uint32_t uVar4;

  uint16_t uVar6;

  

  iVar1 = csaEthGetConnType(param_1,*(uint32_t *)(param_2 + 0x10));

  if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_MDADRV,0xa8e8ab0,1,0), iVar2 != 0)) {

    tracePrintVRtr(_MOD_MDADRV,0xa8e8ab0,1,0,1,0xa8e8ac8,*(uint32_t *)(param_1 + 8),

                   *(uint16_t *)(param_2 + 0x14));

  }

  iVar2 = xmacRedIsCardActive(*(uint32_t *)(param_1 + 8));

  if ((iVar2 != 0) && (iVar2 = macMdaRemoved(*(uint32_t *)(param_1 + 8)), iVar2 == 0)) {

    uVar5 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0x7f10,0x1e);

    csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x7f10,uVar5 | 0x100,0x1e);

    uVar5 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0xa201,1);

    csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0xa201,uVar5 | 4,1);

    if ((*(uint *)(*(int *)(param_1 + 0x110) * 0x28 +

                   *(int *)(*(int *)(param_1 + 0x10c) * 0x18 + 0x6a19394) + 0x1c) & 0x400) == 0) {

      if (_tracepointsActive == 0) {

        uVar6 = *(uint16_t *)(param_2 + 0x14);

      }

      else {

        iVar2 = traceTest(_MOD_MDADRV,0xa8e8ab0,1,0);

        if (iVar2 == 0) {

          uVar6 = *(uint16_t *)(param_2 + 0x14);

        }

        else {

          tracePrintVRtr(_MOD_MDADRV,0xa8e8ab0,1,0,1,0xa8e8ad0,*(uint32_t *)(param_1 + 8),

                         *(uint16_t *)(param_2 + 0x14));

          uVar6 = *(uint16_t *)(param_2 + 0x14);

        }

      }

      uVar3 = csaEthMdioRead(param_1,uVar6,0xa101,1);

      uVar6 = *(uint16_t *)(param_2 + 0x14);

      if ((uVar3 & 8) == 0) {

        uVar5 = csaEthMdioRead(param_1,uVar6,0x7f11,0x1e);

        csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x7f11,uVar5 | 0x10,0x1e);

        uVar6 = *(uint16_t *)(param_2 + 0x14);

      }

      uVar3 = csaEthMdioRead(param_1,uVar6,0x8017,1);

      csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x8017,uVar3 & 0xffc1 | 0x20,1);

      uVar3 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0xa008,1);

      if (*(int *)(param_1 + 0x108) == 0xa9 || *(int *)(param_1 + 0x108) == 0xac) {

        uVar3 = uVar3 & 0xffe8 | 1;

      }

      else {

        uVar3 = uVar3 & 0xfff8 | 0x11;

      }

      csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0xa008,uVar3,1);

      if (iVar1 == 8) {

        uVar3 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0xa009,1);

        csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0xa009,uVar3 & 0xfff8 | 0x18,1);

      }

      sysDelayNanos(15000000);

      uVar3 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0x18,4);

      if ((uVar3 & 0x100f) == 0x100f) {

        uVar6 = *(uint16_t *)(param_2 + 0x14);

      }

      else {

        iVar1 = macMdaRemoved(*(uint32_t *)(param_1 + 8));

        if (iVar1 == 0) {

          if (*(int *)(param_1 + 0x108) != 0xa9 && *(int *)(param_1 + 0x108) != 0xac) {

            iVar1 = macMdaRemoved(*(uint32_t *)(param_1 + 8));

            if (iVar1 != 0) {

              return 0xffffffff;

            }

            if (_traceEnabled == 0) {

              if (_tracepointsActive == 0) {

                return 0xffffffff;

              }

              iVar1 = traceTest(_MOD_MDADRV,0xa8e8ab0,4,0);

              if (iVar1 == 0) {

                return 0xffffffff;

              }

              uVar4 = *(uint32_t *)(param_1 + 8);

            }

            else {

              uVar4 = *(uint32_t *)(param_1 + 8);

            }

            tracePrintVRtr(_MOD_MDADRV,0xa8e8ab0,4,0,1,0xa8e8b08,uVar4,

                           *(uint16_t *)(param_2 + 0x14),0x100f,uVar3 & 0x100f);

            return 0xffffffff;

          }

          uVar6 = *(uint16_t *)(param_2 + 0x14);

        }

        else {

          uVar6 = *(uint16_t *)(param_2 + 0x14);

        }

      }

    }

    else {

      if (_tracepointsActive == 0) {

        uVar6 = *(uint16_t *)(param_2 + 0x14);

      }

      else {

        iVar1 = traceTest(_MOD_MDADRV,0xa8e8ab0,1,0);

        if (iVar1 == 0) {

          uVar6 = *(uint16_t *)(param_2 + 0x14);

        }

        else {

          tracePrintVRtr(_MOD_MDADRV,0xa8e8ab0,1,0,1,0xa8e8ae8,*(uint32_t *)(param_1 + 8),

                         *(uint16_t *)(param_2 + 0x14));

          uVar6 = *(uint16_t *)(param_2 + 0x14);

        }

      }

      uVar3 = csaEthMdioRead(param_1,uVar6,0x8017,1);

      csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x8017,uVar3 & 0xffc1 | 0x1a,1);

      uVar3 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0x8018,1);

      csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x8018,uVar3 & 0xff3f | 0xc0,1);

      uVar3 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0x8019,1);

      csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x8019,uVar3 & 0xffe1 | 4,1);

      uVar6 = *(uint16_t *)(param_2 + 0x14);

    }

    uVar3 = csaEthMdioRead(param_1,uVar6,0x8013,1);

    csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x8013,uVar3 & 0xf0e0 | 0xb0b,1);

    uVar3 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0x8014,1);

    csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0x8014,uVar3 & 0xe0c0 | 0x1804,1);

    uVar5 = csaEthMdioRead(param_1,*(uint16_t *)(param_2 + 0x14),0xae00,1);

    csaEthMdioWrite(param_1,*(uint16_t *)(param_2 + 0x14),0xae00,uVar5 | 6,1);

    if (*(int *)(param_1 + 0x108) == 0xac) {

      sarmEthXgigRingPhyLedConfig(param_1,param_2);

    }

  }

  return 0;

}