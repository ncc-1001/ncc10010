#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t configRouterIsisInterfaceLspInterval(uint32_t param_1)



{

  int iVar1;

  uint32_t uVar2;

  

  iVar1 = cfgRouterISISInterfaceElements();

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07dd58);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}



