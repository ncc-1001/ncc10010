#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwSarmFpgaDebugDisplayTemp(void)



{

  int in_zero;

  uint32_t uVar1;

  int iVar2;

  uintptr_t auStack_28 [16];

  

  iVar2 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar2 + 0x10c8f925) != -0x23) {

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) != -0x12) {

      hwSarmFpgaGetTemperature(auStack_28);

                    /* WARNING: Bad instruction - Truncating control flow here */

      halt_baddata();

    }

  }

  uVar1 = hwSarHCFpgaGetBoardTemp(1);

                    /* WARNING: Subroutine does not return */

  printf(0x69c3060,0x69c3280,uVar1);

}