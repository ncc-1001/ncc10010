#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;

uint hwSarHCFpgaGetBoardTemp(int param_1)
{
  int in_zero;
  uint uVar1;
  int iVar2;
  uint32_t uStack_30;
  uint32_t uVar3; // Modified: Added missing variable declaration
  
  uStack_30 = 0;
  iVar2 = 0;
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
    }
    else {
      iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
    }
  }
  if (*(char *)(iVar2 + 0x10c8f925) != -0x23) {
    iVar2 = 0;
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
      }
      else {
        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
      }
    }
    if (*(char *)(iVar2 + 0x10c8f925) != -0x12) {
      return 0xffffff81;
    }
  }
  if (param_1 - 1U < 2) {
                    /* WARNING: Subroutine does not return */
    intLockCore();
  }
  uVar3 = 0x3c;
  if (param_1 != 3) {
    uVar1 = 0;
    if (param_1 != 4) goto LAB_0296c890;
    uVar3 = 0x40;
  }
  hwSarmFpgaMciRead(0,uVar3,&uStack_30);
  uVar1 = uStack_30 & 0x7f80;
  // Modified: Replaced structure member access with bit operation
  if ((uStack_30 & 0x8000) != 0) {
    return ((int)uVar1 >> 7) + -0x100 >> 1 | 0xffffff00;
  }
LAB_0296c890:
  return (int)uVar1 >> 8;
}