#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Adjust typedef for 'code' type to match function signature
typedef uint (*code)(uint32_t, uint32_t, int);

// Modified: Add extern declarations for undeclared globals
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern void *fpgaI2CBaseCtlInit;

uint32_t csaEthResetWinpath4(int param_1,char param_2)
{
  int in_zero;
  uint uVar1;
  int iVar2;
  code *pcVar3;
  uint uVar4;
  uint32_t uVar5;
  char acStack_38 [8];
  int iStack_30;
  uint32_t uStack_2c;
  uint32_t uStack_28;
  uint32_t uStack_24;
  uint32_t uStack_20;
  
  if ((param_1 == 0) && (iVar2 = macMdaRemoved(*(uint32_t *)(in_zero + 8)), iVar2 == 0)) {
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return 0xffffffff;
      }
      iVar2 = traceTest(_MOD_MDADRV,0xa8c390c,4,0);
      if (iVar2 == 0) {
        return 0xffffffff;
      }
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8c390c,4,0,1,0xa8c389c);
    return 0xffffffff;
  }
  uVar5 = 1;
  if ((param_2 != '\0') && (uVar5 = 0x20000, param_2 != '\x01')) {
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return 0xffffffff;
      }
      iVar2 = traceTest(_MOD_MDADRV,0xa8c390c,4,0);
      if (iVar2 == 0) {
        return 0xffffffff;
      }
      uVar5 = *(uint32_t *)(param_1 + 8);
    }
    else {
      uVar5 = *(uint32_t *)(param_1 + 8);
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8c390c,4,0,1,0xa8c38ac,param_2,uVar5);
    return 0xffffffff;
  }
  uVar1 = fpgaI2CCtlInit(*(uint32_t *)(param_1 + 8),1,0,&fpgaI2CBaseCtlInit);
  iVar2 = xmacRedIsCardActive(*(uint32_t *)(param_1 + 8));
  if (iVar2 == 0) {
    return 0;
  }
  if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_MDADRV,0xa8c390c,1,0), iVar2 != 0)) {
    tracePrintVRtr(_MOD_MDADRV,0xa8c390c,1,0,1,0xa8c3920,*(uint32_t *)(param_1 + 8),
                   *(uint32_t *)(param_1 + 0x108));
  }
  if (((param_1 == 0) || (*(int *)(param_1 + 0x284) == 0)) ||
     (pcVar3 = *(code **)(*(int *)(param_1 + 0x284) + 8), pcVar3 == (code *)0x0)) {
    if (_traceEnabled == 0) {
      if ((_tracepointsActive == 0) || (iVar2 = traceTest(_MOD_MDADRV,0xa8c390c,4,0), iVar2 == 0))
      goto LAB_063555b0;
      uVar5 = *(uint32_t *)(param_1 + 8);
    }
    else {
      uVar5 = *(uint32_t *)(param_1 + 8);
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8c390c,4,0,1,0xa8c37e8,uVar5,*(uint32_t *)(param_1 + 0x108));
    taskDelay(1);
    if (_tracepointsActive != 0) goto LAB_06355814;
    uVar5 = *(uint32_t *)(param_1 + 0xe8);
  }
  else {
    uVar1 = (*pcVar3)(*(uint32_t *)(param_1 + 8),uVar5,1);
LAB_063555b0:
    taskDelay(1);
    if (_tracepointsActive == 0) {
      uVar5 = *(uint32_t *)(param_1 + 0xe8);
    }
    else {
LAB_06355814:
      iVar2 = traceTest(_MOD_MDADRV,0xa8c390c,1,0);
      if (iVar2 == 0) {
        uVar5 = *(uint32_t *)(param_1 + 0xe8);
      }
      else {
        tracePrintVRtr(_MOD_MDADRV,0xa8c390c,1,0,1,0xa8c3814,*(uint32_t *)(param_1 + 8),
                       *(uint32_t *)(param_1 + 0x108));
        uVar5 = *(uint32_t *)(param_1 + 0xe8);
      }
    }
  }
  semGive(uVar5);
  memset(&iStack_30,0,0x14);
  iVar2 = wpCsaGetBootLoadInfo(*(uint32_t *)(param_1 + 8),param_2,&iStack_30);
  if (iVar2 == 0) {
    uVar4 = wpCsaResetCfgCheck(*(uint32_t *)(param_1 + 8),param_2,&iStack_30,acStack_38);
    if ((uVar1 | uVar4) == 0) {
      if (acStack_38[0] == '\0') {
        if (iStack_30 != 0) {
          wpCsaWriteResetCfg(*(uint32_t *)(param_1 + 8),param_2,iStack_30,uStack_2c,uStack_28,
                             uStack_24,uStack_20);
        }
        uVar5 = *(uint32_t *)(param_1 + 0xe8);
      }
      else {
        uVar5 = *(uint32_t *)(param_1 + 0xe8);
      }
    }
    else {
      uVar5 = *(uint32_t *)(param_1 + 0xe8);
    }
                    /* WARNING: Subroutine does not return */
    semTake(uVar5,0xffffffff);
  }
  if (_traceEnabled == 0) {
    if (_tracepointsActive == 0) {
      uVar5 = *(uint32_t *)(param_1 + 0xe8);
    }
    else {
      iVar2 = traceTest(_MOD_MDADRV,0xa8c390c,4,0);
      if (iVar2 != 0) {
        uVar5 = *(uint32_t *)(param_1 + 8);
        goto LAB_06355b20;
      }
      uVar5 = *(uint32_t *)(param_1 + 0xe8);
    }
                    /* WARNING: Subroutine does not return */
    semTake(uVar5,0xffffffff);
  }
  uVar5 = *(uint32_t *)(param_1 + 8);
LAB_06355b20:
  tracePrintVRtr(_MOD_MDADRV,0xa8c390c,4,0,1,0xa8c38dc,uVar5);
                    /* WARNING: Subroutine does not return */
  semTake(*(uint32_t *)(param_1 + 0xe8),0xffffffff);
}