#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char TunlMergeReturnStr[100]; // Modified: Added array size to resolve compilation error
extern char isisTitleStr[];

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint32_t isisMergeTunnelsForSameOutIntf(uint32_t *param_1,int param_2,int param_3)
{
  char cVar1;
  int iVar2;
  int iVar3;
  uint32_t uVar4;
  int aiStack_20 [2];
  
  aiStack_20[0] = 0;
  cVar1 = *(char *)(param_3 + 0x28);
  iVar2 = mergeTunnelsForSameOutIntf
                    (*(uint32_t *)(param_2 + 0x24),param_2 + 0x2c,*(uintptr_t *)(param_2 + 0x28),
                     param_3 + 0x24,param_3 + 0x2c,param_3 + 0x28,aiStack_20);
  if ((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x100) != 0)) {
    iVar3 = isisDebugCheck(param_1,0x100,0,0);
    if (iVar3 != 0) {
      if (_IsisLogger == 0) {
        tracePrint(_MOD_ISIS,0xa1b1f08,0,0,0xa1b1f28,*(uint32_t *)(param_2 + 0x24),
                   *(uint32_t *)(param_3 + 0x24),*(uintptr_t *)(param_2 + 0x28),
                   *(uintptr_t *)(param_3 + 0x28),
                   *(uint32_t *)(&TunlMergeReturnStr + aiStack_20[0] * 4),
                   *(uint32_t *)(&TunlMergeReturnStr + iVar2 * 4));
      }
      else {
        logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1f28,
                           *(uint32_t *)(param_2 + 0x24),*(uint32_t *)(param_3 + 0x24),
                           *(uintptr_t *)(param_2 + 0x28),*(uintptr_t *)(param_3 + 0x28),
                           *(uint32_t *)(&TunlMergeReturnStr + aiStack_20[0] * 4),
                           *(uint32_t *)(&TunlMergeReturnStr + iVar2 * 4));
      }
    }
  }
  uVar4 = 1;
  if ((cVar1 != '\0') || (*(char *)(param_3 + 0x28) == '\0')) {
    uVar4 = 0;
  }
  return uVar4;
}