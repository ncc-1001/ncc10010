#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int configureRouterISISLSpWaitHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t *puStack_30;

  uint32_t *puStack_2c;

  uint32_t *puStack_28;

  uint32_t *puStack_24;

  

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_30);

  uVar3 = 0;

  uVar4 = 0;

  uVar5 = 0;

  if (iVar1 == 0) {

    uVar3 = *puStack_30;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,&puStack_2c);

  if (iVar1 != 0) {

    return iVar1;

  }

  uVar2 = *puStack_2c;

  iVar1 = RCC_DB_RetrieveParam(param_2,0,4,&puStack_28);

  if (iVar1 == 0) {

    uVar4 = *puStack_28;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,8,&puStack_24);

  if (iVar1 == 0) {

    uVar5 = *puStack_24;

  }

  iVar1 = configRouterIsisLspWait(param_1,uVar3,uVar2,uVar4,uVar5);

  return iVar1;

}



