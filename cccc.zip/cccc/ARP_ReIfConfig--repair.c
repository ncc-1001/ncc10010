#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_ATIC_L3;

uint32_t ARP_ReIfConfig(uint32_t param_1,uint32_t param_2,int param_3)
{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  
  ARP_Lock();
  iVar2 = arp_getObj(param_1);
  if ((iVar2 == 0) || (iVar3 = arp_getIf(iVar2,param_2), iVar3 == 0)) {
    ARP_UnLock();
    if ((_traceEnabled != 0) ||
       ((_tracepointsActive != 0 && (iVar2 = traceTest(_MOD_ATIC_L3,0x9f6552c,4,7), iVar2 != 0)))) {
      tracePrintVRtr(_MOD_ATIC_L3,0x9f6552c,4,7,1,0x9f6366c,param_2);
    }
    return 3;
  }
  if ((_tracepointsActive != 0) && (iVar6 = traceTest(_MOD_ATIC_L3,0x9f6552c,1,7), iVar6 != 0)) {
    tracePrintVRtr(_MOD_ATIC_L3,0x9f6552c,1,7,1,0x9f6553c,*(uint32_t *)(param_3 + 0x3c),
                   *(uint32_t *)(param_3 + 0x40),*(uint32_t *)(param_3 + 0x44));
  }
  strncpy(iVar3 + 0x68,param_3,0x20);
  *(uintptr_t *)(iVar3 + 0x87) = 0;
  *(uint32_t *)(iVar3 + 0x3c) = *(uint32_t *)(param_3 + 0x20);
  *(uint32_t *)(iVar3 + 0x40) = *(uint32_t *)(param_3 + 0x24);
  *(uint32_t *)(iVar3 + 0x44) = *(uint32_t *)(param_3 + 0x28);
  *(uint32_t *)(iVar3 + 0x4c) = *(uint32_t *)(param_3 + 0x2c);
  *(char *)(iVar3 + 0x9b) = (char)*(uint32_t *)(param_3 + 0x30);
  *(uint32_t *)(iVar3 + 0x50) = *(uint32_t *)(param_3 + 0x34);
  uVar4 = *(uint *)(param_3 + 0x38) & 0xfffffffe;
  if ((*(byte *)(iVar3 + 0x67) & 1) != 0) {
    uVar4 = uVar4 | 1;
  }
  *(uint *)(iVar3 + 100) = uVar4;
  iVar7 = *(int *)(iVar3 + 0x88);
  iVar6 = *(int *)(param_3 + 0x3c);
  if (iVar7 == iVar6) {
    cVar1 = *(char *)(iVar3 + 0x9a);
  }
  else {
    *(int *)(iVar3 + 0x88) = iVar6;
    arpTimerCalculate(*(uint32_t *)(iVar2 + 0x3c),iVar6,iVar3 + 0x8c);
    iVar6 = *(int *)(iVar3 + 0x5c);
    if (iVar6 == 0) {
      iVar6 = *(int *)(param_3 + 0x40);
    }
    else {
      do {
        iVar5 = *(int *)(iVar6 + 0xb4);
        while (iVar5 == 2) {
          uVar4 = *(uint *)(iVar3 + 0x88);
          if (iVar7 == 0) {
            *(uint *)(iVar6 + 0x8c) = uVar4;
          }
          else {
            if (*(uint *)(iVar6 + 0x8c) <= uVar4) {
              iVar6 = *(int *)(iVar6 + 0x14);
              goto LAB_0369ade4;
            }
            *(uint *)(iVar6 + 0x8c) = uVar4;
          }
          iVar6 = *(int *)(iVar6 + 0x14);
          if (iVar6 == 0) {
            iVar6 = *(int *)(param_3 + 0x40);
            goto LAB_0369ae24;
          }
          iVar5 = *(int *)(iVar6 + 0xb4);
        }
        iVar6 = *(int *)(iVar6 + 0x14);
LAB_0369ade4:;
        // Modified: Added empty statement after label to fix syntax error
      } while (iVar6 != 0);
      iVar6 = *(int *)(param_3 + 0x40);
    }
LAB_0369ae24:
    if (iVar6 == 0) {
      iVar6 = 5;
    }
    *(int *)(iVar3 + 0x90) = iVar6;
    iVar6 = *(int *)(param_3 + 0x44);
    if (iVar6 == 0) {
      iVar6 = 1;
    }
    *(int *)(iVar3 + 0x94) = iVar6;
    cVar1 = *(char *)(iVar3 + 0x9a);
  }
  if (cVar1 != *(char *)(param_3 + 0x58)) {
    _updateArpPopulateState(iVar2,iVar3);
  }
  memcpy(iVar3 + 0x154,param_3 + 0x48,6);
  memcpy(iVar3 + 0x15a,param_3 + 0x4e,6);
  *(uint32_t *)(iVar3 + 0x160) = *(uint32_t *)(param_3 + 0x54);
  ARP_UnLock();
  return 0;
}