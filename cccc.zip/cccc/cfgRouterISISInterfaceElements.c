#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int cfgRouterISISInterfaceElements

              (uint32_t param_1,int param_2,int param_3,int param_4,uint32_t param_5,int param_6

              ,uint param_7)



{

  int iVar1;

  int iVar2;

  uintptr_t auStack_7f0 [1000];

  uintptr_t auStack_408 [1000];

  

  if ((param_2 == 0 || param_3 == 0) || (param_4 == 0 || param_6 == 0)) {

    timosAssert(0xa07ce14,0xa07cd10,0x1a9,0xa07cdf4,0xa07cd74);

  }

  if ((param_7 & 1) == 0) {

    iVar1 = getISISIfIndexBuf(param_1,param_2,param_3,auStack_408,1000);

  }

  else {

    iVar1 = getISISCircIndexBuf(param_1,param_2,param_3,auStack_408,1000);

  }

  iVar2 = 2;

  if (iVar1 == 1) {

    snprintf(auStack_7f0,1000,0xa07ce68,param_4,auStack_408);

    iVar1 = RCC_RCB_WriteValueToRCB(param_1,auStack_7f0,param_5,param_6);

    iVar2 = -(uint)(iVar1 < 0);

  }

  return iVar2;

}



