#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added proper typedef for function pointer type 'code'
typedef uint32_t (*code)(uint32_t, uint32_t, uintptr_t*);

// Modified: Added extern declaration for global variable
extern int _runtime_feature_7705isis;

uint32_t

isisGenerateGracefulRestartConfig

          (code *param_1,uint32_t param_2,uint32_t param_3,char param_4,char param_5,int param_6

          ,int param_7)


{
  int iVar1;
  uint32_t uVar2;
  uintptr_t auStack_2c0 [64];
  uint32_t auStack_280 [119];
  int iStack_a4;
  
  iVar1 = timosMgmtIsInDebugMode();
  if ((iVar1 != 0) || (_runtime_feature_7705isis == 0)) {
    auStack_280[0] = 1;
    iVar1 = sia_vRtrIsisEntryGet(1,auStack_280);
    if (iVar1 == 0) {
      blankStrInit(auStack_2c0,param_6);
      if (iStack_a4 == 1) {
        if (param_5 == '\0') {
          (*param_1)(param_2,0xa1a9144,auStack_2c0);
        }
        isisGenerateGRHelperConfig
                  (param_1,param_2,auStack_280[0],param_4,param_5,param_6 + param_7,param_7);
        uVar2 = (*param_1)(param_2,0xa1a9074,auStack_2c0);
      }
      else if (param_4 == '\0') {
        uVar2 = 0;
      }
      else {
        uVar2 = (*param_1)(param_2,0xa1a912c,auStack_2c0);
      }
      return uVar2;
    }
  }
  return 0;
}