#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for undeclared global variable
extern uint32_t _gFpgaSarmSharedMem;

void fpgaSarmPcieRead(uint32_t param_1,uint32_t param_2)

{

  if (_gFpgaSarmSharedMem != 0) {

    fpgaSarmSharedMemRead();

    return;

  }

  hwSarmFpgaReadReg32(param_2);

  return;

}