#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendAreaMismatchTrap

               (uint32_t *param_1,uint32_t param_2,int param_3,uint32_t param_4,int param_5)



{

  uint32_t uVar1;

  uint32_t uVar2;

  uintptr_t auStack_1a8 [400];

  

  auStack_1a8[0] = 0;

  if (0x40 < param_5) {

    param_5 = 0x40;

  }

  logger_OctetsHexDump(param_4,param_5,auStack_1a8,400);

  uVar1 = strlen(auStack_1a8);

  uVar2 = *param_1;

  logEvent_ISIS_vRtrIsisAreaMismatch

            (uVar2,0xa1bbb9c,uVar2,0,param_2,uVar2,*(uint32_t *)(param_3 + 8),param_4,param_5,

             auStack_1a8,uVar1);

  return;

}



