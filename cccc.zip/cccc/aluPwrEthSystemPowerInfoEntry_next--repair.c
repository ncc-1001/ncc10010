#include "nokia.h"
#include <stdint.h>

extern uint32_t uRam0c2b5680; // Modified: Added extern declaration for undeclared variable

void aluPwrEthSystemPowerInfoEntry_next
               (uint32_t param_1,int param_2,uint32_t param_3,uint32_t param_4,
               uint32_t *param_5)
{
  int iVar1;
  uint32_t auStack_18 [2];
  
  group_by_getproc_and_instance(param_4,param_5,param_2,param_3);
  if (param_2 == 0) {
    iVar1 = sia_aluPwrEthSystemPowerInfoEntryGet(2,0xc2b5680);
    if (iVar1 == 0x66 || iVar1 == 0x68) {
      for (; param_5 != (uint32_t *)0x0; param_5 = (uint32_t *)*param_5) {
        nextproc_no_next(param_4,param_5);
      }
      return;
    }
    if (iVar1 != 0) {
      for (; param_5 != (uint32_t *)0x0; param_5 = (uint32_t *)*param_5) {
        nextproc_error(param_4,param_5,5);
      }
      return;
    }
    auStack_18[0] = uRam0c2b5680;
    while (param_5 != (uint32_t *)0x0) {
      iVar1 = FUN_03306bc4(param_5[6],param_4,param_5,0xc2b5680);
      if (iVar1 == 0) {
        nextproc_next_instance(param_4,param_5,1);
        param_5 = (uint32_t *)*param_5;
      }
      else {
        nextproc_error(param_4,param_5,iVar1,auStack_18);
        param_5 = (uint32_t *)*param_5;
      }
    }
  }
  else {
    for (; param_5 != (uint32_t *)0x0; param_5 = (uint32_t *)*param_5) {
      nextproc_no_next(param_4,param_5);
    }
  }
  return;
}