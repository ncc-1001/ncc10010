#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _traceEnabled;
extern void* csaEthMixeFpgaHwApi;
extern void* csaEthMixeNpHwApi;
extern void* csaEthXgigMdioCtlHwApi;
extern void* csaEthMixeSyncHwApi;

// Modified: Updated 'code' type to match actual usage in the code
typedef int (*code)(uint32_t, uint32_t, int);

int csaEthMixeHwFpgaInit(int param_1)
{
  uintptr_t *puVar1;
  uint32_t uVar2;
  int iVar3;
  code *pcVar4;
  int iVar5;
  
  puVar1 = (uintptr_t *)csaEthGetMda(*(uint32_t *)(param_1 + 8),0);
  if ((_tracepointsActive != 0) && (iVar3 = traceTest(_MOD_MDADRV,0xa8eaf68,1,0), iVar3 != 0)) {
    tracePrintVRtr(_MOD_MDADRV,0xa8eaf68,1,0,1,0xa8eaf90,*(uint32_t *)(param_1 + 8),
                   *(uint32_t *)(param_1 + 0x108),*(uint32_t *)(param_1 + 4));
  }
  if (puVar1 == (uintptr_t *)0x0) {
    iVar3 = -1;
  }
  else {
    *puVar1 = 1;
    *(uintptr_t **)(puVar1 + 4) = &csaEthMixeFpgaHwApi;
    *(uintptr_t **)(puVar1 + 8) = &csaEthMixeNpHwApi;
    uVar2 = mdaGpioApiGet(*(uint32_t *)(param_1 + 0x108));
    *(uint32_t *)(param_1 + 0x284) = uVar2;
    *(uintptr_t **)(puVar1 + 0x10) = &csaEthXgigMdioCtlHwApi;
    *(uintptr_t ***)(puVar1 + 0xc) = &csaEthMixeSyncHwApi;
    memset(puVar1 + 0x18,0,0x3a48);
    memset(puVar1 + 0x3a60,0,0xc);
    puVar1[0x3a74] = 0;
    iVar3 = modMalloc(0x49c,_MOD_MDADRV);
    if (iVar3 == 0) {
      iVar3 = macMdaRemoved(*(uint32_t *)(param_1 + 8));
      if (iVar3 != 0) {
        return -1;
      }
      if (_traceEnabled == 0) {
        if (_tracepointsActive == 0) {
          return -1;
        }
        iVar3 = traceTest(_MOD_MDADRV,0xa8eaf68,4,0);
        if (iVar3 == 0) {
          return -1;
        }
        uVar2 = *(uint32_t *)(param_1 + 8);
      }
      else {
        uVar2 = *(uint32_t *)(param_1 + 8);
      }
      tracePrintVRtr(_MOD_MDADRV,0xa8eaf68,4,0,1,0xa8eafb4,uVar2);
      return -1;
    }
    *(int *)(puVar1 + 0x3a6c) = iVar3;
    memset(iVar3,0,0x49c);
    **(uintptr_t **)(puVar1 + 0x3a6c) = 2;
    if (param_1 == 0) {
      return 0;
    }
    if (*(code ***)(param_1 + 0x284) == (code **)0x0) {
      return 0;
    }
    pcVar4 = **(code ***)(param_1 + 0x284);
    if (pcVar4 == (code *)0x0) {
      return 0;
    }
    iVar3 = (*pcVar4)(*(uint32_t *)(param_1 + 8),*(uint32_t *)(param_1 + 0x108),1);
    if (iVar3 == 0) {
      return 0;
    }
  }
  iVar5 = macMdaRemoved(*(uint32_t *)(param_1 + 8));
  if (iVar5 == 0) {
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return iVar3;
      }
      iVar5 = traceTest(_MOD_MDADRV,0xa8eaf68,4,0);
      if (iVar5 == 0) {
        return iVar3;
      }
      uVar2 = *(uint32_t *)(param_1 + 8);
    }
    else {
      uVar2 = *(uint32_t *)(param_1 + 8);
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8eaf68,4,0,1,0xa8eaf80,uVar2);
  }
  return iVar3;
}