#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr[];

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisRedSendIpReassignRouteDbToInactive

               (int *param_1,uint32_t *param_2,uint param_3,uint32_t param_4,uint param_5)



{

  uint uVar1;

  uint uVar2;

  int iVar3;

  uint uStack_50;

  uint32_t uStack_4c;

  uint32_t uStack_48;

  uint32_t uStack_44;

  uint32_t uStack_40;

  uint32_t uStack_3c;

  uintptr_t uStack_38;

  uintptr_t uStack_36;

  uint32_t uStack_34;

  uint32_t uStack_30;

  uint32_t uStack_2c;

  uint32_t uStack_28;

  uint32_t uStack_24;

  uint32_t uStack_20;

  uint32_t uStack_1c;

  

  if (param_1[0x842] == 0) {

    memset(&uStack_50,0,0x38);

    uVar2 = (param_3 & 7) << 0x16;

    uVar1 = (param_5 & 3) << 0x14;

    uStack_2c = param_4;

    if (param_2 != (uint32_t *)0x0) {

      uStack_4c = *param_2;

      uStack_48 = param_2[1];

      uStack_44 = param_2[2];

      uStack_40 = param_2[3];

      uStack_3c = param_2[4];

      uStack_38 = *(uintptr_t *)(param_2 + 5);

      uStack_34 = param_2[6];

      uStack_36 = (uintptr_t)param_2[7];

      if ((param_2[0xc] & 0x1000) == 0) {

        uStack_30 = param_2[0xb];

      }

      else {

        uStack_30 = param_2[10];

      }

      iVar3 = param_2[0xd];

      uStack_50 = uStack_50 & 0x40001 | *param_1 << 0x1c | 0x4000000 | uVar2 | uVar1 |

                  (param_2[0xc] & 0x3000) << 1;

      if (iVar3 != 0) {

        if (param_5 == 2) {

          uStack_20 = *(uint32_t *)(iVar3 + 4);

          uStack_1c = *(uint32_t *)(iVar3 + 8);

        }

        else {

          uStack_28 = *(uint32_t *)(iVar3 + 4);

          uStack_24 = *(uint32_t *)(iVar3 + 8);

        }

      }

      redSendUpdate(0x34,0xe,&uStack_50,0x38);

      return;

    }

    if (((param_1[0x1b] & 0x100000U) != 0) &&

       (uStack_50 = uStack_50 & 0xdffff | *param_1 << 0x1c | 0x4000000 | uVar2 | uVar1,

       iVar3 = isisDebugCheck(param_1,0x100000,0,0), iVar3 != 0)) {

      if (_IsisLogger == 0) {

        tracePrint(_MOD_ISIS,0xa1ad3c0,0,0,0xa1ad374);

      }

      else {

        logEvent_debug_fmt(*param_1,0xa1ac4d0,&isisTitleStr,0xa1ad374);

      }

    }

  }

  return;

}