#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for missing global variables
extern int _IsisLogger;
extern uint32_t _MOD_ISIS;
extern char *isisTitleStr;
extern char *isisReachStr;
extern char *isisLevelStr;

// Modified: Added structure definition for iStack_90 access
typedef struct {
    char _0_1_;
    // Other members if needed
} iStack90_struct;

void isisSpfAddReach(uint32_t *param_1,uint32_t param_2,int param_3,int param_4,

                    uint32_t param_5,uint param_6,uint32_t param_7,uint32_t param_8,

                    uint32_t param_9,int param_10,uint param_11,int param_12,int param_13,

                    int param_14,uint param_15,int param_16)

{

  byte bVar1;
  bool bVar2;
  uintptr_t uVar7;
  int iVar3;
  int *piVar4;
  int *piVar5;
  int iVar6;
  uint *puVar8;
  uint32_t uVar9;
  uint *puVar10;
  uint uVar11;
  uint uVar12;
  char cStack_a8;
  uint uStack_a4;
  uint32_t uStack_a0;
  uint32_t uStack_9c;
  uint32_t uStack_98;
  // Modified: Changed declaration to use structure for member access
  union {
    int asInt;
    iStack90_struct asStruct;
  } iStack_90;
  uint uStack_8c;
  int iStack_88;
  int iStack_84;
  int iStack_80;
  uintptr_t auStack_78 [8];
  uintptr_t auStack_70 [64];
  uint32_t uStack_30;
  uint32_t uStack_2c;
  
  iStack_90.asInt = param_10;
  iVar3 = iStack_90.asInt;
  cStack_a8 = (char)((uint)param_5 >> 0x18);
  uStack_a4 = param_6;
  uStack_a0 = param_7;
  // Modified: Using structure access instead of direct member access
  iStack_90.asStruct._0_1_ = (char)((uint)param_10 >> 0x18);
  uStack_9c = param_8;
  uStack_98 = param_9;
  uStack_8c = param_11;
  iStack_88 = param_12;
  iStack_84 = param_13;
  iStack_80 = param_14;
  uVar12 = (uint)(cStack_a8 == '\0');
  uVar9 = 4;
  // Modified: Using structure access instead of direct member access
  if (iStack_90.asStruct._0_1_ == '\0') {
    uVar9 = 0x10;
  }
  iStack_90.asInt = iVar3;
  uVar7 = netMaskToLen6(&uStack_8c,uVar9);
  uVar9 = 4;
  if (uVar12 != 0) {
    uVar9 = 0x10;
  }
  auStack_78[0] = 0;
  if (param_3 == 1) {
    if (*(char *)((int)param_1 + 0x2059) != '\x01') goto LAB_04252970;
LAB_04252978:
    iVar3 = rtTableAddRoute(param_1[param_4 * 2 + uVar12 + 0x26b],&uStack_a4,uVar9,uVar7);
  }
  else {
    if (*(char *)((int)param_1 + 0x205a) == '\x01') goto LAB_04252978;
LAB_04252970:
    if (param_15 < 0x40) goto LAB_04252978;
    iVar3 = rtTableAddRoute(param_1[param_4 * 2 + uVar12 + 0x26b],&uStack_a4,uVar9,uVar7);
    param_15 = 0x3f;
  }
  if (iVar3 == 0) {
    isisHandleMemFail(param_1);
    if (param_1 == (uint32_t *)0x0) {
      return;
    }
    if ((param_1[0x1b] & 0x100) == 0) {
      return;
    }
    iVar3 = isisDebugCheck(param_1,0x100,param_3,0);
    if (iVar3 == 0) {
      return;
    }
    if (_IsisLogger == 0) {
      tracePrint(_MOD_ISIS,0xa1b18b4,0,0,0xa1b18c4);
      return;
    }
    logEvent_debug_fmt(*param_1,0xa1b10ac,isisTitleStr,0xa1b18c4);
    return;
  }
  bVar2 = param_3 != 1;
  uVar11 = (uint)bVar2;
  piVar4 = (int *)rtGetRouteInfo(iVar3);
  if (piVar4 == (int *)0x0) {
    param_1[0x7a1] = param_1[0x7a1] + 1;
  }
  else if (((((piVar4[0xb] & 0x20000000U) == 0) &&
            (piVar5 = (int *)piVar4[0xf], (int *)piVar4[0xf] != (int *)0x0)) ||
           (piVar5 = piVar4, (piVar4[0xb] & 0x20000000U) != 0)) && (piVar5 != (int *)0x0)) {
    iVar3 = isisSpfCheckNewPreferred(piVar5,uVar11,param_15,auStack_78);
    if (iVar3 == 0) {
      return;
    }
    if (param_1 == (uint32_t *)0x0) {
      *(bool *)((int)piVar5 + 0x2e) = bVar2;
    }
    else if ((param_1[0x1b] & 0x100) == 0) {
      *(bool *)((int)piVar5 + 0x2e) = bVar2;
    }
    else {
      iVar3 = isisDebugCheck(param_1,0x100,param_3,0);
      if (iVar3 == 0) {
        *(bool *)((int)piVar5 + 0x2e) = bVar2;
      }
      else if (_IsisLogger == 0) {
        uVar9 = isisXlateMtId(param_4);
        if (cStack_a8 == '\0') {
          FmtIp6Addr(&uStack_a4,auStack_70,0x40);
        }
        else {
          FmtIpAddr(uStack_a4,auStack_70,0x40);
        }
        tracePrint(_MOD_ISIS,0xa1b18b4,0,0,0xa1b193c,param_3,uVar9,auStack_70,uVar7,param_2,
                   isisReachStr,isisLevelStr);
        *(bool *)((int)piVar5 + 0x2e) = bVar2;
      }
      else {
        uVar9 = isisXlateMtId(param_4);
        if (cStack_a8 == '\0') {
          FmtIp6Addr(&uStack_a4,auStack_70,0x40);
        }
        else {
          FmtIpAddr(uStack_a4,auStack_70,0x40);
        }
        logEvent_debug_fmt(*param_1,0xa1b10ac,isisTitleStr,0xa1b193c,param_3,uVar9,auStack_70,uVar7
                           ,param_2,isisReachStr,isisLevelStr);
        *(bool *)((int)piVar5 + 0x2e) = bVar2;
      }
    }
    piVar5[0xd] = param_15;
    piVar5[0x10] = param_1[0x26f];
    piVar5[0xb] = piVar5[0xb] & 0xc0ffffff;
    piVar5[0xc] = param_16;
    memcpy(piVar5[0x12],param_1 + 8,6);
    *(bool *)((*(byte *)(piVar5 + 0xb) & 0x1f) * 0x6c + piVar5[0x12] + 8) = uVar12 == 0;
    iVar3 = (*(byte *)(piVar5 + 0xb) & 0x1f) * 0x6c + piVar5[0x12];
    if (*(char *)(iVar3 + 8) == '\0') {
      memset(iVar3 + 0xc,0,0x10);
      bVar1 = *(byte *)(piVar5 + 0xb);
    }
    else {
      *(uint32_t *)(iVar3 + 0xc) = 0;
      bVar1 = *(byte *)(piVar5 + 0xb);
    }
    *(uint32_t *)((bVar1 & 0x1f) * 0x6c + piVar5[0x12] + 0x1c) = param_2;
    goto LAB_04252d30;
  }
  piVar5 = (int *)isisSpfIpReachAlloc(param_1);
  if (piVar5 == (int *)0x0) {
    return;
  }
  if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x100) != 0)) &&
     (iVar6 = isisDebugCheck(param_1,0x100,param_3,0), iVar6 != 0)) {
    if (_IsisLogger == 0) {
      uStack_2c = isisXlateMtId(param_4);
      if (cStack_a8 == '\0') {
        FmtIp6Addr(&uStack_a4,auStack_70,0x40);
      }
      else {
        FmtIpAddr(uStack_a4,auStack_70,0x40);
      }
      tracePrint(_MOD_ISIS,0xa1b18b4,0,0,0xa1b18e8,param_3,uStack_2c,param_2,auStack_70,uVar7,
                 isisReachStr,isisLevelStr);
    }
    else {
      uStack_30 = isisXlateMtId(param_4);
      if (cStack_a8 == '\0') {
        FmtIp6Addr(&uStack_a4,auStack_70,0x40);
      }
      else {
        FmtIpAddr(uStack_a4,auStack_70,0x40);
      }
      logEvent_debug_fmt(*param_1,0xa1b10ac,isisTitleStr,0xa1b18e8,param_3,uStack_30,param_2,
                         auStack_70,uVar7,isisReachStr,isisLevelStr);
    }
  }
  if (piVar4 == (int *)0x0) {
    rtSetRouteInfo(iVar3,piVar5);
    piVar5[0xb] = piVar5[0xb] | 0x20000000;
    piVar5[0x10] = param_1[0x26f];
  }
  else {
    piVar5[0xb] = piVar5[0xb] & 0xdfffffff;
    piVar4[0xf] = (int)piVar5;
  }
  *piVar5 = (int)param_1;
  piVar5[0x11] = param_1[0x815];
  puVar10 = &uStack_a4;
  if (cStack_a8 == '\0') {
    puVar8 = &uStack_8c;
    *(uintptr_t *)(piVar5 + 1) = 0;
    piVar4 = piVar5 + 2;
    iVar3 = 0xf;
    do {
      bVar1 = *(byte *)puVar8;
      iVar3 = iVar3 + -1;
      puVar8 = (uint *)((int)puVar8 + 1);
      *(byte *)piVar4 = *(byte *)puVar10 & bVar1;
      puVar10 = (uint *)((int)puVar10 + 1);
      piVar4 = (int *)((int)piVar4 + 1);
    } while (-1 < iVar3);
  }
  else {
    *(uintptr_t *)(piVar5 + 1) = 1;
    piVar5[2] = uStack_a4 & uStack_8c;
  }
  piVar5[0xb] = piVar5[0xb] & 0x7fffffffU | param_4 << 0x1f;
  *(bool *)((int)piVar5 + 0x2e) = bVar2;
  piVar5[6] = iStack_90.asInt;
  piVar5[7] = uStack_8c;
  piVar5[8] = iStack_88;
  piVar5[10] = iStack_80;
  piVar5[9] = iStack_84;
  piVar5[0xd] = param_15;
  piVar5[0x10] = param_1[0x26f];
  piVar5[0xb] = piVar5[0xb] & 0xe0ffffff;
  piVar5[0xc] = param_16;
  memcpy(piVar5[0x12],param_1 + 8,6);
  *(bool *)((*(byte *)(piVar5 + 0xb) & 0x1f) * 0x6c + piVar5[0x12] + 8) = uVar12 == 0;
  iVar3 = (*(byte *)(piVar5 + 0xb) & 0x1f) * 0x6c + piVar5[0x12];
  if (*(char *)(iVar3 + 8) == '\0') {
    memset(iVar3 + 0xc,0,0x10);
    bVar1 = *(byte *)(piVar5 + 0xb);
  }
  else {
    *(uint32_t *)(iVar3 + 0xc) = 0;
    bVar1 = *(byte *)(piVar5 + 0xb);
  }
  *(uint32_t *)((bVar1 & 0x1f) * 0x6c + piVar5[0x12] + 0x1c) = param_2;
LAB_04252d30:
  piVar5[0xb] = piVar5[0xb] & 0xe0ffffffU | (((uint)piVar5[0xb] >> 0x18 & 0x1f) + 1 & 0x1f) << 0x18;
  return;
}