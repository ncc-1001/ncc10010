#include "nokia.h"
#include <stdint.h>

// Modified: Added typedef for 'code' as it was undefined but used as a function pointer type
typedef uint32_t (*code)(uint32_t, uint32_t, uintptr_t*, uint32_t);

uint32_t

isisGenerateMultiTopoConfig

          (code *param_1,uint32_t param_2,uint32_t param_3,char param_4,uint32_t param_5,

          int param_6,int param_7)



{
  int iVar1;
  uint32_t uVar2;
  uintptr_t auStack_2b0 [64];
  uint32_t auStack_270 [141];
  char cStack_3b;
  
  auStack_270[0] = 1;
  iVar1 = sia_vRtrIsisEntryGet(1,auStack_270);
  uVar2 = 0;
  if (iVar1 != 0) {
    return 0;
  }
  blankStrInit(auStack_2b0,param_6 + param_7);
  if (cStack_3b != '\x02' || param_4 != '\0') {
    uVar2 = 0xa1a8f50;
    if (cStack_3b != '\x01') {
      uVar2 = 0xa1a8f54;
    }
    uVar2 = (*param_1)(param_2,0xa1a8f3c,auStack_2b0,uVar2);
  }
  return uVar2;
}