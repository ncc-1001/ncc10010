#include "nokia.h"
#include <stdint.h>

// Added: Declaration for undeclared variable uRam0aee36c8
extern uint32_t uRam0aee36c8;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


void handlePwe3TdmChangedEvents(uint16_t *param_1)

{

  ushort uVar1;

  ushort uVar2;

  ushort uVar3;

  bool bVar4;

  int iVar5;

  int iVar6;

  uint16_t uVar7;

  uint32_t uVar8;

  ushort *puVar9;

  uint16_t *puVar10;

  int iVar11;

  uint auStack_180 [92];
  
  if (param_1 == (uint16_t *)0x0) {
    return;
  }
  iVar5 = posMdaTribGetFwdChan();
  iVar6 = posMdaTribGetSapConfig(param_1);
  puVar9 = *(ushort **)(param_1 + 0x4d2);
  uVar1 = puVar9[1];
  uVar2 = *puVar9;
  iVar11 = *(int *)(*(int *)(param_1 + 0xc) + 4);
  if (iVar5 == 0) {
    return;
  }
  uVar3 = *(ushort *)(iVar6 + 0x1c);
  if (uVar3 == 0) {
    return;
  }
  if (cRam10c8f925 == -5) {
    bVar4 = uVar3 < 0x2000;
  }
  else {
    bVar4 = uVar3 < 0x11a1;
    if (cRam10c8f925 != -2 && cRam10c8f925 != -0x18) {
      bVar4 = uVar3 < 0x301;
    }
  }
  if (!bVar4) {
    return;
  }
  *(uint *)(puVar9 + 0x178) = *(uint *)(puVar9 + 0x178) & 0x7fffffff | (uint)(*puVar9 >> 2) << 0x1f;
  puVar9 = *(ushort **)(param_1 + 0x4d2);
  *(uint *)(puVar9 + 0x178) = *(uint *)(puVar9 + 0x178) & 0xbfffffff | (*puVar9 >> 4 & 1) << 0x1e;
  puVar9 = *(ushort **)(param_1 + 0x4d2);
  *(uint *)(puVar9 + 0x178) = *(uint *)(puVar9 + 0x178) & 0xcfffffff | (*puVar9 >> 5 & 2) << 0x1c;
  iVar5 = *(int *)(param_1 + 0x4d2);
  if (*(int *)(iVar5 + 0x18) == *(int *)(iVar5 + 0x14)) {
    *(byte *)(iVar5 + 0x2f1) = ~*(byte *)(iVar5 + 0x2f0);
    iVar5 = *(int *)(param_1 + 0x4d2);
  }
  setPwe3AlarmBits(uVar2 & uVar1,iVar5 + 0x10);
  puVar10 = *(uint16_t **)(param_1 + 0x4d2);
  auStack_180[0] = (uint)(ushort)puVar10[8];
  if (*(int *)(puVar10 + 0xc) != *(int *)(puVar10 + 10)) {
    if (auStack_180[0] == (ushort)puVar10[9]) {
      uVar7 = *puVar10;
      goto LAB_064b9260;
    }
    if ((uint)(_vxAbsTicks - *(int *)(puVar10 + 6)) < 0x1a) {
      uVar7 = *puVar10;
      goto LAB_064b9260;
    }
  }
  if (_tracepointsActive == 0) {
    uVar8 = *(uint32_t *)(param_1 + 0xc);
  }
  else {
    iVar5 = traceTest(_MOD_MDADRV,0xa96891c,1,0);
    if (iVar5 == 0) {
      uVar8 = *(uint32_t *)(param_1 + 0xc);
    }
    else {
      tracePrintVRtr(_MOD_MDADRV,0xa96891c,1,0,1,0xa964fa8,uRam0aee36c8,
                     *(uint16_t *)(*(int *)(param_1 + 0x4d2) + 0x10),
                     *(uint16_t *)(*(int *)(param_1 + 0x4d2) + 0x12),
                     *(uint32_t *)(iVar11 + 0x36ca24),
                     *(int *)(*(int *)(param_1 + 0xc) + 0xcb8) + 1,*param_1);
      uVar8 = *(uint32_t *)(param_1 + 0xc);
    }
  }
  posPortEventFn(uVar8,1,*param_1,0x12,auStack_180,1);
  *(int *)(*(int *)(param_1 + 0x4d2) + 0xc) = _vxAbsTicks;
  *(uint16_t *)(*(int *)(param_1 + 0x4d2) + 0x12) =
       *(uint16_t *)(*(int *)(param_1 + 0x4d2) + 0x10);
  *(uint32_t *)(*(int *)(param_1 + 0x4d2) + 0x18) = 10;
  puVar10 = *(uint16_t **)(param_1 + 0x4d2);
  uVar7 = *puVar10;
LAB_064b9260:
  puVar10[2] = uVar7;
  return;
}