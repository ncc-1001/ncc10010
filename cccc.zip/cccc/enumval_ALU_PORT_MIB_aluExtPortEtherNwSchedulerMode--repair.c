#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern int iRam0b6fb910;
extern uint32_t uRam0b6fb914;

int enumval_ALU_PORT_MIB_aluExtPortEtherNwSchedulerMode(int param_1,uint32_t param_2,int param_3)
{
  int iVar1;

  if (param_3 == 1) {
    iVar1 = 0x9f5ebe8;

LAB_036526f8:
    if (param_1 != 0) {
      snprintf(param_1,param_2,0x9f4ee10,iVar1);
      iVar1 = param_1;
    }
  }
  else {
    if (param_3 < 2) {
      iVar1 = 0x9f5b85c;
      if (param_3 == 0) goto LAB_036526f8;
    }
    else if (param_3 == 2) {
      iVar1 = 0x9f5ebf8;
      goto LAB_036526f8;
    }
    if (param_1 == 0) {
      return iRam0b6fb910;
    }
    snprintf(param_1,param_2,uRam0b6fb914,iRam0b6fb910,param_3);
    iVar1 = param_1;
  }
  return iVar1;
}