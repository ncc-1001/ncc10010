#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t

getISISCircLevelIndexBuf

          (uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,

          uint32_t param_5,uint32_t param_6)



{

  int iVar1;

  int iVar2;

  uint32_t uVar3;

  int aiStack_20 [2];

  

  iVar1 = getVRtrId();

  if (iVar1 != 0) {

    aiStack_20[0] = pipGetRtrIfIndex(iVar1,param_3);

    if (aiStack_20[0] == 0) {

      uVar3 = 0xa07cc68;

    }

    else {

      iVar2 = isisGetCircIdFromIfId(iVar1,aiStack_20[0],aiStack_20);

      uVar3 = 0xa07ccc4;

      if (iVar2 == 0) {

        snprintf(param_5,param_6,0xa07ccec,iVar1,aiStack_20[0],param_4);

        return 0;

      }

    }

    cliErrorMesg(param_1,uVar3,param_3);

  }

  return 0xffffffff;

}



