#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
// Modified: Added array bounds for isisReachStr and isisRtmActionStr
extern char isisReachStr[256];
extern char isisRtmActionStr[256];
extern char isisTitleStr[256];
extern int _gIsisRestart;
extern int _gIsisRtmMiss3;
extern int _gIsisRtmMiss4;
extern int _gIsisRtmFillFail;


void isisRtmRouteChanged(uint32_t *param_1,int param_2,int param_3,int param_4)

{

  char cVar1;

  bool bVar2;

  int iVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint uVar6;

  uintptr_t auStack_380 [800];

  uintptr_t auStack_60 [64];

  

  bVar2 = *(char *)(param_3 + 4) == '\0';

  uVar6 = (uint)bVar2;

  if ((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x800) == 0)) {

    iVar3 = param_1[0x808];

  }

  else {

    iVar3 = isisDebugCheck(param_1,0x800,param_3 + 4,0);

    if (iVar3 == 0) {

      iVar3 = param_1[0x808];

    }

    else if (_IsisLogger == 0) {

      if (*(char *)(param_3 + 4) == '\0') {

        FmtIp6Addr(param_3 + 8,auStack_60,0x40);

        cVar1 = *(char *)(param_3 + 0x18);

      }

      else {

        FmtIpAddr(*(uint32_t *)(param_3 + 8),auStack_60,0x40);

        cVar1 = *(char *)(param_3 + 0x18);

      }

      uVar4 = 4;

      if (cVar1 == '\0') {

        uVar4 = 0x10;

      }

      uVar4 = netMaskToLen6(param_3 + 0x1c,uVar4);

      tracePrint(_MOD_ISIS,0xa1afb4c,0,0,0xa1afb60,param_3,param_2,auStack_60,uVar4,

                 (&isisReachStr)[*(byte *)(param_3 + 0x2e)],*(uint *)(param_3 + 0x2c) >> 0x18 & 0x1f

                 ,*(uint32_t *)(param_3 + 0x30),*(uint32_t *)(&isisRtmActionStr + param_4 * 4));

      iVar3 = param_1[0x808];

    }

    else {

      if (*(char *)(param_3 + 4) == '\0') {

        FmtIp6Addr(param_3 + 8,auStack_60,0x40);

        cVar1 = *(char *)(param_3 + 0x18);

      }

      else {

        FmtIpAddr(*(uint32_t *)(param_3 + 8),auStack_60,0x40);

        cVar1 = *(char *)(param_3 + 0x18);

      }

      uVar4 = 4;

      if (cVar1 == '\0') {

        uVar4 = 0x10;

      }

      uVar4 = netMaskToLen6(param_3 + 0x1c,uVar4);

      logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1afb60,param_3,param_2,auStack_60,uVar4

                         ,(&isisReachStr)[*(byte *)(param_3 + 0x2e)],

                         *(uint *)(param_3 + 0x2c) >> 0x18 & 0x1f,*(uint32_t *)(param_3 + 0x30),

                         *(uint32_t *)(&isisRtmActionStr + param_4 * 4));

      iVar3 = param_1[0x808];

    }

  }

  if (iVar3 == 2) {

    _gIsisRestart = _gIsisRestart + 1;

    return;

  }

  iVar3 = isisRtmFillRouteInfo(param_1,param_3,auStack_380,param_4);

  if (iVar3 == 0) {

    if ((*(char *)(param_1 + 0x249) == '\x01' && !bVar2) ||

       (((uint)(*(char *)((int)param_1 + 0x926) != '\x01') | uVar6 ^ 1) == 0)) {

      _gIsisRtmMiss3 = _gIsisRtmMiss3 + 1;

    }

    else {

      iVar3 = isisRtmDoRouteChangedAction

                        (param_1[uVar6 * 7 + param_2 * 0xe + 0x22c],auStack_380,param_4);

      if (iVar3 != 0) {

        if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x800) == 0)) ||

           (iVar3 = isisDebugCheck(param_1,0x800,param_3 + 4,0), iVar3 == 0)) {

          isisHandleMemFail(param_1);

        }

        else if (_IsisLogger == 0) {

          if (*(char *)(param_3 + 4) == '\0') {

            FmtIp6Addr(param_3 + 8,auStack_60,0x40);

            cVar1 = *(char *)(param_3 + 0x18);

          }

          else {

            FmtIpAddr(*(uint32_t *)(param_3 + 8),auStack_60,0x40);

            cVar1 = *(char *)(param_3 + 0x18);

          }

          uVar4 = 4;

          if (cVar1 == '\0') {

            uVar4 = 0x10;

          }

          uVar4 = netMaskToLen6(param_3 + 0x1c,uVar4);

          tracePrint(_MOD_ISIS,0xa1afb4c,0,0,0xa1afc08,auStack_60,uVar4,

                     (&isisReachStr)[*(byte *)(param_3 + 0x2e)],

                     *(uint *)(param_3 + 0x2c) >> 0x18 & 0x1f,param_4);

          isisHandleMemFail(param_1);

        }

        else {

          if (*(char *)(param_3 + 4) == '\0') {

            FmtIp6Addr(param_3 + 8,auStack_60,0x40);

            cVar1 = *(char *)(param_3 + 0x18);

          }

          else {

            FmtIpAddr(*(uint32_t *)(param_3 + 8),auStack_60,0x40);

            cVar1 = *(char *)(param_3 + 0x18);

          }

          uVar4 = 4;

          if (cVar1 == '\0') {

            uVar4 = 0x10;

          }

          uVar4 = netMaskToLen6(param_3 + 0x1c,uVar4);

          logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1afc08,auStack_60,uVar4,

                             (&isisReachStr)[*(byte *)(param_3 + 0x2e)],

                             *(uint *)(param_3 + 0x2c) >> 0x18 & 0x1f,param_4);

          isisHandleMemFail(param_1);

        }

      }

    }

    if ((param_2 != 0) ||

       ((*(char *)((int)param_1 + 0x925) != '\x01' || uVar6 != 0 &&

        (*(char *)((int)param_1 + 0x927) != '\x01' || !bVar2)))) {

      _gIsisRtmMiss4 = _gIsisRtmMiss4 + 1;

      return;

    }

    if (uVar6 == 1) {

      uVar4 = param_1[0x247];

    }

    else {

      uVar4 = param_1[0x245];

    }

    iVar3 = isisRtmDoRouteChangedAction(uVar4,auStack_380,param_4);

    if (iVar3 != 0) {

      if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x800) == 0)) ||

         (iVar3 = isisDebugCheck(param_1,0x800,param_3 + 4,0), iVar3 == 0)) {

        isisHandleMemFail(param_1);

      }

      else if (_IsisLogger == 0) {

        if (*(char *)(param_3 + 4) == '\0') {

          FmtIp6Addr(param_3 + 8,auStack_60,0x40);

          cVar1 = *(char *)(param_3 + 0x18);

        }

        else {

          FmtIpAddr(*(uint32_t *)(param_3 + 8),auStack_60,0x40);

          cVar1 = *(char *)(param_3 + 0x18);

        }

        uVar4 = 4;

        if (cVar1 == '\0') {

          uVar4 = 0x10;

        }

        uVar4 = netMaskToLen6(param_3 + 0x1c,uVar4);

        uVar5 = 0xa1af45c;

        if (uVar6 != 1) {

          uVar5 = 0xa1aedfc;

        }

        tracePrint(_MOD_ISIS,0xa1afb4c,0,0,0xa1afbbc,uVar5,auStack_60,uVar4,

                   (&isisReachStr)[*(byte *)(param_3 + 0x2e)],

                   *(uint *)(param_3 + 0x2c) >> 0x18 & 0x1f,param_4);

        isisHandleMemFail(param_1);

      }

      else {

        if (*(char *)(param_3 + 4) == '\0') {

          FmtIp6Addr(param_3 + 8,auStack_60,0x40);

          cVar1 = *(char *)(param_3 + 0x18);

        }

        else {

          FmtIpAddr(*(uint32_t *)(param_3 + 8),auStack_60,0x40);

          cVar1 = *(char *)(param_3 + 0x18);

        }

        uVar4 = 4;

        if (cVar1 == '\0') {

          uVar4 = 0x10;

        }

        uVar4 = netMaskToLen6(param_3 + 0x1c,uVar4);

        uVar5 = 0xa1af45c;

        if (uVar6 != 1) {

          uVar5 = 0xa1aedfc;

        }

        logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1afbbc,uVar5,auStack_60,uVar4,

                           (&isisReachStr)[*(byte *)(param_3 + 0x2e)],

                           *(uint *)(param_3 + 0x2c) >> 0x18 & 0x1f,param_4);

        isisHandleMemFail(param_1);

      }

    }

  }

  else {

    _gIsisRtmFillFail = _gIsisRtmFillFail + 1;

  }

  return;

}