#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern uint32_t *_gMdaInfo;
extern int _traceEnabled;
extern int _tracepointsActive;
extern uint32_t _MOD_MDADRV;

uint32_t fpgaSarmGetClockMonBitsMask(uint param_1,uint *param_2)

{

  bool bVar1;

  int iVar2;

  int iVar3;

  

  iVar3 = 0;

  if ((param_1 != 0) &&

     (((*_gMdaInfo < param_1 || (iVar2 = fpgaIsValidMda(), iVar2 == 0)) ||

      (iVar3 = fpgaGetMda(param_1), iVar3 == 0)))) {

    bVar1 = iVar3 != 0;

    if (param_1 == 0) goto LAB_063a9ac0;

    if (param_1 <= *_gMdaInfo) {

      iVar2 = macMdaRemoved(param_1);

      bVar1 = iVar3 != 0;

      if (iVar2 != 0) goto LAB_063a9ac0;

      if (_traceEnabled == 0) {

        bVar1 = iVar3 != 0;

        if (_tracepointsActive == 0) goto LAB_063a9ac0;

        iVar2 = traceTest(_MOD_MDADRV,0xa8d84f8,4,0);

        if (iVar2 == 0) {

          bVar1 = iVar3 != 0;

          goto LAB_063a9ac0;

        }

      }

      tracePrintVRtr(_MOD_MDADRV,0xa8d84f8,4,0,1,0xa8d84dc,param_1);

      bVar1 = iVar3 != 0;

      goto LAB_063a9ac0;

    }

  }

  bVar1 = iVar3 != 0;
LAB_063a9ac0:

  if (!(bool)(bVar1 & param_2 != (uint *)0x0)) {

    return 0xffffffff;

  }

  *param_2 = 0;

  switch(*(uint32_t *)(iVar3 + 8)) {

  case 0x7e:

    *param_2 = *param_2 | 0x812;

    break;

  case 0x7f:

  case 0xb3:

    *param_2 = *param_2 | 0x20;

    break;

  default:

    if (_traceEnabled == 0) {

      if (_tracepointsActive == 0) {

        return 0xffffffff;

      }

      iVar2 = traceTest(_MOD_MDADRV,0xa8d84f8,4,0);

      if (iVar2 == 0) {

        return 0xffffffff;

      }

    }

    tracePrintVRtr(_MOD_MDADRV,0xa8d84f8,4,0,1,0xa8d8514,param_1,*(uint32_t *)(iVar3 + 8));

    return 0xffffffff;

  case 0xaf:

  case 0xb0:

  case 0xb2:

  case 0xb4:

    *param_2 = *param_2 | 0x852;

    break;

  case 0xbb:

  case 0xbc:

  case 0xbd:

  case 0xbe:

  case 0xbf:

    *param_2 = *param_2 | 0x2852;

  }

  return 0;
}