#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t debugIsisSpf(uint32_t param_1,uint32_t param_2,int param_3,int param_4,char param_5)



{

  int iVar1;

  uint32_t uVar2;

  uint auStack_138 [30];

  uint uStack_c0;

  int iStack_bc;

  uintptr_t auStack_b8 [160];

  

  memset(auStack_138,0,0x120);

  auStack_138[0] = auStack_138[0] | 0x100;

  if (param_3 == 0) {

LAB_039e0414:

    if (param_4 != 0) {

      iVar1 = strToIsisSystemId(param_4,auStack_b8);

      if (iVar1 != 0) {

        uVar2 = 0x9fffe4c;

        goto LAB_039e0480;

      }

      uStack_c0 = uStack_c0 | 2;

    }

    if (param_5 == '\0') {

      isisDebugOn(1,auStack_138);

      uVar2 = 0;

    }

    else {

      isisDebugOff(1,auStack_138);

      uVar2 = 0;

    }

  }

  else {

    iStack_bc = atoi(param_3);

    uVar2 = 0x9fffe3c;

    if (iStack_bc - 1U < 2) {

      uStack_c0 = uStack_c0 | 1;

      goto LAB_039e0414;

    }

LAB_039e0480:

    cliErrorMesg(param_1,uVar2);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}



