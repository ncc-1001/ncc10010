#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing variables
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



bool isisRtmEnable(uint32_t *param_1,int param_2,int param_3)


{

  int iVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t *puVar4;

  bool bVar5;

  

  if ((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x800) == 0)) {

    uVar3 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];

  }

  else {

    iVar1 = isisDebugCheck(param_1,0x800,0,0);

    if (iVar1 == 0) {

      uVar3 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];

    }

    else if (_IsisLogger == 0) {

      tracePrint(_MOD_ISIS,0xa1af424,0,0,0xa1af434,param_2,param_3);

      uVar3 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];

    }

    else {

      logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af434,param_2,param_3);

      uVar3 = param_1[param_2 * 0xe + param_3 * 7 + 0x22c];

    }

  }

  iVar1 = isisRtmRegister(param_1,uVar3,param_1 + param_2 * 0xe + param_3 * 7 + 0x22d,

                          param_1 + param_2 * 0xe + param_3 * 7 + 0x229);

  bVar5 = iVar1 != 0;

  if (bVar5) {

    if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x800) != 0)) &&

       (iVar1 = isisDebugCheck(param_1,0x800,0,0), iVar1 != 0)) {

      if (_IsisLogger == 0) {

        tracePrint(_MOD_ISIS,0xa1af424,0,0,0xa1af484,param_3);

      }

      else {

        logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af484,param_3);

      }

    }

LAB_0423b990:

    isisHandleMemFail(param_1);

    return bVar5;

  }

  if (param_3 == 1) {

    iVar1 = param_1[0x247];

  }

  else {

    iVar1 = param_1[0x245];

  }

  puVar4 = param_1 + 0x248;

  if (param_3 != 1) {

    puVar4 = param_1 + 0x246;

  }

  if (param_2 == 0 && iVar1 != 0) {

    iVar1 = isisRtmRegister(param_1,iVar1,puVar4,param_1 + param_2 * 0xe + param_3 * 7 + 0x229);

    bVar5 = iVar1 != 0;

    if (bVar5) {

      if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x800) != 0)) &&

         (iVar1 = isisDebugCheck(param_1,0x800,0,0), iVar1 != 0)) {

        if (_IsisLogger == 0) {

          uVar3 = 0xa1aedfc;

          if (param_3 != 0) {

            uVar3 = 0xa1af45c;

          }

          tracePrint(_MOD_ISIS,0xa1af424,0,0,0xa1af460,uVar3);

        }

        else {

          uVar3 = 0xa1aedfc;

          if (param_3 != 0) {

            uVar3 = 0xa1af45c;

          }

          logEvent_debug_fmt(*param_1,0xa1aee40,&isisTitleStr,0xa1af460,uVar3);

        }

      }

      goto LAB_0423b990;

    }

  }

  iVar1 = rtGetFirstRoute(param_1[param_3 + 0x1c1]);

  while (iVar1 != 0) {

    iVar2 = rtGetNextRoute(param_1[param_3 + 0x1c1],iVar1);

    isisSummWalkEnable(iVar1,param_1,param_2);

    iVar1 = iVar2;

  }

  return false;

}