#include "nokia.h"
#include <stdint.h>

// Added: extern declaration for undeclared variable isisLspEventSeqNum
extern int isisLspEventSeqNum;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


void isisLspRegenerateTimerExp(uint32_t param_1,uint32_t *param_2,int param_3)


{

  int *piVar1;

  int iVar2;

  ushort uVar4;

  uint32_t uVar3;

  

  if ((param_2 == (uint32_t *)0x0) || ((param_2[0x1b] & 0x200) == 0)) {

    uVar4 = *(ushort *)(param_3 + 0xc);

  }

  else {

    iVar2 = isisDebugCheck(param_2,0x200,param_3,0);

    if (iVar2 == 0) {

      uVar4 = *(ushort *)(param_3 + 0xc);

    }

    else if (_IsisLogger == 0) {

      uVar3 = isisDumpLspId(param_3 + 4,param_2 + 0x6a1,0x400,0);

      tracePrint(_MOD_ISIS,0xa1aa4c0,0,0,0xa1aa4dc,uVar3,*(uint32_t *)(param_3 + 0x24),

                 *(uint16_t *)(param_3 + 0xc));

      uVar4 = *(ushort *)(param_3 + 0xc);

    }

    else {

      uVar3 = isisDumpLspId(param_3 + 4,param_2 + 0x6a1,0x400,0);

      logEvent_debug_fmt(*param_2,0xa1aa444,&isisTitleStr,0xa1aa4dc,uVar3,

                         *(uint32_t *)(param_3 + 0x24),*(uint16_t *)(param_3 + 0xc));

      uVar4 = *(ushort *)(param_3 + 0xc);

    }

  }

  if ((uVar4 & 0x10) == 0) {

    *(uint32_t *)(param_3 + 0x1c) = 0;

  }

  else {

    *(ushort *)(param_3 + 0xc) = uVar4 & 0xffef;

    if (*(int *)(param_3 + 0x1c) == 0) {

      timosAssert(0xa1aa51c,0xa1aa410,0x2cd,0xa1aa4c0,0xa1aa518);

      uVar3 = param_2[0x1a4];

    }

    else {

      uVar3 = param_2[0x1a4];

    }

    piVar1 = (int *)dlistAllocateNodeExt(uVar3,4,1);

    if (piVar1 != (int *)0x0) {

      *piVar1 = param_3;

      *(int **)(param_3 + 0x158) = piVar1;

      isisLspUpdateHistory(param_2,param_3,0xe,&isisLspEventSeqNum,0,0x2db);

      dlist_insert(param_2[0x1a4],piVar1,0xa1aa410,0x2dd);

      isisLspIncRef(param_2,param_3,0xa1aa410,0x2de);

      if ((*(ushort *)(param_3 + 0xc) & 0x400) == 0) {

        isisLspUpdateHistory(param_2,param_3,0xf,&isisLspEventSeqNum,0,0x2df);

        *(ushort *)(param_3 + 0xc) = *(ushort *)(param_3 + 0xc) | 0x400;

      }

      else {

        *(ushort *)(param_3 + 0xc) = *(ushort *)(param_3 + 0xc) | 0x400;

      }

      return;

    }

    *(ushort *)(param_3 + 0xc) = *(ushort *)(param_3 + 0xc) | 0x10;

    isisLspSetRegenTimer(param_2,param_3,0);

  }

  return;

}