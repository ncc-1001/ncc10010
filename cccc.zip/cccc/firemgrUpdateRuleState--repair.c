#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing variables
// Modified: These variables are referenced in the code but not declared
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_FIREWALL;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t firemgrUpdateRuleState(int param_1)

{

  uint32_t *puVar1;

  int iVar2;

  uint32_t uStack_130;

  uint32_t uStack_12c;

  uintptr_t auStack_128 [280];
  
  puVar1 = (uint32_t *)
           firemgrGetZoneRule(1,*(uint16_t *)(param_1 + 8),*(int *)(param_1 + 4) + 1);
  if (puVar1 != (uint32_t *)0x0) {
    memcpy(puVar1 + 0xe,param_1,0x48);
    iVar2 = firemgrAmIActive();
    if (iVar2 == 0) {
      return 0;
    }
    uStack_130 = 5;
    uStack_12c = *puVar1;
    memcpy(auStack_128,puVar1 + 0xe,0x48);
    redFireMgrAddUpdateToBuffer(&uStack_130);
    return 0;
  }
  if (_traceEnabled == 0) {
    if (_tracepointsActive == 0) {
      return 0xffffffff;
    }
    iVar2 = traceTest(_MOD_FIREWALL,0xa176610,4,0);
    if (iVar2 == 0) {
      return 0xffffffff;
    }
    iVar2 = *(int *)(param_1 + 4);
  }
  else {
    iVar2 = *(int *)(param_1 + 4);
  }
  tracePrintVRtr(_MOD_FIREWALL,0xa176610,4,0,1,0xa176628,*(uint16_t *)(param_1 + 8),iVar2 + 1);
  return 0xffffffff;
}