#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _IsisLogger; // Modified: Added extern declaration for undeclared identifier
extern int _MOD_ISIS; // Modified: Added extern declaration for undeclared identifier
extern char isisTitleStr; // Modified: Added extern declaration for undeclared identifier

void isisRedSendNbrToInactive
               (uint32_t *param_1,uint param_2,uint32_t param_3,uint32_t param_4,
               uint32_t param_5,uint32_t param_6,uint32_t param_7,uint32_t param_8,
               uint32_t param_9,uint32_t param_10,uint32_t param_11,uint32_t param_12,
               uint32_t param_13,uint32_t param_14,uint32_t param_15,uint32_t param_16,
               int param_17,uint32_t *param_18,uint32_t *param_19,char param_20,
               uintptr_t param_21,uintptr_t param_22)
{
  uint32_t uVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  uint32_t uVar5;
  uint32_t uVar6;
  uint32_t uVar7;
  uint32_t uVar8;
  uint32_t uVar9;
  uint32_t uVar10;
  uint32_t uVar11;
  uint32_t uVar12;
  int iVar13;
  uint32_t uStack_88;
  uint32_t uStack_84;
  uint32_t uStack_80;
  uintptr_t auStack_7c [8];
  uint32_t uStack_74;
  uint32_t uStack_70;
  uint32_t uStack_6c;
  uint32_t uStack_68;
  uint32_t uStack_64;
  uint32_t uStack_60;
  uint32_t uStack_5c;
  uint32_t uStack_58;
  uint32_t uStack_54;
  uint32_t uStack_50;
  uint32_t uStack_4c;
  uint32_t uStack_48;
  uint32_t uStack_44;
  uint32_t uStack_40;
  uint32_t uStack_3c;
  uint32_t uStack_38;
  uint uStack_34;
  uintptr_t uStack_30;
  uintptr_t uStack_2f;
  char cStack_2e;
  uintptr_t uStack_2d;
  uintptr_t uStack_2c;
  
  if (param_2 == 4) {
    timosAssert(0xa1ace70,0xa1ac610,0xe11,0xa1ace54,0xa1ac5b8);
    iVar13 = param_1[0x842];
  }
  else {
    iVar13 = param_1[0x842];
  }
  if (iVar13 == 0) {
    memset(&uStack_88,0,0x60);
    uStack_88 = *param_1;
    memcpy(auStack_7c,param_3,7);
    uStack_2d = param_22;
    uStack_2c = param_21;
    cStack_2e = param_20;
    uStack_84 = param_4;
    uStack_34 = param_2;
    if (param_17 == 0) {
      if ((param_1[0x1b] & 0x100000) == 0) {
        uStack_80 = 0;
      }
      else {
        iVar13 = isisDebugCheck(param_1,0x100000,0,0);
        if (iVar13 == 0) {
          uStack_80 = 0;
        }
        else if (_IsisLogger == 0) {
          tracePrint(_MOD_ISIS,0xa1ace54,0,0,0xa1ace98);
          uStack_80 = 0;
        }
        else {
          logEvent_debug_fmt(*param_1,0xa1ac4d0,&isisTitleStr,0xa1ace98);
          uStack_80 = 0;
        }
      }
    }
    else {
      uStack_80 = *(uint32_t *)(param_17 + 8);
    }
    uVar1 = uStack_74;
    uVar2 = uStack_70;
    uVar3 = uStack_6c;
    uVar4 = uStack_68;
    uVar5 = uStack_64;
    uVar6 = uStack_60;
    uVar7 = uStack_5c;
    uVar8 = uStack_58;
    uVar9 = uStack_54;
    uVar10 = uStack_50;
    uVar11 = uStack_4c;
    uVar12 = uStack_48;
    if ((((param_2 ^ 2) == 0 && param_20 != '\x01') ||
        (uVar1 = param_5, uVar2 = param_6, uVar3 = param_7, uVar4 = param_8, uVar5 = param_9,
        uVar6 = param_10, uVar7 = param_11, uVar8 = param_12, uVar9 = param_13, uVar10 = param_14,
        uVar11 = param_15, uVar12 = param_16, param_2 != 0 && (param_2 ^ 2) != 0)) &&
       (uStack_48 = uVar12, uStack_4c = uVar11, uStack_50 = uVar10, uStack_54 = uVar9,
       uStack_58 = uVar8, uStack_5c = uVar7, uStack_60 = uVar6, uStack_64 = uVar5, uStack_68 = uVar4
       , uStack_6c = uVar3, uStack_70 = uVar2, uStack_74 = uVar1,
       ((uint)param_18 | (uint)param_19) != 0)) {
      if (param_18 != (uint32_t *)0x0) {
        uStack_44 = *param_18;
        uStack_40 = param_18[1];
        uStack_30 = 1;
      }
      if (param_19 != (uint32_t *)0x0) {
        uStack_3c = *param_19;
        uStack_38 = param_19[1];
        uStack_2f = 1;
      }
    }
    redSendUpdate(0x34,0xd,&uStack_88,0x60);
    return;
  }
  return;
}