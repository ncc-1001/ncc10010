#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;

void hwSarmFpgaFanPowerEnable(void)
{
  int in_zero;
  int iVar1;
  
  iVar1 = 0;
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
    }
    else {
      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
    }
  }
  if (*(char *)(iVar1 + 0x10c8f925) != -0x13) {
    iVar1 = 0;
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
      }
      else {
        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
      }
    }
    if (*(char *)(iVar1 + 0x10c8f925) != -0x15) {
      return;
    }
  }
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}