#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared variable cRam10c8f925
extern byte cRam10c8f925;

uint32_t hwWakiResetBcm6529(char param_1)

{

  int iVar1;

  uint32_t uVar2;

  uint auStack_10 [2];

  

  if ((byte)(cRam10c8f925 + 0x1eU) < 6) {

    iVar1 = hwWakiGetCtrl3ExtDevReset(auStack_10);

    if (iVar1 == -1) {

      return 0xffffffff;

    }

    if (param_1 == '\0') {

      auStack_10[0] = auStack_10[0] | 4;

    }

    else {

      auStack_10[0] = auStack_10[0] & 0xfffffffb;

    }

    iVar1 = hwWakiSetCtrl3ExtDevReset();

    if (iVar1 == -1) {

      return 0xffffffff;

    }

  }

  else {

    iVar1 = hwWakiSetCtrl5GpioDir(0xf);

    if (iVar1 != 0) {

      return 0xffffffff;

    }

    uVar2 = 0;

    if (param_1 == '\0') {

      uVar2 = 0xf;

    }

    iVar1 = hwWakiSetCtrl4Gpo(uVar2);

    if (iVar1 != 0) {

      return 0xffffffff;

    }

  }

  return 0;

}
