#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for currentTimingCtrl to fix compilation error
extern uintptr_t *currentTimingCtrl;

/* WARNING: Control flow encountered bad instruction data */

void hwSarmFpgaSetSyncOutClkFreq(int param_1)
{
  uintptr_t *puVar1;
  
  if (param_1 == 1) {
    puVar1 = (uintptr_t *)((uint)currentTimingCtrl & 0xfffffff9);
  }
  else if (param_1 == 0) {
    puVar1 = (uintptr_t *)((uint)currentTimingCtrl | 2);
  }
  else {
    if (param_1 != 2) {
                    /* WARNING: Subroutine does not return */
      printf(0x69c1744,0x69c1728,param_1);
    }
    puVar1 = (uintptr_t *)((uint)currentTimingCtrl & 0xfffffffd | 4);
  }
  if (puVar1 != currentTimingCtrl) {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}