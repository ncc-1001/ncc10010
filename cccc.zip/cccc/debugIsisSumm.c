#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t debugIsisSumm(uint32_t param_1,uint32_t param_2,int param_3,char param_4)



{

  int iVar1;

  uint auStack_138 [63];

  uint uStack_3c;

  uintptr_t uStack_38;

  uint32_t uStack_34;

  uint32_t auStack_18 [2];

  

  memset(auStack_138,0,0x120);

  auStack_138[0] = auStack_138[0] | 0x200000;

  if (param_3 != 0) {

    iVar1 = ipStrToIpAddr(param_3,auStack_18);

    if (iVar1 != 0) {

      cliErrorMesg(param_1,0x9fffe60);

      return 0xffffffff;

    }

    uStack_38 = 1;

    uStack_3c = uStack_3c | 1;

    uStack_34 = auStack_18[0];

  }

  if (param_4 == '\0') {

    isisDebugOn(1,auStack_138);

  }

  else {

    isisDebugOff(1,auStack_138);

  }

  return 0;

}



