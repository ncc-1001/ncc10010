#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _ip_FCopy_1;
extern int _ip_FCopy_Fail1;
extern int _ip_FCopy_Fail2;
extern int _ip_FCopy_Fail3;
extern int _MOD_ATIC_L3;
extern int Status;
extern int _vxAbsTicks;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern int _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern char pbufMarkHistoryTrack;
extern int _pbufMarkHistoryOffStart;
extern int _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern char pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern char pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern char pbufMarkHistoryVal3;
extern char pbufMarkHistoryMatchLocation1;
extern int _pbufMarkHistoryLocationVal1;
extern int pbufMarkHistoryLock;
extern char pbufMarkHistoryTable;

int ipFCopy(int param_1)
{
  ushort uVar1;
  bool bVar2;
  int in_zero;
  uint32_t uVar3;
  int iVar4;
  uint32_t uVar5;
  uint32_t uVar6;
  uint uVar7;
  int *piVar8;
  uint32_t uVar9;
  uint uVar10;
  char *pcVar11;
  uint32_t uVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  uint32_t *puVar16;
  uint16_t uVar17;
  int iVar18;
  uint uVar19;
  uint32_t uVar20;
  uint32_t uVar21;
  uint uVar22;
  
  _ip_FCopy_1 = _ip_FCopy_1 + 1;
  iVar13 = 0;
  if (*(int *)(param_1 + 8) != 0) {
    iVar13 = *(int *)(*(int *)(param_1 + 8) + 8);
  }
  iVar18 = *(int *)(iVar13 + 0x14);
  uVar12 = *(uint32_t *)(iVar13 + 0x3c);
  uVar9 = *(uint32_t *)(iVar13 + 0x38);
  iVar15 = ((*(int *)(iVar13 + 8) + iVar13) - iVar18) + 0xa0;
  uVar3 = *(uint32_t *)(iVar13 + 0x34);
  uVar14 = *(int *)(param_1 + 0x18) + 100 + iVar15;
  uVar20 = *(uint32_t *)(iVar13 + 0x18);
  uVar21 = *(uint32_t *)(iVar13 + 0x1c);
  uVar19 = *(uint *)(param_1 + 0x24);
  iVar13 = B_NewEx(0,0xffffffff,uVar14);
  if (iVar13 == 0) {
    _ip_FCopy_Fail1 = _ip_FCopy_Fail1 + 1;
    if (_tracepointsActive == 0) {
      return 0;
    }
    iVar13 = traceTest(_MOD_ATIC_L3,0x9f683c4,1,1);
    if (iVar13 == 0) {
      return 0;
    }
    tracePrintVRtr(_MOD_ATIC_L3,0x9f683c4,1,1,1,0x9f67be8,uVar14);
    return 0;
  }
  if (*(uint *)(iVar13 + 0x20) < uVar14) {
    _ip_FCopy_Fail2 = _ip_FCopy_Fail2 + 1;
    if ((_tracepointsActive != 0) && (iVar15 = traceTest(_MOD_ATIC_L3,0x9f683c4,1,1), iVar15 != 0))
    {
      tracePrintVRtr(_MOD_ATIC_L3,0x9f683c4,1,1,1,0x9f67c4c,uVar14);
      B_DeleteEx(iVar13,1,0);
      return 0;
    }
LAB_036bb790:
    B_DeleteEx(iVar13,1,0);
    return 0;
  }
  iVar4 = _F_NewEx(iVar13,0,0,0xffffffff,0x9f67880,0x13e1);
  if (iVar4 == 0) {
    _ip_FCopy_Fail3 = _ip_FCopy_Fail3 + 1;
    if ((_tracepointsActive != 0) && (iVar15 = traceTest(_MOD_ATIC_L3,0x9f683c4,1,1), iVar15 != 0))
    {
      tracePrintVRtr(_MOD_ATIC_L3,0x9f683c4,1,1,1,0x9f67cb4);
      B_DeleteEx(iVar13,1,0);
      return 0;
    }
    goto LAB_036bb790;
  }
  uVar5 = F_GetData(iVar4);
  F_AddToEnd(iVar4,iVar18,iVar15);
  uVar6 = F_GetData(param_1);
  F_AddToEnd(iVar4,uVar6,*(uint32_t *)(param_1 + 0x18));
  F_CutFromStart(iVar4,iVar15);
  iVar13 = F_GetData(iVar4);
  uVar14 = Status;
  uVar22 = (uint)*(byte *)(iVar13 + 9);
  *(uint *)(iVar4 + 0x24) = *(uint *)(iVar4 + 0x24) | uVar19;
  iVar13 = 0;
  if (*(int *)(iVar4 + 8) != 0) {
    iVar13 = *(int *)(*(int *)(iVar4 + 8) + 8);
  }
  *(uint32_t *)(iVar13 + 0x18) = uVar20;
  *(uint32_t *)(iVar13 + 0x1c) = uVar21;
  *(uint32_t *)(iVar13 + 0x14) = uVar5;
  *(uint32_t *)(iVar13 + 0x34) = uVar3;
  *(uint32_t *)(iVar13 + 0x38) = uVar9;
  *(uint32_t *)(iVar13 + 0x3c) = uVar12;
  uVar19 = _vxAbsTicks;
  if (*(int *)(iVar4 + 8) == 0) {
    return iVar4;
  }
  iVar13 = *(int *)(*(int *)(iVar4 + 8) + 8);
  puVar16 = (uint32_t *)(iVar13 + 0x88);
  uVar10 = (uint)*(ushort *)(iVar13 + 0x94);
  uVar7 = _vxAbsTicks / 100;
  if (uVar10 == 0) {
    return iVar4;
  }
  uVar17 = (uint16_t)uVar7;
  if (_kernelIsSmp == 0) {
    if (_smpIntCnt == 0) {
LAB_036bb850:
      *puVar16 = _smpTaskIdCurrent;
      goto LAB_036bb61c;
    }
    uVar1 = *(ushort *)(iVar13 + 0x96);
LAB_036bb7e4:
    *puVar16 = 0;
    uVar14 = Status;
  }
  else {
    Status = Status & 0xfffffffe;
    setCopReg(0,Status,uVar14,0);
    if (0 < *(int *)(&smpIntCnt + (EBase & 0xff) * 4)) {
      uVar1 = *(ushort *)(iVar13 + 0x96);
      goto LAB_036bb7e4;
    }
    if (_kernelIsSmp == 0) goto LAB_036bb850;
    *puVar16 = *(uint32_t *)(in_zero + -0x8000);
LAB_036bb61c:
    uVar1 = *(ushort *)(iVar13 + 0x96);
    uVar14 = Status;
  }
  uVar7 = (uVar7 & 0xffff) - (uint)uVar1 & 0xffff;
  if ((uVar7 != 0) && (uVar10 < 0xab)) {
    if (8 < uVar7) {
      uVar7 = 8;
    }
    iVar15 = (uVar10 * 0x558 + uVar7) * 8;
    piVar8 = (int *)(iVar15 + 0xecd4c6c);
    *(uint16_t *)(iVar15 + 0xecd4c70) = uVar17;
    *piVar8 = *piVar8 + 1;
  }
  Status = uVar14;
  if (pbufMarkHistoryTrack == ' ') goto LAB_036bb9e0;
  if ((*(uint *)(iVar13 + 0x9c) & 0x8000) == 0) {
    iVar15 = *(int *)(iVar13 + 8) + iVar13 + 0xa0;
    bVar2 = false;
    uVar19 = *(uint *)(iVar13 + 0xc);
    if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {
      uVar7 = _pbufMarkHistoryOffStart;
      do {
        if ((((_pbufMarkHistoryOff1 == -1) ||
             ((_pbufMarkHistoryOff1 + uVar7 < uVar19 &&
              (*(char *)(_pbufMarkHistoryOff1 + iVar15 + uVar7) == pbufMarkHistoryVal1)))) &&
            ((_pbufMarkHistoryOff2 == -1 ||
             ((_pbufMarkHistoryOff2 + uVar7 < uVar19 &&
              (*(char *)(_pbufMarkHistoryOff2 + iVar15 + uVar7) == pbufMarkHistoryVal2)))))) &&
           ((_pbufMarkHistoryOff3 == -1 ||
            ((_pbufMarkHistoryOff3 + uVar7 < uVar19 &&
             (*(char *)(_pbufMarkHistoryOff3 + iVar15 + uVar7) == pbufMarkHistoryVal3)))))) {
          bVar2 = true;
        }
        uVar7 = uVar7 + 1;
      } while (!bVar2 && uVar7 <= _pbufMarkHistoryOffEnd);
    }
    if (bVar2) {
      if ((pbufMarkHistoryMatchLocation1 != ' ') && (_pbufMarkHistoryLocationVal1 != 0x2d)) {
        *(uint16_t *)(iVar13 + 0x96) = uVar17;
        *(uint16_t *)(iVar13 + 0x94) = 0x2d;
        *(uint *)(iVar13 + 0x98) = uVar22;
        return iVar4;
      }
    }
    else if (!bVar2) goto LAB_036bb9e0;
                    /* WARNING: Subroutine does not return */
    intLockProtect(&pbufMarkHistoryLock);
  }
  iVar15 = (uint)*(ushort *)(iVar13 + 0x9c) * 0x408;
  pcVar11 = &pbufMarkHistoryTable + iVar15;
  if (*pcVar11 == ' ') {
    *pcVar11 = '';
    *(uint32_t *)(iVar15 + 0xe58e868) = 0;
    uVar7 = *(uint *)(iVar15 + 0xe58e868);
  }
  else {
    uVar7 = *(uint *)(iVar15 + 0xe58e868);
  }
  if (0x3e < uVar7) goto LAB_036bb9e0;
  puVar16 = (uint32_t *)(pcVar11 + uVar7 * 0x10 + 8);
  if (_kernelIsSmp == 0) {
    if (_smpIntCnt == 0) {
LAB_036bba4c:
      *puVar16 = _smpTaskIdCurrent;
    }
    else {
      *puVar16 = 0;
    }
  }
  else {
    Status = uVar14 & 0xfffffffe;
    setCopReg(0,Status,uVar14,0);
    if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
      if (_kernelIsSmp == 0) goto LAB_036bba4c;
      *puVar16 = *(uint32_t *)(in_zero + -0x8000);
    }
    else {
      *puVar16 = 0;
    }
  }
  *(uint *)(pcVar11 + uVar7 * 0x10 + 0x10) = uVar19;
  *(uint16_t *)(pcVar11 + uVar7 * 0x10 + 0xc) = 0x2d;
  *(uint *)(pcVar11 + uVar7 * 0x10 + 0x14) = uVar22;
  *(uint16_t *)(pcVar11 + uVar7 * 0x10 + 0xe) = uVar17;
  *(int *)(iVar15 + 0xe58e868) = *(int *)(iVar15 + 0xe58e868) + 1;
LAB_036bb9e0:
  *(uint16_t *)(iVar13 + 0x96) = uVar17;
  *(uint16_t *)(iVar13 + 0x94) = 0x2d;
  *(uint *)(iVar13 + 0x98) = uVar22;
  return iVar4;
}