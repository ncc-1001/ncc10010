#include "nokia.h"
#include <stdint.h>

void isisDumpPktTEIPReach

               (uint32_t param_1,code *param_2,byte *param_3,uint32_t param_4,byte param_5)



{

  uint uVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uint uVar4;

  byte *pbVar5;

  byte *pbVar6;

  byte *pbVar7;

  byte *pbVar8;

  byte *pbVar9;

  byte *pbVar10;

  byte *pbVar11;

  byte bVar14;

  uint uVar12;

  uint uVar13;

  uint uVar15;

  uint uVar16;

  uint uVar17;

  uint uVar18;

  byte *apbStackX_8 [2];

  uintptr_t auStack_230 [512];

  uint auStack_30 [2];

  

  uVar18 = (uint)param_5;

  uVar17 = 0;

  if (uVar18 != 0) {

    apbStackX_8[0] = param_3;

    do {

      while( true ) {

        auStack_30[0] =

             (uint)*apbStackX_8[0] << 0x18 | (uint)apbStackX_8[0][1] << 0x10 |

             (uint)apbStackX_8[0][2] << 8 | (uint)apbStackX_8[0][3];

        apbStackX_8[0] = apbStackX_8[0] + 4;

        (*param_2)(param_1,0xa1b73c8,auStack_30[0]);

        uVar2 = 0xa1b5808;

        bVar14 = *apbStackX_8[0];

        apbStackX_8[0] = apbStackX_8[0] + 1;

        if (-1 < (char)bVar14) {

          uVar2 = 0xa1b739c;

        }

        uVar3 = 0xa1b57b4;

        if ((bVar14 & 0x40) == 0) {

          uVar3 = 0xa1b739c;

        }

        (*param_2)(param_1,0xa1b7580,uVar2,uVar3,bVar14 & 0x3f);

        (*param_2)(param_1,0xa1b75a8);

        uVar15 = (bVar14 & 0x3f) >> 3;

        if ((bVar14 & 7) != 0) {

          uVar15 = uVar15 + 1;

        }

        auStack_30[0] = 0;

        memcpy(auStack_30,apbStackX_8[0],uVar15);

        apbStackX_8[0] = apbStackX_8[0] + uVar15;

        uVar4 = auStack_30[0] >> 8 & 0xff;

        uVar1 = auStack_30[0] & 0xff;

        (*param_2)(param_1,0xa1b75b8,auStack_30[0] >> 0x18,auStack_30[0] >> 0x10 & 0xff,uVar4,uVar1)

        ;

        uVar17 = uVar17 + uVar15 + 5 & 0xffff;

        if ((bVar14 & 0x40) == 0) break;

        (*param_2)(param_1,0xa1b75c8);

        uVar15 = (uint)*apbStackX_8[0];

        pbVar5 = apbStackX_8[0] + 1;

        if (uVar15 != 0) {

          bVar14 = apbStackX_8[0][1];

          apbStackX_8[0] = apbStackX_8[0] + 2;

          uVar16 = uVar15;

          uVar13 = uVar4;

          if (bVar14 == 1) goto LAB_04276938;

LAB_04276808:

          uVar4 = uVar16 - 1;

          if (bVar14 == 2) {

            uVar12 = (uint)*apbStackX_8[0];

            apbStackX_8[0] = apbStackX_8[0] + 1;

            uVar16 = (uVar16 - uVar12) - 2 & 0xff;

            uVar4 = uVar13;

            for (; 7 < uVar12; uVar12 = uVar12 - 8 & 0xff) {

              bVar14 = *apbStackX_8[0];

              pbVar5 = apbStackX_8[0] + 1;

              pbVar6 = apbStackX_8[0] + 2;

              pbVar7 = apbStackX_8[0] + 3;

              pbVar8 = apbStackX_8[0] + 4;

              pbVar9 = apbStackX_8[0] + 5;

              pbVar10 = apbStackX_8[0] + 6;

              pbVar11 = apbStackX_8[0] + 7;

              apbStackX_8[0] = apbStackX_8[0] + 8;

              (*param_2)(param_1,0xa1b75dc,

                         (uint)bVar14 << 0x18 | (uint)*pbVar5 << 0x10 | (uint)*pbVar6 << 8 |

                         (uint)*pbVar7 | (int)((uint)*pbVar8 << 0x18) >> 0x1f,

                         (uint)*pbVar8 << 0x18 | (uint)*pbVar9 << 0x10 | (uint)*pbVar10 << 8 |

                         (uint)*pbVar11,uVar4,uVar1);

            }

          }

          else {

            uVar1 = 0xa1b7614;

            isisPrintHex(auStack_230,0,0x200,apbStackX_8,uVar4,0xa1b7614,1);

            (*param_2)(param_1,0xa1b761c,bVar14,auStack_230);

            memset(auStack_230,0,0x200);

            uVar16 = 0;

          }

          while (pbVar5 = apbStackX_8[0], uVar16 != 0) {

            while( true ) {

              bVar14 = *apbStackX_8[0];

              apbStackX_8[0] = apbStackX_8[0] + 1;

              uVar13 = uVar4;

              if (bVar14 != 1) goto LAB_04276808;

LAB_04276938:

              uVar13 = (uint)*apbStackX_8[0];

              apbStackX_8[0] = apbStackX_8[0] + 1;

              uVar16 = (uVar16 - uVar13) - 2 & 0xff;

              if (uVar13 < 4) break;

              do {

                bVar14 = *apbStackX_8[0];

                pbVar5 = apbStackX_8[0] + 1;

                pbVar6 = apbStackX_8[0] + 2;

                pbVar7 = apbStackX_8[0] + 3;

                apbStackX_8[0] = apbStackX_8[0] + 4;

                (*param_2)(param_1,0xa1b75f8,

                           (uint)bVar14 << 0x18 | (uint)*pbVar5 << 0x10 | (uint)*pbVar6 << 8 |

                           (uint)*pbVar7);

                uVar13 = uVar13 - 4 & 0xff;

              } while (3 < uVar13);

              pbVar5 = apbStackX_8[0];

              if (uVar16 == 0) goto LAB_042769cc;

            }

          }

        }

LAB_042769cc:

        apbStackX_8[0] = pbVar5;

        (*param_2)(param_1,0xa1b53b4);

        uVar17 = uVar17 + uVar15 + 1 & 0xffff;

        if (uVar18 <= uVar17) {

          return;

        }

      }

    } while (uVar17 < uVar18);

  }

  return;

}



