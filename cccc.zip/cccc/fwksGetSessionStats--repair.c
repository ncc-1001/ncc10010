#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Add extern declarations for all undeclared identifiers
extern void * __gxx_personality_sj0;
extern void * __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern unsigned int uRam0c959618;
extern int iRam0c95961c;

// Modified: Change unknown type 'code' to 'void'

uint fwksGetSessionStats(int param_1,uint32_t param_2)
{
  int iVar1;
  int iVar2;
  char cVar3;
  uintptr_t auStack_80 [16];
  uintptr_t auStack_70 [4];
  uint32_t uStack_6c;
  void *pcStack_58; // Modified: Changed from 'code *' to 'void *'
  uint32_t uStack_54;
  uintptr_t *puStack_50;
  uint32_t uStack_4c;
  uintptr_t *puStack_48;
  uint uStack_3c;
  int iStack_30;
  
  puStack_48 = auStack_80;
  puStack_50 = auStack_70;
  pcStack_58 = __gxx_personality_sj0;
  uStack_4c = 0x40e95e4;
  uStack_54 = 0xbff85ce;
  _Unwind_SjLj_Register(puStack_50);
  iVar1 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    // Modified: Simplified complex if condition
    int condition1 = (__ZN8Firewall10FwksFilter8m_uLimitE == 0);
    int condition2 = (__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE == (uint)(uRam0c9594cc < uRam0c9594c4));
    int condition3 = (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE);
    
    if (condition1 || (condition2 && condition3)) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_6c = 0xffffffff;
      iStack_30 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_30 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_6c = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_30;
    iVar1 = 0;
    if (iStack_30 != 0) {
      iVar1 = iStack_30;
    }
  }
  if ((iVar1 != 0) && (param_1 != 0)) {
    iVar2 = 0xb6b950;
    if (*(int *)(iVar1 + 0xb2f190) == 0) {
      iVar2 = 0xb6a070;
    }
    uStack_6c = 0xffffffff;
    cVar3 = _ZN8Firewall9ZoneGroup15getSessionStatsERNS_16FwksSessionArrayER14FwksEndSessionj
                      (iVar1 + iVar2,iVar1 + 0x54,param_1,param_2);
    uStack_3c = (uint)(cVar3 != '\0');
    _Unwind_SjLj_Unregister(auStack_70);
    return uStack_3c;
  }
  uStack_3c = 0;
  _Unwind_SjLj_Unregister(auStack_70);
  return uStack_3c;
}