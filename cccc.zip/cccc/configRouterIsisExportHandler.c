#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void configRouterIsisExportHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t *puVar3;

  int iVar4;

  int iVar5;

  uint32_t uVar6;

  uint32_t auStack_38 [6];

  uint32_t *puStack_20;

  uint32_t uStack_1c;

  

  uVar6 = 0;

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_20);

  if (iVar1 == 0) {

    uVar6 = *puStack_20;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,&uStack_1c);

  if (iVar1 == 0) {

    iVar1 = RCC_DB_GetArraySize(uStack_1c);

    if (0 < iVar1) {

      puVar3 = auStack_38;

      iVar5 = 0;

      do {

        iVar4 = iVar5 + 1;

        uVar2 = RCC_DB_GetArrayElement(uStack_1c,iVar5);

        *puVar3 = uVar2;

        puVar3 = puVar3 + 1;

        iVar5 = iVar4;

      } while (iVar4 < iVar1);

    }

    if (iVar1 < 5) {

      puVar3 = auStack_38 + iVar1;

      iVar5 = iVar1;

      do {

        iVar5 = iVar5 + 1;

        *puVar3 = 0;

        puVar3 = puVar3 + 1;

      } while (iVar5 < 5);

    }

    configRouterIsisExport(param_1,uVar6,auStack_38,iVar1);

    return;

  }

  return;

}



