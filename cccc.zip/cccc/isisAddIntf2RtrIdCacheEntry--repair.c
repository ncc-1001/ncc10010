#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing variables
extern uint32_t _isisIntf2RtrIdMutex;
extern int _gIsisIntf2RtrCacheDisabled;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t isisAddIntf2RtrIdCacheEntry(int *param_1)



{

  uint32_t uVar1;

  int iVar2;

  int in_stack_00000010;

  

  uVar1 = _isisIntf2RtrIdMutex;

  if ((_gIsisIntf2RtrCacheDisabled == 0) && (param_1 != (int *)0x0)) {

    iVar2 = *param_1;

    if (in_stack_00000010 - 1U < 2) {

      iVar2 = iVar2 * 0x14 + in_stack_00000010 * 0x28;

      *(int *)(iVar2 + 0xc98c09c) = *(int *)(iVar2 + 0xc98c09c) + 1;

                    /* WARNING: Subroutine does not return */

      semTake(uVar1,0xffffffff);

    }

    timosAssert(0xa1bbf70,0xa1bb3b0,0x803,0xa1bbf54,0xa1bbe14);

    uVar1 = _isisIntf2RtrIdMutex;

    iVar2 = iVar2 * 0x14 + in_stack_00000010 * 0x28;

    *(int *)(iVar2 + 0xc98c09c) = *(int *)(iVar2 + 0xc98c09c) + 1;

                    /* WARNING: Subroutine does not return */

    semTake(uVar1,0xffffffff);

  }

  return 0;

}
