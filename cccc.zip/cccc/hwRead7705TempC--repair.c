#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared global variable 'cRam10c8f925'
extern int cRam10c8f925;

uint32_t hwRead7705TempC(int param_1,uint32_t *param_2)
{
  uint32_t uVar1;
  
  *param_2 = 0xffffff81;
  if (param_1 - 6U < 0x10) {
    uVar1 = macMdaGetTempC(param_1 + -5);
    return uVar1;
  }
  if (cRam10c8f925 != -0x23 && cRam10c8f925 != -0x12) {
    if (((((cRam10c8f925 != -0x13 && cRam10c8f925 != -0x17) && (1 < (byte)(cRam10c8f925 + 0x16U)))
         && (cRam10c8f925 != -0xd && cRam10c8f925 != -0xf)) &&
        (((cRam10c8f925 != -8 && (cRam10c8f925 != -9)) &&
         ((cRam10c8f925 != -10 && cRam10c8f925 != -0x10 &&
          ((cRam10c8f925 != -0xe && (cRam10c8f925 != -0x24)))))))) &&
       ((5 < (byte)(cRam10c8f925 + 0x1eU) && (cRam10c8f925 != -7)))) {
      if (((((byte)(cRam10c8f925 + 4U) < 2 || cRam10c8f925 == -6) ||
           (cRam10c8f925 == -2 || cRam10c8f925 == -0x18)) || (cRam10c8f925 == -5)) && (param_1 == 0)
         ) {
        uVar1 = getADT7302Local(param_2);
        return uVar1;
      }
      return 0xffffffff;
    }
    uVar1 = hwReadSarMTempC(param_1,param_2);
    return uVar1;
  }
  uVar1 = hwReadSarHCTempC();
  return uVar1;
}