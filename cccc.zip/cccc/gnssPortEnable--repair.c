#include "nokia.h"
#include <stdint.h>

// Modified: Add typedef for 'uint'
typedef unsigned int uint;
// Modified: Add typedef for 'code' (fixed syntax)
typedef void (*code)(int, char);

// Modified: Add extern declarations for global variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern int smpIntCnt;
extern int EBase;
extern int *_gMdaInfo;
extern int Status;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void gnssPortEnable(int param_1,char param_2)
{
  char cVar1;
  code *pcVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int *piVar6;
  
  if ((_tracepointsActive != 0) && (iVar5 = traceTest(_MOD_MDADRV,0xa9be008,1,0), iVar5 != 0)) {
    tracePrintVRtr(_MOD_MDADRV,0xa9be008,1,0,1,0xa9be03c,
                   *(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24));
  }
  uVar4 = Status;
  piVar6 = (int *)0x0;
  if (_kernelIsSmp == 0) {
    iVar5 = *(int *)(param_1 + 4);
    if (_smpIntCnt != 0) goto LAB_066edc68;
  }
  else {
    Status = Status & 0xfffffffe;
    setCopReg(0,Status,uVar4,0);
    iVar5 = *(int *)(param_1 + 4);
    if (0 < *(int *)(&smpIntCnt + (EBase & 0xff) * 4)) {
LAB_066edc68:
      uVar4 = *(uint *)(iVar5 + 0x36ca24);
      if ((uVar4 != 0) && (uVar4 <= *_gMdaInfo)) {
        piVar6 = *(int **)(uVar4 * 4 + 0xeb6f544);
      }
      goto LAB_066edbb8;
    }
  }
  if ((*(uint *)(iVar5 + 0x36ca24) == 0) || (*_gMdaInfo < *(uint *)(iVar5 + 0x36ca24))) {
    timosAssert(0xa9be018,0xa9bde9c,0x1ed,0xa9be008,0xa9bde74,*(uint32_t *)(iVar5 + 0x36ca24));
    iVar5 = *(int *)(param_1 + 4);
  }
  piVar6 = *(int **)(*(int *)(iVar5 + 0x36ca24) * 4 + 0xeb6f544);
  if (piVar6 == (int *)0x0) {
    timosAssert(0xa9be04c,0xa9bde9c,0x1ed,0xa9be008,0xa9be048);
    iVar5 = *(int *)(param_1 + 4);
  }
LAB_066edbb8:
  iVar3 = *(int *)(*(int *)(iVar5 + 0x36ca24) * 4 + 0xeb6f544) + *(int *)(param_1 + 0xcb8) * 0x1b0;
  if ((*piVar6 == 0) || (pcVar2 = *(code **)(*piVar6 + 0xa8), pcVar2 == (code *)0x0)) {
    cVar1 = *(char *)(iVar3 + 0x3668);
  }
  else {
    (*pcVar2)(*(int *)(iVar5 + 0x36ca24),param_2);
    cVar1 = *(char *)(iVar3 + 0x3668);
  }
  if (cVar1 != param_2) {
    setAdminStatus(*(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24),param_2);
    if (param_2 == '\0') {
      *(uint32_t *)(iVar3 + 0x3674) = 1;
      *(uint32_t *)(iVar3 + 0x3678) = 8;
      *(uintptr_t *)(iVar3 + 0x3668) = 0;
    }
    else {
      *(char *)(iVar3 + 0x3668) = param_2;
    }
  }
  return;
}