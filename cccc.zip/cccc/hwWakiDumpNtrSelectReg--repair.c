#include "nokia.h"
#include <stdint.h>

// Modified: Added typedef for 'byte' to fix undeclared identifier
typedef unsigned char byte;
// Modified: Added extern declaration for 'cRam10c8f925' to fix undeclared identifier
extern unsigned int cRam10c8f925;

void hwWakiDumpNtrSelectReg(void)
{
  int iVar1;
  uintptr_t auStack_10 [8];
  
  if ((5 < (byte)(cRam10c8f925 + 0x1eU)) &&
     (iVar1 = hwWakiGetCtrl2NtrRefClockSelEn(auStack_10), iVar1 == 0)) {
                    /* WARNING: Subroutine does not return */
    printf(0xa7b03b8);
  }
  return;
}