#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void configRouterIsisNoStrictAdjacencyCheckHdlr(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t *apuStack_18 [2];

  

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,apuStack_18);

  uVar2 = 0;

  if (iVar1 == 0) {

    uVar2 = *apuStack_18[0];

  }

  configRouterIsisStrictAdjacencyCheck(param_1,uVar2,0);

  return;

}



