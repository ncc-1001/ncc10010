#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared symbols
extern void* __gxx_personality_sj0;
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern unsigned int uRam0c959618;
extern int iRam0c95961c;

void fwksGetTrafficStatsStr(uintptr_t *param_1,int param_2)
{
  int iVar1;
  uintptr_t auStack_90 [16];
  uint32_t uStack_80;
  uintptr_t *puStack_7c;
  uint16_t uStack_78;
  uint16_t uStack_76;
  uintptr_t uStack_70;
  uint16_t uStack_6e;
  uintptr_t uStack_6c;
  uintptr_t auStack_68 [4];
  uint32_t uStack_64;
  // Modified: Replaced 'code' with 'void*'
  void* pcStack_50;
  uint32_t uStack_4c;
  uint32_t *puStack_48;
  uint32_t uStack_44;
  uintptr_t *puStack_40;
  int iStack_2c;

  puStack_40 = auStack_90;
  pcStack_50 = __gxx_personality_sj0;
  uStack_4c = 0xbff86fa;
  puStack_48 = &uStack_80;
  uStack_44 = 0x40f1f58;
  _Unwind_SjLj_Register(auStack_68);
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_64 = 0xffffffff;
      iStack_2c = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_2c = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_64 = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_2c;
    iVar1 = 0;
    if (iStack_2c == 0) goto LAB_040f1e20;
  }
  iVar1 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
LAB_040f1e20:
  if ((iVar1 != 0) && (param_1 != (uintptr_t *)0x0 && param_2 != 0)) {
    uStack_80 = 0xa17dc08;
    uStack_78 = (uint16_t)param_2;
    uStack_76 = 0;
    if (param_1 != (uintptr_t *)0x0) {
      *param_1 = 0;
    }
    uStack_70 = 1;
    uStack_6c = 1;
    uStack_64 = 0xffffffff;
    uStack_6e = 0;
    puStack_7c = param_1;
    FUN_040f72cc(iVar1 + 0xb2b6d8,&uStack_80,0xffffffff);
  }
  _Unwind_SjLj_Unregister(auStack_68);
  return;
}