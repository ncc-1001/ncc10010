#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
// Modified: _TgtHw is used as an integer in comparisons
extern int _TgtHw;
// Modified: _kernelIsSmp is used as an integer in comparisons
extern int _kernelIsSmp;
// Modified: _smpTaskIdCurrent is used as a pointer in arithmetic
extern int _smpTaskIdCurrent;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t hwSarmFpgaACOButtonPressed(void)



{

  int in_zero;

  int iVar1;

  

  iVar1 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar1 + 0x10c8f925) != -0x13) {

    iVar1 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar1 + 0x10c8f925) != -0x17) {

      iVar1 = 0;

      if (_TgtHw == 1) {

        if (_kernelIsSmp == 0) {

          iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

        }

        else {

          iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

        }

      }

      if (*(char *)(iVar1 + 0x10c8f925) != -0x15) {

        iVar1 = 0;

        if (_TgtHw == 1) {

          if (_kernelIsSmp == 0) {

            iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

          }

          else {

            iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

          }

        }

        if (*(char *)(iVar1 + 0x10c8f925) != -0x16) {

          iVar1 = 0;

          if (_TgtHw == 1) {

            if (_kernelIsSmp == 0) {

              iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

            }

            else {

              iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

            }

          }

          if (*(char *)(iVar1 + 0x10c8f925) != -0x24) {

            iVar1 = 0;

            if (_TgtHw == 1) {

              if (_kernelIsSmp == 0) {

                iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

              }

              else {

                iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

              }

            }

            if (*(char *)(iVar1 + 0x10c8f925) != -0x23) {

              iVar1 = 0;

              if (_TgtHw == 1) {

                if (_kernelIsSmp == 0) {

                  iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                }

                else {

                  iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                }

              }

              if (*(char *)(iVar1 + 0x10c8f925) != -0x12) {

                return 0;

              }

            }

                    /* WARNING: Bad instruction - Truncating control flow here */

            halt_baddata();

          }

        }

      }

    }

  }

                    /* WARNING: Bad instruction - Truncating control flow here */

  halt_baddata();

}


