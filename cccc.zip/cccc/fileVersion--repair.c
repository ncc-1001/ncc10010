#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern uint32_t ftpErrorSuppress_3;
extern uint32_t _ftpErrorSuppress;
extern int cliAltPrintf;
extern int cliAltErrorMesg;
extern int dummyAltPrintf;
extern int _MyHwFamily;

uint32_t fileVersion(uint32_t param_1,uint32_t param_2,char param_3)
{
  bool bVar1;
  uint32_t uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uintptr_t auStack_888 [8];
  uintptr_t auStack_880 [40];
  uintptr_t auStack_858 [120];
  int iStack_7e0;
  int iStack_6b4;
  uintptr_t auStack_488 [400];
  uint32_t auStack_2f8 [182];
  
  uVar5 = (uint)ftpErrorSuppress_3;
  _ftpErrorSuppress = 1;
  uVar2 = cliFileCurrentDirectoryGet();
  bVar1 = false;
  iVar3 = fileAbsPath(cliAltPrintf,param_1,cliAltErrorMesg,param_1,uVar2,param_2,auStack_488,400);
  if (iVar3 != 0) {
    _ftpErrorSuppress = uVar5;
    return 0xffffffff;
  }
  iVar3 = fileUrlIsFtp(auStack_488);
  if (((iVar3 != 0) && (iVar3 = fileUrlIsLocalFtp(auStack_488), iVar3 == 0)) &&
     (iVar3 = fileVerifyFtpUrl(cliAltPrintf,param_1,cliAltErrorMesg,param_1,auStack_488), iVar3 == 0
     )) {
    _ftpErrorSuppress = uVar5;
    return 0xffffffff;
  }
  iVar3 = openURL(auStack_488,0,0,auStack_2f8);
  if (iVar3 < 0) {
    iVar3 = fileUrlIsFtp(auStack_488);
    if ((iVar3 != 0) && (iVar3 = fileUrlIsLocalFtp(auStack_488), iVar3 == 0)) {
      fileSendFtpTrap(auStack_488,0,0,0xa003ee4);
    }
    goto LAB_039fc774;
  }
  iVar3 = readTimfileHeader(auStack_2f8[0],auStack_888,dummyAltPrintf,0,0x400);
  iVar4 = RCC_EXT_ReadBreak(param_1);
  if (iVar4 == 0) {
LAB_039fc728:
    cliErrorMesg(param_1,0xa003f84);
  }
  else {
    if (iVar3 == 0) {
      iVar3 = strcmp(auStack_888,0xa004058);
      if (iVar3 == 0) {
LAB_039fc5b4:
        cliPrintf(param_1,0xa004074,auStack_880);
        if (iStack_6b4 != 0) {
          uVar2 = pnGetPlatformNameForType();
          cliPrintf(param_1,0xa0040b4,uVar2);
        }
        if (iStack_7e0 == 1) {
          uVar2 = pnGetHardwareNameForType(1);
          cliPrintf(param_1,0xa0040b4,uVar2);
        }
        cliPrintf(param_1,0xa003e74,auStack_858);
        if (param_3 == '\0') {
LAB_039fc660:
          closeURL(auStack_2f8);
          _ftpErrorSuppress = uVar5;
          return 0;
        }
        cliPrintf(param_1,0xa004080);
        cliStartPinwheel(param_1,1);
        if (bVar1) {
          closeURL(auStack_2f8);
          iVar3 = openURL(auStack_488,0,0,auStack_2f8);
          if (iVar3 < 0) {
LAB_039fc774:
            cliErrorMesg(param_1,0xa003ecc,auStack_488);
            _ftpErrorSuppress = uVar5;
            return 0xffffffff;
          }
        }
        if (_MyHwFamily == 3) {
          iVar3 = verify7705TimFile(param_1,auStack_2f8[0],auStack_888);
        }
        else {
          iVar3 = verifyTimFile(param_1,auStack_2f8[0],auStack_888);
        }
        if (iVar3 == 0) {
          cliStopPinwheel(param_1,1);
          cliPrintf(param_1,0xa004090);
          goto LAB_039fc660;
        }
        goto LAB_039fc718;
      }
      iVar3 = readBootLdrTimHeader(param_1,auStack_2f8[0],auStack_888);
      if (iVar3 == 0x48) goto LAB_039fc728;
      if (iVar3 != 0) goto LAB_039fc708;
      iVar3 = strcmp(auStack_888,0xa004058);
      bVar1 = true;
      uVar2 = 0xa004060;
      if (iVar3 == 0) goto LAB_039fc5b4;
    }
    else {
LAB_039fc708:
      uVar2 = 0xa004094;
    }
    cliErrorMesg(param_1,uVar2);
  }
LAB_039fc718:
  closeURL(auStack_2f8);
  _ftpErrorSuppress = uVar5;
  return 0xffffffff;
}