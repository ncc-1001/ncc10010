#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for global variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;

// Modified: Changed ushort to unsigned short to fix compilation error
uint32_t hwCpldGetDubuVariantAndRevision(unsigned short *param_1,unsigned short *param_2)


{

  int in_zero;

  uint32_t uVar1;

  // Modified: Changed ushort to unsigned short to fix compilation error
  unsigned short uVar2;

  int iVar3;

  

  iVar3 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar3 + 0x10c8f925) != -0x13) {

    iVar3 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar3 + 0x10c8f925) != -0x17) {

      iVar3 = 0;

      if (_TgtHw == 1) {

        if (_kernelIsSmp == 0) {

          iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

        }

        else {

          iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

        }

      }

      if (*(char *)(iVar3 + 0x10c8f925) != -0x15) {

        iVar3 = 0;

        if (_TgtHw == 1) {

          if (_kernelIsSmp == 0) {

            iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

          }

          else {

            iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

          }

        }

        if (*(char *)(iVar3 + 0x10c8f925) != -0x16) {

          iVar3 = 0;

          if (_TgtHw == 1) {

            if (_kernelIsSmp == 0) {

              iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

            }

            else {

              iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

            }

          }

          if (*(char *)(iVar3 + 0x10c8f925) != -0xd) {

            iVar3 = 0;

            if (_TgtHw == 1) {

              if (_kernelIsSmp == 0) {

                iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

              }

              else {

                iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

              }

            }

            if (*(char *)(iVar3 + 0x10c8f925) != -0xf) {

              iVar3 = 0;

              if (_TgtHw == 1) {

                if (_kernelIsSmp == 0) {

                  iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                }

                else {

                  iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                }

              }

              if (*(char *)(iVar3 + 0x10c8f925) != -8) {

                iVar3 = 0;

                if (_TgtHw == 1) {

                  if (_kernelIsSmp == 0) {

                    iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                  }

                  else {

                    iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                  }

                }

                if (*(char *)(iVar3 + 0x10c8f925) != -9) {

                  iVar3 = 0;

                  if (_TgtHw == 1) {

                    if (_kernelIsSmp == 0) {

                      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                    }

                    else {

                      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                    }

                  }

                  if (*(char *)(iVar3 + 0x10c8f925) != -10) {

                    iVar3 = 0;

                    if (_TgtHw == 1) {

                      if (_kernelIsSmp == 0) {

                        iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                      }

                      else {

                        iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                      }

                    }

                    if (*(char *)(iVar3 + 0x10c8f925) != -0x10) {

                      iVar3 = 0;

                      if (_TgtHw == 1) {

                        if (_kernelIsSmp == 0) {

                          iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                        }

                        else {

                          iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                        }

                      }

                      if (*(char *)(iVar3 + 0x10c8f925) != -0xe) {

                        iVar3 = 0;

                        if (_TgtHw == 1) {

                          if (_kernelIsSmp == 0) {

                            iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                          }

                          else {

                            iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                          }

                        }

                        if (*(char *)(iVar3 + 0x10c8f925) != -0x24) {

                          iVar3 = 0;

                          if (_TgtHw == 1) {

                            if (_kernelIsSmp == 0) {

                              iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                            }

                            else {

                              iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                            }

                          }

                          if (*(char *)(iVar3 + 0x10c8f925) != -0x23) {

                            iVar3 = 0;

                            if (_TgtHw == 1) {

                              if (_kernelIsSmp == 0) {

                                iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                              }

                              else {

                                iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                              }

                            }

                            if (*(char *)(iVar3 + 0x10c8f925) != -0x12) {

                              iVar3 = 0;

                              if (_TgtHw == 1) {

                                if (_kernelIsSmp == 0) {

                                  iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                }

                                else {

                                  iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                }

                              }

                              if (*(char *)(iVar3 + 0x10c8f925) != -0x1e) {

                                iVar3 = 0;

                                if (_TgtHw == 1) {

                                  if (_kernelIsSmp == 0) {

                                    iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                  }

                                  else {

                                    iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                  }

                                }

                                if (*(char *)(iVar3 + 0x10c8f925) != -0x1d) {

                                  iVar3 = 0;

                                  if (_TgtHw == 1) {

                                    if (_kernelIsSmp == 0) {

                                      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                    }

                                    else {

                                      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                    }

                                  }

                                  if (*(char *)(iVar3 + 0x10c8f925) != -0x1c) {

                                    iVar3 = 0;

                                    if (_TgtHw == 1) {

                                      if (_kernelIsSmp == 0) {

                                        iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                      }

                                      else {

                                        iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                      }

                                    }

                                    if (*(char *)(iVar3 + 0x10c8f925) != -0x1b) {

                                      iVar3 = 0;

                                      if (_TgtHw == 1) {

                                        if (_kernelIsSmp == 0) {

                                          iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                        }

                                        else {

                                          iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

                                        }

                                      }

                                      if (*(char *)(iVar3 + 0x10c8f925) != -0x1a) {

                                        iVar3 = 0;

                                        if (_TgtHw == 1) {

                                          if (_kernelIsSmp == 0) {

                                            iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                          }

                                          else {

                                            iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) *

                                                    3;

                                          }

                                        }

                                        if (*(char *)(iVar3 + 0x10c8f925) != -0x19) {

                                          iVar3 = 0;

                                          if (_TgtHw == 1) {

                                            if (_kernelIsSmp == 0) {

                                              iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

                                            }

                                            else {

                                              iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8)

                                                      * 3;

                                            }

                                          }

                                          if (*(char *)(iVar3 + 0x10c8f925) != -7) {

                                            uVar1 = hwCpldReadReg(0);

                                            uVar2 = (unsigned short)uVar1 & 0x7f;

                                            // Modified: Changed uint to uint32_t to fix compilation error
                                            *param_1 = (unsigned short)((uint32_t)uVar1 >> 8) & 0x3f;

                                            goto LAB_028b4f58;

                                          }

                                        }

                                      }

                                    }

                                  }

                                }

                              }

                            }

                          }

                        }

                      }

                    }

                  }

                }

              }

            }

          }

        }

      }

    }

  }

  uVar2 = 0xfe;

  *param_1 = 0xfe;

LAB_028b4f58:

  *param_2 = uVar2;

  return 0;

}