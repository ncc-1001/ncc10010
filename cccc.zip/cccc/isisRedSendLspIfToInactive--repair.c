#include "nokia.h"
#include <stdint.h>

extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr[];

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisRedSendLspIfToInactive

               (uint32_t *param_1,uint32_t param_2,int param_3,char *param_4,int param_5)



{
  char cVar1;
  uint32_t *puVar2;
  uint32_t uVar3;
  uint32_t *puVar4;
  int iVar5;
  uint32_t uVar6;
  uint32_t uVar7;
  uint32_t uVar8;
  uint32_t *puVar9;
  uint32_t *puVar10;
  uint uVar11;
  uint uVar12;
  int iVar13;
  
  uVar12 = 0;
  if (param_1[0x842] == 0) {
    iVar13 = 0x30;
    if (param_5 != 0 && param_3 != 0) {
      puVar2 = (uint32_t *)(param_3 + 0x14c);
      iVar13 = 1;
      do {
        uVar3 = *puVar2;
        iVar13 = iVar13 + -1;
        puVar2 = puVar2 + 1;
        iVar5 = dlistGetNodes(uVar3);
        uVar12 = uVar12 + iVar5;
      } while (-1 < iVar13);
      iVar13 = uVar12 * 0x14 + 0x30;
    }
    puVar2 = (uint32_t *)isisCalloc(iVar13,1);
    if (puVar2 != (uint32_t *)0x0) {
      uVar3 = *param_1;
      puVar2[1] = param_2;
      puVar2[5] = param_5;
      *puVar2 = uVar3;
      if (param_3 != 0) {
        uVar3 = *(uint32_t *)(param_3 + 8);
        puVar2[2] = *(uint32_t *)(param_3 + 4);
        puVar2[3] = uVar3;
        *(uint16_t *)(puVar2 + 4) = *(uint16_t *)(param_3 + 0xc);
      }
      if (param_4 == (char *)0x0) {
        *(uintptr_t *)(puVar2 + 7) = 1;
        puVar2[8] = 0;
      }
      else {
        cVar1 = *param_4;
        *(char *)(puVar2 + 7) = cVar1;
        if (cVar1 == '\0') {
          uVar7 = *(uint32_t *)(param_4 + 0x10);
          uVar3 = *(uint32_t *)(param_4 + 8);
          uVar6 = *(uint32_t *)(param_4 + 0xc);
          puVar2[8] = *(uint32_t *)(param_4 + 4);
          puVar2[9] = uVar3;
          puVar2[10] = uVar6;
          puVar2[0xb] = uVar7;
        }
        else {
          puVar2[8] = *(uint32_t *)(param_4 + 4);
        }
      }
      puVar2[6] = 0;
      if (((param_5 != 0) && (param_3 != 0)) && ((*(ushort *)(param_3 + 0xc) & 0x80) == 0)) {
        puVar10 = (uint32_t *)(param_3 + 0x14c);
        uVar11 = 0;
        puVar9 = puVar2 + 0xc;
        do {
          for (puVar4 = (uint32_t *)dlistGetFirst(*puVar10); puVar4 != (uint32_t *)0x0;
              puVar4 = (uint32_t *)dlistGetNext(puVar4)) {
            if (uVar12 < puVar2[6] + 1) {
              if (((param_1[0x1b] & 2) != 0) && (iVar5 = isisDebugCheck(param_1,2,0,0), iVar5 != 0))
              {
                if (_IsisLogger == 0) {
                  tracePrint(_MOD_ISIS,0xa1acc84,0,0,0xa1acca0);
                }
                else {
                  logEvent_debug_fmt(*param_1,0xa1ac4d0,&isisTitleStr,0xa1acca0);
                }
              }
              break;
            }
            uVar3 = puVar4[1];
            uVar6 = puVar4[2];
            uVar7 = puVar4[3];
            uVar8 = puVar4[4];
            *puVar9 = *puVar4;
            puVar9[1] = uVar3;
            puVar9[2] = uVar6;
            puVar9[3] = uVar7;
            puVar9[4] = uVar8;
            puVar9 = puVar9 + 5;
            puVar2[6] = puVar2[6] + 1;
          }
          uVar11 = uVar11 + 1;
          puVar10 = puVar10 + 1;
        } while (uVar11 < 2);
      }
      redSendUpdate(0x34,10,puVar2,iVar13);
      isisFree(puVar2);
    }
  }
  return;
}