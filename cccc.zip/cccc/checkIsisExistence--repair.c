#include "nokia.h"
#include <stdint.h>

extern unsigned char *___ctype; // Modified: Added extern declaration for undeclared identifier ___ctype

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t checkIsisExistence(uint32_t param_1,byte *param_2)

{

  int iVar1;

  uint32_t uVar2;

  int aiStack_268 [21];

  int iStack_214;

  

  aiStack_268[0] = strToRtrId(param_2,2 - (uint)((*(byte *)((uint)*param_2 + ___ctype) & 4) == 0));

  if (aiStack_268[0] == 0) {

    cliErrorMesg(param_1,0xa0dd630,param_2);

    uVar2 = 0xffffffff;

  }

  else {

    iVar1 = siaEsasVRtrEntryGet(1,aiStack_268);

    if (iVar1 == 0) {

      uVar2 = 0;

      if (iStack_214 == 2) {

        cliErrorMesg(param_1,0xa0dd618);

        uVar2 = 0xffffffff;

      }

    }

    else {

      cliErrorMesg(param_1,0xa0dd600,aiStack_268[0]);

      uVar2 = 0xffffffff;

    }

  }

  return uVar2;

}
