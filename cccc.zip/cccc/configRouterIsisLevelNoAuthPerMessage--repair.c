#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int ___chk_strnum; // Modified: Added extern declaration for undeclared variable

uint32_t

configRouterIsisLevelNoAuthPerMessage

          (uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4)



{

  int iVar1;

  uint32_t uVar2;

  uintptr_t auStack_e0 [200];

  

  iVar1 = strcmp(param_4,0xa07d0f4);

  uVar2 = 0xa07d660;

  if (iVar1 != 0) {

    iVar1 = strcmp(param_4,0xa07d0fc,0xa07d660);

    uVar2 = 0xa07d680;

    if (iVar1 != 0) {

      iVar1 = strcmp(param_4,0xa07d120,0xa07d680);

      uVar2 = 0xa07d6a0;

      if (iVar1 != 0) {

        return 0xffffffff;

      }

    }

  }

  snprintf(auStack_e0,200,uVar2);

  ___chk_strnum = 2;

  iVar1 = cfgRouterISISLevelElements(param_1,param_2,param_3,auStack_e0,0,0xa07cc34);

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07d6c4);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}


