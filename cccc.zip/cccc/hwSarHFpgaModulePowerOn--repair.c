#include "nokia.h"
#include <stdint.h>

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern char cRam10c8f925;

void hwSarHFpgaModulePowerOn(uint param_1)
{
  int in_zero;
  int iVar1;
  
  if (param_1 < 2) {
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar1 = *(int *)(_smpTaskIdCurrent + 0x2b8);
      }
      else {
        iVar1 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8);
      }
      if (*(char *)(iVar1 * 3 + 0x10c8f925) == -0x24) {
        return;
      }
    }
    else if (cRam10c8f925 == -0x24) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
  }
  return;
}