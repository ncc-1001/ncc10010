#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared variable 'cRam10c8f925'
extern byte cRam10c8f925;

int hwWakiClearMciAlarms(void)
{
  int iVar1;
  
  iVar1 = -1;
  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {
    iVar1 = hwWakiWriteReg32(0,0xc,0xff);
    iVar1 = (iVar1 == 0) - 1;
  }
  return iVar1;
}
