#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for _tracepointsActive and MOD_PLATFORM as they are undeclared
extern int _tracepointsActive;
extern int MOD_PLATFORM;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t bdbOverEtherHandler(uint32_t *param_1)



{

  int iVar1;

  uint uVar2;

  uint32_t uVar3;

  uint32_t uStack_1018;

  int iStack_1014;

  uintptr_t auStack_810 [2048];

  

  if ((_tracepointsActive == 0) || (iVar1 = traceTest(MOD_PLATFORM,0x6a0eccc,1,0), iVar1 == 0)) {

    uVar2 = param_1[4];

  }

  else {

    tracePrintVRtr(MOD_PLATFORM,0x6a0eccc,1,0,1,0x6a0ed2c,param_1[1],param_1[3],param_1[4]);

    uVar2 = param_1[4];

  }

  if (0x800 < uVar2) {

    timosAssert(0x6a0ece0,0x6a0ec58,0x173,0x6a0eccc,0x6a0ed00);

    uVar2 = param_1[4];

  }

  uStack_1018 = *param_1;

  iStack_1014 = hwBdbSimTransfer(*(uintptr_t *)((int)param_1 + 0xb),param_1[3],param_1 + 5,

                                 auStack_810,uVar2);

  uVar3 = 0xffffffff;

  if (iStack_1014 == 0) {

    sfSimBdbEthSendResp(&uStack_1018,auStack_810,param_1[4],param_1[1]);

    uVar3 = 0;

  }

  return uVar3;

}