#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared global variable _TunnelPipRecSem
extern int _TunnelPipRecSem;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void ipsecGetTunnelInfoFromTunnelId

               (uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4)



{

                    /* WARNING: Subroutine does not return */

  semTake(_TunnelPipRecSem,0xffffffff,param_3,param_4,0);

}


