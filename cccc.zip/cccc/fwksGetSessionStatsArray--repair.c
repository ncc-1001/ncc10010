// Modified: Changed absolute path to relative path for compilation
#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing symbols
typedef void (*code)(void);
extern void* __gxx_personality_sj0;
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern unsigned int uRam0c959618;
extern int iRam0c95961c;
extern void (*pcRam0a17e048)(void*, int);
extern void _Unwind_SjLj_Register(void*);
extern void _Unwind_SjLj_Unregister(void*);
extern void _ZN8Firewall10FwksFilterC1Ev(void);
extern int firewallMalloc(int);
extern void _Z17fwksZoneStatsDumpRN8Firewall12OutputStreamERNS_6IndentERNS_10FwksFilterER19tFwksZoneStatistics(void*, void*, int, void*);

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void fwksGetSessionStatsArray(uint32_t param_1)


{

  uint32_t *puVar1;

  int iVar2;

  uintptr_t *puVar3;

  int iVar4;

  uintptr_t auStack_538 [16];

  uintptr_t auStack_528 [144];

  uint32_t uStack_498;

  uint32_t uStack_494;

  uintptr_t *puStack_490;

  uint32_t uStack_488;

  uint32_t *puStack_484;

  uint32_t uStack_480;

  uintptr_t uStack_47c;

  uint16_t uStack_7c;

  uint16_t uStack_7a;

  uintptr_t auStack_78 [2];

  uint16_t uStack_76;

  uintptr_t uStack_74;

  uintptr_t auStack_70 [4];

  uint32_t uStack_6c;

  code *pcStack_58;

  uint32_t uStack_54;

  uintptr_t *puStack_50;

  uint32_t uStack_4c;

  uintptr_t *puStack_48;

  int iStack_3c;

  int iStack_30;

  

  puStack_48 = auStack_538;

  puVar3 = auStack_538;

  pcStack_58 = __gxx_personality_sj0;

  uStack_54 = 0xbff8636;

  puStack_50 = auStack_528;

  uStack_4c = 0x40ec3a8;

  _Unwind_SjLj_Register(auStack_70);

  iStack_3c = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;

  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {

    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||

       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==

         (uint)(uRam0c9594cc < uRam0c9594c4) &&

        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {

      uRam0c9594cc = uRam0c9594cc + 1;

      uRam0c959610 = uRam0c959610 + 1;

      __ZN8Firewall10FwksFilter6m_uNewE =

           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);

      iRam0c959614 = iRam0c959614 + 1;

      iRam0c95960c = iRam0c95960c + 0xb6d5f0;

      if (uRam0c959618 < uRam0c959610) {

        uRam0c959618 = uRam0c959610;

      }

      uStack_6c = 0xffffffff;

      iStack_30 = firewallMalloc(0xb6d5f0);

    }

    else {

      iStack_30 = 0;

      iRam0c95961c = iRam0c95961c + 1;

    }

    uStack_6c = 1;

    _ZN8Firewall10FwksFilterC1Ev();

    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_30;

    iStack_3c = 0;

    if (iStack_30 != 0) {

      iStack_3c = iStack_30;

    }

  }

  if (iStack_3c != 0) {

    iVar4 = 0;

    do {

      puVar1 = (uint32_t *)(puVar3 + 0x10);

      iVar2 = 0x11;

      do {

        iVar2 = iVar2 + -1;

        *puVar1 = 0;

        puVar1 = puVar1 + 1;

      } while (-1 < iVar2);

      iVar4 = iVar4 + 1;

      puVar3 = puVar3 + 0x48;

    } while (iVar4 < 2);

    uStack_498 = 0xa17df18;

    puStack_490 = auStack_528;

    puStack_484 = &uStack_498;

    uStack_488 = 0xa17e048;

    uStack_6c = 0xffffffff;

    uStack_494 = param_1;

    (*pcRam0a17e048)(&uStack_488,iStack_3c + 0x54);

    uStack_480 = 0xa17ddb0;

    uStack_7c = 0x400;

    auStack_78[0] = 1;

    uStack_74 = 1;

    uStack_7a = 0;

    uStack_47c = 0;

    uStack_76 = 0;

    _Z17fwksZoneStatsDumpRN8Firewall12OutputStreamERNS_6IndentERNS_10FwksFilterER19tFwksZoneStatistics

              (&uStack_480,auStack_78,iStack_3c,auStack_528);

  }

  _Unwind_SjLj_Unregister(auStack_70);

  return;

}