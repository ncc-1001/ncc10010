#include "nokia.h"
#include <stdint.h>

// Modified: Added declaration for undeclared variable 'sarmFpgaInitialized'
extern uint32_t sarmFpgaInitialized;
// Modified: Added declaration for undeclared variable 'is1588InReset'
extern uint32_t is1588InReset;

/* WARNING: Control flow encountered bad instruction data */



void hwSarmFpgaUBlazeRegRead(uint32_t param_1,uint32_t param_2,uint32_t param_3)



{

  uint32_t uVar1;

  

  uVar1 = 0x69c14e8;

  if (sarmFpgaInitialized != '\0') {

    uVar1 = 0x69c1508;

    param_3 = 0;

    if (is1588InReset == '\0') {

                    /* WARNING: Bad instruction - Truncating control flow here */

      halt_baddata();

    }

  }

                    /* WARNING: Subroutine does not return */

  printf(uVar1,0x69c14d0,param_3);

}
