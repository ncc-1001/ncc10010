#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern void* cdceMdaSpiCtlApi;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

uint32_t csaUfe4Choc3TIInit(uint32_t param_1)
{
  int iVar1;
  int iVar2;
  uint32_t uVar3;
  uint auStack_18 [2];
  
  cdceRegisterSpiCtlApi(param_1,&cdceMdaSpiCtlApi);
  iVar1 = iomRedIsCardActive();
  uVar3 = 0;
  if (iVar1 != 0) {
    iVar1 = macMdaRemoved(param_1);
    if (iVar1 == 0) {
      iVar1 = cdceWrite(param_1,6,0,0x205e027);
      uVar3 = 0xffffffff;
      if (iVar1 == 0) {
        iVar1 = cdceWrite(param_1,6,1,0x921b4f8);
        uVar3 = 0xffffffff;
        if (iVar1 == 0) {
          iVar1 = cdceWrite(param_1,6,2,0x180);
          uVar3 = 0xffffffff;
          if (iVar1 == 0) {
            iVar1 = cdceWrite(param_1,6,2,0x100);
            uVar3 = 0xffffffff;
            if (iVar1 == 0) {
              iVar1 = cdceWrite(param_1,6,2,0x180);
              uVar3 = 0xffffffff;
              if (iVar1 == 0) {
                iVar1 = cdce62005Write(param_1,4,0,0x8104032);
                uVar3 = 0xffffffff;
                if (iVar1 == 0) {
                  iVar1 = cdce62005Write(param_1,4,1,0x8106030);
                  uVar3 = 0xffffffff;
                  if (iVar1 == 0) {
                    iVar1 = cdce62005Write(param_1,4,2,0x3106030);
                    uVar3 = 0xffffffff;
                    if (iVar1 == 0) {
                      iVar1 = cdce62005Write(param_1,4,3,0x106030);
                      uVar3 = 0xffffffff;
                      if (iVar1 == 0) {
                        iVar1 = cdce62005Write(param_1,4,4,0x8106031);
                        uVar3 = 0xffffffff;
                        if (iVar1 == 0) {
                          iVar1 = cdce62005Write(param_1,4,5,0x60041c4);
                          uVar3 = 0xffffffff;
                          if (iVar1 == 0) {
                            iVar1 = cdce62005Write(param_1,4,6,0x4ff09e);
                            uVar3 = 0xffffffff;
                            if (iVar1 == 0) {
                              iVar1 = cdce62005Write(param_1,4,7,0xbd99fde);
                              uVar3 = 0xffffffff;
                              if (iVar1 == 0) {
                                iVar1 = cdce62005Write(param_1,4,8,0x8000180);
                                uVar3 = 0xffffffff;
                                if (iVar1 == 0) {
                                  iVar1 = cdce62005Write(param_1,4,8,0x8000100);
                                  uVar3 = 0xffffffff;
                                  if (iVar1 == 0) {
                                    iVar1 = cdce62005Write(param_1,4,8,0x8000180);
                                    uVar3 = 0xffffffff;
                                    if (iVar1 == 0) {
                                      auStack_18[0] = 0;
                                      iVar1 = 10;
                                      do {
                                        taskDelay(1);
                                        iVar1 = iVar1 + -1;
                                        auStack_18[0] = 0;
                                        iVar2 = mdaSpiderStatusGet(param_1,0x600000,0,auStack_18);
                                        if ((iVar2 != 0) || (iVar1 == 0)) break;
                                      } while ((auStack_18[0] & 0x600000) != 0x600000);
                                      uVar3 = 0;
                                      if ((auStack_18[0] & 0x600000) != 0x600000) {
                                        iVar1 = macMdaRemoved(param_1);
                                        uVar3 = 0xffffffff;
                                        if (iVar1 == 0) {
                                          if (_traceEnabled == 0) {
                                            if (_tracepointsActive == 0) {
                                              return 0xffffffff;
                                            }
                                            iVar1 = traceTest(_MOD_MDADRV,0xa8f36ec,4,0);
                                            if (iVar1 == 0) {
                                              return 0xffffffff;
                                            }
                                          }
                                          tracePrintVRtr(_MOD_MDADRV,0xa8f36ec,4,0,1,0xa8f3700,
                                                         param_1,auStack_18[0]);
                                          uVar3 = 0xffffffff;
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    else {
      uVar3 = 0;
    }
  }
  return uVar3;
}