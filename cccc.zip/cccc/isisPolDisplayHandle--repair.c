#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared global variables
extern int disp_isis_level;
extern int disp_isis_type;

uintptr_t * isisPolDisplayHandle(int param_1,uintptr_t *param_2,uint32_t param_3)
{

  uintptr_t *puVar1;

  uintptr_t *puVar2;

  uintptr_t auStack_a8 [128];

  uintptr_t auStack_28 [4];

  uint32_t uStack_24;

  uint32_t uStack_20;

  int iStack_1c;

  int iStack_18;

  uint32_t uStack_14;

  

  uStack_20 = 0;

  puVar1 = (uintptr_t *)0x0;

  if (param_1 != 0) {

    puVar2 = param_2;

    if (param_2 == (uintptr_t *)0x0) {

      puVar2 = auStack_a8;

      param_3 = 0x80;

    }

    isisPolExtractRtInfo(param_1,&iStack_1c,&iStack_18,&uStack_14,auStack_28,&uStack_24,&uStack_20);

    snprintf(puVar2,param_3,0xa1ac474,(&disp_isis_level)[iStack_1c],(&disp_isis_type)[iStack_18],

             uStack_14,auStack_28[0],uStack_24,uStack_20);

    puVar1 = param_2;

    if (param_2 == (uintptr_t *)0x0) {

                    /* WARNING: Subroutine does not return */

      printf(0xa1ac4bc,puVar2);

    }

  }

  return puVar1;
}