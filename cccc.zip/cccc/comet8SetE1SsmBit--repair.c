#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

typedef unsigned char byte; // Modified: Added to fix 'unknown type name byte' error
extern int *_gMdaInfo; // Modified: Added to fix '_gMdaInfo undeclared' error
extern int _tracepointsActive; // Modified: Added to fix '_tracepointsActive undeclared' error
extern int _MOD_MDADRV; // Modified: Added to fix '_MOD_MDADRV undeclared' error
extern int cRam10c8f925; // Modified: Added to fix 'cRam10c8f925 undeclared' error
extern uint32_t uRam00000004; // Modified: Added to fix 'uRam00000004 undeclared' error
extern uint32_t uRam0a985e58; // Modified: Added to fix 'uRam0a985e58 undeclared' error
extern uint32_t uRam0a985e5c; // Modified: Added to fix 'uRam0a985e5c undeclared' error
extern uint32_t uRam0a985e60; // Modified: Added to fix 'uRam0a985e60 undeclared' error
extern uint32_t uRam0a985e64; // Modified: Added to fix 'uRam0a985e64 undeclared' error

void comet8SetE1SsmBit(uint param_1,uint param_2,uint param_3)
{

  int iVar1;
  uint uVar2;
  uint32_t uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  uint32_t uStack_40;
  uint32_t uStack_3c;
  uint32_t uStack_38;
  uint32_t uStack_34;
  uint uStack_30;
  int iStack_2c;
  
  uStack_30 = param_3 & 0xff;
  iVar6 = 0;
  if (((param_1 == 0) || (*_gMdaInfo < param_1)) ||
     (iVar6 = *(int *)(param_1 * 4 + 0xccb422c), iVar6 == 0)) {
    timosAssert(0xa9847c4,0xa9847d0,0x1903,0xa985e68,0xa9847c0);
  }
  iVar4 = *(int *)((param_2 >> 3) * 4 + iVar6 + 0x94);
  if (iVar4 == 0) {
    timosAssert(0xa985e9c,0xa9847d0,0x1904,0xa985e68,0xa9847c0);
  }
  if ((_tracepointsActive != 0) && (iVar8 = traceTest(_MOD_MDADRV,0xa985e68,1,0), iVar8 != 0)) {
    tracePrintVRtr(_MOD_MDADRV,0xa985e68,1,0,1,0xa985e7c,param_1,param_2,uStack_30);
  }
  iStack_2c = param_2 * 0x8c + iVar6 + 0xb4;
  iVar4 = utilCometqDeviceHandle2Ddb(iVar4);
  iVar9 = (param_2 & 7) * 0x100;
  iVar8 = *(int *)(iVar4 + 0x10);
  iVar6 = (iVar9 + 0x86) * 4;
  if (cRam10c8f925 != -0x24) {
    iVar6 = iVar9 + 0x86;
  }
  iVar10 = iVar9 + 0x87;
  iVar1 = iVar10 * 4;
  if (cRam10c8f925 != -0x24) {
    iVar1 = iVar10;
  }
  bVar7 = 4;
  iVar5 = *(int *)(iVar4 + 0x14);
  while( true ) {
    if (iVar5 == 0) {
      timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);
      uVar3 = uRam00000004;
    }
    else {
      uVar3 = *(uint32_t *)(iVar5 + 4);
    }
    fpgaFramerWrite(uVar3,iVar6 + iVar8,(bVar7 - 1) * ' ');
    if (*(int *)(iVar4 + 0x14) == 0) {
      timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);
      uVar3 = uRam00000004;
    }
    else {
      uVar3 = *(uint32_t *)(*(int *)(iVar4 + 0x14) + 4);
    }
    fpgaFramerWrite(uVar3,iVar1 + iVar8,0xf);
    bVar7 = bVar7 + 1;
    if (8 < bVar7) break;
    iVar5 = *(int *)(iVar4 + 0x14);
  }
  iVar1 = uStack_30 - 1;
  if (*(int *)(iVar4 + 0x14) == 0) {
    timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);
    uVar3 = uRam00000004;
  }
  else {
    uVar3 = *(uint32_t *)(*(int *)(iVar4 + 0x14) + 4);
  }
  fpgaFramerWrite(uVar3,iVar6 + iVar8,iVar1 * 0x20 & 0xff);
  iVar6 = (iVar9 + 0x9b) * 4;
  if (cRam10c8f925 != -0x24) {
    iVar6 = iVar9 + 0x9b;
  }
  uVar2 = uStack_30 & 7;
  if (*(int *)(iVar4 + 0x14) == 0) {
    timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);
    uVar3 = uRam00000004;
  }
  else {
    uVar3 = *(uint32_t *)(*(int *)(iVar4 + 0x14) + 4);
  }
  fpgaFramerWrite(uVar3,iVar6 + iVar8,uVar2 << 5);
  if (*(char *)(iStack_2c + 0x88) != '\0') {
    uVar2 = *(byte *)(iStack_2c + 0x89) & 0xf;
    if (uStack_30 == 8) {
      uStack_40 = uRam0a985e58;
      uStack_3c = uRam0a985e5c;
      uStack_38 = uRam0a985e60;
      uStack_34 = uRam0a985e64;
      uVar2 = (uint)*(byte *)((int)&uStack_40 + uVar2);
    }
    iVar6 = iVar10 * 4;
    if (cRam10c8f925 != -0x24) {
      iVar6 = iVar10;
    }
    if (*(int *)(iVar4 + 0x14) == 0) {
      timosAssert(0xa98547c,0xa9847d0,0x175b,0xa985790,0xa9847c0);
      uVar3 = uRam00000004;
    }
    else {
      uVar3 = *(uint32_t *)(*(int *)(iVar4 + 0x14) + 4);
    }
    fpgaFramerWrite(uVar3,iVar6 + iVar8,uVar2 | 0xf0);
  }
  return;
}