#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendSuppProtoMismatchTrap

               (uint32_t *param_1,uint32_t param_2,uint32_t param_3,int param_4,

               uint32_t param_5,uint32_t param_6)



{

  uint32_t uVar1;

  uint32_t uVar2;

  uintptr_t auStack_40 [40];

  

  auStack_40[0] = 0;

  FmtIsisLSPId(*param_1,param_2,8,auStack_40,0x21,1);

  uVar1 = strlen(auStack_40);

  uVar2 = *param_1;

  logEvent_ISIS_vRtrIsisProtoSuppMismatch

            (uVar2,0xa1bbbfc,uVar2,param_5,param_6,param_3,param_2,8,auStack_40,uVar1,uVar2,

             *(uint32_t *)(param_4 + 8));

  return;

}



