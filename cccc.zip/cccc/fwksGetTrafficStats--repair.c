#include "nokia.h" // Modified: Changed absolute path to relative path for compilation
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables and types
typedef void (*code)();
extern code __gxx_personality_sj0; // Modified: Changed from void to function pointer type
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern unsigned int uRam0c959618;
extern int iRam0c959614;
extern int iRam0c95960c;
extern int iRam0c95961c;
extern void _Unwind_SjLj_Register(uintptr_t*);
extern void _Unwind_SjLj_Unregister(uintptr_t*);
extern void _ZN8Firewall10FwksFilterC1Ev();
extern void* firewallMalloc(int);

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void fwksGetTrafficStats(int param_1)



{

  int iVar1;

  int iVar2;

  int iVar3;

  uint uVar4;

  int iVar5;

  int iVar6;

  int iVar7;

  uint uVar8;

  int iVar9;

  uintptr_t auStack_80 [16];

  uintptr_t auStack_70 [4];

  uint32_t uStack_6c;

  code *pcStack_58;

  uint32_t uStack_54;

  uintptr_t *puStack_50;

  uint32_t uStack_4c;

  uintptr_t *puStack_48;

  int iStack_34;

  int iStack_30;

  int iStack_2c;

  

  puStack_48 = auStack_80;

  puStack_50 = auStack_70;

  pcStack_58 = &__gxx_personality_sj0; // Modified: Added address-of operator

  uStack_4c = 0x40f1c10;

  uStack_54 = 0xbff86f2;

  _Unwind_SjLj_Register(puStack_50);

  if (param_1 == 0) goto LAB_040f1b50;

  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {

    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||

       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==

         (uint)(uRam0c9594cc < uRam0c9594c4) &&

        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {

      uRam0c9594cc = uRam0c9594cc + 1;

      uRam0c959610 = uRam0c959610 + 1;

      __ZN8Firewall10FwksFilter6m_uNewE =

           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);

      iRam0c959614 = iRam0c959614 + 1;

      iRam0c95960c = iRam0c95960c + 0xb6d5f0;

      if (uRam0c959618 < uRam0c959610) {

        uRam0c959618 = uRam0c959610;

      }

      uStack_6c = 0xffffffff;

      iStack_34 = firewallMalloc(0xb6d5f0);

    }

    else {

      iStack_34 = 0;

      iRam0c95961c = iRam0c95961c + 1;

    }

    uStack_6c = 1;

    _ZN8Firewall10FwksFilterC1Ev();

    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_34;

    iVar1 = 0;

    if (iStack_34 != 0) goto LAB_040f1a0c;

  }

  else {

LAB_040f1a0c:

    iVar1 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;

  }

  if (iVar1 != 0) {

    iStack_30 = iVar1 + 0xb2b6d8;

    iStack_2c = param_1;

    strncpy(param_1,0xa17dbf4,0xfa);

    iVar3 = 9;

    iVar1 = iStack_2c;

    do {

      iVar3 = iVar3 + -1;

      *(uint32_t *)(iVar1 + 0x104) = 0;

      *(uint32_t *)(iVar1 + 0x100) = 0;

      *(uint32_t *)(iVar1 + 0x154) = 0;

      *(uint32_t *)(iVar1 + 0x150) = 0;

      iVar1 = iVar1 + 8;

    } while (-1 < iVar3);

    iVar3 = 0;

    iVar1 = iStack_30;

    do {

      iVar9 = 0;

      if (iVar1 + 0x30 != *(int *)(iVar1 + 0x34)) {

        iVar9 = *(int *)(iVar1 + 0x34);

      }

      iVar2 = iVar9 + -0x24;

      if (iVar9 == 0) {

        iVar2 = 0;

      }

      while (iVar2 != 0) {

        iVar9 = 0;

        do {

          iVar6 = iVar9 * 8 + iVar2;

          iVar5 = iVar9 * 8 + iStack_2c;

          uVar8 = *(uint *)(iVar6 + 0x74);

          iVar7 = *(int *)(iVar6 + 0x70);

          uVar4 = *(int *)(iVar5 + 0x104) + uVar8;

          *(uint *)(iVar5 + 0x104) = uVar4;

          *(uint *)(iVar5 + 0x100) = *(int *)(iVar5 + 0x100) + iVar7 + (uint)(uVar4 < uVar8);

          uVar8 = *(uint *)(iVar6 + 0xc4);

          iVar6 = *(int *)(iVar6 + 0xc0);

          uVar4 = *(int *)(iVar5 + 0x154) + uVar8;

          iVar9 = iVar9 + 1;

          *(uint *)(iVar5 + 0x154) = uVar4;

          *(uint *)(iVar5 + 0x150) = *(int *)(iVar5 + 0x150) + iVar6 + (uint)(uVar4 < uVar8);

        } while (iVar9 < 10);

        iVar9 = iVar2 + 0x24;

        if (iVar2 == 0) {

          iVar9 = 0;

        }

        iVar5 = 0;

        if (iVar1 + 0x30 != *(int *)(iVar9 + 4)) {

          iVar5 = *(int *)(iVar9 + 4);

        }

        iVar2 = iVar5 + -0x24;

        if (iVar5 == 0) {

          iVar2 = 0;

        }

      }

      iVar3 = iVar3 + 1;

      iVar1 = iVar1 + 0x18;

    } while (iVar3 < 0x100);

  }

LAB_040f1b50:

  _Unwind_SjLj_Unregister(auStack_70);

  return;

}