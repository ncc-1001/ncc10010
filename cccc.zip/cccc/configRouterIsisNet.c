#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t configRouterIsisNet(uint32_t param_1,int param_2,char *param_3)



{

  bool bVar1;

  int iVar2;

  byte bVar4;

  uint uVar3;

  uint32_t uVar5;

  char *pcVar6;

  uint uVar7;

  uint uVar8;

  uint uVar9;

  int iStack_38;

  uintptr_t uStack_34;

  byte abStack_33 [23];

  uint32_t uStack_1c;

  

  uVar9 = 0;

  if (param_2 == 0 || param_3 == (char *)0x0) {

    timosAssert(0xa07d890,0xa07cd10,0x7ba,0xa07d87c,0xa07cd74);

  }

  iStack_38 = getVRtrId(param_1,param_2);

  uVar5 = 0xffffffff;

  if (iStack_38 != 0) {

    uVar8 = 0;

    memset(abStack_33,0,0x14);

    iVar2 = strlen(param_3);

    bVar1 = true;

    uVar7 = 0;

    pcVar6 = param_3;

    if (iVar2 != 0) {

      do {

        if (*pcVar6 == '.') {

          if (bVar1) {

            uVar9 = uVar9 + 1;

          }

        }

        else {

          if (uVar7 != 0) {

            abStack_33[(int)uVar9 / 2] = abStack_33[(int)uVar9 / 2] << 4;

          }

          iVar2 = (int)uVar9 / 2;

          bVar4 = hexCharToVal();

          uVar9 = uVar9 + 1;

          abStack_33[iVar2] = bVar4 | abStack_33[iVar2];

        }

        uVar8 = uVar8 + 1;

        uVar3 = strlen(param_3);

        pcVar6 = param_3 + uVar8;

        bVar1 = (int)uVar8 < 2;

        uVar7 = uVar9 & 1;

      } while (uVar8 < uVar3);

    }

    uStack_1c = 4;

    uStack_34 = (uintptr_t)((int)(uVar9 + 1) / 2);

    iVar2 = sia_isisManAreaAddrEntryCheck(1,&iStack_38);

    uVar5 = 0xffffffff;

    if (iVar2 == 0) {

      sia_isisManAreaAddrEntrySet(1,&iStack_38);

      uVar5 = 0;

    }

  }

  return uVar5;

}



