#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisAdjClear(uint32_t *param_1,int param_2)



{

  int iVar1;

  int iVar2;

  int iVar3;

  int iVar4;

  uint32_t uVar5;

  int iVar6;

  

  for (iVar2 = dlistGetFirst(param_1[0xa8]); iVar2 != 0; iVar2 = dlistGetNext(iVar2)) {

    iVar6 = 1;

    if (*(int *)(iVar2 + 0x2f4) == 1) {

      iVar6 = *(int *)(iVar2 + 0x3d8);

      if ((iVar6 != 0) && ((param_2 == 0 || (iVar3 = memcmp(iVar6 + 6,param_2,6), iVar3 == 0)))) {

        redTransModuleX(0x34,1,0xa1a688c,0x371);

        isisHoldTimerExp(*param_1,iVar6,0);

        redTransModuleX(0x34,0,0xa1a688c,0x375);

      }

    }

    else {

      do {

        if (iVar6 == 1) {

          uVar5 = *(uint32_t *)(iVar2 + 0x420);

        }

        else {

          uVar5 = *(uint32_t *)(iVar2 + 0x5f0);

        }

        iVar3 = dlistGetFirst(uVar5);

        while (iVar1 = iVar3, iVar1 != 0) {

          iVar3 = dlistGetNext(iVar1);

          if ((param_2 == 0) || (iVar4 = memcmp(iVar1 + 6,param_2,6), iVar4 == 0)) {

            redTransModuleX(0x34,1,0xa1a688c,0x381);

            isisHoldTimerExp(*param_1,iVar1,0);

            redTransModuleX(0x34,0,0xa1a688c,0x385);

          }

        }

        iVar6 = iVar6 + 1;

      } while (iVar6 < 3);

    }

  }

  return;

}



