#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Add typedef for 'code' type
typedef void code;

// Modified: Add extern declarations for undeclared global variables
extern code *__gxx_personality_sj0;
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern unsigned int uRam0c959618;
extern int iRam0c95961c;

uint fwksZonesUpdate(ushort *param_1)
{
  uint uVar1;
  int iVar2;
  uintptr_t auStack_98 [16];
  uintptr_t auStack_88 [4];
  uint32_t uStack_84;
  code *pcStack_70;
  uint32_t uStack_6c;
  uintptr_t *puStack_68;
  uint32_t uStack_64;
  uintptr_t *puStack_60;
  uint uStack_54;
  int iStack_48;
  int iStack_44;
  ushort *puStack_40;
  int iStack_3c;
  int iStack_38;
  uint uStack_34;
  ushort *puStack_30;
  
  puStack_60 = auStack_98;
  puStack_68 = auStack_88;
  pcStack_70 = __gxx_personality_sj0;
  uStack_64 = 0x40e500c;
  uStack_6c = 0xbff8544;
  _Unwind_SjLj_Register(puStack_68);
  uStack_54 = 0;
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_84 = 0xffffffff;
      iStack_48 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_48 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_84 = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_48;
    iVar2 = 0;
    if (iStack_48 == 0) goto LAB_040e4e88;
  }
  iVar2 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
LAB_040e4e88:
  if ((iVar2 != 0) && (param_1 != (ushort *)0x0)) {
    iStack_3c = 0;
    uVar1 = 1;
    iStack_44 = iVar2;
    puStack_40 = param_1;
    if (*param_1 != 0) {
      puStack_30 = param_1 + 4;
      iStack_38 = iVar2 + 0xb30000;
      do {
        iVar2 = 0xb6b950;
        if (*(int *)(iStack_38 + -0xe70) == 0) {
          iVar2 = 0xb6a070;
        }
        uStack_84 = 0xffffffff;
        uVar1 = _ZN8Firewall9ZoneGroup11updateStateER9tFwksZone(iStack_44 + iVar2,puStack_30);
        iStack_3c = iStack_3c + 1;
        puStack_30 = puStack_30 + 4;
      } while ((iStack_3c < (int)(uint)*puStack_40) && (uVar1 != 0));
    }
    uStack_54 = uVar1 & 0xff;
  }
  uStack_34 = (uint)(uStack_54 != 0);
  _Unwind_SjLj_Unregister(auStack_88);
  return uStack_34;
}