#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern uintptr_t IsisAllISMacAddr;
extern uintptr_t IsisAllL1ISMacAddr;
extern uintptr_t IsisAllL2ISMacAddr;
extern uintptr_t osiLlcHdr;

void isisEncodeL2Hdr(uint32_t param_1,int param_2,int param_3,int param_4,int param_5)
{
  int iVar1;
  uintptr_t *puVar2;
  uint uVar3;
  int iVar4;
  uintptr_t *puVar5;
  
  iVar1 = *(int *)(param_4 + 8) + param_4;
  if (*(int *)(param_2 + 0x2f4) == 1) {
    puVar5 = &IsisAllISMacAddr;
  }
  else if (param_3 == 1) {
    puVar5 = &IsisAllL1ISMacAddr;
  }
  else {
    puVar5 = &IsisAllL2ISMacAddr;
  }
  memcpy(iVar1 + 0xa0,puVar5,6);
  memcpy(iVar1 + 0xa6,param_2 + 0x1c8,6);
  uVar3 = param_5 + 3U & 0xffff;
  *(char *)(iVar1 + 0xac) = (char)(uVar3 >> 8);
  *(char *)(iVar1 + 0xad) = (char)uVar3;
  iVar4 = 0;
  puVar5 = (uintptr_t *)(iVar1 + 0xae);
  do {
    puVar2 = &osiLlcHdr + iVar4;
    iVar4 = iVar4 + 1;
    *puVar5 = *puVar2;
    puVar5 = puVar5 + 1;
  } while (iVar4 < 3);
  *(int *)(param_4 + 0xc) = param_5 + 0x11;
  return;
}