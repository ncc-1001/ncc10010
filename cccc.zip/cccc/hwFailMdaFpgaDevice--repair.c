#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern byte bRam80018008;
extern int cRam10c8f925;

uint32_t hwFailMdaFpgaDevice(uint param_1)
{
  uint uVar1;
  uint uVar2;
  uint32_t uVar3;
  uint16_t auStack_18 [4];
  
  uVar3 = 0;
  if ((param_1 != 0) && (param_1 <= *(byte *)((uint)bRam80018008 * 0x48 + 0xaeb426b))) {
    uVar1 = macMdaGetHwMdaType();
    if (cRam10c8f925 == -0x24) {
      uVar3 = 0xffffffff;
    }
    else if (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12) {
      uVar3 = 0xffffffff;
    }
    if ((((((cRam10c8f925 == -0x13 || cRam10c8f925 == -0x17) || ((byte)(cRam10c8f925 + 0x16U) < 2))
          || (cRam10c8f925 == -0xd || cRam10c8f925 == -0xf)) ||
         (((cRam10c8f925 == -8 || (cRam10c8f925 == -9)) ||
          ((cRam10c8f925 == -10 || cRam10c8f925 == -0x10 ||
           ((cRam10c8f925 == -0xe || (cRam10c8f925 == -0x24)))))))) ||
        (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12)) ||
       (((byte)(cRam10c8f925 + 0x1eU) < 6 || (cRam10c8f925 == -7)))) {
      if ((param_1 != 0) && (((2 < param_1 && (param_1 == 3)) && (uVar1 != 0x7c)))) {
        if (uVar1 < 0x7d) {
          uVar2 = 0x7a;
        }
        else {
          if (uVar1 == 0x7d) {
            auStack_18[0] = 0;
            hwHartlandSetMciConfig(auStack_18);
            return uVar3;
          }
          uVar2 = 0xa5;
        }
        if (uVar1 != uVar2) {
          return uVar3;
        }
      }
    }
    else if (uVar1 == 0x88) {
      mdaGpioResetDeviceTest(param_1,0x40,1);
      return uVar3;
    }
  }
  return 0xffffffff;
}