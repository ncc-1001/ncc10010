#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void convert_from_SW_RAW_PARMS(int param_1,int param_2,uint32_t param_3)



{

  *(byte *)(param_2 + 0xc) =

       *(byte *)(param_2 + 0xc) & 0xf | (byte)((ushort)*(uint16_t *)(param_1 + 0x10) >> 8) & 0xf0;

  insert_bits(param_2,100,0,*(ushort *)(param_1 + 0x10) & 0xfff,0xc);

  *(byte *)(param_2 + 0xe) =

       *(byte *)(param_2 + 0xe) & 0xf | (byte)((ushort)*(uint16_t *)(param_1 + 0x12) >> 8) & 0xf0;

  convert_from_SW_RAW_MAIN_PARMS(param_1,param_2,param_3);

  return;

}



