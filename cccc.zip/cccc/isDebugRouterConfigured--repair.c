#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared runtime feature variables
extern int _runtime_feature_l2tp;
extern int _runtime_feature_ip6;
extern int _runtime_feature_igmp;
extern int _runtime_feature_pim;
extern int _runtime_feature_msdp;

uint32_t isDebugRouterConfigured(uint32_t param_1,uint32_t param_2,int param_3)
{
  int iVar1;
  uint32_t uVar2;
  int aiStack_8c8 [42];
  int aiStack_820 [72];
  uint auStack_700 [20];
  uint auStack_6b0 [116];
  uint auStack_4e0 [10];
  uintptr_t auStack_4b8 [664];
  uintptr_t auStack_220 [136];
  char cStack_198;
  char cStack_197;
  char acStack_196 [6];
  int iStack_190;
  uint32_t uStack_18c;
  uint32_t uStack_188;
  uintptr_t auStack_28 [4];
  uint32_t uStack_24;
  int aiStack_20 [2];
  
  aiStack_20[0] = 0;
  uStack_24 = 0;
  cStack_198 = '\0';
  cStack_197 = '\0';
  acStack_196[0] = '\0';
  memset(&iStack_190,0,0x168);
  iStack_190 = param_3;
  if (param_3 == 1) {
    memset(aiStack_820,0,0x120);
    isisDebugInfoGet(1,aiStack_820);
    if (aiStack_820[0] != 0) {
      return 1;
    }
    iVar1 = mplsDebugGetFirstContext(auStack_220);
    if (iVar1 == 0) {
      return 1;
    }
    iVar1 = ldpDebugState_GetFirst(1,auStack_28,0,&uStack_24);
    if (iVar1 == 0) {
      return 1;
    }
    iVar1 = ldpDebugState_GetFirst(1,0,auStack_28,&uStack_24);
    if (iVar1 == 0) {
      return 1;
    }
    if ((_runtime_feature_l2tp != 0) && (iVar1 = debugL2tpConfigured(), iVar1 != 0)) {
      return 1;
    }
  }
  pipGenerateDebugConfigProcess(param_1,param_2,1,param_3,0,&cStack_198);
  if (cStack_198 != '\0') {
    return 1;
  }
  if ((_runtime_feature_ip6 != 0 || param_3 == 0xfff) &&
     (tipGenerateDebugConfigProcess(param_1,param_2,1,param_3,0,acStack_196), acStack_196[0] != '\0'
     )) {
    return 1;
  }
  ripGenerateDebugConfigProcess(param_1,param_2,1,param_3,0,&cStack_197);
  if (cStack_197 != '\0') {
    return 1;
  }
  memset(auStack_4b8,0,0x294);
  bgp_debug_get_config(param_3,aiStack_20,auStack_4b8);
  if (aiStack_20[0] != 0) {
    return 1;
  }
  memset(aiStack_8c8,0,0xa4);
  while( true ) {
    iVar1 = sia_tmnxOspfGeneralEntryGet(3,&iStack_190);
    if (iVar1 != 0) break;
    ospfGetDebugSettings(param_3,uStack_18c,uStack_188);
    if (aiStack_8c8[0] != 0) {
      return 1;
    }
  }
  if (_runtime_feature_igmp != 0) {
    // Modified: Fixed memset call by removing extra argument
    memset(auStack_700,0,0x50);
    igmpDebugInfoGet(param_3,0,auStack_700);
    if ((auStack_700[0] & 0xfffffffd) != 0) {
      return 1;
    }
    memset(auStack_700,0,0x50);
    igmpDebugInfoGet(param_3,1,auStack_700);
    if ((auStack_700[0] & 0xfffffffd) != 0) {
      return 1;
    }
  }
  if (_runtime_feature_pim != 0) {
    memset(auStack_6b0,0,0x1cc);
    pimGetDebugInfo(param_3,auStack_6b0);
    if ((auStack_6b0[0] & 0xfffffffe) != 0) {
      return 1;
    }
  }
  if (_runtime_feature_msdp != 0) {
    memset(auStack_4e0,0,0x28);
    msdpGetDebugInfo(param_3,auStack_4e0);
    if ((auStack_4e0[0] & 0xfffffffe) != 0) {
      return 1;
    }
  }
  iVar1 = mTraceGetDebugFlag(param_3);
  if (iVar1 != 0) {
    return 1;
  }
  vrrpLock();
  for (iVar1 = vrrpGetDebugInfoPtr(); iVar1 != 0; iVar1 = *(int *)(iVar1 + 0x28)) {
    if (*(int *)(iVar1 + 4) == param_3) goto LAB_03be17a0;
  }
  iVar1 = srrpGetDebugInfoPtr();
  while( true ) {
    if (iVar1 == 0) {
      vrrpUnlock();
      uVar2 = dhcpsDebugPresent(param_3);
      return uVar2;
    }
    if (*(int *)(iVar1 + 4) == param_3) break;
    iVar1 = *(int *)(iVar1 + 0x10);
  }
LAB_03be17a0:
  vrrpUnlock();
  return 1;
}