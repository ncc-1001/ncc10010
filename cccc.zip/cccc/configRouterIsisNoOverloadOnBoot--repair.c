#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t configRouterIsisNoOverloadOnBoot(uint32_t param_1,uint32_t param_2)


{

  int iVar1;
  
  ___chk_strnum = 1;
  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d958,0,0xa07cc30);
  if (iVar1 == 0) {
    ___chk_strnum = 0;
    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07d970,0,0xa07d274);
    if (iVar1 == 0) {
      return 0;
    }
  }
  cliErrorMesg(param_1, 0xa07d924, 0); // Modified: Added dummy argument to match cliErrorMesg declaration
  return 0xffffffff;
}
