#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared global variable
extern int *_gMdaInfo;
// Modified: Added extern declaration for undeclared global variable
extern char cRam0000002c;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



bool csaEthPtpPollTimeUpdate(uint param_1,int param_2)


{

  bool bVar2;

  int iVar1;

  char *pcVar3;

  

  bVar2 = false;

  if (param_1 != 0) {

    pcVar3 = (char *)(param_1 * 0x3a88 + 0x10d260a8);

    if (((param_1 <= *_gMdaInfo) && (*pcVar3 != '\0')) && (pcVar3 != (char *)0x0)) {

      if (*(char *)(param_1 * 0x3a88 + 0x10d260ec) != '\x01') {

        return false;

      }

      goto LAB_063686bc;

    }

  }

  if (cRam0000002c != '\x01') {

    return false;

  }

LAB_063686bc:

  iVar1 = fpgaUBlazeTimeUpdateReady();

  if (iVar1 != 0) {

    iVar1 = fpgaUBlazeGetSysTimeOffsetNs(param_1,param_2,param_2 + 4);

    bVar2 = iVar1 == 0;

  }

  return bVar2;

}
