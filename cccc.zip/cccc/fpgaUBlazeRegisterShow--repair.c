// Modified: Changed absolute path to relative path for nokia.h include
#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared variables
extern uint* _gMdaInfo;
extern int cRam10c8f925;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void fpgaUBlazeRegisterShow(uint param_1)


{

  int iVar1;

  uint uVar2;

  uint32_t uVar3;

  

  if (param_1 != 0) {

    if (((param_1 <= *_gMdaInfo) && (iVar1 = fpgaIsValidMda(), iVar1 != 0)) &&

       (iVar1 = fpgaGetMda(param_1), iVar1 != 0)) {

      // Modified: Fixed complex if condition syntax
      if ((cRam10c8f925 == -0x13 || cRam10c8f925 == -0x17 || (byte)(cRam10c8f925 + 0x16U) < 2) ||
          (cRam10c8f925 == -0xd || cRam10c8f925 == -0xf || cRam10c8f925 == -8 || cRam10c8f925 == -9) ||
          (cRam10c8f925 == -10 || cRam10c8f925 == -0x10) ||
          (cRam10c8f925 == -0xe || cRam10c8f925 == -0x24 || cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12) ||
          ((byte)(cRam10c8f925 + 0x1eU) < 6 || cRam10c8f925 == -7)) {

        iVar1 = hwSarmFpgaIs1588InReset();

        uVar3 = 0xa8db09c;

        if (iVar1 == 0) {

          uVar3 = _fpgaUBlazeRegRead(param_1,0);

                    /* WARNING: Subroutine does not return */

          printf(0xa8db0b8,0xa8db0d4,0,uVar3);

        }

      }

      else {

        uVar2 = fpgaRegRead(param_1,0x24);

        if ((uVar2 & 0x40000000) != 0) {

                    /* WARNING: Subroutine does not return */

          printf(0xa8db5ec);

        }

        uVar3 = 0xa8db5cc;

      }

                    /* WARNING: Subroutine does not return */

      printf(uVar3);

    }

    // Modified: Fixed complex if condition syntax
    if ((param_1 != 0) && (param_1 <= *_gMdaInfo) &&
       (iVar1 = macMdaRemoved(param_1), iVar1 == 0) &&
       (_traceEnabled != 0 ||
        (_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa8db070,4,0), iVar1 != 0)))) {

      tracePrintVRtr(_MOD_MDADRV,0xa8db070,4,0,1,0xa8d9798,param_1);

    }

  }

                    /* WARNING: Subroutine does not return */

  printf(0xa8db088,0xa8db070);

}
