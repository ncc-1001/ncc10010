#include "nokia.h"
#include <stdint.h>

extern int* _gMdaInfo; // Modified: Added extern declaration for undeclared global variable

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void csaEthPtpPollPeerStats(uint param_1)



{

  char cVar1;

  uintptr_t uVar2;

  int iVar3;

  int iVar4;

  uint uVar5;

  char *pcVar6;

  uint32_t auStack_20 [2];
  

  auStack_20[0] = 0;

  uVar5 = 1;

  iVar3 = xmacRedIsCardActive();

  if ((iVar3 != 0) && (iVar3 = macMdaRemoved(param_1), iVar3 == 0)) {

    pcVar6 = (char *)(param_1 * 0x3a88 + 0x10d260a8);

    do {

      if ((((param_1 != 0) && (param_1 <= *_gMdaInfo)) && (*pcVar6 != '\0')) &&

         (((iVar3 = param_1 * 0x3a88 + 0x10d260c0, pcVar6 != (char *)0x0 && (iVar3 != 0)) &&

          ((uVar5 - 1 < 10 && (iVar3 = uVar5 * 0x5c8 + iVar3, iVar3 != 0x578)))))) {

        if (*(int *)(iVar3 + -0x564) == 1) {

          iVar4 = fpgaUBlazeGetStat(param_1,2,auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x560) = auStack_20[0];

          }

          iVar4 = fpgaUBlazeGetStat(param_1,3,auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x558) = auStack_20[0];

          }

          iVar4 = fpgaUBlazeGetStat(param_1,5,auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x550) = auStack_20[0];

          }

          iVar4 = fpgaUBlazeGetStat(param_1,6,auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x54c) = auStack_20[0];

          }

          iVar4 = fpgaUBlazeGetStat(param_1,8,auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x544) = auStack_20[0];

            *(uint32_t *)(iVar3 + -0x548) = 0;

          }

          else {

            *(uint32_t *)(iVar3 + -0x548) = 0;

          }

          *(uint32_t *)(iVar3 + -0x55c) = 0;

          *(uint32_t *)(iVar3 + -0x554) = 0;

        }

        else if (*(int *)(iVar3 + -0x564) == 2) {

          iVar4 = fpgaUBlazeGetStat(param_1,*(char *)(iVar3 + 0x48) + '\t',auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x554) = auStack_20[0];

            cVar1 = *(char *)(iVar3 + 0x48);

          }

          else {

            cVar1 = *(char *)(iVar3 + 0x48);

          }

          iVar4 = fpgaUBlazeGetStat(param_1,cVar1 + '\x18',auStack_20);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x548) = auStack_20[0];

            uVar2 = *(uintptr_t *)(iVar3 + 0x48);

          }

          else {

            uVar2 = *(uintptr_t *)(iVar3 + 0x48);

          }

          iVar4 = fpgaUBlazeGetSyncTxCnt(param_1,uVar2,auStack_20,0);

          if (iVar4 == 0) {

            *(uint32_t *)(iVar3 + -0x55c) = auStack_20[0];

            *(uint32_t *)(iVar3 + -0x544) = 0;

          }

          else {

            *(uint32_t *)(iVar3 + -0x544) = 0;

          }

          *(uint32_t *)(iVar3 + -0x560) = 0;

          *(uint32_t *)(iVar3 + -0x550) = 0;

          *(uint32_t *)(iVar3 + -0x54c) = 0;

        }

      }

      uVar5 = uVar5 + 1 & 0xff;

    } while (uVar5 < 0xb);

    return;

  }

  return;
}
