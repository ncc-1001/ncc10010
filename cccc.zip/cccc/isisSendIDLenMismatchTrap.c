#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisSendIDLenMismatchTrap(uint32_t *param_1,int param_2,int param_3)



{

  byte bVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  byte bVar5;

  uintptr_t auStack_1a8 [400];

  

  bVar1 = *(byte *)(param_3 + 3);

  iVar2 = (uint)bVar1 + param_3 + 0xb;

  if (2 < *(byte *)(param_3 + 4) - 0xf) {

    iVar2 = param_3 + 8;

  }

  bVar5 = *(byte *)(iVar2 + 1);

  if (0x40 < bVar5) {

    bVar5 = 0x40;

  }

  auStack_1a8[0] = 0;

  logger_OctetsHexDump(param_3,bVar5,auStack_1a8,400);

  uVar3 = strlen(auStack_1a8);

  uVar4 = *param_1;

  logEvent_ISIS_vRtrIsisIDLenMismatch

            (uVar4,0xa1bba38,uVar4,(uint)bVar1,uVar4,*(uint32_t *)(param_2 + 8),param_3,bVar5,

             auStack_1a8,uVar3);

  return;

}



