#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisRedOverloadClear(int param_1)



{

  int iVar1;

  int iVar2;

  int iVar3;

  int iVar4;

  uint uVar5;

  int aiStack_10 [2];

  

  if (param_1 == 0) {

    param_1 = 1;

  }

  iVar1 = isisGetNode(param_1,aiStack_10);

  uVar5 = 1;

  if (iVar1 != 0) {

                    /* WARNING: Subroutine does not return */

    printf(0xa1ae00c,param_1);

  }

  do {

    iVar3 = 0;

    iVar4 = 0;

    iVar1 = 1;

    do {

      if (uVar5 == 1) {

        iVar2 = iVar4 + aiStack_10[0] + 0x5e0;

      }

      else {

        iVar2 = iVar3 + aiStack_10[0] + 0x630;

      }

      iVar1 = iVar1 + -1;

      iVar4 = iVar4 + 0x28;

      iVar3 = iVar3 + 0x28;

      if (iVar2 != 0) {

        *(uint32_t *)(iVar2 + 0x24) = 0;

        *(uintptr_t *)(iVar2 + 0xe) = 0;

        *(uint32_t *)(iVar2 + 0x14) = 0;

        *(uint32_t *)(iVar2 + 0x18) = 0;

        *(uint32_t *)(iVar2 + 0x1c) = 0;

        *(uint32_t *)(iVar2 + 0x20) = 0;

      }

    } while (-1 < iVar1);

    uVar5 = uVar5 + 1;

  } while (uVar5 < 3);

  return;

}



