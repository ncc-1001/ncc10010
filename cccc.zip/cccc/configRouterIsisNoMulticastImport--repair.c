#include "nokia.h"
#include <stdint.h>

extern int ___chk_strnum;  // Modified: Added extern declaration for undeclared variable

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t configRouterIsisNoMulticastImport(uint32_t param_1,uint32_t param_2,int param_3)


{

  int iVar1;

  

  if ((param_3 == 0) || (iVar1 = strcmp(param_3,0xa07e1b4), iVar1 == 0)) {

    ___chk_strnum = 2;

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e224,0,0xa07cc34);

    if (iVar1 != 0) goto LAB_03a993c4;

    ___chk_strnum = 2;

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e23c,0,0xa07cc34);

    if (iVar1 != 0) goto LAB_03a9933c;

  }

  if (param_3 == 0) {

    return 0;

  }

  iVar1 = strcmp(param_3,0xa07e164);

  if (iVar1 == 0) {

    ___chk_strnum = 2;

    iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e224,0,0xa07cc34);

    if (iVar1 != 0) {

LAB_03a993c4:

      cliErrorMesg(param_1,0xa07e284);

      return 0xffffffff;

    }

  }

  if (param_3 == 0) {

    return 0;

  }

  iVar1 = strcmp(param_3,0xa07e1ac);

  if (iVar1 != 0) {

    return 0;

  }

  ___chk_strnum = 2;

  iVar1 = cfgRouterIndexElements(param_1,param_2,0xa07e23c,0,0xa07cc34);

  if (iVar1 == 0) {

    return 0;

  }

LAB_03a9933c:

  cliErrorMesg(param_1,0xa07e258);

  return 0xffffffff;

}
