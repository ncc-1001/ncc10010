#include "nokia.h"
#include <stdint.h>

extern int _tracepointsActive; // Modified: Added extern declaration for undeclared variable
extern int _MOD_MDADRV; // Modified: Added extern declaration for undeclared variable

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



int csaEthXgigPhyPortReConfig(int param_1,int param_2,uint32_t *param_3)



{

  uint32_t *puVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  int iVar5;

  uint32_t *puVar6;

  uint32_t *puVar7;

  uint32_t uVar8;

  uint32_t *puVar9;

  int iVar10;

  

  iVar2 = *(int *)(param_2 + 0x8b0);

  iVar5 = param_3[4];

  iVar10 = 0;

  if (iVar5 == iVar2) {

LAB_06401f6c:

    if ((iVar2 != 2) || (iVar5 != 2)) {

      if (param_3[0xe] != *(int *)(param_2 + 0x8d8)) {

        if (_tracepointsActive != 0) {

          iVar5 = traceTest(_MOD_MDADRV,0xa8e8e98,1,0);

          iVar10 = 1;

          if (iVar5 != 0) {

            tracePrintVRtr(_MOD_MDADRV,0xa8e8e98,1,0,1,0xa8e8ef8,*(uint32_t *)(param_1 + 8),

                           *(uint16_t *)(param_2 + 0x14),*(uint32_t *)(param_2 + 0x8d8),

                           param_3[0xe]);

            goto LAB_06401fa0;

          }

        }

        iVar10 = 1;

      }

LAB_06401fa0:

      puVar7 = param_3;

      puVar1 = (uint32_t *)(param_2 + 0x8a0);

      do {

        puVar9 = puVar1;

        puVar6 = puVar7;

        uVar8 = puVar6[1];

        uVar3 = puVar6[2];

        uVar4 = puVar6[3];

        puVar7 = puVar6 + 4;

        *puVar9 = *puVar6;

        puVar9[1] = uVar8;

        puVar9[2] = uVar3;

        puVar9[3] = uVar4;

        puVar1 = puVar9 + 4;

      } while (puVar7 != param_3 + 0x10);

      uVar8 = *puVar7;

      uVar3 = puVar6[5];

      puVar9[6] = puVar6[6];

      puVar9[4] = uVar8;

      puVar9[5] = uVar3;

      if ((_tracepointsActive != 0) && (iVar5 = traceTest(_MOD_MDADRV,0xa8e8e98,1,0), iVar5 != 0)) {

        uVar8 = 0xa8e8ee8;

        if (iVar10 == 0) {

          uVar8 = 0xa8e8ef0;

        }

        tracePrintVRtr(_MOD_MDADRV,0xa8e8e98,1,0,1,0xa8e8eb4,*(uint32_t *)(param_1 + 8),

                       *(uint16_t *)(param_2 + 0x14),uVar8);

      }

      return iVar10;

    }

  }

  else {

    if (_tracepointsActive == 0) {

      csaEthWpSetLoopbackMode

                (*(uint32_t *)(param_1 + 8),*(uint32_t *)(param_2 + 0x10),iVar5,

                 *(uintptr_t *)(param_3 + 0xd));

      iVar5 = param_3[4];

      *(uintptr_t *)(param_2 + 0x8d4) = *(uintptr_t *)(param_3 + 0xd);

    }

    else {

      iVar5 = traceTest(_MOD_MDADRV,0xa8e8e98,1,0);

      if (iVar5 == 0) {

        uVar8 = param_3[4];

      }

      else {

        tracePrintVRtr(_MOD_MDADRV,0xa8e8e98,1,0,1,0xa8e8f30,*(uint32_t *)(param_1 + 8),

                       *(uint16_t *)(param_2 + 0x14),param_3[4],*(uint32_t *)(param_2 + 0x8b0),

                       *(uintptr_t *)(param_3 + 0xd));

        uVar8 = param_3[4];

      }

      csaEthWpSetLoopbackMode

                (*(uint32_t *)(param_1 + 8),*(uint32_t *)(param_2 + 0x10),uVar8,

                 *(uintptr_t *)(param_3 + 0xd));

      iVar5 = param_3[4];

      *(uintptr_t *)(param_2 + 0x8d4) = *(uintptr_t *)(param_3 + 0xd);

    }

    if (iVar5 != 1) {

      iVar10 = 1;

      iVar2 = *(int *)(param_2 + 0x8b0);

      if (iVar2 != 1) goto LAB_06401f6c;

    }

    *(int *)(param_2 + 0x8b0) = iVar5;

  }

  return 0;

}
