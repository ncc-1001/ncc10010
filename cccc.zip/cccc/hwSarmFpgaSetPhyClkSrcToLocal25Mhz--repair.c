#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undefined variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;
extern uintptr_t *currentTimingCtrl;

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void hwSarmFpgaSetPhyClkSrcToLocal25Mhz(char param_1)



{

  int in_zero;

  uint uVar1;

  int iVar2;

  uintptr_t *puVar3;

  

  iVar2 = 0;

  if (_TgtHw == 1) {

    if (_kernelIsSmp == 0) {

      iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

    }

    else {

      iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

    }

  }

  if (*(char *)(iVar2 + 0x10c8f925) == -0x1e) {

LAB_029614a4:

    uVar1 = 0xffffefff;

    if (param_1 == '\0') {

      puVar3 = (uintptr_t *)((uint)currentTimingCtrl | 0x1000);

      goto LAB_029614b0;

    }

  }

  else {

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) == -0x1d) goto LAB_029614a4;

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) == -0x1c) goto LAB_029614a4;

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) == -0x1b) goto LAB_029614a4;

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) == -0x1a) goto LAB_029614a4;

    iVar2 = 0;

    if (_TgtHw == 1) {

      if (_kernelIsSmp == 0) {

        iVar2 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;

      }

      else {

        iVar2 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;

      }

    }

    if (*(char *)(iVar2 + 0x10c8f925) == -0x19) goto LAB_029614a4;

    uVar1 = 0xffffdfff;

    if (param_1 != '\0') {

      puVar3 = (uintptr_t *)((uint)currentTimingCtrl | 0x2000);

      goto LAB_029614b0;

    }

  }

  puVar3 = (uintptr_t *)((uint)currentTimingCtrl & uVar1);

LAB_029614b0:

  if (puVar3 != currentTimingCtrl) {

                    /* WARNING: Bad instruction - Truncating control flow here */

    halt_baddata();

  }

  return;

}



