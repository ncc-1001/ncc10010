#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undefined globals/functions
extern uint32_t _gFpgaSarmSharedMem;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int traceTest(uint32_t, uint32_t, int, int);
extern void tracePrintVRtr(uint32_t, uint32_t, int, int, int, uint32_t, uint32_t, uint32_t);

uint32_t fpgaSarmSharedMemRead(uint32_t param_1,uint param_2)
{
  int iVar1;
  
  if ((_gFpgaSarmSharedMem != 0 && param_2 < 0x4000) && ((param_2 & 3) == 0)) {
    return *(uint32_t *)(_gFpgaSarmSharedMem + param_2);
  }
  if ((_traceEnabled == 0) &&
     ((_tracepointsActive == 0 ||
      (iVar1 = traceTest(_MOD_MDADRV | 0x80000000,0xa8d88f4,4,0), iVar1 == 0)))) {
    return 0;
  }
  tracePrintVRtr(_MOD_MDADRV | 0x80000000,0xa8d88f4,4,0,1,0xa8d890c,param_1,param_2);
  return 0;
}