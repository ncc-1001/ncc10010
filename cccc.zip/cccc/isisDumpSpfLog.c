#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

/* WARNING: Removing unreachable block (ram,0x0427bf0c) */



void isisDumpSpfLog(uint32_t param_1)



{

  int iVar1;

  int aiStack_30 [2];

  

  aiStack_30[0] = 0;

  iVar1 = isisGetNode(param_1,aiStack_30);

  if ((iVar1 == 0) && (*(int *)(aiStack_30[0] + 0x20c4) != 0)) {

                    /* WARNING: Subroutine does not return */

    printf(0xa1b97f4);

  }

  return;

}



