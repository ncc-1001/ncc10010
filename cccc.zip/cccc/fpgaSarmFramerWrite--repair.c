#include "nokia.h"
#include <stdint.h>

// Modified: Added declaration for undeclared variable
int cRam10c8f925;
// Modified: Added definition for PRId (assuming it's a constant)
#define PRId 0xd0000000

void fpgaSarmFramerWrite(int param_1,uint param_2,uintptr_t param_3)
{

  uintptr_t *puVar1;

  uint uVar2;

  uint uVar3;

  

  if ((cRam10c8f925 == -0x24) || (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12)) {
    if ((((cRam10c8f925 != -0x13 && cRam10c8f925 != -0x17) && (1 < (byte)(cRam10c8f925 + 0x16U))) ||
        (uVar2 = 0, param_1 != 3)) &&
       ((uVar2 = 2, cRam10c8f925 == -0x24 && (uVar2 = param_1 - 2, 1 < uVar2)))) {
      uVar2 = 2;
    }
    hwSarmFpgaMciWrite(uVar2);
    return;
  }

  if (0xfffffff < param_2) {
    uVar3 = PRId >> 8 & 0xffff;
    uVar2 = uVar3 ^ 0xd01;
    if ((((uVar2 != 0) && (uVar2 = uVar3 ^ 0xd06, uVar2 != 0)) &&
        (uVar2 = uVar3 ^ 0xd04, uVar2 != 0)) && (uVar2 = uVar3 ^ 0xd93, uVar2 != 0)) {
      uVar2 = uVar3 ^ 0xd90;
    }
    if (uVar2 == 0) {
      *(uintptr_t *)(param_2 | 0xa0000000) = param_3;
      return;
    }
  }

  if ((param_2 < 0x800000) ||
     (puVar1 = (uintptr_t *)(param_2 | 0xc0000000), (PRId >> 0x10 & 0xff) != 0xd)) {
    puVar1 = (uintptr_t *)(param_2 | 0xa0000000);
  }
  *puVar1 = param_3;
  return;
}