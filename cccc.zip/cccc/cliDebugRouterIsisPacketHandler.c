#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void cliDebugRouterIsisPacketHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  int iVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint32_t *puStack_30;

  int *piStack_2c;

  uint32_t *puStack_28;

  uint32_t *puStack_24;

  

  uVar3 = 0;

  iVar2 = 0;

  uVar4 = 0;

  uVar5 = 0;

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_30);

  if (iVar1 == 0) {

    uVar3 = *puStack_30;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,&piStack_2c);

  if (iVar1 == 0) {

    iVar2 = *piStack_2c;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,4,&puStack_28);

  if (iVar1 == 0) {

    uVar4 = *puStack_28;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0xa395bc8,8,&puStack_24);

  if (iVar1 == 0) {

    uVar5 = *puStack_24;

  }

  if (iVar2 != 0) {

    iVar2 = RCC_DB_FullEnum(piStack_2c[5],iVar2);

  }

  debugIsisPacket(param_1,uVar3,iVar2,uVar4,uVar5,0);

  return;

}



