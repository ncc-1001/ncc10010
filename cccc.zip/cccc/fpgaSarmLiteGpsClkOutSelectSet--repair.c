#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int _traceEnabled;

void fpgaSarmLiteGpsClkOutSelectSet
               (uint32_t param_1,int param_2,uint32_t param_3,int param_4,char param_5)
{
  uint32_t uVar1;
  int iVar2;
  uint32_t uVar3;
  char cVar4;
  
  cVar4 = '\0';
  if (param_4 != 1) {
    cVar4 = (param_4 != 2) + '\x01';
  }
  if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_MDADRV,0xa8d8c10,1,0), iVar2 != 0)) {
    uVar3 = fpgaFmtRecClkMode(param_2);
    uVar1 = 0xa8d89ac;
    if (param_5 == '\0') {
      uVar1 = 0xa8d89b4;
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8d8c10,1,0,1,0xa8d8a54,param_1,uVar3,param_3,param_4,uVar1);
  }
  if (param_4 == 0) {
    if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_MDADRV,0xa8d8c10,2,0), iVar2 != 0)) {
      uVar3 = fpgaFmtRecClkMode(param_2);
      tracePrintVRtr(_MOD_MDADRV,0xa8d8c10,2,0,1,0xa8d8a9c,param_1,param_3,uVar3);
    }
    return;
  }
  if (param_5 != '\0') {
    if (param_2 == 0) {
      if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_MDADRV,0xa8d8c10,1,0), iVar2 != 0)) {
        tracePrintVRtr(_MOD_MDADRV,0xa8d8c10,1,0,1,0xa8d8c30,param_1,param_3);
      }
      hwSarmLiteFpgaSetRefClkSrc(cVar4,7,cVar4);
      return;
    }
    if ((_traceEnabled != 0) ||
       ((_tracepointsActive != 0 && (iVar2 = traceTest(_MOD_MDADRV,0xa8d8c10,4,0), iVar2 != 0)))) {
      uVar3 = fpgaFmtRecClkMode(param_2);
      tracePrintVRtr(_MOD_MDADRV,0xa8d8c10,4,0,1,0xa8d8b40,param_1,param_3,param_4,uVar3);
      hwSarmLiteFpgaSetRefClkSrc(cVar4,8,cVar4);
      return;
    }
  }
  hwSarmLiteFpgaSetRefClkSrc(cVar4,8,cVar4);
  return;
}