#include "nokia.h"
#include <stdint.h>

// Modified: Added missing declarations for compilation
// Modified: Updated 'code' type to match actual function signatures
typedef void (*code)(uint32_t, uint32_t, uint32_t); // Modified: Define 'code' with correct parameters
extern int Status; // Modified: Declare 'Status' as extern
extern int _kernelIsSmp; // Modified: Declare '_kernelIsSmp' as extern
extern int _smpIntCnt; // Modified: Declare '_smpIntCnt' as extern
extern int* _gMdaInfo; // Modified: Declare '_gMdaInfo' as extern pointer
extern int smpIntCnt; // Modified: Declare 'smpIntCnt' as extern
extern int EBase; // Modified: Declare 'EBase' as extern
extern int _MOD_MDADRV; // Modified: Declare '_MOD_MDADRV' as extern
extern int _tracepointsActive; // Modified: Declare '_tracepointsActive' as extern

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void csaSerialTribCreate(uint32_t param_1)
{
  int iVar1;
  uint uVar2;
  int iVar3;
  code *pcVar4;
  uint uVar5;
  uint32_t uVar6;
  int iVar7;
  uint32_t uVar8;
  
  iVar1 = posMdaTribGetPort();
  uVar2 = posMdaTribGetChanType(param_1);
  uVar5 = Status;
  iVar7 = 0;
  if (_kernelIsSmp == 0) {
    if (_smpIntCnt != 0) {
      iVar3 = *(int *)(iVar1 + 4);
      goto LAB_063e93bc;
    }
    iVar7 = *(int *)(iVar1 + 4);
LAB_063e92bc:
    if ((*(uint *)(iVar7 + 0x36ca24) == 0) || (*_gMdaInfo < *(uint *)(iVar7 + 0x36ca24))) {
      timosAssert(0xa8e4a88,0xa8e47b4,0x1ab,0xa8e4a74,0xa8e478c,
                  *(uint32_t *)(*(int *)(iVar1 + 4) + 0x36ca24));
      iVar7 = *(int *)(iVar1 + 4);
    }
    iVar7 = *(int *)(*(int *)(iVar7 + 0x36ca24) * 4 + 0xeb6f544);
    if (iVar7 == 0) {
      timosAssert(0xa8e47e0,0xa8e47b4,0x1ab,0xa8e4a74,0xa8e47dc);
    }
  }
  else {
    Status = Status & 0xfffffffe;
    setCopReg(0,Status,uVar5,0);
    if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
      iVar7 = *(int *)(iVar1 + 4);
      goto LAB_063e92bc;
    }
    iVar3 = *(int *)(iVar1 + 4);
LAB_063e93bc:
    uVar5 = *(uint *)(iVar3 + 0x36ca24);
    if ((uVar5 != 0) && (uVar5 <= *_gMdaInfo)) {
      iVar7 = *(int *)(uVar5 * 4 + 0xeb6f544);
    }
  }
  if ((_tracepointsActive != 0) && (iVar3 = traceTest(_MOD_MDADRV,0xa8e4a74,1,0), iVar3 != 0)) {
    uVar6 = posMdaTribGetPhysOffset(param_1);
    uVar8 = FmtChanType(uVar2);
    tracePrintVRtr(_MOD_MDADRV,0xa8e4a74,1,0,1,0xa8e4aac,*(uint32_t *)(iVar1 + 0xcb8),uVar6,uVar8)
    ;
  }
  if (uVar2 == 0x14) {
    uVar6 = 4;
    uVar8 = 1;
LAB_063e9500:
    iVar3 = *(int *)(iVar7 + 0x28);
  }
  else {
    if (uVar2 < 0x15) {
      uVar6 = 6;
      if (uVar2 != 0x13) goto LAB_063e937c;
      uVar8 = 0;
      goto LAB_063e9500;
    }
    uVar6 = 3;
    if (uVar2 != 0x15) goto LAB_063e937c;
    iVar3 = *(int *)(iVar7 + 0x28);
    uVar8 = 2;
  }
  if ((iVar3 != 0) && (*(code **)(iVar3 + 4) != (code *)0x0)) {
    (**(code **)(iVar3 + 4))
              (*(uint32_t *)(*(int *)(iVar1 + 4) + 0x36ca24),*(uint32_t *)(iVar1 + 0xcb8),uVar6)
    ;
  }
  uVar6 = posMdaTribGetSerialDeviceGender(param_1);
  csaSerialSetSipexMiscCtrl
            (*(uint32_t *)(*(int *)(iVar1 + 4) + 0x36ca24),*(uint32_t *)(iVar1 + 0xcb8),uVar2,
             uVar6);
  if ((*(code ***)(iVar7 + 0x18) != (code **)0x0) &&
     (pcVar4 = **(code ***)(iVar7 + 0x18), pcVar4 != (code *)0x0)) {
    (*pcVar4)(*(uint32_t *)(*(int *)(iVar1 + 4) + 0x36ca24),*(uint32_t *)(iVar1 + 0xcb8),uVar8);
  }
LAB_063e937c:
  miniTdmCsaTribCreate(param_1);
  return;
}