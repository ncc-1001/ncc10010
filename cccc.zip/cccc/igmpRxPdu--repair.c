#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern uint32_t Status;
extern uint32_t _vxAbsTicks;
extern int _kernelIsSmp;
extern int _smpIntCnt;
extern uint32_t _smpTaskIdCurrent;
extern int smpIntCnt;
extern int EBase;
extern char pbufMarkHistoryTrack;
extern uint32_t _pbufMarkHistoryOffStart;
extern uint32_t _pbufMarkHistoryOffEnd;
extern int _pbufMarkHistoryOff1;
extern char pbufMarkHistoryVal1;
extern int _pbufMarkHistoryOff2;
extern char pbufMarkHistoryVal2;
extern int _pbufMarkHistoryOff3;
extern char pbufMarkHistoryVal3;
extern char pbufMarkHistoryMatchLocation1;
extern uint32_t _pbufMarkHistoryLocationVal1;
extern uint32_t pbufMarkHistoryLock;
extern char pbufMarkHistoryTable;

uint32_t

igmpRxPdu(uint32_t param_1,int param_2,uint32_t *param_3,uint32_t *param_4,uint32_t param_5,

         int param_6)

{
  bool bVar1;
  int in_zero;
  uint uVar2;
  uint uVar3;
  uint32_t uVar4;
  int *piVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  char *pcVar10;
  uint32_t *puVar11;
  int iVar12;
  uint16_t uVar13;
  
  uVar7 = Status;
  uVar3 = _vxAbsTicks;
  if (*(int *)(param_2 + 8) == 0) goto LAB_0416e7e4;
  iVar12 = *(int *)(*(int *)(param_2 + 8) + 8);
  puVar11 = (uint32_t *)(iVar12 + 0x88);
  uVar9 = (uint)*(ushort *)(iVar12 + 0x94);
  uVar2 = _vxAbsTicks / 100;
  if (uVar9 == 0) goto LAB_0416e7e4;
  if (_kernelIsSmp == 0) {
    if (_smpIntCnt == 0) {
LAB_0416ebfc:
      *puVar11 = _smpTaskIdCurrent;
    }
    else {
      *puVar11 = 0;
    }
  }
  else {
    Status = Status & 0xfffffffe;
    setCopReg(0,Status,uVar7,0);
    if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
      if (_kernelIsSmp == 0) goto LAB_0416ebfc;
      *puVar11 = *(uint32_t *)(in_zero + -0x8000);
    }
    else {
      *puVar11 = 0;
    }
  }
  uVar7 = Status;
  uVar8 = (uVar2 & 0xffff) - (uint)*(ushort *)(iVar12 + 0x96) & 0xffff;
  uVar13 = (uint16_t)uVar2;
  if ((uVar8 != 0) && (uVar9 < 0xab)) {
    if (8 < uVar8) {
      uVar8 = 8;
    }
    iVar6 = (uVar9 * 0x558 + uVar8) * 8;
    piVar5 = (int *)(iVar6 + 0xecd53ac);
    *(uint16_t *)(iVar6 + 0xecd53b0) = uVar13;
    *piVar5 = *piVar5 + 1;
  }
  if (pbufMarkHistoryTrack != '\0') {
    if ((*(uint *)(iVar12 + 0x9c) & 0x8000) == 0) {
      iVar6 = *(int *)(iVar12 + 8) + iVar12 + 0xa0;
      bVar1 = false;
      uVar3 = *(uint *)(iVar12 + 0xc);
      if (_pbufMarkHistoryOffStart <= _pbufMarkHistoryOffEnd) {
        uVar7 = _pbufMarkHistoryOffStart;
        do {
          if ((((_pbufMarkHistoryOff1 == -1) ||
               ((_pbufMarkHistoryOff1 + uVar7 < uVar3 &&
                (*(char *)(_pbufMarkHistoryOff1 + iVar6 + uVar7) == pbufMarkHistoryVal1)))) &&
              ((_pbufMarkHistoryOff2 == -1 ||
               ((_pbufMarkHistoryOff2 + uVar7 < uVar3 &&
                (*(char *)(_pbufMarkHistoryOff2 + iVar6 + uVar7) == pbufMarkHistoryVal2)))))) &&
             ((_pbufMarkHistoryOff3 == -1 ||
              ((_pbufMarkHistoryOff3 + uVar7 < uVar3 &&
               (*(char *)(_pbufMarkHistoryOff3 + iVar6 + uVar7) == pbufMarkHistoryVal3)))))) {
            bVar1 = true;
          }
          uVar7 = uVar7 + 1;
        } while (!bVar1 && uVar7 <= _pbufMarkHistoryOffEnd);
      }
      if (bVar1) {
        if ((pbufMarkHistoryMatchLocation1 == '\0') || (_pbufMarkHistoryLocationVal1 == 0x4a))
        goto LAB_0416ec34;
        *(uint16_t *)(iVar12 + 0x96) = uVar13;
        *(uint16_t *)(iVar12 + 0x94) = 0x4a;
        *(uint32_t *)(iVar12 + 0x98) = 0xffffffff;
        goto LAB_0416e7e4;
      }
      if (bVar1) {
LAB_0416ec34:
                    /* WARNING: Subroutine does not return */
        intLockProtect(&pbufMarkHistoryLock);
      }
    }
    else {
      iVar6 = (uint)*(ushort *)(iVar12 + 0x9c) * 0x408;
      pcVar10 = &pbufMarkHistoryTable + iVar6;
      if (*pcVar10 == '\0') {
        *pcVar10 = '\x01';
        *(uint32_t *)(iVar6 + 0xe58e868) = 0;
        uVar2 = *(uint *)(iVar6 + 0xe58e868);
      }
      else {
        uVar2 = *(uint *)(iVar6 + 0xe58e868);
      }
      if (uVar2 < 0x3f) {
        puVar11 = (uint32_t *)(pcVar10 + uVar2 * 0x10 + 8);
        if (_kernelIsSmp == 0) {
          if (_smpIntCnt == 0) {
LAB_0416edb0:
            *puVar11 = _smpTaskIdCurrent;
          }
          else {
            *puVar11 = 0;
          }
        }
        else {
          Status = Status & 0xfffffffe;
          setCopReg(0,Status,uVar7,0);
          if (*(int *)(&smpIntCnt + (EBase & 0xff) * 4) < 1) {
            if (_kernelIsSmp == 0) goto LAB_0416edb0;
            *puVar11 = *(uint32_t *)(in_zero + -0x8000);
          }
          else {
            *puVar11 = 0;
          }
        }
        *(uint *)(pcVar10 + uVar2 * 0x10 + 0x10) = uVar3;
        *(uint16_t *)(pcVar10 + uVar2 * 0x10 + 0xc) = 0x4a;
        *(uint32_t *)(pcVar10 + uVar2 * 0x10 + 0x14) = 0xffffffff;
        *(uint16_t *)(pcVar10 + uVar2 * 0x10 + 0xe) = uVar13;
        *(int *)(iVar6 + 0xe58e868) = *(int *)(iVar6 + 0xe58e868) + 1;
      }
    }
  }
  *(uint16_t *)(iVar12 + 0x96) = uVar13;
  *(uint16_t *)(iVar12 + 0x94) = 0x4a;
  *(uint32_t *)(iVar12 + 0x98) = 0xffffffff;
LAB_0416e7e4:
  iVar12 = 0;
  if (*(int *)(param_2 + 8) != 0) {
    iVar12 = *(int *)(*(int *)(param_2 + 8) + 8);
  }
  if (param_6 == 0) {
    uVar4 = IPLIB_GetHdrLength(param_2);
    F_CutFromStart(param_2,uVar4);
    uVar3 = *(uint *)(param_2 + 0x18);
  }
  else {
    uVar3 = *(uint *)(param_2 + 0x18);
  }
  iVar6 = uVar3 + 0x4c;
  if (200 < uVar3) {
    iVar6 = 0x4c;
  }
  puVar11 = (uint32_t *)mmpiAllocMsg(iVar6);
  if (puVar11 == (uint32_t *)0x0) {
    _F_DeleteExt(param_2,1,0xa185c98,0x240);
    uVar4 = 0xffffffff;
  }
  else {
    puVar11[1] = 1;
    puVar11[2] = 0x40;
    *puVar11 = param_1;
    puVar11[3] = param_5;
    uVar4 = 0;
    if (iVar12 != 0) {
      uVar4 = *(uint32_t *)(iVar12 + 0x18);
    }
    puVar11[4] = uVar4;
    uVar4 = 0;
    if (iVar12 != 0) {
      uVar4 = *(uint32_t *)(iVar12 + 0x1c);
    }
    puVar11[5] = uVar4;
    puVar11[6] = param_6;
    if (param_6 == 0) {
      *(uintptr_t *)(puVar11 + 7) = 1;
      uVar4 = *param_3;
      *(uintptr_t *)(puVar11 + 0xc) = 1;
      puVar11[8] = uVar4;
      puVar11[0xd] = *param_4;
      uVar3 = *(uint *)(param_2 + 0x18);
    }
    else {
      *(uintptr_t *)(puVar11 + 7) = 0;
      memcpy(puVar11 + 8,param_3,0x10);
      *(uintptr_t *)(puVar11 + 0xc) = 0;
      memcpy(puVar11 + 0xd,param_4,0x10);
      uVar3 = *(uint *)(param_2 + 0x18);
    }
    puVar11[0x11] = puVar11[0x11] & 0xffffbfff | (uVar3 < 0xc9 ^ 1) << 0xe;
    *(short *)(puVar11 + 0x11) = (short)*(uint32_t *)(param_2 + 0x18);
    uVar3 = puVar11[0x11];
    uVar7 = (*(uint *)(param_2 + 0x24) & 0x800) << 4;
    puVar11[0x11] = uVar3 & 0xffff7fff | uVar7;
    puVar11[0x11] = uVar3 & 0xffff5fff | uVar7 | (*(byte *)(param_2 + 0x24) & 1) << 0xd;
    if ((uVar3 & 0x4000) == 0) {
      uVar4 = F_GetData(param_2);
      memcpy(puVar11 + 0x12,uVar4,*(uint16_t *)(puVar11 + 0x11));
      _F_DeleteExt(param_2,1,0xa185c98,0x26b);
    }
    else {
      puVar11[0x12] = param_2;
    }
    iVar12 = mmpiPostMsg(param_1,1,param_1,1,1,puVar11,0xffffffff);
    uVar4 = 0;
    if (iVar12 != 0) {
      if ((puVar11[0x11] & 0x4000) == 0) {
        mmpiFreeMsg(puVar11);
        uVar4 = 0xffffffff;
      }
      else {
        _F_DeleteExt(param_2,1,0xa185c98,0x272);
        mmpiFreeMsg(puVar11);
        uVar4 = 0xffffffff;
      }
    }
  }
  return uVar4;
}