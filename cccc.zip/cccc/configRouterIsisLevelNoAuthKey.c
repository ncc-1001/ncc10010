#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t configRouterIsisLevelNoAuthKey(uint32_t param_1)



{

  int iVar1;

  uint32_t uVar2;

  

  iVar1 = cfgRouterISISLevelElements();

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07d2e4);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}



