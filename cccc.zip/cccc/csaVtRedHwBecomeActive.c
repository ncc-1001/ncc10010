#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void csaVtRedHwBecomeActive(int param_1)



{

  csaVpApiBecomeActive(*(uint32_t *)(param_1 + 0x36ca24));

  miniTdmCsaRedHwBecomeActive(param_1);

  return;

}



