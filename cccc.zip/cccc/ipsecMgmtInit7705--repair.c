#include "nokia.h"
#include <stdint.h>

// Modified: Added missing global variable declarations
int cRam10c8f925;
void* hwTypeInfo;
typedef unsigned char byte;
char ipsecStarted;

void ipsecMgmtInit7705(void)
{
  int iVar1;
  
  if ((((cRam10c8f925 == -5) ||
       (((cRam10c8f925 == -2 || cRam10c8f925 == -0x18 &&
         (iVar1 = hwCardTypeIsRialzi(hwTypeInfo), iVar1 != 0)) || (cRam10c8f925 == -0xe)))) ||
      (((cRam10c8f925 == -0x24 || (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12)) ||
       ((byte)(cRam10c8f925 + 0x1eU) < 6)))) && (ipsecStarted == '\0')) {
    ipsecStarted = 1;
    ipsecMgmtInit();
    ipsecIkeInit();
    return;
  }
  return;
}