#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

int configRouterIsisLevelWideMetricsHandler(uint32_t param_1,uint32_t param_2)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t *puStack_18;

  uint32_t *puStack_14;

  

  iVar1 = RCC_DB_RetrieveParam(param_2,0,1,&puStack_18);

  uVar2 = 0;

  if (iVar1 == 0) {

    uVar2 = *puStack_18;

  }

  iVar1 = RCC_DB_RetrieveParam(param_2,0,2,&puStack_14);

  if (iVar1 != 0) {

    return iVar1;

  }

  iVar1 = configRouterIsisLevelWideMetrics(param_1,uVar2,*puStack_14);

  return iVar1;

}



