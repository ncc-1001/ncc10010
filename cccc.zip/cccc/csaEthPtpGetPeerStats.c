#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t csaEthPtpGetPeerStats(uint param_1,uint param_2,uint32_t param_3)



{

  int iVar1;

  char *pcVar2;

  int iVar3;

  uint uVar4;

  uint uVar5;

  int iVar6;

  int aiStack_60 [8];

  int aiStack_40 [5];

  int aiStack_2c [7];

  

  param_2 = param_2 & 0xffff;

  iVar1 = macMdaRemoved();

  if (iVar1 != 0) {

    return 0;

  }

  if ((_tracepointsActive != 0) && (iVar1 = traceTest(_MOD_MDADRV,0xa8c5328,0,0), iVar1 != 0)) {

    tracePrintVRtr(_MOD_MDADRV,0xa8c5328,0,0,1,0xa8c5340,param_1,param_2);

  }

  if ((param_1 != 0) && (param_1 <= *_gMdaInfo)) {

    pcVar2 = (char *)(param_1 * 0x3a88 + 0x10d260a8);

    if ((*pcVar2 != '\0') &&

       (((iVar1 = param_1 * 0x3a88 + 0x10d260c0, pcVar2 != (char *)0x0 && (iVar1 != 0)) &&

        (param_2 - 1 < 10)))) {

      iVar1 = param_2 * 0x5c8 + iVar1;

      iVar6 = iVar1 + -0x578;

      uVar5 = 0;

      if (iVar6 != 0) {

        do {

          iVar3 = uVar5 * 4 + iVar6;

          uVar4 = uVar5 + 1;

          aiStack_60[uVar5] = *(int *)(iVar3 + 0x18) - *(int *)(iVar3 + 0x68);

          uVar5 = uVar4;

        } while (uVar4 < 8);

        uVar5 = 0;

        do {

          iVar3 = uVar5 * 4 + iVar6;

          uVar4 = uVar5 + 1;

          aiStack_40[uVar5] = *(int *)(iVar3 + 0x38) - *(int *)(iVar3 + 0x88);

          uVar5 = uVar4;

        } while (uVar4 < 5);

        uVar5 = 0;

        do {

          iVar3 = uVar5 * 4 + iVar6;

          uVar4 = uVar5 + 1;

          aiStack_2c[uVar5] = *(int *)(iVar3 + 0x4c) - *(int *)(iVar3 + 0x9c);

          uVar5 = uVar4;

        } while (uVar4 < 7);

        memcpy(iVar1 + -0x510,iVar1 + -0x560,0x50);

        memcpy(param_3,aiStack_60,0x50);

        return 0;

      }

    }

  }

  return 0xffffffff;

}



