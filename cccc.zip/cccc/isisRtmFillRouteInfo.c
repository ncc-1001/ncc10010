#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisRtmFillRouteInfo(int param_1,int param_2,int param_3,int param_4)



{

  char cVar1;

  byte bVar2;

  bool bVar3;

  uintptr_t uVar5;

  int iVar4;

  uint uVar6;

  uint32_t uVar7;

  int iVar8;

  int iVar9;

  int iVar10;

  int iVar11;

  

  bVar3 = *(char *)(param_2 + 4) == '\0';

  memset(param_3,0,800);

  *(uint32_t *)(param_3 + 0x40) = 0xffabcdff;

  if (bVar3) {

    memcpy(param_3 + 8,param_2 + 8,0x10);

    cVar1 = *(char *)(param_2 + 0x18);

  }

  else {

    *(uint32_t *)(param_3 + 8) = *(uint32_t *)(param_2 + 8);

    cVar1 = *(char *)(param_2 + 0x18);

  }

  uVar7 = 4;

  if (cVar1 == '\0') {

    uVar7 = 0x10;

  }

  uVar5 = netMaskToLen6(param_2 + 0x1c,uVar7);

  *(uintptr_t *)(param_3 + 4) = uVar5;

  *(uintptr_t *)(param_3 + 0x5e) = 0xc;

  *(uint *)(param_3 + 0x54) = (uint)(*(int *)(param_2 + 0x2c) < 0) << 4;

  switch(*(uintptr_t *)(param_2 + 0x2e)) {

  default:

    return 4;

  case 2:

  case 6:

    uVar6 = (uint)*(byte *)(param_1 + 0x92a);

    break;

  case 3:

  case 7:

    uVar6 = (uint)*(byte *)(param_1 + 0x92c);

    break;

  case 4:

    uVar6 = (uint)*(byte *)(param_1 + 0x92b);

    break;

  case 5:

    uVar6 = (uint)*(byte *)(param_1 + 0x92d);

    break;

  case 8:

    bVar2 = *(byte *)(param_1 + 0x92c);

    goto LAB_0423f500;

  case 9:

    bVar2 = *(byte *)(param_1 + 0x92d);

LAB_0423f500:

    *(uint *)(param_3 + 0x5c) = *(uint *)(param_3 + 0x5c) & 0xfe01ffff | (uint)bVar2 << 0x11;

    uVar7 = *(uint32_t *)(param_2 + 0x38);

    goto LAB_0423f520;

  }

  *(uint *)(param_3 + 0x5c) = *(uint *)(param_3 + 0x5c) & 0xfe01ffff | uVar6 << 0x11;

  uVar7 = *(uint32_t *)(param_2 + 0x34);

LAB_0423f520:

  *(uint32_t *)(param_3 + 0x48) = uVar7;

  iVar10 = 0;

  if ((*(byte *)(param_2 + 0x2c) & 0x1f) != 0) {

    uVar6 = *(uint *)(param_3 + 0x44);

    iVar8 = 0;

    iVar11 = 0;

    iVar9 = 0;

    do {

      while (iVar4 = (uVar6 >> 0x1a) * 0x2c + param_3, bVar3) {

        memcpy(iVar4 + 0x6c,*(int *)(param_2 + 0x48) + iVar11 + 0xc,0x10);

        *(uint32_t *)(iVar4 + 0x7c) = *(uint32_t *)(iVar8 + *(int *)(param_2 + 0x48) + 0x1c);

        if (param_4 != 1) goto LAB_0423f580;

LAB_0423f620:

        *(uint32_t *)(iVar4 + 0x88) = 0;

        iVar10 = iVar10 + 1;

        iVar9 = iVar9 + 0x6c;

        uVar6 = *(uint *)(param_3 + 0x44) & 0x3ffffff |

                ((*(uint *)(param_3 + 0x44) >> 0x1a) + 1) * 0x4000000;

        *(uint *)(param_3 + 0x44) = uVar6;

        iVar11 = iVar11 + 0x6c;

        iVar8 = iVar8 + 0x6c;

        if ((int)(*(byte *)(param_2 + 0x2c) & 0x1f) <= iVar10) {

          return 0;

        }

      }

      *(uint32_t *)(iVar4 + 0x6c) = *(uint32_t *)(iVar9 + *(int *)(param_2 + 0x48) + 0xc);

      *(uint32_t *)(iVar4 + 0x7c) = *(uint32_t *)(iVar8 + *(int *)(param_2 + 0x48) + 0x1c);

      if (param_4 == 1) goto LAB_0423f620;

LAB_0423f580:

      *(int *)(iVar4 + 0x88) = param_2;

      iVar10 = iVar10 + 1;

      iVar9 = iVar9 + 0x6c;

      uVar6 = *(uint *)(param_3 + 0x44) & 0x3ffffff |

              ((*(uint *)(param_3 + 0x44) >> 0x1a) + 1) * 0x4000000;

      *(uint *)(param_3 + 0x44) = uVar6;

      iVar11 = iVar11 + 0x6c;

      iVar8 = iVar8 + 0x6c;

    } while (iVar10 < (int)(*(byte *)(param_2 + 0x2c) & 0x1f));

  }

  return 0;

}



