#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int isisCircSrmSsnCmp;
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

void isisClearSsnFlag(uint32_t *param_1,int param_2,int param_3,int *param_4,uint32_t param_5) // Modified: Changed 'uint' to 'uint32_t' to fix unknown type error

{

  int iVar1;

  uint32_t uVar2; // Modified: Changed 'uint' to 'uint32_t'

  uint32_t uVar3;

  uint32_t uVar4;

  

  iVar1 = redAmIActive(0x34);

  if (iVar1 == 0) {

    return;

  }

  iVar1 = param_5 << 2;

  if (param_4 == (int *)0x0) {

    if (*(int *)(param_2 + 0x27d4) == 0) {

      return;

    }

    param_5 = (*(uint32_t *)(param_3 + 4) ^ *(uint32_t *)(param_3 + 8)) % 0x407; // Modified: Changed 'uint' to 'uint32_t'

    iVar1 = param_5 * 4;

    param_4 = (int *)dlistFindExact(*(uint32_t *)(iVar1 + param_2 + 0x17a4),isisCircSrmSsnCmp,

                                    param_3,0);

    if (param_4 == (int *)0x0) {

      return;

    }

  }

  uVar4 = *(uint32_t *)(iVar1 + param_2 + 0x17a4);

  if ((*param_4 == param_3) || ((*(uint16_t *)(*param_4 + 0xc) & 1) != 0)) { // Modified: Changed 'ushort' to 'uint16_t'

    uVar2 = *(uint32_t *)(param_2 + 0x27c8); // Modified: Changed 'uint' to 'uint32_t'

  }

  else {

    timosAssert(0xa1a806c,0xa1a7e2c,0x908,0xa1a80d8,0xa1a7ef8);

    uVar2 = *(uint32_t *)(param_2 + 0x27c8); // Modified: Changed 'uint' to 'uint32_t'

  }

  if ((uVar2 == param_5) && (*(int **)(param_2 + 0x27cc) == param_4)) {

    uVar3 = dlistGetNext(param_4);

    *(uint32_t *)(param_2 + 0x27cc) = uVar3;

  }

  if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x40) != 0)) &&

     (iVar1 = isisDebugCheck(param_1,0x40,param_2,0), iVar1 != 0)) {

    if (_IsisLogger == 0) {

      uVar3 = isisDumpLspId(param_3 + 4,param_1 + 0x6a1,0x400,0);

      tracePrint(_MOD_ISIS,0xa1a80d8,0,0,0xa1a80ec,uVar3,*(uint32_t *)(param_3 + 0x24),

                 *(uint32_t *)(param_2 + 8));

    }

    else {

      uVar3 = isisDumpLspId(param_3 + 4,param_1 + 0x6a1,0x400,0);

      logEvent_debug_fmt(*param_1,0xa1a7e00,&isisTitleStr,0xa1a80ec,uVar3,

                         *(uint32_t *)(param_3 + 0x24),*(uint32_t *)(param_2 + 8));

    }

  }

  isisLspDecRef(param_1,param_4,0xa1a7e2c,0x915);

  dlist_delete(uVar4,param_4,0,0xa1a7e2c,0x916);

  dlistFreeNodeExt(uVar4,param_4);

  *(int *)(param_2 + 0x27d4) = *(int *)(param_2 + 0x27d4) + -1;

  return;

}