#include "nokia.h"
#include <stdint.h>

// Modified: Added missing declarations for compilation
int _IsisLogger;
int _MOD_ISIS;
char *isisTitleStr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t isisRedAddNbr(int param_1,uint32_t *param_2,uint32_t *param_3)


{

  int iVar1;

  int iVar2;

  

  if ((param_2 != (uint32_t *)0x0 && param_3 != (uint32_t *)0x0) && (*(int *)(param_1 + 8) != 0)

     ) {

    iVar1 = *(int *)(param_1 + 0xc) + 4;

    if (*(int *)(param_1 + 0xc) == 0) {

      iVar1 = 0;

    }

    iVar2 = *(int *)(param_1 + 0x1c) + 4;

    if (*(int *)(param_1 + 0x1c) == 0) {

      iVar2 = 0;

    }

    isisRedSendNbrToInactive

              (param_2,param_3[1],param_1,*param_3,*(uint32_t *)(param_1 + 0x14),

               *(uint32_t *)(param_1 + 0x18),*(uint32_t *)(param_1 + 0x24),

               *(uint32_t *)(param_1 + 0x28),*(uint32_t *)(param_1 + 0x2c),

               *(uint32_t *)(param_1 + 0x30),*(uint32_t *)(param_1 + 0x34),

               *(uint32_t *)(param_1 + 0x38),*(uint32_t *)(param_1 + 0x3c),

               *(uint32_t *)(param_1 + 0x40),*(uint32_t *)(param_1 + 0x44),

               *(uint32_t *)(param_1 + 0x48),*(int *)(param_1 + 8),iVar1,iVar2,0,0,0);

    return 0;

  }

  if (param_3 != (uint32_t *)0x0) {

    param_3[2] = 1;

  }

  if (((param_2 != (uint32_t *)0x0) && ((param_2[0x1b] & 2) != 0)) &&

     (iVar1 = isisDebugCheck(param_2,2,0,0), iVar1 != 0)) {

    if (_IsisLogger == 0) {

      tracePrint(_MOD_ISIS,0xa1acea4,0,0,0xa1aceb4,param_2,param_3,*(uint32_t *)(param_1 + 8));

    }

    else {

      logEvent_debug_fmt(*param_2,0xa1ac4d0,&isisTitleStr,0xa1aceb4,param_2,param_3,

                         *(uint32_t *)(param_1 + 8));

    }

  }

  return 0x100;

}