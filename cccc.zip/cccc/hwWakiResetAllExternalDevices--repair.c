#include "nokia.h"
#include <stdint.h>

extern byte cRam10c8f925; // Modified: Added extern declaration for undeclared variable

uint32_t hwWakiResetAllExternalDevices(char param_1,int param_2)

{

  if (param_1 == '\0') {

    if ((byte)(cRam10c8f925 + 0x1eU) < 6) {

      hwWakiResetBcm6519(0);

    }

    else {

      hwWakiResetEbimc(0);

      hwWakiResetBcm6519(0);

    }

    if (param_2 == 0x7a) {

      hwWakiResetSocrates(0);

    }

    hwWakiResetBcm6529(0);

  }

  else {

    hwWakiResetBcm6529(param_1);

    hwWakiResetBcm6519(param_1);

    if (param_2 == 0x7a) {

      hwWakiResetSocrates(param_1);

    }

    if (5 < (byte)(cRam10c8f925 + 0x1eU)) {

      hwWakiResetEbimc(param_1);

    }

  }

  return 0;

}