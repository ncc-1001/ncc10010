#include "nokia.h"
#include <stdint.h>

// Modified: Added typedef for 'code' type
typedef void (*code)(void);
// Modified: Added extern declaration for '_emptyARPTransmit'
extern void _emptyARPTransmit(void);

uint32_t ARP_Init(uint *param_1,uint32_t param_2,uint32_t param_3)
{

  int iVar1;
  uint uVar2;
  
  ARP_Lock();
  iVar1 = ARPO_Allocate();
  *(uint32_t *)(iVar1 + 0x10) = param_2;
  strncpy(iVar1 + 0x14,param_3,0x20);
  *(uintptr_t *)(iVar1 + 0x33) = 0;
  if (param_1 == (uint *)0x0) {
    uVar2 = *(uint *)(iVar1 + 0x40);
  }
  else {
    uVar2 = *param_1;
    *(uint *)(iVar1 + 0x38) = uVar2;
    if (uVar2 < param_1[1]) {
      *(uint *)(iVar1 + 0x3c) = uVar2;
    }
    else {
      *(uint *)(iVar1 + 0x3c) = param_1[1];
    }
    uVar2 = param_1[2];
    *(uint *)(iVar1 + 0x40) = uVar2;
  }
  if (uVar2 == 0) {
    *(uint32_t *)(iVar1 + 0x40) = 5;
  }
  if (param_1 == (uint *)0x0) {
    uVar2 = *(uint *)(iVar1 + 0x44);
  }
  else {
    uVar2 = param_1[3];
    *(uint *)(iVar1 + 0x44) = uVar2;
  }
  if (uVar2 == 0) {
    *(uint32_t *)(iVar1 + 0x44) = 1;
  }
  if (param_1 == (uint *)0x0) {
    uVar2 = *(uint *)(iVar1 + 0x70);
  }
  else {
    uVar2 = param_1[4];
    *(uint *)(iVar1 + 0x70) = uVar2;
  }
  if (uVar2 == 0) {
    *(code **)(iVar1 + 0x70) = _emptyARPTransmit;
  }
  uVar2 = 0;
  if (param_1 != (uint *)0x0) {
    uVar2 = param_1[5];
  }
  *(uint *)(iVar1 + 0x74) = uVar2;
  uVar2 = 0;
  if (param_1 != (uint *)0x0) {
    uVar2 = param_1[6];
  }
  *(uint *)(iVar1 + 0x84) = uVar2;
  arp_addObj(iVar1);
  pipStaticArpCacheInit();
  ARP_UnLock();
  return 0;
}