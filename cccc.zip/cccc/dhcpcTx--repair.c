#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for undeclared variable _tracepointsActive
extern int _tracepointsActive;
// Modified: Added extern declaration for undeclared variable _MOD_DHCPC
extern int _MOD_DHCPC;

uint32_t dhcpcTx(int param_1,char param_2,uintptr_t param_3,uint32_t param_4)
{
  uint32_t uVar1;
  int iVar2;
  uint32_t uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  uintptr_t auStack_5e8 [1472];
  uint32_t auStack_28 [2];
  
  uVar1 = dhcpcGenDhcpMsg(param_1,param_3,auStack_5e8,auStack_28);
  iVar4 = (int)param_2;
  if (*(int *)(param_1 + 0x18) != 0) {
    dhcpcTxToInterface(param_1,param_3,uVar1,auStack_28[0],param_4);
    return 0;
  }
  if (iVar4 == 8) {
    if (_tracepointsActive == 0) {
      iVar4 = *(int *)(param_1 + 0x1c);
    }
    else {
      iVar4 = traceTest(_MOD_DHCPC,0xa13f964,1,0);
      if (iVar4 == 0) {
        iVar4 = *(int *)(param_1 + 0x1c);
      }
      else {
        uVar3 = dhcpcOptionMsgTypeStr(param_3);
        tracePrintVRtr(_MOD_DHCPC,0xa13f964,1,0,1,0xa13f96c,uVar3);
        iVar4 = *(int *)(param_1 + 0x1c);
      }
    }
    uVar6 = 0;
    if (iVar4 != 0) {
      piVar5 = (int *)(param_1 + 0x1c);
      do {
        piVar5 = piVar5 + 1;
        dhcpcInformServer(param_1,uVar6,param_3,uVar1,auStack_28[0],param_4);
        uVar6 = uVar6 + 1;
      } while (*piVar5 != 0 && uVar6 < 8);
      return 0;
    }
  }
  else if (iVar4 < 0) {
    if (_tracepointsActive == 0) {
      iVar2 = *(int *)(param_1 + 0x1c);
    }
    else {
      iVar2 = traceTest(_MOD_DHCPC,0xa13f964,1,0);
      if (iVar2 == 0) {
        iVar2 = *(int *)(param_1 + 0x1c);
      }
      else {
        uVar3 = dhcpcOptionMsgTypeStr(param_3);
        tracePrintVRtr(_MOD_DHCPC,0xa13f964,1,0,1,0xa13f998,uVar3,iVar4);
        iVar2 = *(int *)(param_1 + 0x1c);
      }
    }
    uVar6 = 0;
    if (iVar2 != 0) {
      piVar5 = (int *)(param_1 + 0x20);
      do {
        if (-iVar4 != uVar6) {
          dhcpcInformServer(param_1,uVar6,param_3,uVar1,auStack_28[0],param_4);
        }
        iVar2 = *piVar5;
        uVar6 = uVar6 + 1;
        piVar5 = piVar5 + 1;
      } while (iVar2 != 0 && uVar6 < 8);
    }
  }
  else {
    if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_DHCPC,0xa13f964,1,0), iVar2 != 0)) {
      uVar3 = dhcpcOptionMsgTypeStr(param_3);
      tracePrintVRtr(_MOD_DHCPC,0xa13f964,1,0,1,0xa13f984,uVar3,iVar4);
    }
    dhcpcInformServer(param_1,iVar4,param_3,uVar1,auStack_28[0],param_4);
  }
  return 0;
}