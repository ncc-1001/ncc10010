#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern byte cRam10c8f925;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

int hwWakiSetInterruptMaskReg(uint param_1,uint32_t param_2)
{
  int iVar1;
  uint32_t uVar2;
  
  uVar2 = 7;
  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {
    uVar2 = 0x1ff;
  }
  if ((param_1 < 10) && (iVar1 = hwWakiSarwxIsValidReg(uVar2,param_1), iVar1 != 0)) {
    iVar1 = hwWakiWriteReg32(0,param_1 * 4 + 0x7c,param_2);
    return (iVar1 == 0) - 1;
  }
  if ((_traceEnabled != 0) ||
     ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa7b00cc,4,0), iVar1 != 0)))) {
    tracePrintVRtr(_MOD_MDADRV,0xa7b00cc,4,0,1,0xa7b00e8,param_1);
  }
  return -1;
}