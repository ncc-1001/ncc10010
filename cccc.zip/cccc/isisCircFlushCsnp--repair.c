#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
// Modified: Added size to array declaration
extern char isisPduTypeStr[256];
extern char isisTitleStr[256];
extern void *uRam0d92c398;

/* WARNING: Removing unreachable block (ram,0x041fdd18) */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisCircFlushCsnp(int *param_1,int param_2)



{

  int iVar1;

  int iVar2;

  bool bVar3;

  int iVar4;

  int *piVar5;

  int iVar6;

  int iVar7;

  byte abStack_30 [8];

  

  iVar7 = param_1[0xf6];

  piVar5 = param_1 + 0x160;

  if (param_2 != 1) {

    piVar5 = param_1 + 0x1d4;

  }

  iVar6 = piVar5[6];

  if ((iVar6 == 0) || (*piVar5 <= piVar5[3])) {

    return;

  }

  iVar4 = *(int *)(iVar6 + 0xc);

  do {

    isisCircUpdateStats(param_1,*(int *)(iVar4 + 8) + iVar4 + 0xb1,1);

    isisDumpRawFrame(*param_1,param_1,iVar4,*(int *)(iVar4 + 8) + iVar4 + 0xb1,1);

    bVar3 = true;

    iVar1 = *(int *)(iVar4 + 8) + iVar4;

    abStack_30[0] = *(byte *)(iVar1 + 0xb5);

    if (param_1[0xbd] == 2) {

      if (*(int *)(iVar6 + 8) == 1) {

        iVar2 = param_1[0x113];

      }

      else {

        iVar2 = param_1[0x187];

      }

      if (iVar2 == 0) {

        bVar3 = false;

      }

LAB_041fdb90:

      if (bVar3) {

        iVar2 = *param_1;

        goto LAB_041fdb9c;

      }

      pbufFree(iVar4);

    }

    else {

      if (iVar7 == 0) {

        bVar3 = false;

        goto LAB_041fdb90;

      }

      if (*(int *)(iVar7 + 0x44) != 2) {

        bVar3 = false;

        goto LAB_041fdb90;

      }

      iVar2 = *(int *)(iVar7 + 0x50);

      if (iVar2 == 2) {

        if (*(int *)(iVar6 + 8) != 1) goto LAB_041fdc58;

        goto LAB_041fdb90;

      }

      if ((iVar2 == 3) && (*(int *)(iVar6 + 8) == 2)) goto LAB_041fdb90;

LAB_041fdc58:

      if (iVar2 != 4) {

        bVar3 = false;

        goto LAB_041fdb90;

      }

      iVar2 = *param_1;

LAB_041fdb9c:

      if (((iVar2 != 0) && ((*(uint *)(iVar2 + 0x6c) & 8) != 0)) &&

         (iVar2 = isisDebugCheck(iVar2,8,param_1,abStack_30), iVar2 != 0)) {

        if (_IsisLogger == 0) {

          tracePrint(_MOD_ISIS,0xa1a8374,0,0,0xa1a8388,(&isisPduTypeStr)[abStack_30[0]],param_1[2]);

        }

        else {

          logEvent_debug_fmt(*(uint32_t *)*param_1,0xa1a7e00,&isisTitleStr,0xa1a8388,

                             (&isisPduTypeStr)[abStack_30[0]],param_1[2]);

        }

      }

      isisCircPrintSnp(param_1,iVar1 + 0xb1);

      isisTxPdu(*param_1,param_1,iVar4);

    }

    isisCircTxQUnlink(piVar5,iVar6);

    piVar5[3] = piVar5[3] + 1;

    fsmem_free(uRam0d92c398,iVar6);

    iVar6 = piVar5[6];

    if (iVar6 == 0) {

      return;

    }

    if (*piVar5 <= piVar5[3]) {

      return;

    }

    iVar4 = *(int *)(iVar6 + 0xc);

  } while( true );

}
