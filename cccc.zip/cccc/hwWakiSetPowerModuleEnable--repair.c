#include "nokia.h"
#include <stdint.h>

extern byte cRam10c8f925; // Modified: Added extern declaration for undeclared variable

int hwWakiSetPowerModuleEnable(uint32_t param_1)
{
  int iVar1;
  
  iVar1 = -1;
  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {
    iVar1 = hwWakiWriteReg32(0,0x14,param_1);
    iVar1 = (iVar1 == 0) - 1;
  }
  return iVar1;
}