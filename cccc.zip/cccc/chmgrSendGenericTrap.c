#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void chmgrSendGenericTrap

               (uint32_t param_1,int param_2,uint32_t param_3,uint32_t param_4,

               uint32_t *param_5)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  uintptr_t auStack_30 [8];

  uintptr_t auStack_28 [16];

  

  if (param_2 == 0x77) {

    uVar2 = *param_5;

    uVar3 = 0x77;

    uVar4 = 0xa1f03a0;

  }

  else if (param_2 < 0x78) {

    if (param_2 == 0x6d) {

      uVar2 = FmtSlotNum(param_5[1],auStack_30,3);

      uVar3 = 0x6d;

      uVar4 = 0xa1f040c;

      goto LAB_043e9ee4;

    }

    if (param_2 < 0x6e) {

      if (param_2 != 0x68) {

        if (param_2 < 0x69) {

          if (param_2 == 0x66) {

            trapperSendGenericTrap(1,param_1,0xa1ee710,0x66,param_5,param_3,param_4,0xa1f0350);

            return;

          }

        }

        else if (param_2 == 0x6a) {

          uVar2 = param_5[1];

          uVar3 = 0x6a;

          uVar4 = 0xa1f03d4;

          goto LAB_043e9c70;

        }

LAB_043e9bcc:

        if ((_traceEnabled == 0) &&

           ((_tracepointsActive == 0 || (iVar1 = traceTest(MOD_LOG,0xa1f0310,4,0), iVar1 == 0)))) {

          return;

        }

        tracePrintVRtr(MOD_LOG,0xa1f0310,4,0,1,0xa1f0388,param_2);

        return;

      }

      uVar2 = param_5[1];

      uVar3 = 0x68;

      uVar4 = 0xa1f04d8;

    }

    else {

      if (param_2 != 0x71) {

        if (param_2 < 0x72) {

          if (param_2 == 0x6e) {

            uVar2 = FmtSlotNum(param_5[1],auStack_30,3);

            uVar3 = 0x6e;

            uVar4 = 0xa1f0528;

            goto LAB_043e9ee4;

          }

        }

        else {

          if (param_2 == 0x75) {

            uVar2 = FmtSlotNum(param_5[1],auStack_30,3);

            uVar3 = 0x75;

            uVar4 = 0xa1f0558;

            goto LAB_043e9ee4;

          }

          if (param_2 == 0x76) {

            trapperSendGenericTrap(1,param_1,0xa1ee710,0x76,param_5,param_3,param_4,0xa1f03b8);

            return;

          }

        }

        goto LAB_043e9bcc;

      }

      uVar2 = param_5[1];

      uVar3 = 0x71;

      uVar4 = 0xa1f0474;

    }

  }

  else if (param_2 == 0x7f) {

    uVar2 = param_5[1];

    uVar3 = 0x7f;

    uVar4 = 0xa1f0424;

  }

  else if (param_2 < 0x80) {

    if (param_2 == 0x79) {

      uVar2 = FmtCcagPathId(param_5[1]);

      uVar3 = FmtCcagCcType(param_5[2]);

      trapperSendGenericTrap

                (1,param_1,0xa1ee710,0x79,param_5,param_3,param_4,0xa1f0494,*param_5,uVar2,uVar3);

      return;

    }

    if (param_2 < 0x79) {

      FmtCcagPathId(param_5[1]);

      uVar2 = *param_5;

      uVar3 = 0x78;

      uVar4 = 0xa1f0450;

    }

    else {

      if (param_2 == 0x7a) {

        trapperSendGenericTrap(1,1,0xa1ee710,0x7a,param_5,0,0,0xa1f0508,param_5[1],param_5[2]);

        return;

      }

      if (param_2 != 0x7e) goto LAB_043e9bcc;

      uVar2 = *param_5;

      uVar3 = 0x7e;

      uVar4 = 0xa1f0328;

    }

  }

  else {

    if (param_2 == 0xfa1) {

      uVar2 = FmtAlarmId(param_5[1],auStack_28,0x10);

      uVar3 = 0xfa1;

      uVar4 = 0xa1f04c0;

LAB_043e9ee4:

      trapperSendGenericTrap(1,param_1,0xa1ee710,uVar3,param_5,param_3,param_4,uVar4,uVar2);

      return;

    }

    if (param_2 < 0xfa2) {

      if (param_2 != 0x80) goto LAB_043e9bcc;

      uVar2 = param_5[1];

      uVar3 = 0x80;

      uVar4 = 0xa1f036c;

    }

    else {

      if (param_2 == 0xfa2) {

        uVar2 = FmtAlarmId(param_5[1],auStack_28,0x10);

        uVar3 = 0xfa2;

        uVar4 = 0xa1f0544;

        goto LAB_043e9ee4;

      }

      if (param_2 != 0xfa3) goto LAB_043e9bcc;

      uVar2 = param_5[1];

      uVar3 = 0xfa3;

      uVar4 = 0xa1f03f0;

    }

  }

LAB_043e9c70:

  trapperSendGenericTrap(1,param_1,0xa1ee710,uVar3,param_5,param_3,param_4,uVar4,uVar2);

  return;

}



