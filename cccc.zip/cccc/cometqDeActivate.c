#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t cometqDeActivate(void)



{

  int iVar1;

  uint32_t uVar2;

  

  iVar1 = utilCometqDeviceHandle2Ddb();

  uVar2 = 0xffffff98;

  if ((iVar1 != 0) && (uVar2 = 0xffffff95, *(int *)(iVar1 + 0xc) == 3 || *(int *)(iVar1 + 0xc) == 1)

     ) {

    if (*(int *)(iVar1 + 0x1c) == 0) {

      uVar2 = sysCometqPreemptDis();

      isrCometqReset(iVar1);

      *(uint32_t *)(iVar1 + 0xc) = 2;

      isrCometqGetStatus(iVar1,0xccd72a4);

      sysCometqPreemptEn(uVar2);

      uVar2 = 0;

    }

    else {

      *(uint32_t *)(iVar1 + 0xc) = 2;

      uVar2 = 0;

    }

  }

  return uVar2;

}



