#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void csaEthXcmFxDisableLink(int param_1,int param_2)



{

  char cVar1;

  int iVar2;

  uint32_t uVar3;

  ushort auStack_18 [4];

  

  cVar1 = *(char *)(param_2 + 0x19);

  if (cVar1 == '\x02') {

    auStack_18[0] = 0x8000;

    iVar2 = csaEthXcmFxSfpPhyWrite(param_1,param_2,0,auStack_18);

    if (iVar2 == 0) {

      iVar2 = csaEthXcmFxSfpPhyRead(param_1,param_2,0x14,auStack_18);

      if (iVar2 == 0) {

        auStack_18[0] = auStack_18[0] | 0x1000;

        iVar2 = csaEthXcmFxSfpPhyWrite(param_1,param_2,0x14,auStack_18);

        if (((iVar2 != 0) && (iVar2 = macMdaRemoved(*(uint32_t *)(param_1 + 8)), iVar2 == 0)) &&

           ((_traceEnabled != 0 ||

            ((_tracepointsActive != 0 && (iVar2 = traceTest(_MOD_MDADRV,0xa8e6ac8,4,0), iVar2 != 0))

            )))) {

          tracePrintVRtr(_MOD_MDADRV,0xa8e6ac8,4,0,1,0xa8e6b08);

        }

      }

      else {

        iVar2 = macMdaRemoved(*(uint32_t *)(param_1 + 8));

        if ((iVar2 == 0) &&

           ((_traceEnabled != 0 ||

            ((_tracepointsActive != 0 && (iVar2 = traceTest(_MOD_MDADRV,0xa8e6ac8,4,0), iVar2 != 0))

            )))) {

          tracePrintVRtr(_MOD_MDADRV,0xa8e6ac8,4,0,1,0xa8e6b3c);

        }

      }

    }

    else {

      iVar2 = macMdaRemoved(*(uint32_t *)(param_1 + 8));

      if ((iVar2 == 0) &&

         ((_traceEnabled != 0 ||

          ((_tracepointsActive != 0 && (iVar2 = traceTest(_MOD_MDADRV,0xa8e6ac8,4,0), iVar2 != 0))))

         )) {

        tracePrintVRtr(_MOD_MDADRV,0xa8e6ac8,4,0,1,0xa8e6ae0);

      }

    }

    return;

  }

  if (cVar1 == '\x03' || cVar1 == '\x06') {

    uVar3 = *(uint32_t *)(param_1 + 8);

  }

  else {

    if (cVar1 != '\a') {

      return;

    }

    uVar3 = *(uint32_t *)(param_1 + 8);

  }

  fpgaSfpLaserEnable(uVar3,*(uint32_t *)(param_2 + 0x10),0);

  return;

}



