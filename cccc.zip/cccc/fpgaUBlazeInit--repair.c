#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables to fix compilation errors
extern int *_gMdaInfo;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern int cRam10c8f925;

void fpgaUBlazeInit(uint param_1)
{
  uint uVar1;
  uint uVar2;
  uint32_t uVar3;
  int iVar4;
  int iVar5;
  uintptr_t auStack_18 [8];
  
  auStack_18[0] = 0;
  iVar5 = 0;
  if (((param_1 != 0) &&
      (((*_gMdaInfo < param_1 || (iVar4 = fpgaIsValidMda(), iVar4 == 0)) ||
       (iVar5 = fpgaGetMda(param_1), iVar5 == 0)))) &&
     (((param_1 != 0 && (param_1 <= *_gMdaInfo)) && (iVar4 = macMdaRemoved(param_1), iVar4 == 0))))
  {
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) goto LAB_063b0900;
      iVar4 = traceTest(_MOD_MDADRV,0xa8da2d0,4,0);
      if (iVar4 == 0) goto LAB_063b08f0;
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8da2d0,4,0,1,0xa8d9798,param_1);
  }
LAB_063b08f0:
  if ((_tracepointsActive != 0) && (iVar4 = traceTest(_MOD_MDADRV,0xa8da2d0,1,0), iVar4 != 0)) {
    tracePrintVRtr(_MOD_MDADRV,0xa8da2d0,1,0,1,0xa8da2e0,param_1);
  }
LAB_063b0900:
  if (((((((cRam10c8f925 == -0x13 || cRam10c8f925 == -0x17) || ((byte)(cRam10c8f925 + 0x16U) < 2))
         || (cRam10c8f925 == -0xd || cRam10c8f925 == -0xf)) ||
        ((cRam10c8f925 == -8 || (cRam10c8f925 == -9)))) ||
       ((cRam10c8f925 == -10 || cRam10c8f925 == -0x10 ||
        ((cRam10c8f925 == -0xe || (cRam10c8f925 == -0x24)))))) ||
      (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12)) ||
     (((byte)(cRam10c8f925 + 0x1eU) < 6 || (cRam10c8f925 == -7)))) {
    hwSarmFpgaReset1588(0);
    hwSarmFpgaResetMicroBlaze(0);
    taskDelay(0x10);
    uVar1 = _fpgaUBlazeRegRead(param_1,0x30);
    uVar2 = 0x7d000000;
    if (cRam10c8f925 != -0xd && cRam10c8f925 != -0xf) {
      if (((cRam10c8f925 == -8) || (cRam10c8f925 == -9)) ||
         (cRam10c8f925 == -10 || cRam10c8f925 == -0x10)) {
        uVar2 = 0x7d000000;
      }
      else if (cRam10c8f925 == -0x24) {
        uVar2 = 0x74000000;
      }
      else {
        uVar2 = 0x79000000;
      }
    }
    _fpgaUBlazeRegWrite(param_1,0x30,uVar1 & 0xff0000 | uVar2 | 1);
  }
  else {
    fpgaRegClear(param_1,0xa0,0x2000000);
    fpgaRegSet(param_1,0x24,0x40000000);
    taskDelay(0x10);
  }
  fpgaUBlazeSetTcEnable(param_1,1);
  uVar3 = _fpgaUBlazeRegRead(param_1,4);
  *(uint32_t *)(iVar5 + 0x10e8) = uVar3;
  uVar3 = _fpgaUBlazeRegRead(param_1,0xc);
  *(uint32_t *)(iVar5 + 0x10ec) = uVar3;
  *(uintptr_t *)(iVar5 + 0x121d) = 0;
  *(uintptr_t *)(iVar5 + 0x121e) = 0;
  *(uintptr_t *)(iVar5 + 0x121c) = auStack_18[0];
  *(uint32_t *)(iVar5 + 0x1220) = 0;
  *(uint32_t *)(iVar5 + 0x1224) = 0;
  memset(iVar5 + 0x1228,0,0x1c0);
  *(uint32_t *)(iVar5 + 0x122c) = 0x1000;
  *(uintptr_t *)(iVar5 + 0x1229) = 0;
  *(uintptr_t *)(iVar5 + 0x1228) = 0;
  iVar4 = _fpgaUBlazeIsEccSupported(param_1);
  if ((iVar4 == 0) || (iVar4 = fpgaUBlazeIsEccCapable(param_1,auStack_18), iVar4 != 0)) {
    iVar5 = _fpgaUBlazeIsExcepIndSupported(param_1);
  }
  else {
    *(uintptr_t *)(iVar5 + 0x121c) = auStack_18[0];
    iVar5 = _fpgaUBlazeIsExcepIndSupported(param_1);
  }
  if (iVar5 != 0) {
    uVar1 = _fpgaUBlazeRegRead(param_1,0xc4);
    _fpgaUBlazeRegWrite(param_1,0xc4,uVar1 | 0x1c83ff);
    _fpgaUBlazeRegWrite(param_1,0,0x1ffe0000);
    _fpgaUBlazeRegWrite(param_1,0x74,0xffffff);
    _fpgaUBlazeRegWrite(param_1,0x2c,0xbfa90000);
    return;
  }
  _fpgaUBlazeRegWrite(param_1,0,0x1ffe0000);
  _fpgaUBlazeRegWrite(param_1,0x74,0xffffff);
  _fpgaUBlazeRegWrite(param_1,0x2c,0xbfa90000);
  return;
}