#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declaration for undeclared variable
extern int *_gMdaInfo;
// Modified: Added extern declaration for undeclared variable
extern int cRam10c8f925;

void csaEthDoLeds(uint param_1)

{

  ushort uVar1;

  int iVar2;

  int iVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  int iVar6;

  int iVar7;

  uint uVar8;

  int iVar9;

  uint32_t auStack_30 [2];
  
  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
    timosAssert(0xa8c399c,0xa8c3970,0xe5c,0xa8c6c04,0xa8c3960);
  }
  iVar7 = *(int *)(param_1 * 4 + 0xccb630c);
  if (iVar7 == 0) {
    timosAssert(0xa8c39e8,0xa8c3970,0xe5c,0xa8c6c04,0xa8c3960);
  }
  iVar2 = xmacRedIsCardActive(param_1);
  if ((iVar2 != 0) && (uVar8 = 0, *(int *)(iVar7 + 0xec) != 0)) {
    iVar2 = 0;
    do {
      iVar2 = iVar2 * 0x800 + uVar8 * 0xa60 + iVar7;
      iVar9 = 2;
      if (*(char *)(iVar7 + 0x63b30) == '\0' && iVar2 != -0x9c8) {
        iVar9 = *(int *)(iVar2 + 0xb7c);
      }
      iVar6 = *(int *)(iVar2 + 0xb94);
      uVar5 = *(uint32_t *)(iVar2 + 0xb90);
      iVar3 = csaEthGetPortType(iVar7,uVar8);
      if (iVar3 != 0x24) {
        if (*(int *)(iVar7 + 0x108) == 0xbe) {
          uVar8 = 4;
        }
        uVar4 = 0;
        if ((*(char *)(iVar7 + 0x63b30) == '\0') && (*(char *)(iVar2 + 0xb70) != '\0' && iVar9 == 3)
           ) {
          uVar4 = 1;
        }
        macPortSetStatusLed(*(uint32_t *)(iVar7 + 0x63b2c),
                            (uint)*(ushort *)(iVar2 + 0x9dc) * 2 + 1,uVar4,0,iVar9,0);
        iVar3 = *(int *)(iVar7 + 0x108);
        if (iVar3 != 0xac) {
          if (iVar9 == 3) {
            auStack_30[0] = 0;
            iVar6 = uVar8 * 8;
            iVar3 = iVar6;
            // Modified: Simplified complex condition to fix compilation errors
            int condition1 = (cRam10c8f925 == -0x13) || (cRam10c8f925 == -0x17);
            int condition2 = (1 < (byte)(cRam10c8f925 + 0x16U)) && (cRam10c8f925 != -0xd) && (cRam10c8f925 != -0xf);
            int condition3 = (cRam10c8f925 == -8) || (cRam10c8f925 == -9);
            int condition4 = (cRam10c8f925 != -10) && (cRam10c8f925 != -0x10);
            int condition5 = (cRam10c8f925 == -0xe) || (cRam10c8f925 == -0x24);
            int condition6 = (cRam10c8f925 != -0x23) && (cRam10c8f925 != -0x12);
            int condition7 = (5 < (byte)(cRam10c8f925 + 0x1eU)) && (cRam10c8f925 == -7);
            
            if (condition1 || (condition2 && (condition3 || (condition4 && (condition5 || (condition6 && condition7)))))) {
              iVar3 = iVar6;
            }
            iVar6 = fpgaPCIeRegRead(param_1,iVar3,auStack_30);
            iVar3 = *(int *)(iVar7 + 0x108);
            uVar5 = 0;
          }
          if (iVar3 == 0xa9 || iVar3 == 0xb4) {
LAB_063672f8:
            uVar1 = *(ushort *)(iVar2 + 0x9dc);
LAB_063672fc:
            macPortCsaSetActivityLed
                      (*(uint32_t *)(iVar7 + 0x63b2c),(uint)uVar1 * 2 + 2,iVar9,
                       iVar6 - *(int *)(iVar2 + 0xb94),0);
            *(int *)(iVar2 + 0xb94) = iVar6;
          }
          else {
            if (iVar3 - 0xbbU < 3) {
              uVar1 = *(ushort *)(iVar2 + 0x9dc);
              goto LAB_063672fc;
            }
            if ((iVar3 == 0xbe) || (iVar3 == 0x9c)) goto LAB_063672f8;
            macPortSetActivityLed
                      (*(uint32_t *)(iVar7 + 0x63b2c),(uint)*(ushort *)(iVar2 + 0x9dc) * 2 + 2,
                       iVar9,iVar6 - *(int *)(iVar2 + 0xb94),0);
            *(int *)(iVar2 + 0xb94) = iVar6;
          }
          *(uint32_t *)(iVar2 + 0xb90) = uVar5;
        }
      }
      uVar8 = uVar8 + 1;
      iVar2 = uVar8 * 2;
    } while (uVar8 < *(uint *)(iVar7 + 0xec));
  }
  return;
}