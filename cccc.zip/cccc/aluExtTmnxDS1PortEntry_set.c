#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void aluExtTmnxDS1PortEntry_set(void)



{

  int iVar1;

  uint32_t in_a3;

  int *piVar2;

  uint32_t uVar3;

  int iVar4;

  int *in_stack_00000010;

  

  uVar3 = 0;

  iVar4 = in_stack_00000010[0xe];

  if (in_stack_00000010 == (int *)0x0) {

LAB_0358d984:

    iVar4 = sia_tmnxDS1PortEntrySet(uVar3,iVar4);

    if (iVar4 == 0) {

      return;

    }

    setproc_error(in_a3,in_stack_00000010,iVar4);

  }

  else {

    iVar1 = in_stack_00000010[6];

    piVar2 = in_stack_00000010;

    while (uVar3 = 0x8000, iVar1 == 1) {

      *(int *)(iVar4 + 0x20) = piVar2[10];

      setproc_good();

      piVar2 = (int *)*piVar2;

      if (piVar2 == (int *)0x0) goto LAB_0358d984;

      iVar1 = piVar2[6];

    }

    setproc_error(in_a3,piVar2,0xe);

  }

  return;

}



