#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared function 'isisSpfAddLspNbrsToTent'
extern void isisSpfAddLspNbrsToTent(uint32_t *, uintptr_t *, int, int, int, int, int);

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



uint32_t isisSpfAddNbrInfoToTent(uint32_t *param_1,int param_2,int param_3,int param_4)



{

  int iVar1;

  uint32_t uVar2;

  uint32_t uVar3;

  uint32_t uVar4;

  int iVar5;

  uintptr_t auStack_28 [6];

  uintptr_t uStack_22;

  uintptr_t uStack_21;

  

  iVar5 = param_4 + 8;

  memcpy(auStack_28,iVar5,6);

  uStack_22 = *(uintptr_t *)(param_4 + 0xe);

  uStack_21 = 0;

  iVar1 = isisLspFind(param_1,auStack_28,param_2);

  if (iVar1 == 0) {

    if (param_1 == (uint32_t *)0x0) {

      return 0;

    }

    if ((param_1[0x1b] & 0x100) == 0) {

      return 0;

    }

    iVar1 = isisDebugCheck(param_1,0x100,param_2,iVar5);

    if (iVar1 == 0) {

      return 0;

    }

    if (_IsisLogger != 0) {

      uVar2 = isisXlateMtId(param_3);

      uVar3 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

      logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1b18,param_2,uVar2,uVar3);

      return 0;

    }

    uVar3 = isisXlateMtId(param_3);

    uVar2 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

    uVar4 = 0xa1b1b18;

  }

  else if ((*(ushort *)(iVar1 + 0xc) & 0x20) == 0) {

    if (*(int *)(iVar1 + 0x10) == 0) {

      if (param_1 == (uint32_t *)0x0) {

        return 0;

      }

      if ((param_1[0x1b] & 0x100) == 0) {

        return 0;

      }

      iVar1 = isisDebugCheck(param_1,0x100,param_2,iVar5);

      if (iVar1 == 0) {

        return 0;

      }

      if (_IsisLogger != 0) {

        uVar2 = isisXlateMtId(param_3);

        uVar3 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

        logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1a90,param_2,uVar2,uVar3);

        return 0;

      }

      uVar3 = isisXlateMtId(param_3);

      uVar2 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

      uVar4 = 0xa1b1a90;

    }

    else {

      if (param_2 == 1) {

        isisSpfAddNbrLspAreaAddr(param_1,param_3,iVar1);

        iVar1 = *(int *)(iVar1 + 0x154);

      }

      else {

        isisSpfUpdateAllAreaAddr(param_1,param_3,iVar1);

        iVar1 = *(int *)(iVar1 + 0x154);

      }

      if (*(char *)(param_3 + iVar1 + 0x51d) == '\0') {

        isisLspBrowseNodeLsps

                  (param_1,auStack_28,iVar1,isisSpfAddLspNbrsToTent,param_2,param_2,param_3,param_4)

        ;

        return 0;

      }

      if (param_1 == (uint32_t *)0x0) {

        return 0;

      }

      if ((param_1[0x1b] & 0x100) == 0) {

        return 0;

      }

      iVar1 = isisDebugCheck(param_1,0x100,param_2,iVar5);

      if (iVar1 == 0) {

        return 0;

      }

      if (_IsisLogger != 0) {

        uVar2 = isisXlateMtId(param_3);

        uVar3 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

        logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1ad0,param_2,uVar2,uVar3);

        return 0;

      }

      uVar3 = isisXlateMtId(param_3);

      uVar2 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

      uVar4 = 0xa1b1ad0;

    }

  }

  else {

    if (param_1 == (uint32_t *)0x0) {

      return 0;

    }

    if ((param_1[0x1b] & 0x100) == 0) {

      return 0;

    }

    iVar1 = isisDebugCheck(param_1,0x100,param_2,iVar5);

    if (iVar1 == 0) {

      return 0;

    }

    if (_IsisLogger != 0) {

      uVar2 = isisXlateMtId(param_3);

      uVar3 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

      logEvent_debug_fmt(*param_1,0xa1b10ac,&isisTitleStr,0xa1b1b54,param_2,uVar2,uVar3);

      return 0;

    }

    uVar3 = isisXlateMtId(param_3);

    uVar2 = isisDumpSysId(iVar5,param_1 + 0x6a1,0x400,0);

    uVar4 = 0xa1b1b54;

  }

  tracePrint(_MOD_ISIS,0xa1b1a78,0,0,uVar4,param_2,uVar3,uVar2);

  return 0;

}
