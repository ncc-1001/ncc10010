#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared variable sarmFpgaInitialized
extern char sarmFpgaInitialized;

/* WARNING: Control flow encountered bad instruction data */



void hwSarHCResetWPCTRL(void)


{

  if (sarmFpgaInitialized != '\0') {
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  return;
}
