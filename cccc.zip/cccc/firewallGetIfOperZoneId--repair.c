#include "nokia.h"  // Modified: Changed absolute path to local header file
#include <stdint.h>

extern uint32_t FirewallIfOperZone[4096];  // Modified: Added extern declaration with size for FirewallIfOperZone

uint32_t firewallGetIfOperZoneId(uint param_1)



{

  uint32_t uVar1;

  

  if (0x8ff < param_1) {

    return 0;

  }

  uVar1 = vxAtomicGet(&FirewallIfOperZone + param_1 * 4);

  return uVar1;

}



