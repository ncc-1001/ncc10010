#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _IsisLogger; // Modified: Added extern declaration for undeclared identifier
extern char isisTitleStr; // Modified: Added extern declaration for undeclared identifier
extern void isisSpfAddLspReach(); // Modified: Added extern declaration for undeclared identifier
extern int _MOD_ISIS; // Modified: Added extern declaration for undeclared identifier

void isisSpfAddReachability(uint32_t param_1,int *param_2,uint32_t *param_3)
{
  int iVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  uint32_t *puVar4;
  uint32_t uVar5;
  uint32_t uVar6;
  int *piVar7;
  uintptr_t auStack_20 [6];
  uintptr_t uStack_1a;
  uintptr_t uStack_19;
  
  uVar5 = param_3[2];
  puVar4 = (uint32_t *)*param_3;
  uVar6 = param_3[1];
  if (*param_2 == 0) {
    return;
  }
  piVar7 = param_2 + 2;
  memcpy(auStack_20,piVar7,6);
  uStack_1a = *(uintptr_t *)((int)param_2 + 0xe);
  uStack_19 = 0;
  iVar1 = isisLspFind(puVar4,auStack_20,uVar6);
  if (iVar1 == 0) {
    if (puVar4 == (uint32_t *)0x0) {
      return;
    }
    if ((puVar4[0x1b] & 0x100) == 0) {
      return;
    }
    iVar1 = isisDebugCheck(puVar4,0x100,uVar6,piVar7);
    if (iVar1 == 0) {
      return;
    }
    if (_IsisLogger != 0) {
      uVar5 = isisXlateMtId(uVar5);
      uVar2 = isisDumpSysId(piVar7,puVar4 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*puVar4,0xa1b10ac,&isisTitleStr,0xa1b1310,uVar6,uVar5,uVar2);
      return;
    }
    uVar2 = isisXlateMtId(uVar5);
    uVar5 = isisDumpSysId(piVar7,puVar4 + 0x6a1,0x400,0);
    uVar3 = 0xa1b1310;
  }
  else if ((*(ushort *)(iVar1 + 0xc) & 0x20) == 0) {
    if (*(int *)(iVar1 + 0x10) != 0) {
      param_2[4] = *(int *)(*(int *)(iVar1 + 0x154) + 0x518);
      isisLspBrowseNodeLsps
                (puVar4,auStack_20,*(uint32_t *)(iVar1 + 0x154),isisSpfAddLspReach,uVar6,uVar6,
                 uVar5,param_2);
      return;
    }
    if (puVar4 == (uint32_t *)0x0) {
      return;
    }
    if ((puVar4[0x1b] & 0x100) == 0) {
      return;
    }
    iVar1 = isisDebugCheck(puVar4,0x100,uVar6,piVar7);
    if (iVar1 == 0) {
      return;
    }
    if (_IsisLogger != 0) {
      uVar5 = isisXlateMtId(uVar5);
      uVar2 = isisDumpSysId(piVar7,puVar4 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*puVar4,0xa1b10ac,&isisTitleStr,0xa1b1264,uVar6,uVar5,uVar2);
      return;
    }
    uVar2 = isisXlateMtId(uVar5);
    uVar5 = isisDumpSysId(piVar7,puVar4 + 0x6a1,0x400,0);
    uVar3 = 0xa1b1264;
  }
  else {
    if (puVar4 == (uint32_t *)0x0) {
      return;
    }
    if ((puVar4[0x1b] & 0x100) == 0) {
      return;
    }
    iVar1 = isisDebugCheck(puVar4,0x100,uVar6,piVar7);
    if (iVar1 == 0) {
      return;
    }
    if (_IsisLogger != 0) {
      uVar5 = isisXlateMtId(uVar5);
      uVar2 = isisDumpSysId(piVar7,puVar4 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*puVar4,0xa1b10ac,&isisTitleStr,0xa1b12bc,uVar6,uVar5,uVar2);
      return;
    }
    uVar2 = isisXlateMtId(uVar5);
    uVar5 = isisDumpSysId(piVar7,puVar4 + 0x6a1,0x400,0);
    uVar3 = 0xa1b12bc;
  }
  tracePrint(_MOD_ISIS,0xa1b124c,0,0,uVar3,uVar6,uVar2,uVar5);
  return;
}