// Modified: Added extern declaration for undeclared identifier _MOD_MDADRV
extern int _MOD_MDADRV;

#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void choc412MdaCleanupOnShutdown(int param_1)



{

  byte bVar1;

  int iVar2;

  ushort uVar3;

  int iVar4;

  uint uVar5;

  uint uVar6;

  uint uVar7;

  uint uVar8;

  

  uVar8 = 0;

  cdceUnRegisterSpiCtlApi(*(uint32_t *)(param_1 + 0x36ca24));

  if (*(char *)(param_1 + 0x36caa4) != '\0') {

    iVar2 = 0;

    do {

      iVar2 = (iVar2 + uVar8) * 4 + param_1;

      if (iVar2 != 0) {

        uVar3 = 0;

LAB_064369d4:

        uVar7 = 0;

        bVar1 = *(byte *)(iVar2 + 100);

LAB_064369d8:

        uVar5 = (uint)bVar1;

        iVar4 = *(int *)((uVar5 + *(int *)(param_1 + 0x36ca24)) * 4 + 0xcca8798);

        if ((iVar4 != 0) && (*(int *)(uVar7 * 0xc + iVar4 + 4) != 0)) {

          rngDelete();

          uVar5 = (uint)*(byte *)(iVar2 + 100);

        }

        uVar6 = 0;

        do {

          iVar4 = *(int *)((uVar5 + *(int *)(param_1 + 0x36ca24)) * 4 + 0xcca8798);

          if ((iVar4 != 0) &&

             (iVar4 = *(int *)(uVar7 * 0x6cc + uVar6 * 0x244 + iVar4 + 0x34), iVar4 != 0)) {

            rngDelete(iVar4);

            uVar5 = (uint)*(byte *)(iVar2 + 100);

          }

          iVar4 = *(int *)((uVar5 + *(int *)(param_1 + 0x36ca24)) * 4 + 0xcca8798);

          if ((iVar4 == 0) ||

             (iVar4 = *(int *)(uVar7 * 0x6cc + uVar6 * 0x244 + iVar4 + 0x38), iVar4 == 0)) {

            uVar6 = uVar6 + 1 & 0xff;

            if (2 < uVar6) goto LAB_06436b2c;

            bVar1 = *(byte *)(iVar2 + 100);

          }

          else {

            rngDelete(iVar4);

            uVar6 = uVar6 + 1 & 0xff;

            if (2 < uVar6) goto LAB_06436b2c;

            bVar1 = *(byte *)(iVar2 + 100);

          }

          uVar5 = (uint)bVar1;

        } while( true );

      }

LAB_06436b70:

      uVar8 = uVar8 + 1 & 0xffff;

      iVar2 = uVar8 << 5;

    } while (uVar8 < *(byte *)(param_1 + 0x36caa4));

  }

  ufe4SonetSdhShutdown(param_1);

  ufe4PdhShutdown(param_1);

  return;

LAB_06436b2c:

  uVar7 = uVar7 + 1 & 0xff;

  if (3 < uVar7) goto code_r0x06436b3c;

  bVar1 = *(byte *)(iVar2 + 100);

  goto LAB_064369d8;

code_r0x06436b3c:

  iVar4 = *(int *)((uVar8 + *(int *)(param_1 + 0x36ca24)) * 4 + 0xcca8798);

  if (iVar4 != 0) {

    modFree(iVar4,_MOD_MDADRV);

    *(uint32_t *)((uVar8 + *(int *)(param_1 + 0x36ca24)) * 4 + 0xcca8798) = 0;

  }

  uVar3 = uVar3 + 1;

  if (3 < uVar3) goto LAB_06436b70;

  goto LAB_064369d4;

}