#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

void isisAdjBfdDel(uint32_t param_1,int param_2)
{
  int iVar1;
  int *piVar2;
  
  if (*(char *)(param_2 + 0x96) != '\0') {
    piVar2 = *(int **)(param_2 + 0x68);
    iVar1 = bfd_client_remove_session(5,1,param_2 + 0x98);
    if (iVar1 == 0) {
      *(uintptr_t *)(param_2 + 0x96) = 0;
      return;
    }
    iVar1 = *piVar2;
    if (((iVar1 != 0) && ((*(uint *)(iVar1 + 0x6c) & 0x800000) != 0)) &&
       (iVar1 = isisDebugCheck(iVar1,0x800000,param_2,piVar2), iVar1 != 0)) {
      if (_IsisLogger == 0) {
        tracePrint(_MOD_ISIS,0xa1a71ac,0,0,0xa1a71bc,*(uint32_t *)(param_2 + 0x98));
      }
      else {
        logEvent_debug_fmt(*(uint32_t *)*piVar2,0xa1a69b0,&isisTitleStr,0xa1a71bc,
                           *(uint32_t *)(param_2 + 0x98));
      }
    }
  }
  return;
}