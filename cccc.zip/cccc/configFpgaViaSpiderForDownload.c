#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t configFpgaViaSpiderForDownload(uint32_t param_1,byte param_2)



{

  ushort uVar1;

  uint32_t uVar2;

  int iVar3;

  ushort auStack_28 [4];

  

  uVar2 = spiGetChannelGivenMda();

  iVar3 = spiWritePortConfig(uVar2,2,0xd8fc);

  if ((iVar3 == 0) && (iVar3 = spiReadPort(uVar2,2,auStack_28), iVar3 == 0)) {

    if ((((param_2 == 0xa2 || param_2 == 0x90) ||

         ((((param_2 ^ 0x91) == 0 || (param_2 ^ 0x9a) == 0 || (param_2 == 0xa3 || param_2 == 0xaa))

          || (param_2 == 0x9b)))) ||

        (((param_2 == 0xa9 || (param_2 == 0x80 || param_2 == 0xae)) ||

         (param_2 == 0xb5 || param_2 == 0xb9)))) ||

       (uVar1 = auStack_28[0] | 0x800, param_2 == 0x9c || param_2 == 0x9d)) {

      if ((((param_2 ^ 0x91) == 0 || (param_2 ^ 0x9a) == 0) || (param_2 == 0xa3 || param_2 == 0xaa))

         || ((param_2 == 0x9b ||

             ((((param_2 == 0xa9 || (param_2 == 0x80 || param_2 == 0xae)) ||

               (param_2 == 0xb5 || param_2 == 0xb9)) || (param_2 == 0x9c || param_2 == 0x9d)))))) {

        auStack_28[0] = auStack_28[0] & 0xffdf | 0x800;

        iVar3 = hwCpldGetSlotPosition();

        if (iVar3 == 0) {

          uVar1 = auStack_28[0] | 4;

        }

        else {

          uVar1 = auStack_28[0] & 0xfffb;

        }

      }

      else {

        uVar1 = auStack_28[0] | 0x820;

      }

    }

    auStack_28[0] = uVar1;

    iVar3 = spiWritePort(uVar2,2,auStack_28[0]);

    if ((iVar3 == 0) && (iVar3 = spiReadPort(uVar2,2,auStack_28), iVar3 == 0)) {

      auStack_28[0] = auStack_28[0] | 0x1000;

      iVar3 = spiWritePort(uVar2,2,auStack_28[0]);

      if (iVar3 == 0) {

        sysDelayNanos(10000000);

        iVar3 = spiReadPort(uVar2,2,auStack_28);

        if (iVar3 == 0) {

          auStack_28[0] = auStack_28[0] & 0xefff;

          iVar3 = spiWritePort(uVar2,2,auStack_28[0]);

          if (iVar3 == 0) {

                    /* WARNING: Subroutine does not return */

            sysCountGet64();

          }

        }

      }

    }

  }

  return 0xffffffff;

}



