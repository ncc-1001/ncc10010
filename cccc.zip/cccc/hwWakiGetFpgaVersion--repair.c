#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared variable cRam10c8f925
extern byte cRam10c8f925;

int hwWakiGetFpgaVersion(uint32_t param_1)
{
  int iVar1;
  
  iVar1 = -1;
  if (5 < (byte)(cRam10c8f925 + 0x1eU)) {
    iVar1 = hwWakiReadReg32(0,0,param_1);
    iVar1 = (iVar1 == 0) - 1;
  }
  return iVar1;
}
