#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for missing variables
extern char dhsTraceAll;
extern int _MOD_DHS;
extern void* _dhsDelayedRepliesTbl;
extern int dhsTimeoutQueueLock;
extern int _tracepointsActive;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t dhsDelayMsg(int param_1)

{

  uint16_t uVar1;

  int iVar2;

  int iVar3;

  uint32_t uVar4;

  uint32_t uVar5;

  uint uVar6;

  uintptr_t auStack_68 [64];
  
  uVar6 = *(uint *)(param_1 + 0x2c);
  if (((dhsTraceAll != '\0') && (_tracepointsActive != 0)) &&
     (iVar2 = traceTest(_MOD_DHS,0xa5960c4,1,0), iVar2 != 0)) {
    uVar4 = sbmTraceDhcpMsgType(0,*(uint *)(param_1 + 0x4c) >> 0xc & 0xf);
    uVar5 = FmtMac(param_1 + 0x30,auStack_68,0x40);
    tracePrintVRtr(_MOD_DHS,0xa5960c4,1,0,1,0xa5960fc,uVar4,uVar5,uVar6);
  }
  iVar2 = dhsAllocEvent(uVar6 & 0xffff,0);
  if (iVar2 == 0) {
    if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_DHS,0xa5960c4,1,0), iVar2 != 0)) {
      uVar4 = sbmTraceDhcpMsgType(0,*(uint *)(param_1 + 0x4c) >> 0xc & 0xf);
      tracePrintVRtr(_MOD_DHS,0xa5960c4,1,0,1,0xa59612c,uVar4);
    }
  }
  else {
    *(uint *)(iVar2 + 0xa8) = uVar6;
    *(uint32_t *)(iVar2 + 0xac) = *(uint32_t *)(param_1 + 0x30);
    uVar1 = *(uint16_t *)(param_1 + 0x34);
    *(int *)(iVar2 + 0xa4) = param_1;
    *(uint16_t *)(iVar2 + 0xb0) = uVar1;
    iVar3 = avlpInsert(_dhsDelayedRepliesTbl,iVar2 + 0xa8,iVar2);
    if (iVar3 != -1) {
                    /* WARNING: Subroutine does not return */
      intLockProtect(&dhsTimeoutQueueLock);
    }
    dhsFreeEvent(iVar2);
    if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_DHS,0xa5960c4,1,0), iVar2 != 0)) {
      uVar4 = sbmTraceDhcpMsgType(0,*(uint *)(param_1 + 0x4c) >> 0xc & 0xf);
      tracePrintVRtr(_MOD_DHS,0xa5960c4,1,0,1,0xa5960d0,uVar4);
    }
  }
  return 0;
}