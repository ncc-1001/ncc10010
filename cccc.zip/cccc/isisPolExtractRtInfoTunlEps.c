#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isisPolExtractRtInfoTunlEps

               (int param_1,uint param_2,uintptr_t *param_3,uint32_t *param_4,int *param_5)



{

  int iVar1;

  

  if (param_5 == (int *)0x0 || param_3 == (uintptr_t *)0x0) {

    return;

  }

  if (param_1 != 0) {

    iVar1 = (param_2 & 0xff) * 0x6c;

    if (param_1 < 0xb) {

      *param_3 = 0;

    }

    if ((param_2 & 0xff) < (*(byte *)(param_1 + 0x2c) & 0x1f)) {

      *param_3 = *(uintptr_t *)(iVar1 + *(int *)(param_1 + 0x48) + 0x28);

      *param_4 = *(uint32_t *)(iVar1 + *(int *)(param_1 + 0x48) + 0x24);

      *param_5 = *(int *)(param_1 + 0x48) + iVar1 + 0x2c;

      return;

    }

  }

  *param_3 = 0;

  return;

}



