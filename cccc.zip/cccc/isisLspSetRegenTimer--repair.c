#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared identifiers
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

void isisLspSetRegenTimer(uint32_t *param_1,int param_2,char param_3)
{
  uint32_t uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = 0;
  if ((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x200) == 0)) {
    iVar2 = *(int *)(param_2 + 0x1c);
  }
  else {
    iVar2 = isisDebugCheck(param_1,0x200,param_2,0);
    if (iVar2 == 0) {
      iVar2 = *(int *)(param_2 + 0x1c);
    }
    else if (_IsisLogger == 0) {
      uVar1 = isisDumpLspId(param_2 + 4,param_1 + 0x6a1,0x400,0);
      tracePrint(_MOD_ISIS,0xa1aa468,0,0,0xa1aa480,uVar1,*(uint32_t *)(param_2 + 0x24),
                 *(uint16_t *)(param_2 + 0xc),*(uint32_t *)(param_2 + 0x1c));
      iVar2 = *(int *)(param_2 + 0x1c);
    }
    else {
      uVar1 = isisDumpLspId(param_2 + 4,param_1 + 0x6a1,0x400,0);
      logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1aa480,uVar1,
                         *(uint32_t *)(param_2 + 0x24),*(uint16_t *)(param_2 + 0xc),
                         *(uint32_t *)(param_2 + 0x1c));
      iVar2 = *(int *)(param_2 + 0x1c);
    }
  }
  if (iVar2 == 1) {
    iVar2 = param_1[0x1a1];
    iVar4 = 2;
  }
  else if (iVar2 == 0) {
    iVar2 = param_1[0x1a0];
    iVar4 = 1;
  }
  else {
    if (iVar2 != 2) {
      iVar2 = *(int *)(param_2 + 0x20);
      goto LAB_0420f324;
    }
    iVar4 = 2;
    iVar2 = *(int *)(param_2 + 0x20) << 1;
  }
  *(int *)(param_2 + 0x20) = iVar2;
LAB_0420f324:
  iVar3 = param_1[0x1a2];
  if (iVar3 < iVar2) {
    *(int *)(param_2 + 0x20) = iVar3;
    iVar2 = iVar3;
  }
  *(int *)(param_2 + 0x1c) = iVar4;
  if (iVar2 == 0) {
    if (iVar4 == 0) {
      return;
    }
    isisLspRegenerateTimerExp(*param_1,param_1,param_2);
    return;
  }
  iVar4 = redAmIActive(0x34);
  if (iVar4 == 0) {
    if (param_3 == '\0') {
      return;
    }
    iVar4 = *(int *)(param_2 + 0x20);
  }
  else {
    iVar4 = *(int *)(param_2 + 0x20);
  }
  timerReset(*(uint32_t *)(param_2 + 0x18),iVar4 * 10);
  return;
}