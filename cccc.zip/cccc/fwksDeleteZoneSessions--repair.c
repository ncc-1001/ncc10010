#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

typedef int (*code)(int, int);  // Modified: Changed typedef to match function signature used in code
extern code __gxx_personality_sj0;  // Modified: Changed extern declaration to match expected type
extern int __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
extern unsigned int __ZN8Firewall10FwksFilter8m_uLimitE;
extern unsigned int __ZN8Firewall10FwksFilter6m_uNewE;
extern unsigned int __ZN8Firewall10FwksFilter9m_uDeleteE;
extern unsigned int uRam0c9594cc;
extern unsigned int uRam0c9594c4;
extern unsigned int uRam0c959610;
extern int iRam0c959614;
extern int iRam0c95960c;
extern unsigned int uRam0c959618;
extern int iRam0c95961c;

uint32_t fwksDeleteZoneSessions(int param_1)
{
  int **ppiVar1;
  uint32_t uVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  uintptr_t auStack_98 [16];
  uintptr_t auStack_88 [4];
  uint32_t uStack_84;
  code *pcStack_70;
  uint32_t uStack_6c;
  uintptr_t *puStack_68;
  uint32_t uStack_64;
  uintptr_t *puStack_60;
  uint32_t uStack_54;
  int iStack_48;
  int iStack_44;
  int iStack_40;
  int *piStack_3c;
  int *piStack_38;
  int iStack_34;
  int iStack_30;
  
  puStack_60 = auStack_98;
  puStack_68 = auStack_88;
  pcStack_70 = &__gxx_personality_sj0;  // Modified: Added address-of operator
  uStack_64 = 0x40ea13c;
  uStack_6c = 0xbff85e6;
  _Unwind_SjLj_Register(puStack_68);
  iVar3 = __ZN8Firewall10FwksFilter17m_pFilterInstanceE;
  if (__ZN8Firewall10FwksFilter17m_pFilterInstanceE == 0) {
    if ((__ZN8Firewall10FwksFilter8m_uLimitE == 0) ||
       ((__ZN8Firewall10FwksFilter6m_uNewE - __ZN8Firewall10FwksFilter9m_uDeleteE ==
         (uint)(uRam0c9594cc < uRam0c9594c4) &&
        (uRam0c9594cc - uRam0c9594c4 < __ZN8Firewall10FwksFilter8m_uLimitE)))) {
      uRam0c9594cc = uRam0c9594cc + 1;
      uRam0c959610 = uRam0c959610 + 1;
      __ZN8Firewall10FwksFilter6m_uNewE =
           __ZN8Firewall10FwksFilter6m_uNewE + (uint)(uRam0c9594cc == 0);
      iRam0c959614 = iRam0c959614 + 1;
      iRam0c95960c = iRam0c95960c + 0xb6d5f0;
      if (uRam0c959618 < uRam0c959610) {
        uRam0c959618 = uRam0c959610;
      }
      uStack_84 = 0xffffffff;
      iStack_48 = firewallMalloc(0xb6d5f0);
    }
    else {
      iStack_48 = 0;
      iRam0c95961c = iRam0c95961c + 1;
    }
    uStack_84 = 1;
    _ZN8Firewall10FwksFilterC1Ev();
    __ZN8Firewall10FwksFilter17m_pFilterInstanceE = iStack_48;
    iVar3 = 0;
    if (iStack_48 != 0) {
      iVar3 = iStack_48;
    }
  }
  uStack_54 = 0;
  uVar2 = uStack_54;
  if (iVar3 != 0) {
    iStack_44 = iVar3;
    if (param_1 == 0) {
      if (*(int *)(iVar3 + 0xb2f190) == 0) {
        iVar4 = iVar3 + 0xb6a070;
      }
      else {
        iVar4 = iVar3 + 0xb6b950;
      }
      iStack_34 = 0;
      if (iVar4 + 0x28 != *(int *)(iVar4 + 0x2c)) {
        iStack_34 = *(int *)(iVar4 + 0x2c);
      }
      if (iStack_34 != 0) {
        iStack_30 = iVar3 + 0xb30000;
        do {
          uStack_84 = 0xffffffff;
          _ZN8Firewall7ZoneRep10clearStateEv(*(uint32_t *)(iStack_34 + 0x44));
          iVar3 = 0xb6b974;
          if (*(int *)(iStack_30 + -0xe70) == 0) {
            iVar3 = 0xb6a094;
          }
          piVar5 = (int *)(iStack_34 + 4);
          iStack_34 = 0;
          if (iStack_44 + iVar3 + 4 != *piVar5) {
            iStack_34 = *piVar5;
          }
        } while (iStack_34 != 0);
        iStack_34 = 0;
        uVar2 = 1;
        goto LAB_040e9fa8;
      }
    }
    else {
      iVar4 = 0xb6b974;
      if (*(int *)(iVar3 + 0xb2f190) == 0) {
        iVar4 = 0xb6a094;
      }
      iVar3 = iVar3 + iVar4;
      piStack_3c = (int *)0x0;
      if ((int *)(iVar3 + 4) != *(int **)(iVar3 + 8)) {
        piStack_3c = *(int **)(iVar3 + 8);
      }
      iStack_40 = param_1;
      if (piStack_3c != (int *)0x0) {
        piStack_38 = (int *)(iVar3 + 4);
        do {
          uStack_84 = 0xffffffff;
          iVar3 = (**(code **)(*piStack_3c + 0x20))(piStack_3c,iStack_40);
          piVar5 = piStack_3c;
          if (iVar3 != 0) goto LAB_040e9f88;
          ppiVar1 = (int **)(piStack_3c + 1);
          piStack_3c = (int *)0x0;
          if (piStack_38 != *ppiVar1) {
            piStack_3c = *ppiVar1;
          }
        } while (piStack_3c != (int *)0x0);
      }
      piVar5 = (int *)0x0;
LAB_040e9f88:
      uVar2 = 0;
      if (piVar5 == (int *)0x0) goto LAB_040e9fa8;
      uStack_84 = 0xffffffff;
      _ZN8Firewall7ZoneRep10clearStateEv(piVar5[0x11]);
    }
    uVar2 = 1;
  }
LAB_040e9fa8:
  uStack_54 = uVar2;
  _Unwind_SjLj_Unregister(auStack_88);
  return uStack_54;
}