#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared global variables
extern int *_gMdaInfo;
extern int _traceEnabled;
extern int _tracepointsActive;
extern int _MOD_MDADRV;

uint getUtcOffset(uint param_1)
{
  int iVar1;
  
  if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
    if ((_traceEnabled != 0) ||
       ((_tracepointsActive != 0 && (iVar1 = traceTest(_MOD_MDADRV,0xa9c11d4,4,0x35), iVar1 != 0))))
    {
      tracePrintVRtr(_MOD_MDADRV,0xa9c11d4,4,0x35,1,0xa9c0ae8,param_1);
    }
  }
  else {
    iVar1 = _ZN4GRIP11getInstanceEj();
    if (iVar1 != 0) {
      return *(uint *)(iVar1 + 0xee4) & 0x3f;
    }
  }
  return 0;
}