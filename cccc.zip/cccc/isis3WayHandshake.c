#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

void isis3WayHandshake(uint32_t param_1,uintptr_t param_2)



{

  int iVar1;

  int aiStack_10 [2];

  

  aiStack_10[0] = 0;

  iVar1 = isisGetNode(param_1,aiStack_10);

  if (iVar1 == 0) {

    *(uintptr_t *)(aiStack_10[0] + 0x6a) = param_2;

  }

  return;

}



