#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t firemgrHandleTcpSessionEvents(uint32_t param_1,int param_2)



{

  uint32_t uVar1;

  

  uVar1 = 0xffffffff;

  switch(*(uint16_t *)(param_2 + 4)) {

  case 0x40:

    uVar1 = firemgrProcessTcpSessionUpdate(param_1,1,*(uint32_t *)(param_2 + 0xc));

    break;

  case 0x41:

    uVar1 = firemgrProcessTcpSessionUpdate(param_1,2,*(uint32_t *)(param_2 + 0xc));

    break;

  case 0x42:

    uVar1 = firemgrProcessTcpSessionUpdate(param_1,3,*(uint32_t *)(param_2 + 0xc));

    break;

  case 0x43:

  case 0x44:

    uVar1 = firemgrProcessTcpSessionUpdate(param_1,4,*(uint32_t *)(param_2 + 0xc));

  }

  return uVar1;

}



