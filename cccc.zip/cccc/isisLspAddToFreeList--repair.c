#include "nokia.h"
#include <stdint.h>

// Modified: Added missing global variable declarations
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisLspAddToFreeList(uint32_t *param_1,int param_2)


{

  int *piVar1;

  uint32_t uVar2;

  int iVar3;

  uint32_t uVar4;

  

  if (*(int *)(param_2 + 0x24) == 1) {

    uVar4 = param_1[0x1ad];

  }

  else {

    uVar4 = param_1[0x1ae];

  }

  piVar1 = (int *)dlistAllocateNodeExt(uVar4,4,1);

  if (piVar1 != (int *)0x0) {

    *piVar1 = param_2;

    isisLspIncRef(param_1,param_2,0xa1aa410,0x4d3);

    *(ushort *)(param_2 + 0xc) = *(ushort *)(param_2 + 0xc) | 0x200;

    uVar2 = dlistGetFirst(uVar4);

    dlistInsertBefore(uVar4,uVar2,piVar1);

    return;

  }

  if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x200) == 0)) ||

     (iVar3 = isisDebugCheck(param_1,0x200,0,0), iVar3 == 0)) {

    isisHandleMemFail(param_1);

  }

  else if (_IsisLogger == 0) {

    tracePrint(_MOD_ISIS,0xa1aa548,0,0,0xa1aa560);

    isisHandleMemFail(param_1);

  }

  else {

    logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1aa560);

    isisHandleMemFail(param_1);

  }

  return;

}
