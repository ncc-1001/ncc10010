#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int cRam10c8f925; // Modified: Added extern declaration for undeclared variable
extern int *_gMdaInfo;   // Modified: Added extern declaration for undeclared variable

void fpgaXfpPwrDownEnable(uint param_1,int param_2,char param_3)
{
  int iVar1;

  if (((((((cRam10c8f925 == -0x13 || cRam10c8f925 == -0x17) || ((byte)(cRam10c8f925 + 0x16U) < 2))
         || (cRam10c8f925 == -0xd || cRam10c8f925 == -0xf)) ||
        ((cRam10c8f925 == -8 || (cRam10c8f925 == -9)))) ||
       ((cRam10c8f925 == -10 || cRam10c8f925 == -0x10 ||
        ((cRam10c8f925 == -0xe || (cRam10c8f925 == -0x24)))))) ||
      (cRam10c8f925 == -0x23 || cRam10c8f925 == -0x12)) ||
     (((byte)(cRam10c8f925 + 0x1eU) < 6 || (cRam10c8f925 == -7)))) {
    if ((param_1 == 0) || (*_gMdaInfo < param_1)) {
      timosAssert(0xa8ca374,0xa8ca390,0x104e,0xa8cb944,0xa8ca3bc);
    }
    if (*(int *)(param_1 * 4 + 0xccb630c) == 0) {
      timosAssert(0xa8cb940,0xa8ca390,0x104e,0xa8cb944,0xa8ca3bc);
    }
    if (param_1 == 3) {
      fpgaSarmModuleXfpPwrDownEnable(param_2,param_3);
      return;
    }
  }
  else {
    iVar1 = param_2 * 0x10 + 0x100;
    if (param_3 == '\0') {
      fpgaRegClear(param_1,iVar1,8);
    }
    else {
      fpgaRegSet(param_1,iVar1,8);
    }
  }
  return;
}