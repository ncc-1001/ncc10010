#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Added: Declaration for undeclared variable
char cRam000005a8;

uint32_t iDragaDtrDsrLeadSel(uint param_1,int param_2,uint param_3)
{
  char cVar1;
  int iVar2;
  int iVar3;
  uint32_t uVar4;
  uint auStack_20 [2];
  
  iVar2 = _gHwPlatform * 0x34;
  iVar3 = *(int *)(iVar2 + 0xbbfd934) + *(int *)(iVar2 + 0xbbfd924) * param_2;
  if (2 < _gHwPlatform - 1U) {
    iVar2 = macMdaRemoved();
    if (iVar2 != 0) {
      return 0xffffffff;
    }
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return 0xffffffff;
      }
      iVar2 = traceTest(_MOD_MDADRV,0xa8e1bb8,4,0);
      if (iVar2 == 0) {
        return 0xffffffff;
      }
    }
    tracePrintVRtr(_MOD_MDADRV,0xa8e1bb8,4,0,1,0xa8e1634,_gHwPlatform);
    return 0xffffffff;
  }
  // Modified: Added NULL as fourth argument to match function signature
  iVar2 = (**(code **)(iVar2 + 0xbbfd94c))(param_1,iVar3,auStack_20,NULL);
  if (iVar2 != 0) {
    iVar2 = macMdaRemoved(param_1);
    if (iVar2 != 0) {
      return 0xffffffff;
    }
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return 0xffffffff;
      }
      iVar2 = traceTest(_MOD_MDADRV,0xa8e1bb8,4,0);
      if (iVar2 == 0) {
        return 0xffffffff;
      }
    }
    uVar4 = 0xa8e1650;

LAB_063d3134:
    tracePrintVRtr(_MOD_MDADRV,0xa8e1bb8,4,0,1,uVar4,param_1,iVar3);
    return 0xffffffff;
  }
  auStack_20[0] = auStack_20[0] & 0xffffff7f | (param_3 & 1) << 7;
  // Modified: Added NULL as third and fourth arguments to match function signature
  iVar2 = (**(code **)(_gHwPlatform * 0x34 + 0xbbfd950))(param_1,iVar3,NULL,NULL);
  if (iVar2 != 0) {
    iVar2 = macMdaRemoved(param_1);
    if (iVar2 != 0) {
      return 0xffffffff;
    }
    if (_traceEnabled == 0) {
      if (_tracepointsActive == 0) {
        return 0xffffffff;
      }
      iVar2 = traceTest(_MOD_MDADRV,0xa8e1bb8,4,0);
      if (iVar2 == 0) {
        return 0xffffffff;
      }
    }
    uVar4 = 0xa8e16e4;
    goto LAB_063d3134;
  }
  iVar2 = 0;
  if (param_1 != 0) {
    cVar1 = cRam000005a8;
    if (*_gMdaInfo < param_1) goto LAB_063d2f50;
    iVar2 = *(int *)(param_1 * 4 + 0x10ae59e4);
  }
  cVar1 = *(char *)(iVar2 + 0x5a8);

LAB_063d2f50:
  if (cVar1 == '\0') {
    return 0;
  }
  if (_tracepointsActive == 0) {
    return 0;
  }
  iVar2 = traceTest(_MOD_MDADRV,0xa8e1bb8,1,0);
  if (iVar2 == 0) {
    return 0;
  }
  tracePrintVRtr(_MOD_MDADRV,0xa8e1bb8,1,0,1,0xa8e1690,param_1,param_2,0xa8e1a84,iVar3,auStack_20[0]
                 ,0xa8e1bcc,param_3);
  return 0;
}