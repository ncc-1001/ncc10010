#include "nokia.h"
#include <stdint.h>

// Modified: Added missing global variable declarations
int _IsisLogger;
int _MOD_ISIS;
char* isisTitleStr;

/* WARNING: Removing unreachable block (ram,0x0421b044) */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t

isisLspAddNbr(uint32_t *param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,

             uint32_t param_5,uint32_t param_6,uint32_t param_7,uint32_t param_8,

             uint32_t param_9,uint32_t param_10,uint32_t param_11,uint32_t param_12,

             uint32_t param_13,uint32_t param_14,uint32_t param_15,uint param_16,

             uint32_t param_17)



{
  char cVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  uint32_t uVar5;
  int iVar6;
  uintptr_t auStack_38 [8];
  uint32_t uStack_30;
  
  memcpy(auStack_38,param_3,7);
  iVar6 = 0;
  if (param_16 == 1) {
    uVar5 = param_1[0x1a5];
  }
  else {
    uVar5 = param_1[0x1a6];
  }
  uStack_30 = param_2;
  iVar3 = dlist_find(uVar5,auStack_38,0,0xa1aa410,0xfe7);
  if (iVar3 != 0) {
    return 2;
  }
  if (param_16 == 1) {
    uVar5 = param_1[0x1a5];
  }
  else {
    uVar5 = param_1[0x1a6];
  }
  iVar3 = dlistAllocateNodeExt(uVar5,0x54,1);
  if (iVar3 == 0) {
    if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x200) == 0)) ||
       (iVar6 = isisDebugCheck(param_1,0x200,0,0), iVar6 == 0)) {
LAB_0421b080:
      isisHandleMemFail(param_1);
      return 6;
    }
    if (_IsisLogger == 0) {
      tracePrint(_MOD_ISIS,0xa1ab390,0,0,0xa1ab3a0);
LAB_0421b220:
      isisHandleMemFail(param_1);
      return 6;
    }
    logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1ab3a0);
LAB_0421b0d8:
    isisHandleMemFail(param_1);
    return 6;
  }
  memcpy(iVar3,param_3,7);
  *(uint32_t *)(iVar3 + 0x14) = param_4;
  *(uint32_t *)(iVar3 + 8) = param_2;
  *(uint32_t *)(iVar3 + 0x18) = param_5;
  *(uint32_t *)(iVar3 + 0x28) = param_7;
  *(uint32_t *)(iVar3 + 0x2c) = param_8;
  *(uint32_t *)(iVar3 + 0x24) = param_6;
  *(uint32_t *)(iVar3 + 0x30) = param_9;
  *(uint32_t *)(iVar3 + 0x34) = param_10;
  *(uint32_t *)(iVar3 + 0x3c) = param_12;
  *(uint32_t *)(iVar3 + 0x40) = param_13;
  *(uint32_t *)(iVar3 + 0x38) = param_11;
  *(uint32_t *)(iVar3 + 0x44) = param_14;
  *(uint32_t *)(iVar3 + 0x48) = param_15;
  if (param_16 == 1) {
    cVar1 = *(char *)((int)param_1 + 0x2059);
    uVar5 = param_1[0x82e];
  }
  else {
    cVar1 = *(char *)((int)param_1 + 0x205a);
    uVar5 = param_1[0x82e];
  }
  if (cVar1 != '\x01') {
    iVar6 = dlistAllocateNodeExt(uVar5,4,1);
    if (iVar6 == 0) {
      if (param_16 == 1) {
        uVar5 = param_1[0x1a5];
      }
      else {
        uVar5 = param_1[0x1a6];
      }
      dlistFreeNodeExt(uVar5,iVar3);
      if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x200) != 0)) &&
         (iVar6 = isisDebugCheck(param_1,0x200,0,0), iVar6 != 0)) {
        if (_IsisLogger == 0) {
          tracePrint(_MOD_ISIS,0xa1ab390,0,0,0xa1ab3f0);
          goto LAB_0421b220;
        }
        logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1ab3f0);
        goto LAB_0421b0d8;
      }
      goto LAB_0421b080;
    }
    uVar5 = param_1[0x82e];
  }
  iVar4 = dlistAllocateNodeExt(uVar5,4,1);
  if (iVar4 == 0) {
    if (iVar6 != 0) {
      dlistFreeNodeExt(param_1[0x82e],iVar6);
    }
    if (param_16 == 1) {
      uVar5 = param_1[0x1a5];
    }
    else {
      uVar5 = param_1[0x1a6];
    }
    dlistFreeNodeExt(uVar5,iVar3);
    if (((param_1 == (uint32_t *)0x0) || ((param_1[0x1b] & 0x200) == 0)) ||
       (iVar6 = isisDebugCheck(param_1,0x200,0,0), iVar6 == 0)) goto LAB_0421b080;
    if (_IsisLogger == 0) {
      tracePrint(_MOD_ISIS,0xa1ab390,0,0,0xa1ab3c8);
      goto LAB_0421b220;
    }
    logEvent_debug_fmt(*param_1,0xa1aa444,&isisTitleStr,0xa1ab3c8);
    goto LAB_0421b0d8;
  }
  if (param_16 == 1) {
    dlist_insert(param_1[0x1a5],iVar3,0xa1aa410,0x101e);
    bVar2 = *(byte *)((int)param_1 + 0x2059);
LAB_0421b050:
    if (bVar2 == param_16) goto LAB_0421aeec;
  }
  else {
    dlist_insert(param_1[0x1a6],iVar3,0xa1aa410,0x101e);
    if (param_16 == 1) {
      bVar2 = *(byte *)((int)param_1 + 0x2059);
      goto LAB_0421b050;
    }
    if (*(char *)((int)param_1 + 0x205a) == '\x01') goto LAB_0421aeec;
  }
  isisLspAddNbrToNode(param_1,iVar3,iVar6,param_16,0,0,param_17);
LAB_0421aeec:
  isisLspAddNbrToNode(param_1,iVar3,iVar4,param_16,1,0,param_17);
  iVar6 = *(int *)(iVar3 + 0xc) + 4;
  if (*(int *)(iVar3 + 0xc) == 0) {
    iVar6 = 0;
  }
  iVar4 = *(int *)(iVar3 + 0x1c) + 4;
  if (*(int *)(iVar3 + 0x1c) == 0) {
    iVar4 = 0;
  }
  isisRedSendNbrToInactive
            (param_1,1,param_3,param_16,param_4,param_5,param_6,param_7,param_8,param_9,param_10,
             param_11,param_12,param_13,param_14,param_15,param_2,iVar6,iVar4,0,0,0);
  iVar6 = *(int *)(iVar3 + 0xc) + 4;
  if ((*(int *)(iVar3 + 0xc) == 0) &&
     (iVar6 = *(int *)(iVar3 + 0x1c) + 4, *(int *)(iVar3 + 0x1c) == 0)) {
    iVar6 = 0;
  }
  isisSpfSchedule(param_1,0x400,iVar6);
  return 0;
}