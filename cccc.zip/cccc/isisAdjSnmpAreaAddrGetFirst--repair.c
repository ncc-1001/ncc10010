#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _isisMutex; // Modified: Added extern declaration for undeclared _isisMutex

void isisAdjSnmpAreaAddrGetFirst(void)
{
                    /* WARNING: Subroutine does not return */
  semTake(_isisMutex,0xffffffff);
}