#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for undeclared function isisDumpLspRoute
extern void isisDumpLspRoute(uint32_t);

void isisDumpLspRoutes(uint32_t param_1,int param_2,uint32_t param_3)
{

  int iVar1;

  uint32_t uVar2;

  int iVar3;

  int iVar4;

  uint uVar5;

  int aiStack_28 [2];

  

  iVar1 = isisGetNode(param_1,aiStack_28);

  uVar5 = 0;

  if (iVar1 == 0) {

    iVar1 = 0;

    do {

      iVar4 = 1;

      iVar3 = iVar1;

      do {

        if (param_2 == 1) {

          uVar2 = *(uint32_t *)(iVar3 + aiStack_28[0] + 0x6bc);

        }

        else {

          uVar2 = *(uint32_t *)(iVar1 + aiStack_28[0] + 0x6cc);

        }

        iVar4 = iVar4 + -1;

        iVar3 = iVar3 + 4;

        iVar1 = iVar1 + 4;

        rtShowRouteTable(uVar2,isisDumpLspRoute,param_3,0);

      } while (-1 < iVar4);

      uVar5 = uVar5 + 1;

      iVar1 = uVar5 * 8;

    } while (uVar5 < 2);

    return;

  }

                    /* WARNING: Subroutine does not return */

  printf(0xa1b582c);

}