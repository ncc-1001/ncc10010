#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declaration for missing variable
extern int _IsisLogger;
// Modified: Added extern declaration for missing variable
extern int _MOD_ISIS;
// Modified: Added extern declaration for missing variable
extern char isisTitleStr[];

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */



void isisSendAuthFailTrap

               (uint32_t *param_1,uint32_t param_2,int param_3,uint32_t param_4,int param_5,

               uint32_t param_6)



{
  uint32_t uVar1;
  int iVar2;
  uint32_t uVar3;
  uintptr_t auStack_1b0 [400];
  
  if (((param_1 != (uint32_t *)0x0) && ((param_1[0x1b] & 0x40) != 0)) &&
     (iVar2 = isisDebugCheck(param_1,0x40,param_3,0), iVar2 != 0)) {
    if (_IsisLogger == 0) {
      tracePrint(_MOD_ISIS,0xa1bbb1c,0,0,0xa1bbb50,*(uint32_t *)(param_3 + 8),param_2,param_6);
    }
    else {
      logEvent_debug_fmt(*param_1,0xa1bbad8,&isisTitleStr,0xa1bbb50,*(uint32_t *)(param_3 + 8),
                         param_2,param_6);
    }
  }
  auStack_1b0[0] = 0;
  if (0x40 < param_5) {
    param_5 = 0x40;
  }
  logger_OctetsHexDump(param_4,param_5,auStack_1b0,400);
  uVar1 = strlen(auStack_1b0);
  uVar3 = *param_1;
  logEvent_ISIS_vRtrIsisAuthFail
            (uVar3,0xa1bbb34,uVar3,param_2,param_4,param_5,auStack_1b0,uVar1,uVar3,
             *(uint32_t *)(param_3 + 8));
  return;
}