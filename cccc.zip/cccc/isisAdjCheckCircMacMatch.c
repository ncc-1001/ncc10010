#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t isisAdjCheckCircMacMatch(int param_1,int param_2)



{

  byte bVar1;

  int iVar2;

  int iVar3;

  uint uVar4;

  int *piVar5;

  

  piVar5 = (int *)(param_1 + 0x740);

  if (piVar5 != (int *)0x0) {

    iVar3 = *(int *)(param_1 + 0x740);

    if (iVar3 != 0) {

      bVar1 = *(byte *)(iVar3 + 1);

      while( true ) {

        uVar4 = (uint)bVar1;

        iVar3 = iVar3 + 2;

        while (uVar4 != 0) {

          iVar2 = isisSysIdCmp(param_2 + 0x1c8,iVar3);

          uVar4 = uVar4 - 6;

          iVar3 = iVar3 + 6;

          if (iVar2 == 0) {

            return 1;

          }

        }

        piVar5 = (int *)piVar5[2];

        if ((piVar5 == (int *)0x0) || (iVar3 = *piVar5, iVar3 == 0)) break;

        bVar1 = *(byte *)(iVar3 + 1);

      }

    }

  }

  return 0;

}



