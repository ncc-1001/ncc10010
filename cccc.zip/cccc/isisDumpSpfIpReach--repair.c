#include "nokia.h"
#include <stdint.h>

// Modified: Add typedef for byte type
typedef unsigned char byte;

// Modified: Add extern declaration for isisReachStr
extern char *isisReachStr;

uint32_t isisDumpSpfIpReach(int param_1)
{
  char cVar1;
  uint32_t uVar2;
  uintptr_t auStack_50 [64];
  
  if (param_1 != 0) {
    if (*(char *)(param_1 + 4) == '\0') {
      FmtIp6Addr(param_1 + 8,auStack_50,0x40);
      cVar1 = *(char *)(param_1 + 0x18);
    }
    else {
      FmtIpAddr(*(uint32_t *)(param_1 + 8),auStack_50,0x40);
      cVar1 = *(char *)(param_1 + 0x18);
    }
    uVar2 = 4;
    if (cVar1 == '\0') {
      uVar2 = 0x10;
    }
    uVar2 = netMaskToLen6(param_1 + 0x1c,uVar2);
                    /* WARNING: Subroutine does not return */
    printf(0xa1b6e64,param_1,auStack_50,uVar2,(&isisReachStr)[*(byte *)(param_1 + 0x2e)],
           *(uint32_t *)(param_1 + 0x34),*(uint32_t *)(param_1 + 0x38),
           *(uint32_t *)(param_1 + 0x30));
  }
  return 0;
}