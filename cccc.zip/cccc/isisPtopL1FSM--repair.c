#include "nokia.h"
#include <stdint.h>

// Modified: Add missing type definitions
typedef unsigned char byte;
typedef unsigned int uint;

// Modified: Add extern declarations for missing variables
extern int _IsisLogger;
extern int _MOD_ISIS;
extern char isisTitleStr[];

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */


uint32_t isisPtopL1FSM(uint32_t *param_1,int param_2,int param_3,char param_4)

{

  byte bVar1;

  byte bVar2;

  uint32_t uVar3;

  int iVar4;

  uint uVar5;

  
  if ((param_2 != 0) && (iVar4 = *(int *)(param_2 + 0x3d8), iVar4 != 0)) {
    if (param_4 == '\0') {
      if (param_1 == (uint32_t *)0x0) {
        uVar5 = (uint)*(byte *)(param_3 + 0x11);
      }
      else if ((param_1[0x1b] & 0x10) == 0) {
        uVar5 = (uint)*(byte *)(param_3 + 0x11);
      }
      else {
        iVar4 = isisDebugCheck(param_1,0x10,iVar4,param_2);
        if (iVar4 == 0) {
          uVar5 = (uint)*(byte *)(param_3 + 0x11);
        }
        else if (_IsisLogger == 0) {
          tracePrint(_MOD_ISIS,0xa1a6b14,0,0,0xa1a6b24,*(uint32_t *)(param_2 + 8));
          uVar5 = (uint)*(byte *)(param_3 + 0x11);
        }
        else {
          logEvent_debug_fmt(*param_1,0xa1a69b0,&isisTitleStr,0xa1a6b24,*(uint32_t *)(param_2 + 8)
                            );
          uVar5 = (uint)*(byte *)(param_3 + 0x11);
        }
      }
      isisUpdateNtfyPduFrag(param_1,param_3,param_2,uVar5 << 8 | (uint)*(byte *)(param_3 + 0x12));
      *(int *)(param_2 + 0x27e8) = *(int *)(param_2 + 0x27e8) + 1;
      return 1;
    }
    bVar1 = *(byte *)(param_3 + 8);
    if (bVar1 == 2) {
      if (*(int *)(iVar4 + 0x50) == 2) {
        uVar3 = 1;
      }
      else if (*(int *)(iVar4 + 0x50) == 1) {
        *(uint32_t *)(iVar4 + 0x44) = 3;
        *(uint *)(iVar4 + 0x4c) = (uint)*(byte *)(param_3 + 8);
        uVar3 = 3;
        *(int *)(param_2 + 0x27f4) = *(int *)(param_2 + 0x27f4) + 1;
      }
      else {
        uVar3 = 3;
      }
    }
    else {
      bVar2 = 3;
      if (bVar1 < 3) {
        bVar2 = 1;
      }
      if (bVar1 == bVar2) {
        uVar3 = 2;
        if (*(int *)(iVar4 + 0x44) != 2) {
          *(uint32_t *)(iVar4 + 0x50) = 2;
          uVar3 = 0;
        }
      }
      else {
        uVar3 = 3;
      }
    }
    return uVar3;
  }
  return 1;
}