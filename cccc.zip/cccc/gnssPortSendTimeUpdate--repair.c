#include <stdbool.h>  // Modified: Added for bool type
#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

extern int _tracepointsActive;  // Modified: Added extern declaration for missing global
extern int _MOD_MDADRV;  // Modified: Added extern declaration for missing global

void gnssPortSendTimeUpdate(int param_1,char param_2)
{
  bool bVar1;
  int iVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  uint32_t uStack_180;
  uint32_t uStack_17c;
  char cStack_178;
  int iStack_174;
  char cStack_170;
  
  iVar2 = *(int *)(*(int *)(*(int *)(param_1 + 4) + 0x36ca24) * 4 + 0xeb6f544) +
          *(int *)(param_1 + 0xcb8) * 0x1b0;
  uStack_180 = *(uint32_t *)(iVar2 + 0x3804);
  uStack_17c = *(uint32_t *)(iVar2 + 0x3808);
  iStack_174 = *(int *)(iVar2 + 0x3680);
  bVar1 = iStack_174 == 0xff;
  if (bVar1) {
    iStack_174 = 0;
  }
  cStack_170 = !bVar1;
  cStack_178 = param_2;
  if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_MDADRV,0xa9bddd8,1,0), iVar2 != 0)) {
    uVar3 = 0xa9bde34;
    if (param_2 == '\0') {
      uVar3 = 0xa9bde3c;
    }
    uVar4 = 0xa9bde3c;
    if (cStack_170 == '\0') {
      uVar4 = 0xa9bde34;
    }
    tracePrintVRtr(_MOD_MDADRV,0xa9bddd8,1,0,1,0xa9bddf0,
                   *(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24),*(int *)(param_1 + 0xcb8) + 1,
                   uVar3,uVar4);
    posPortEventFn(param_1,0,0,0x2b,&uStack_180,1);
    return;
  }
  posPortEventFn(param_1,0,0,0x2b,&uStack_180,1);
  return;
}