#include "/disk0/chencheng/CodeRepair/compileFilter/nokia.h"
#include <stdint.h>

uint32_t

debugIsisTunnelSpfLeak(uint32_t param_1,uint32_t param_2,uint param_3,uint param_4,char param_5)



{

  int iVar1;

  uint auStack_140 [51];

  uint uStack_74;

  uintptr_t uStack_70;

  uint32_t uStack_6c;

  uint32_t auStack_20 [2];

  

  auStack_20[0] = 0;

  if ((param_3 | param_4) == 0 && param_5 == '\0') {

    iVar1 = getExecFlag();

    if (iVar1 == 0) {

      cliErrorMesg(param_1,0x9fffe74);

      return 0xffffffff;

    }

    cliWarnMesg(param_1,0x9fffe74);

  }

  memset(auStack_140,0,0x120);

  if (param_3 != 0) {

    auStack_140[0] = auStack_140[0] | 0x1000000;

  }

  if (param_4 != 0) {

    iVar1 = ipStrToIpAddr(param_4,auStack_20);

    if (iVar1 != 0) {

      cliErrorMesg(param_1,0x9fffeb4,param_4);

      return 0xffffffff;

    }

    auStack_140[0] = auStack_140[0] | 0x2000000;

    uStack_74 = uStack_74 | 1;

    uStack_70 = 1;

    uStack_6c = auStack_20[0];

  }

  if (param_5 == '\0') {

    isisDebugOn(1,auStack_140);

  }

  else {

    auStack_140[0] = auStack_140[0] | 0x3000000;

    isisDebugOff(1,auStack_140);

  }

  return 0;

}



