#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added declaration for undeclared global variable ___chk_strnum
int ___chk_strnum;

uint32_t

configureRouterIsisInterfaceLevelIPv6UnicastMetric

          (uint32_t param_1,uint32_t param_2,uint32_t param_3,uint32_t param_4,int param_5)



{
  int iVar1;
  uint32_t uVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  uint32_t uVar5;
  
  uVar3 = 0xa07e3e4;
  uVar4 = 0;
  if (param_5 == 0) {
    param_5 = 0xa07d274;
    ___chk_strnum = 0;
  }
  uVar5 = 2;
  iVar1 = cfgRouterISISIfLevelElements();
  uVar2 = 0;
  if (iVar1 != 0) {
    cliErrorMesg(param_1,0xa07e404,param_3,param_4,uVar3,uVar4,param_5,uVar5);
    uVar2 = 0xffffffff;
  }
  return uVar2;
}
