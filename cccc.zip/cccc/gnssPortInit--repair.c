#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for undeclared variables
extern int _tracepointsActive;
extern int _MOD_MDADRV;
extern uint32_t _vxAbsTicks;
extern void (*gnssGripCallBack)(void);
extern int _traceEnabled;

void gnssPortInit(int param_1)
{
  int iVar1;
  uint32_t uVar2;
  int iVar3;
  
  if (_tracepointsActive == 0) {
    iVar1 = *(int *)(param_1 + 4);
  }
  else {
    iVar1 = traceTest(_MOD_MDADRV,0xa9bdf84,1,0);
    if (iVar1 == 0) {
      iVar1 = *(int *)(param_1 + 4);
    }
    else {
      tracePrintVRtr(_MOD_MDADRV,0xa9bdf84,1,0,1,0xa9bdf94,
                     *(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24),*(int *)(param_1 + 0xcb8) + 1
                    );
      iVar1 = *(int *)(param_1 + 4);
    }
  }
  *(uintptr_t *)(param_1 + 0xcb4) = 0xff;
  *(uint32_t *)(param_1 + 0xcb0) = 8;
  *(uint32_t *)(param_1 + 0xcac) = 8;
  *(uint32_t *)(param_1 + 0xca0) = 1;
  *(uint32_t *)(param_1 + 0xc9c) = 1;
  *(uint32_t *)(param_1 + 0xca8) = 1;
  *(uint32_t *)(param_1 + 0xca4) = 1;
  *(uintptr_t *)(param_1 + 0xcb5) = 0;
  iVar3 = *(int *)(*(int *)(iVar1 + 0x36ca24) * 4 + 0xeb6f544) + *(int *)(param_1 + 0xcb8) * 0x1b0;
  *(int *)(iVar3 + 0x3664) = *(int *)(param_1 + 0xcb8);
  *(uint32_t *)(iVar3 + 0x3678) = 8;
  *(uint32_t *)(iVar3 + 0x3680) = 0xff;
  *(uintptr_t *)(iVar3 + 0x3668) = 0;
  *(uintptr_t *)(iVar3 + 0x3669) = 0;
  *(uintptr_t *)(iVar3 + 0x366a) = 0;
  *(uintptr_t *)(iVar3 + 0x366b) = 0;
  *(uintptr_t *)(iVar3 + 0x366c) = 0;
  *(uintptr_t *)(iVar3 + 0x37e1) = 0;
  *(uint32_t *)(iVar3 + 0x3670) = 1;
  *(uint32_t *)(iVar3 + 0x3674) = 1;
  *(uintptr_t *)(iVar3 + 0x367c) = 0;
  *(uintptr_t *)(iVar3 + 0x367d) = 0;
  *(uintptr_t *)(iVar3 + 0x3685) = 0;
  *(uintptr_t *)(iVar3 + 0x3684) = 0;
  memset(iVar3 + 0x369c,0,0x10);
  memset(iVar3 + 0x3688,0,0x14);
  *(uintptr_t *)(iVar3 + 0x37e2) = 3;
  *(uint32_t *)(iVar3 + 0x37e4) = 0;
  *(uintptr_t *)(iVar3 + 0x37e8) = 0;
  *(uintptr_t *)(iVar3 + 0x37e9) = 0;
  memset(iVar3 + 0x37ec,0,0x10);
  memset(iVar3 + 0x37fc,0,8);
  memset(iVar3 + 0x3804,0,8);
  *(uint32_t *)(iVar3 + 0x380c) = _vxAbsTicks;
  *(uint32_t *)(iVar3 + 0x3810) = _vxAbsTicks;
  iVar1 = GRIPInit(*(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24),0,gnssGripCallBack,
                   *(uint32_t *)(param_1 + 0x7d8),0,*(uintptr_t *)(param_1 + 0x7df),0);
  if (iVar1 == 0) {
    *(uintptr_t *)(iVar3 + 0x366a) = 1;
  }
  else {
    iVar3 = macMdaRemoved(*(uint32_t *)(*(int *)(param_1 + 4) + 0x36ca24));
    if ((iVar3 == 0) &&
       ((_traceEnabled != 0 ||
        ((_tracepointsActive != 0 && (iVar3 = traceTest(_MOD_MDADRV,0xa9bdf84,4,0), iVar3 != 0))))))
    {
      uVar2 = 0xa9bd64c;
      switch(iVar1) {
      case 0:
        uVar2 = 0xa9bd678;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 1:
        uVar2 = 0xa9bd680;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 2:
        uVar2 = 0xa9bd688;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 3:
        uVar2 = 0xa9bd6a8;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 4:
        uVar2 = 0xa9bd6c8;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 5:
        uVar2 = 0xa9bd6e0;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 6:
        uVar2 = 0xa9bd704;
        iVar1 = *(int *)(param_1 + 4);
        break;
      case 7:
        uVar2 = 0xa9bd65c;
        iVar1 = *(int *)(param_1 + 4);
        break;
      default:
        iVar1 = *(int *)(param_1 + 4);
      }
      tracePrintVRtr(_MOD_MDADRV,0xa9bdf84,4,0,1,0xa9bdfac,*(uint32_t *)(iVar1 + 0x36ca24),
                     *(int *)(param_1 + 0xcb8) + 1,uVar2);
    }
  }
  return;
}