#include "nokia.h"
#include <stdint.h>

// Modified: Added extern declarations for undeclared identifiers
extern uint32_t isisPolUserInfo;
extern uint32_t isisPolChangePrefixV6;
extern uint32_t pol_rtm_to_policy_proto_map;

uint32_t

isisPolApplyExportPolicies

          (uint32_t param_1,int param_2,int param_3,uint32_t param_4,uint32_t param_5,

          uint32_t param_6,uint32_t param_7,uint32_t param_8,uint32_t param_9,byte param_10,

          uint32_t param_11,uint *param_12,uint *param_13,uint *param_14,uint32_t *param_15,

          uintptr_t *param_16)



{
  uint32_t uVar1;
  uint uVar2;
  uint32_t uVar3;
  uint32_t uVar4;
  uint32_t uVar5;
  uint32_t *puVar6;
  uint32_t *puVar7;
  int iVar8;
  uint32_t uStack_194;
  uint32_t uStack_190;
  uint32_t uStack_18c;
  uint32_t uStack_188;
  uint32_t auStack_180 [4];
  uintptr_t auStack_170 [20];
  uint uStack_15c;
  uint32_t uStack_140;
  uint uStack_124;
  uint32_t uStack_c0;
  uint32_t uStack_bc;
  uint *puStack_50;
  uint uStack_40;
  uint32_t uStack_3c;
  uint32_t uStack_38;
  uint32_t uStack_34;
  uint32_t uStack_30;
  
  iVar8 = *(int *)(param_2 + 8);
  uStack_194 = param_6;
  uStack_190 = param_7;
  uStack_18c = param_8;
  uStack_188 = param_9;
  uStack_40 = 0;
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_34 = 0;
  uStack_30 = 0;
  puVar6 = (uint32_t *)&isisPolUserInfo;
  puVar7 = auStack_180;
  do {
    uVar1 = *puVar6;
    uVar3 = puVar6[1];
    uVar4 = puVar6[2];
    uVar5 = puVar6[3];
    puVar6 = puVar6 + 4;
    *puVar7 = uVar1;
    puVar7[1] = uVar3;
    puVar7[2] = uVar4;
    puVar7[3] = uVar5;
    puVar7 = puVar7 + 4;
  } while (puVar6 != (uint32_t *)&isisPolChangePrefixV6);
  uVar1 = 0;
  if (iVar8 != 0) {
    uVar1 = 5;
  }
  mibSetAfiSafiBit(auStack_180 + 3,uVar1);
  auStack_180[1] = *(uint32_t *)(&pol_rtm_to_policy_proto_map + param_3 * 4);
  uStack_bc = 0;
  uStack_c0 = param_4;
  baseIp2IpAnyAddr(iVar8 != 0,&uStack_194,auStack_170);
  uStack_124 = *param_12;
  uStack_140 = param_11;
  *param_16 = 0;
  if (param_3 == 0xc) {
    if (*param_14 != 2) {
      uVar1 = *(uint32_t *)(param_2 + 0x18);
      goto LAB_042242ac;
    }
    *param_16 = 1;
  }
  uVar1 = *(uint32_t *)(param_2 + 0x18);
LAB_042242ac:
  uStack_15c = (uint)param_10;
  puStack_50 = &uStack_40;
  iVar8 = pol_find_best_match(uVar1,auStack_180);
  uVar1 = 0x17;
  if (iVar8 == 1) {
    if (param_3 == 0xc) {
      if (*param_14 == puStack_50[2]) {
        return 0x17;
      }
      if (puStack_50[2] == 0) {
        puStack_50[2] = 2 - (*param_14 != 1);
      }
      *param_15 = 0;
    }
    else {
      *param_15 = 1;
    }
    uVar2 = puStack_50[2];
    if (uVar2 == 0) {
      uVar2 = 3;
    }
    *param_14 = uVar2;
    uVar2 = *puStack_50;
    if (0xfe000000 < uVar2) {
      uVar2 = 0xfe000000;
    }
    *param_12 = uVar2;
    if (*(char *)(puStack_50 + 4) == '\x01') {
      *param_13 = puStack_50[3];
    }
    uVar1 = 0;
  }
  return uVar1;
}
