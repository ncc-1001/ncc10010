#include "nokia.h"
#include <stdint.h>
#include <stdbool.h>  // Modified: Added for bool type

/* WARNING: Control flow encountered bad instruction data */

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added extern declarations for global variables
extern int _TgtHw;
extern int _kernelIsSmp;
extern int _smpTaskIdCurrent;

uint32_t hwSarmFpgaResetGTX(int param_1)  // Modified: Changed uint to uint32_t
{
  bool bVar1;
  int in_zero;
  uint32_t uVar2;  // Modified: Changed uint to uint32_t
  int iVar3;
  
  iVar3 = 0;
  if (_TgtHw == 1) {
    if (_kernelIsSmp == 0) {
      iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
    }
    else {
      iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
    }
  }
  uVar2 = 1;
  if (*(char *)(iVar3 + 0x10c8f925) != -0x1e) {
    iVar3 = 0;
    if (_TgtHw == 1) {
      if (_kernelIsSmp == 0) {
        iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
      }
      else {
        iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
      }
    }
    uVar2 = 1;
    if (*(char *)(iVar3 + 0x10c8f925) != -0x1d) {
      iVar3 = 0;
      if (_TgtHw == 1) {
        if (_kernelIsSmp == 0) {
          iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
        }
        else {
          iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
        }
      }
      uVar2 = 1;
      if (*(char *)(iVar3 + 0x10c8f925) != -0x1c) {
        iVar3 = 0;
        if (_TgtHw == 1) {
          if (_kernelIsSmp == 0) {
            iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
          }
          else {
            iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
          }
        }
        uVar2 = 1;
        if (*(char *)(iVar3 + 0x10c8f925) != -0x1b) {
          iVar3 = 0;
          if (_TgtHw == 1) {
            if (_kernelIsSmp == 0) {
              iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
            }
            else {
              iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
            }
          }
          uVar2 = 1;
          if (*(char *)(iVar3 + 0x10c8f925) != -0x1a) {
            iVar3 = 0;
            if (_TgtHw == 1) {
              if (_kernelIsSmp == 0) {
                iVar3 = *(int *)(_smpTaskIdCurrent + 0x2b8) * 3;
              }
              else {
                iVar3 = *(int *)(*(int *)(in_zero + -0x8000) + 0x2b8) * 3;
              }
            }
            uVar2 = param_1 - 1;
            if ((*(char *)(iVar3 + 0x10c8f925) != -0x19) &&
               (bVar1 = uVar2 < 8, uVar2 = 0x80000000, bVar1)) {
                  /* WARNING: Bad instruction - Truncating control flow here */
              halt_baddata();
            }
          }
        }
      }
    }
  }
  return uVar2;
}