#include "nokia.h"
#include <stdint.h>

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

// Modified: Added declaration for undeclared global variable
int ___chk_strnum;

uint32_t configRouterIsisLevelNoAuthType(uint32_t param_1)

{

  int iVar1;

  uint32_t uVar2;

  

  ___chk_strnum = 1;

  iVar1 = cfgRouterISISLevelElements();

  uVar2 = 0;

  if (iVar1 != 0) {

    cliErrorMesg(param_1,0xa07d3a8);

    uVar2 = 0xffffffff;

  }

  return uVar2;

}
