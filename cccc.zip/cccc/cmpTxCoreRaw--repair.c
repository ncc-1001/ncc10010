#include "nokia.h"
#include <stdint.h>

// Added: extern declaration for _CmpTxDump
extern int _CmpTxDump;
// Added: extern declaration for _MOD_CMP
extern int _MOD_CMP;

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int cmpTxCoreRaw(uint32_t param_1,uint32_t param_2)
{
  int iVar1;
  int iVar2;
  uint32_t uVar3;
  uint32_t uStack_80;
  uint32_t uStack_7c;
  uint32_t uStack_78;
  uint32_t uStack_74;
  uint32_t uStack_70;
  uint32_t uStack_6c;
  uint32_t uStack_68;
  uint32_t uStack_64;
  uint32_t uStack_60;
  uint32_t uStack_5c;
  uint32_t uStack_58;
  uintptr_t auStack_50 [32];
  uintptr_t auStack_30 [32];
  
  uStack_74 = 0;
  uStack_70 = 0;
  uStack_6c = 0;
  uStack_68 = 0;
  uStack_64 = 0;
  uStack_60 = 0;
  uStack_5c = 0;
  uStack_58 = 0;
  uStack_80 = 0;
  uStack_78 = 0;
  uStack_7c = param_1;
  iVar1 = sfEncodeRawPktHdr(param_2,&uStack_80);
  if (iVar1 == 0) {
    if (_CmpTxDump != 0) {
      pbufDump(param_2,1);
    }
    iVar1 = sfSendUnicastToPort(param_1,1,param_2);
    if (((iVar1 != 0) && (_tracepointsActive != 0)) &&
       (iVar2 = traceTest(_MOD_CMP,0xa12c690,1,0x16), iVar2 != 0)) {
      uVar3 = FmtPortIdVerbose(param_1,auStack_30,0x1c);
      tracePrintVRtr(_MOD_CMP,0xa12c690,1,0x16,1,0xa12c6a0,uVar3,param_1);
    }
  }
  else {
    if ((_tracepointsActive != 0) && (iVar2 = traceTest(_MOD_CMP,0xa12c690,1,0x16), iVar2 != 0)) {
      uVar3 = FmtPortIdVerbose(param_1,auStack_50,0x1c);
      tracePrintVRtr(_MOD_CMP,0xa12c690,1,0x16,1,0xa12c6c0,uVar3,param_1);
    }
    pbufFree(param_2);
  }
  return iVar1;
}